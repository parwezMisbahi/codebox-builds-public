import { drawAsImage, ImageFormat } from "@shopify/react-native-skia";
import * as FileSystem from "expo-file-system/legacy"; // if your SDK predates this path, import from "expo-file-system"
import * as MediaLibrary from "expo-media-library";
import React from "react";
import type { Design } from "../editor/types";
import { exportSize } from "../editor/geometry";
import { Scene } from "../editor/Scene";
import type { Built } from "../editor/paragraph";

export type ExportResult = { ok: true; uri: string } | { ok: false; reason: "permission" | "failed" };

/** Render the design at full resolution (not screen resolution) and save it to the gallery. */
export async function exportPng(design: Design, built: Record<string, Built>, maxLongEdge = 4096): Promise<ExportResult> {
  try {
    const perm = await MediaLibrary.requestPermissionsAsync(true); // write-only access
    if (!perm.granted) return { ok: false, reason: "permission" };

    const { w, h } = exportSize(design.canvasW, design.canvasH, maxLongEdge);
    const k = w / design.canvasW;
    const image = await drawAsImage(React.createElement(Scene, { design, built, k }), { width: w, height: h });
    const b64 = image.encodeToBase64(ImageFormat.PNG, 100);
    const uri = `${FileSystem.cacheDirectory}design-${Date.now()}.png`;
    await FileSystem.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
    await MediaLibrary.saveToLibraryAsync(uri);
    return { ok: true, uri };
  } catch {
    return { ok: false, reason: "failed" };
  }
}
