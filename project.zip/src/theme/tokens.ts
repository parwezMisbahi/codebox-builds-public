// Generated from tokens.json. Use these, never raw values, in components.
export const tokens = {
  "color": {
    "light": {
      "bg": "#F7F7F8",
      "surface": "#FFFFFF",
      "surface-alt": "#EEEFF2",
      "border": "#D9DBE1",
      "border-input": "#7A7F8C",
      "text": "#16181D",
      "text-muted": "#555B68",
      "accent": "#4F46E5",
      "on-accent": "#FFFFFF",
      "danger": "#B42318",
      "success": "#067647",
      "warning": "#8A5A00",
      "canvas-bg": "#E4E5E9"
    },
    "dark": {
      "bg": "#0F1115",
      "surface": "#181B21",
      "surface-alt": "#232730",
      "border": "#343945",
      "border-input": "#8A90A0",
      "text": "#F2F3F5",
      "text-muted": "#A8AEBB",
      "accent": "#8B93FF",
      "on-accent": "#0F1115",
      "danger": "#FF8A80",
      "success": "#5FD39A",
      "warning": "#F2B84B",
      "canvas-bg": "#0A0B0E"
    }
  },
  "font": {
    "ui": "Inter, system-ui, sans-serif",
    "ui-urdu": "Noto Naskh Arabic, Noto Sans Arabic, sans-serif",
    "design-urdu-nastaliq": "Noto Nastaliq Urdu",
    "_note": "All open (OFL). Urdu UI text needs larger line height than Latin."
  },
  "type": {
    "caption": {
      "size": 12,
      "line": 16,
      "weight": 400
    },
    "body-sm": {
      "size": 14,
      "line": 20,
      "weight": 400
    },
    "body": {
      "size": 16,
      "line": 24,
      "weight": 400
    },
    "label": {
      "size": 14,
      "line": 20,
      "weight": 600
    },
    "title": {
      "size": 20,
      "line": 28,
      "weight": 600
    },
    "headline": {
      "size": 28,
      "line": 36,
      "weight": 700
    },
    "urdu-body": {
      "size": 16,
      "line": 32,
      "weight": 400
    },
    "urdu-title": {
      "size": 22,
      "line": 40,
      "weight": 600
    }
  },
  "space": {
    "0": 0,
    "1": 4,
    "2": 8,
    "3": 12,
    "4": 16,
    "5": 24,
    "6": 32,
    "7": 48
  },
  "radius": {
    "sm": 8,
    "md": 12,
    "lg": 20,
    "full": 999
  },
  "motion": {
    "fast": 120,
    "base": 200,
    "sheet": 280,
    "easing": "cubic-bezier(0.2, 0, 0, 1)"
  },
  "layout": {
    "touch-min": 48,
    "toolbar-h": 56,
    "header-h": 56,
    "bottom-sheet-max-h": "60%",
    "template-grid-cols": 2,
    "breakpoints": {
      "phone": 0,
      "tablet": 600,
      "web": 1024
    }
  }
} as const;
