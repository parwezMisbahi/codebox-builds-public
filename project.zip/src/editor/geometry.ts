import type { Layer } from "./types";

export type Size = { w: number; h: number };

/** Convert a point in design space into a layer's local space (origin at its centre, unrotated, unscaled). */
export function toLocal(layer: Pick<Layer, "x" | "y" | "rotation" | "scale">, px: number, py: number) {
  const dx = px - layer.x;
  const dy = py - layer.y;
  const c = Math.cos(-layer.rotation);
  const s = Math.sin(-layer.rotation);
  return { x: (dx * c - dy * s) / layer.scale, y: (dx * s + dy * c) / layer.scale };
}

export function hitTest(layer: Layer, size: Size, px: number, py: number, slop = 0) {
  const p = toLocal(layer, px, py);
  const pad = slop / layer.scale;
  return Math.abs(p.x) <= size.w / 2 + pad && Math.abs(p.y) <= size.h / 2 + pad;
}

/** Topmost layer under the point. `sizes` maps layer id to its measured box. Layers are ordered back to front. */
export function pickLayer(layers: Layer[], sizes: Record<string, Size>, px: number, py: number, slop = 12) {
  for (let i = layers.length - 1; i >= 0; i--) {
    const s = sizes[layers[i].id];
    if (s && hitTest(layers[i], s, px, py, slop)) return layers[i].id;
  }
  return null;
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/** Keep a layer's centre inside the canvas so it can never be lost off-screen. */
export function keepInside(x: number, y: number, canvasW: number, canvasH: number) {
  return { x: clamp(x, 0, canvasW), y: clamp(y, 0, canvasH) };
}

/** Largest scale that fits a design into a viewport, preserving aspect ratio. */
export function fitScale(design: Size, viewport: Size) {
  return Math.min(viewport.w / design.w, viewport.h / design.h);
}

/** Export size: cap the long edge so cheap phones do not run out of memory. */
export function exportSize(canvasW: number, canvasH: number, maxLongEdge: number) {
  const long = Math.max(canvasW, canvasH);
  const k = long > maxLongEdge ? maxLongEdge / long : 1;
  return { w: Math.round(canvasW * k), h: Math.round(canvasH * k) };
}
