/** Undo/redo over immutable snapshots. Keeps at most `limit` steps. */
export type History<T> = { past: T[]; present: T; future: T[] };

export const createHistory = <T,>(present: T): History<T> => ({ past: [], present, future: [] });

export function commit<T>(h: History<T>, next: T, limit = 50): History<T> {
  if (next === h.present) return h;
  const past = [...h.past, h.present];
  return { past: past.length > limit ? past.slice(past.length - limit) : past, present: next, future: [] };
}

/** Replace the present without adding an undo step (used while dragging). */
export const replace = <T,>(h: History<T>, next: T): History<T> => ({ ...h, present: next });

/** After a drag that used `replace`: record `base` (the state before the drag) as one undo step. */
export function commitFrom<T>(h: History<T>, base: T, limit = 50): History<T> {
  if (base === h.present) return h;
  const past = [...h.past, base];
  return { past: past.length > limit ? past.slice(past.length - limit) : past, present: h.present, future: [] };
}

export function undo<T>(h: History<T>): History<T> {
  if (!h.past.length) return h;
  const prev = h.past[h.past.length - 1];
  return { past: h.past.slice(0, -1), present: prev, future: [h.present, ...h.future] };
}

export function redo<T>(h: History<T>): History<T> {
  if (!h.future.length) return h;
  const [next, ...rest] = h.future;
  return { past: [...h.past, h.present], present: next, future: rest };
}

export const canUndo = <T,>(h: History<T>) => h.past.length > 0;
export const canRedo = <T,>(h: History<T>) => h.future.length > 0;
