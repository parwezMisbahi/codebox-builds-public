export type TextLayer = {
  id: string;
  type: "text";
  text: string;
  fontFamily: string;
  fontSize: number;      // in design pixels
  color: string;         // hex
  strokeColor: string;
  strokeWidth: number;   // 0 = none
  shadow: boolean;
  align: "start" | "center" | "end";
  width: number;         // layout width of the text box, design pixels
  x: number;             // centre of the box, design pixels
  y: number;
  rotation: number;      // radians
  scale: number;
};
export type Layer = TextLayer; // photo, shape, drawing arrive in M2+

export type Design = {
  id: string;
  title: string;
  canvasW: number;
  canvasH: number;
  background: string;
  layers: Layer[];
  updatedAt: number;
};
