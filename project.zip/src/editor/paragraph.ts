import { Skia, TextAlign, TextDirection, PaintStyle, type SkParagraph, type SkTypefaceFontProvider } from "@shopify/react-native-skia";
import type { TextLayer } from "./types";

export type Built = { fill: SkParagraph; stroke: SkParagraph | null; w: number; h: number };

const ALIGN = { start: TextAlign.Right, center: TextAlign.Center, end: TextAlign.Left } as const;
// Urdu is right-to-left, so "start" is the right edge.

/** Build the shaped paragraph(s) for a text layer. Skia's paragraph engine does the joining and bidi. */
export function buildParagraphs(layer: TextLayer, fonts: SkTypefaceFontProvider): Built {
  const make = () => {
    const b = Skia.ParagraphBuilder.Make(
      { textAlign: ALIGN[layer.align], textDirection: TextDirection.RTL },
      fonts
    );
    b.pushStyle({
      fontFamilies: [layer.fontFamily],
      fontSize: layer.fontSize,
      heightMultiplier: 1.6, // Nastaliq needs generous line height or lines collide
      color: Skia.Color(layer.color),
      ...(layer.shadow ? { shadows: [{ color: Skia.Color("#00000066"), offset: { x: 2, y: 3 }, blurRadius: 6 }] } : {}),
    });
    b.addText(layer.text);
    b.pop();
    const p = b.build();
    p.layout(layer.width);
    return p;
  };
  const fill = make();
  let stroke: SkParagraph | null = null;
  if (layer.strokeWidth > 0) {
    const sp = Skia.Paint();
    sp.setStyle(PaintStyle.Stroke);
    sp.setStrokeWidth(layer.strokeWidth);
    sp.setColor(Skia.Color(layer.strokeColor));
    const b = Skia.ParagraphBuilder.Make({ textAlign: ALIGN[layer.align], textDirection: TextDirection.RTL }, fonts);
    b.pushStyle({ fontFamilies: [layer.fontFamily], fontSize: layer.fontSize, heightMultiplier: 1.6, color: Skia.Color(layer.strokeColor) }, sp);
    b.addText(layer.text);
    b.pop();
    stroke = b.build();
    stroke.layout(layer.width);
  }
  return { fill, stroke, w: layer.width, h: Math.max(fill.getHeight(), layer.fontSize) };
}
