import React from "react";
import { Group, Paragraph, Rect, type SkTypefaceFontProvider } from "@shopify/react-native-skia";
import type { Design } from "./types";
import type { Built } from "./paragraph";

/**
 * The picture itself. Used both for the on-screen canvas and for the full-size export,
 * so what you see is what you save. `k` scales design pixels to output pixels.
 */
export function Scene({ design, built, k }: { design: Design; built: Record<string, Built>; k: number }) {
  return (
    <Group transform={[{ scale: k }]}>
      <Rect x={0} y={0} width={design.canvasW} height={design.canvasH} color={design.background} />
      {design.layers.map((l) => {
        const b = built[l.id];
        if (!b) return null;
        return (
          <Group
            key={l.id}
            transform={[
              { translateX: l.x }, { translateY: l.y },
              { rotate: l.rotation }, { scale: l.scale },
              { translateX: -b.w / 2 }, { translateY: -b.h / 2 },
            ]}
          >
            {b.stroke && <Paragraph paragraph={b.stroke} x={0} y={0} width={b.w} />}
            <Paragraph paragraph={b.fill} x={0} y={0} width={b.w} />
          </Group>
        );
      })}
    </Group>
  );
}
