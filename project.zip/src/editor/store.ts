import { create } from "zustand";
import type { Design, TextLayer } from "./types";
import { commit, commitFrom, createHistory, redo, replace, undo, type History } from "./history";

export const CANVAS_PRESETS = [
  { key: "status", label: "Story / status", w: 1080, h: 1920 },
  { key: "square", label: "Square post", w: 1080, h: 1080 },
  { key: "landscape", label: "Wide cover", w: 1920, h: 1080 },
] as const;

const newDesign = (w = 1080, h = 1080): Design => ({
  id: String(Date.now()), title: "", canvasW: w, canvasH: h, background: "#FFFFFF", layers: [], updatedAt: Date.now(),
});

let gestureBase: Design | null = null;

type State = {
  history: History<Design>;
  selectedId: string | null;
  design: () => Design;
  setSelected: (id: string | null) => void;
  addText: (text: string, fontFamily: string) => string;
  updateText: (id: string, patch: Partial<TextLayer>, opts?: { transient?: boolean }) => void;
  beginGesture: () => void;
  commitNow: () => void;
  removeLayer: (id: string) => void;
  setBackground: (c: string) => void;
  resetCanvas: (w: number, h: number) => void;
  undo: () => void;
  redo: () => void;
};

export const useEditor = create<State>((set, get) => ({
  history: createHistory(newDesign()),
  selectedId: null,
  design: () => get().history.present,
  setSelected: (id) => set({ selectedId: id }),

  addText: (text, fontFamily) => {
    const d = get().history.present;
    const layer: TextLayer = {
      id: `t${Date.now()}`, type: "text", text, fontFamily, fontSize: Math.round(d.canvasW / 9),
      color: "#16181D", strokeColor: "#FFFFFF", strokeWidth: 0, shadow: false, align: "center",
      width: Math.round(d.canvasW * 0.8), x: d.canvasW / 2, y: d.canvasH / 2, rotation: 0, scale: 1,
    };
    set({ history: commit(get().history, { ...d, layers: [...d.layers, layer] }), selectedId: layer.id });
    return layer.id;
  },

  // transient = while dragging: update live without an undo step. Call beginGesture() first and commitNow() on release.
  updateText: (id, patch, opts) => {
    const h = get().history;
    const d = h.present;
    const next = { ...d, layers: d.layers.map((l) => (l.id === id ? { ...l, ...patch } : l)) };
    set({ history: opts?.transient ? replace(h, next) : commit(h, next) });
  },

  beginGesture: () => { gestureBase = get().history.present; },

  commitNow: () => {
    if (!gestureBase) return;
    set({ history: commitFrom(get().history, gestureBase) });
    gestureBase = null;
  },

  removeLayer: (id: string) => void;
  setBackground: (c: string) => void;
  resetCanvas: (w: number, h: number) => void;
  undo: () => void;
  redo: () => void;
};

export const useEditor = create<State>((set, get) => ({
  history: createHistory(newDesign()),
  selectedId: null,
  design: () => get().history.present,
  setSelected: (id) => set({ selectedId: id }),

  addText: (text, fontFamily) => {
    const d = get().history.present;
    const layer: TextLayer = {
      id: `t${Date.now()}`, type: "text", text, fontFamily, fontSize: Math.round(d.canvasW / 9),
      color: "#16181D", strokeColor: "#FFFFFF", strokeWidth: 0, shadow: false, align: "center",
      width: Math.round(d.canvasW * 0.8), x: d.canvasW / 2, y: d.canvasH / 2, rotation: 0, scale: 1,
    };
    set({ history: commit(get().history, { ...d, layers: [...d.layers, layer] }), selectedId: layer.id });
    return layer.id;
  },

  // transient = while dragging: update live without an undo step. Call beginGesture() first and commitNow() on release.
  updateText: (id, patch, opts) => {
    const h = get().history;
    const d = h.present;
    const next = { ...d, layers: d.layers.map((l) => (l.id === id ? { ...l, ...patch } : l)) };
    set({ history: opts?.transient ? replace(h, next) : commit(h, next) });
  },

  commitNow: () => {
    // fold the transient drag into one undo step: re-commit the present on top of the pre-drag state
    const h = get().history;
    set({ history: { past: [...h.past], present: h.present, future: [] } });
  },

  removeLayer: (id) => {
    const d = get().history.present;
    set({ history: commit(get().history, { ...d, layers: d.layers.filter((l) => l.id !== id) }), selectedId: null });
  },

  setBackground: (c) => {
    const d = get().history.present;
    set({ history: commit(get().history, { ...d, background: c }) });
  },

  resetCanvas: (w, h) => set({ history: createHistory(newDesign(w, h)), selectedId: null }),
  undo: () => set({ history: undo(get().history) }),
  redo: () => set({ history: redo(get().history) }),
}));
