// Lightweight 2D canvas avatar used instead of the 3D character on mobile.
// No model, textures or WebGL needed. Reacts to the live audio analysers.

export interface OrbInput {
  activity?: 'idle' | 'listening' | 'talking' | 'thinking';
  emotion?: string;
  outputAnalyser?: AnalyserNode | null;
  inputAnalyser?: AnalyserNode | null;
}

const PALETTE: Record<string, [number, number, number]> = {
  idle: [140, 160, 255],
  listening: [90, 220, 190],
  talking: [255, 150, 200],
  thinking: [255, 200, 110],
};
const EMOTION_TINT: Record<string, [number, number, number]> = {
  happy: [255, 190, 120],
  confused: [200, 150, 255],
};

export class Orb {
  private ctx: CanvasRenderingContext2D | null;
  private w = 0; private h = 0; private dpr = 1;
  private raf = 0; private running = false; private lastDraw = 0;
  private input: OrbInput = { activity: 'idle' };
  private level = 0; private color: [number, number, number] = [...PALETTE.idle];
  private buf = new Uint8Array(256);
  private pointer = { x: 0, y: 0 };
  private happyUntil = 0;
  readonly diagnostics = { renderer: 'orb-2d' };

  constructor(private canvas: HTMLCanvasElement) { this.ctx = canvas.getContext('2d'); }

  async load() { /* nothing to load */ }
  resize(width: number, height: number) {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.w = Math.max(1, width); this.h = Math.max(1, height);
    this.canvas.width = Math.round(this.w * this.dpr); this.canvas.height = Math.round(this.h * this.dpr);
  }
  setFrameInput(partial: OrbInput) {
    this.input = { ...this.input, ...partial };
    if (partial.emotion === 'happy') this.happyUntil = performance.now() + 3000;
  }
  setPointer(x: number, y: number) { this.pointer = { x, y }; }
  start() { if (this.running) return; this.running = true; const tick = (t: number) => { if (!this.running) return; this.raf = requestAnimationFrame(tick); if (t - this.lastDraw >= 33) { this.lastDraw = t; this.draw(t); } }; this.raf = requestAnimationFrame(tick); }
  stop() { this.running = false; cancelAnimationFrame(this.raf); }
  dispose() { this.stop(); this.ctx = null; }

  private measure(): number {
    const a = this.input.activity === 'talking' ? this.input.outputAnalyser : this.input.activity === 'listening' ? this.input.inputAnalyser : null;
    if (!a) return 0;
    try {
      if (this.buf.length !== a.fftSize) this.buf = new Uint8Array(a.fftSize);
      a.getByteTimeDomainData(this.buf);
      let sum = 0; for (let i = 0; i < this.buf.length; i++) { const v = (this.buf[i] - 128) / 128; sum += v * v; }
      return Math.min(1, Math.sqrt(sum / this.buf.length) * 4);
    } catch { return 0; }
  }

  private draw(t: number) {
    const c = this.ctx; if (!c) return;
    const activity = this.input.activity || 'idle';
    const happy = performance.now() < this.happyUntil;
    const target = (happy ? EMOTION_TINT.happy : this.input.emotion && EMOTION_TINT[this.input.emotion] ? EMOTION_TINT[this.input.emotion] : PALETTE[activity] || PALETTE.idle);
    for (let i = 0; i < 3; i++) this.color[i] += (target[i] - this.color[i]) * 0.08;
    const raw = this.measure(); this.level += (raw - this.level) * 0.35;
    const [r, g, b] = this.color.map(Math.round);
    const s = t / 1000;
    const base = Math.min(this.w, this.h) * 0.26;
    const breathe = Math.sin(s * (activity === 'thinking' ? 3.2 : 1.4)) * 0.04;
    const radius = base * (1 + breathe + this.level * 0.35);
    const cx = this.w / 2 + this.pointer.x * this.w * 0.03;
    const cy = this.h / 2 - this.pointer.y * this.h * 0.03;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.clearRect(0, 0, this.w, this.h);
    // soft outer glow
    const glow = c.createRadialGradient(cx, cy, radius * 0.6, cx, cy, radius * 2.6);
    glow.addColorStop(0, `rgba(${r},${g},${b},${0.30 + this.level * 0.3})`); glow.addColorStop(1, `rgba(${r},${g},${b},0)`);
    c.fillStyle = glow; c.fillRect(0, 0, this.w, this.h);
    // rings
    for (let i = 0; i < 3; i++) {
      const phase = (s * 0.5 + i / 3) % 1;
      c.beginPath(); c.arc(cx, cy, radius * (1.1 + phase * 0.9), 0, Math.PI * 2);
      c.strokeStyle = `rgba(${r},${g},${b},${(1 - phase) * (activity === 'idle' ? 0.12 : 0.32)})`; c.lineWidth = 2; c.stroke();
    }
    // wobbly body
    c.beginPath();
    const steps = 72;
    for (let i = 0; i <= steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      const wob = 1 + Math.sin(a * 3 + s * 2) * 0.025 + Math.sin(a * 5 - s * 3) * (0.015 + this.level * 0.07);
      const x = cx + Math.cos(a) * radius * wob, y = cy + Math.sin(a) * radius * wob;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
    const body = c.createRadialGradient(cx - radius * 0.35, cy - radius * 0.4, radius * 0.1, cx, cy, radius * 1.1);
    body.addColorStop(0, `rgba(255,255,255,0.95)`); body.addColorStop(0.35, `rgba(${r},${g},${b},0.95)`); body.addColorStop(1, `rgba(${r >> 1},${g >> 1},${b >> 1},0.95)`);
    c.fillStyle = body; c.fill();
    // eyes follow pointer and blink
    const blink = (Math.sin(s * 0.9) > 0.985 || (s % 4.3) < 0.12) ? 0.12 : 1;
    const ex = radius * 0.32, ey = cy - radius * 0.08, er = radius * 0.09;
    c.fillStyle = 'rgba(20,24,40,0.88)';
    for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(cx + sx * ex + this.pointer.x * er * 0.6, ey - this.pointer.y * er * 0.4, er, er * blink * 1.25, 0, 0, Math.PI * 2); c.fill(); }
    // mouth: opens with audio, smiles when happy
    c.strokeStyle = 'rgba(20,24,40,0.85)'; c.lineWidth = Math.max(2, radius * 0.04); c.lineCap = 'round';
    const my = cy + radius * 0.3;
    c.beginPath();
    if (this.level > 0.06) { c.ellipse(cx, my, radius * 0.16, radius * (0.03 + this.level * 0.2), 0, 0, Math.PI * 2); c.fillStyle = 'rgba(20,24,40,0.85)'; c.fill(); }
    else { const smile = happy ? 0.16 : 0.07; c.moveTo(cx - radius * 0.16, my); c.quadraticCurveTo(cx, my + radius * smile * 2, cx + radius * 0.16, my); c.stroke(); }
  }
}
