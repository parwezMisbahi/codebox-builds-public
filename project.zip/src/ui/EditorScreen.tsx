import React, { useCallback, useMemo, useRef, useState } from "react";
import { Alert, Modal, SafeAreaView, ScrollView, Text, TextInput, View, type LayoutChangeEvent } from "react-native";
import { Canvas, useFonts } from "@shopify/react-native-skia";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { useEditor, CANVAS_PRESETS } from "../editor/store";
import { buildParagraphs, type Built } from "../editor/paragraph";
import { Scene } from "../editor/Scene";
import { fitScale, pickLayer, clamp, keepInside } from "../editor/geometry";
import { canRedo, canUndo } from "../editor/history";
import { exportPng } from "../export/exportPng";
import { Button, IconTextButton, Swatch, colors } from "./primitives";
import { tokens } from "../theme/tokens";
import { S } from "../strings";

const FONT = "NotoNastaliqUrdu";
const SWATCHES = ["#16181D", "#FFFFFF", "#B42318", "#067647", "#4F46E5", "#C98A00", "#0B7285", "#7A2E8E"];

export default function EditorScreen() {
  const st = useEditor();
  const design = st.history.present;
  const selected = design.layers.find((l) => l.id === st.selectedId) ?? null;

  // Metro fails the build if this file is missing, so the README says to add it before running.
  const fonts = useFonts({ [FONT]: [require("../../assets/fonts/NotoNastaliqUrdu-Regular.ttf")] });

  const [view, setView] = useState({ w: 0, h: 0 });
  const [editing, setEditing] = useState<null | { id: string | null; text: string }>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const base = useRef<{ x: number; y: number; scale: number; rotation: number } | null>(null);

  const k = view.w ? fitScale({ w: design.canvasW, h: design.canvasH }, view) : 1;

  // Shape every text layer. Rebuilt only when a layer or the font changes.
  const built = useMemo(() => {
    const out: Record<string, Built> = {};
    if (!fonts) return out;
    for (const l of design.layers) out[l.id] = buildParagraphs(l, fonts);
    return out;
  }, [design.layers, fonts]);
  const sizes = useMemo(() => Object.fromEntries(Object.entries(built).map(([id, b]) => [id, { w: b.w, h: b.h }])), [built]);

  const onLayout = (e: LayoutChangeEvent) => setView({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height });
  const say = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2500); };

  // ---- gestures (all on the JS thread in this slice; move to worklets in M2 if it feels laggy)
  const toDesign = (x: number, y: number) => ({ x: x / k, y: y / k });
  const tap = Gesture.Tap().runOnJS(true).onEnd((e) => {
    const p = toDesign(e.x, e.y);
    st.setSelected(pickLayer(design.layers, sizes, p.x, p.y));
  });
  const begin = () => {
    if (!selected) return;
    st.beginGesture();
    base.current = { x: selected.x, y: selected.y, scale: selected.scale, rotation: selected.rotation };
  };
  const end = () => { base.current = null; st.commitNow(); };
  const pan = Gesture.Pan().runOnJS(true).minDistance(2).onBegin(begin).onUpdate((e) => {
    if (!selected || !base.current) return;
    const p = keepInside(base.current.x + e.translationX / k, base.current.y + e.translationY / k, design.canvasW, design.canvasH);
    st.updateText(selected.id, p, { transient: true });
  }).onFinalize(end);
  const pinch = Gesture.Pinch().runOnJS(true).onBegin(begin).onUpdate((e) => {
    if (!selected || !base.current) return;
    st.updateText(selected.id, { scale: clamp(base.current.scale * e.scale, 0.2, 6) }, { transient: true });
  }).onFinalize(end);
  const rotate = Gesture.Rotation().runOnJS(true).onBegin(begin).onUpdate((e) => {
    if (!selected || !base.current) return;
    st.updateText(selected.id, { rotation: base.current.rotation + e.rotation }, { transient: true });
  }).onFinalize(end);
  const gesture = Gesture.Race(tap, Gesture.Simultaneous(pan, pinch, rotate));

  const openAdd = () => setEditing({ id: null, text: "" });
  const openEdit = () => selected && setEditing({ id: selected.id, text: selected.text });
  const saveText = () => {
    if (!editing) return;
    const text = editing.text.trim();
    if (!text) { setEditing(null); return; }
    if (editing.id) st.updateText(editing.id, { text }); else st.addText(text, FONT);
    setEditing(null);
  };

  const doExport = useCallback(async () => {
    setBusy(true);
    const r = await exportPng(st.history.present, built);
    setBusy(false);
    say(r.ok ? S.saved : r.reason === "permission" ? S.noPermission : S.saveFailed);
  }, [built, st.history.present]);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      {/* top bar */}
      <View style={{ height: tokens.layout["header-h"], flexDirection: "row", alignItems: "center", paddingHorizontal: tokens.space[2] }}>
        <IconTextButton label={S.undo} onPress={st.undo} disabled={!canUndo(st.history)} />
        <IconTextButton label={S.redo} onPress={st.redo} disabled={!canRedo(st.history)} />
        <View style={{ flex: 1 }} />
        <Button label={busy ? S.saving : S.export} onPress={doExport} disabled={busy || !design.layers.length || !fonts} />
      </View>

      {/* canvas */}
      <View style={{ flex: 1, backgroundColor: colors["canvas-bg"], alignItems: "center", justifyContent: "center" }} onLayout={onLayout}>
        {view.w > 0 && (
          <GestureDetector gesture={gesture}>
            <View accessible accessibilityLabel="Design canvas" style={{ width: design.canvasW * k, height: design.canvasH * k }}>
              <Canvas style={{ width: design.canvasW * k, height: design.canvasH * k }}>
                <Scene design={design} built={built} k={k} />
              </Canvas>
              {selected && sizes[selected.id] && (
                <View pointerEvents="none" style={{
                  position: "absolute", borderWidth: 2, borderColor: colors.accent, borderStyle: "dashed",
                  width: sizes[selected.id].w * selected.scale * k, height: sizes[selected.id].h * selected.scale * k,
                  left: selected.x * k - (sizes[selected.id].w * selected.scale * k) / 2,
                  top: selected.y * k - (sizes[selected.id].h * selected.scale * k) / 2,
                  transform: [{ rotate: `${selected.rotation}rad` }],
                }} />
              )}
            </View>
          </GestureDetector>
        )}
        {!design.layers.length && <Text style={{ position: "absolute", color: colors["text-muted"], padding: tokens.space[4] }}>{S.emptyHint}</Text>}
        {toast && <Text accessibilityLiveRegion="polite" style={{ position: "absolute", bottom: 16, backgroundColor: colors.text, color: colors.surface, padding: 12, borderRadius: 12 }}>{toast}</Text>}
      </View>

      {/* style panel for the selected text */}
      <View style={{ backgroundColor: colors.surface, borderTopLeftRadius: tokens.radius.lg, borderTopRightRadius: tokens.radius.lg }}>
        {selected && (
          <View style={{ padding: tokens.space[2] }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {SWATCHES.map((s) => <Swatch key={s} color={s} selected={selected.color === s} onPress={() => st.updateText(selected.id, { color: s })} />)}
            </ScrollView>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <IconTextButton label={`${S.size} −`} onPress={() => st.updateText(selected.id, { fontSize: Math.max(12, selected.fontSize - 6) })} />
              <Text style={{ alignSelf: "center", color: colors.text }}>{selected.fontSize}</Text>
              <IconTextButton label={`${S.size} +`} onPress={() => st.updateText(selected.id, { fontSize: Math.min(400, selected.fontSize + 6) })} />
              <IconTextButton label={S.outline} selected={selected.strokeWidth > 0} onPress={() => st.updateText(selected.id, { strokeWidth: selected.strokeWidth > 0 ? 0 : Math.max(4, selected.fontSize / 10) })} />
              <IconTextButton label={S.shadow} selected={selected.shadow} onPress={() => st.updateText(selected.id, { shadow: !selected.shadow })} />
              <IconTextButton label={S.editText} onPress={openEdit} />
              <IconTextButton label={S.delete} onPress={() => st.removeLayer(selected.id)} />
            </ScrollView>
          </View>
        )}
        <View style={{ height: tokens.layout["toolbar-h"], flexDirection: "row", alignItems: "center", paddingHorizontal: tokens.space[2] }}>
          <Button label={S.addText} onPress={openAdd} disabled={!fonts} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginStart: tokens.space[2] }}>
            {CANVAS_PRESETS.map((p) => (
              <IconTextButton key={p.key} label={p.label} selected={design.canvasW === p.w && design.canvasH === p.h}
                onPress={() => {
                  if (!design.layers.length) st.resetCanvas(p.w, p.h);
                  else Alert.alert("Change canvas size?", "Starting a new canvas clears this design.", [
                    { text: S.cancel, style: "cancel" }, { text: "Start new", style: "destructive", onPress: () => st.resetCanvas(p.w, p.h) }]);
                }} />
            ))}
          </ScrollView>
        </View>
      </View>

      {/* text entry */}
      <Modal visible={!!editing} animationType="slide" transparent onRequestClose={() => setEditing(null)}>
        <View style={{ flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.4)" }}>
          <View style={{ backgroundColor: colors.surface, padding: tokens.space[4], borderTopLeftRadius: tokens.radius.lg, borderTopRightRadius: tokens.radius.lg }}>
            <TextInput
              autoFocus multiline value={editing?.text ?? ""} onChangeText={(t) => setEditing((e) => e && { ...e, text: t })}
              placeholder={S.typeHere} accessibilityLabel={S.addText} writingDirection="rtl" textAlign="right"
              style={{ minHeight: 120, fontSize: tokens.type["urdu-body"].size + 4, lineHeight: tokens.type["urdu-body"].line + 4, color: colors.text,
                borderWidth: 1, borderColor: colors["border-input"], borderRadius: tokens.radius.md, padding: tokens.space[3] }}
            />
            <View style={{ flexDirection: "row", justifyContent: "flex-end", gap: tokens.space[2], marginTop: tokens.space[3] }}>
              <Button label={S.cancel} variant="secondary" onPress={() => setEditing(null)} />
              <Button label={S.done} onPress={saveText} />
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
