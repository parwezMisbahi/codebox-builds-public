import React from "react";
import { Pressable, Text, View, type ViewStyle } from "react-native";
import { tokens } from "../theme/tokens";

const c = tokens.color.light; // dark mode: switch by useColorScheme in M2 (kept simple in the slice)

export function Button({ label, onPress, variant = "primary", disabled, style }: {
  label: string; onPress: () => void; variant?: "primary" | "secondary" | "danger"; disabled?: boolean; style?: ViewStyle;
}) {
  const bg = variant === "primary" ? c.accent : variant === "danger" ? c.danger : c["surface-alt"];
  const fg = variant === "secondary" ? c.text : c["on-accent"];
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ disabled: !!disabled }}
      disabled={disabled} onPress={onPress}
      style={({ pressed }) => [{
        minHeight: tokens.layout["touch-min"], paddingHorizontal: tokens.space[4], borderRadius: tokens.radius.md,
        backgroundColor: bg, alignItems: "center", justifyContent: "center", opacity: disabled ? 0.4 : pressed ? 0.85 : 1,
      }, style]}
    >
      <Text style={{ color: fg, fontSize: tokens.type.label.size, fontWeight: "600" }}>{label}</Text>
    </Pressable>
  );
}

export function IconTextButton({ label, onPress, selected, disabled }: {
  label: string; onPress: () => void; selected?: boolean; disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress}
      style={{
        minWidth: tokens.layout["touch-min"], minHeight: tokens.layout["touch-min"], paddingHorizontal: tokens.space[3],
        alignItems: "center", justifyContent: "center", borderRadius: tokens.radius.md,
        backgroundColor: selected ? c["surface-alt"] : "transparent", opacity: disabled ? 0.35 : 1,
      }}
    >
      <Text style={{ color: selected ? c.accent : c.text, fontSize: tokens.type["body-sm"].size, fontWeight: "600" }}>{label}</Text>
    </Pressable>
  );
}

export function Swatch({ color, selected, onPress }: { color: string; selected: boolean; onPress: () => void }) {
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={`Colour ${color}`} accessibilityState={{ selected }} onPress={onPress}
      style={{ width: tokens.layout["touch-min"], height: tokens.layout["touch-min"], alignItems: "center", justifyContent: "center" }}
    >
      <View style={{
        width: 32, height: 32, borderRadius: 16, backgroundColor: color,
        borderWidth: selected ? 3 : 1, borderColor: selected ? c.accent : c["border-input"],
      }} />
    </Pressable>
  );
}

export const colors = c;
