import type { Design } from "../editor/types";

/**
 * The data layer. Screens only call these functions, so replacing the in-memory
 * version with SQLite (M2) and cloud sync (M3) changes no screen code.
 */
export interface DesignsRepo {
  list(): Promise<Design[]>;
  get(id: string): Promise<Design | null>;
  save(d: Design): Promise<void>;
  remove(id: string): Promise<void>;
}

export function createMemoryRepo(): DesignsRepo {
  const db = new Map<string, Design>();
  return {
    async list() { return [...db.values()].sort((a, b) => b.updatedAt - a.updatedAt); },
    async get(id) { return db.get(id) ?? null; },
    async save(d) { db.set(d.id, { ...d, updatedAt: Date.now() }); },
    async remove(id) { db.delete(id); },
  };
}

export const designsRepo: DesignsRepo = createMemoryRepo();
