# Urdu Designer (Android, WebView + HTML canvas)

Native Gradle project: `settings.gradle` and `build.gradle` sit at the repo root, so
`gradle assembleDebug` works in any GitHub Actions builder. The editor itself is
`app/src/main/assets/index.html` (no libraries, works offline).

## Build
Push this folder as the root of a repo and run your usual APK build, or use the
included `.github/workflows/build.yml` (Java 17, Gradle 8.14.3). The APK is at
`app/build/outputs/apk/debug/app-debug.apk`.

## Fonts
`fetchFonts` (in `app/build.gradle`) downloads three open fonts (SIL OFL) from GitHub
before each build: Noto Nastaliq Urdu, Noto Naskh Arabic, Amiri. If a download fails the
build still succeeds, the app shows a "font missing" notice and uses a fallback font.
To skip the download, put these files in `app/src/main/assets/fonts/`:
`NotoNastaliqUrdu.ttf`, `NotoNaskhArabic.ttf`, `Amiri-Regular.ttf`.

## What works (M1 + part of M2)
Add Urdu text (RTL, correct joining by the browser engine), 4 fonts, colour, size, outline,
shadow, alignment, rotate, drag / pinch / two-finger rotate, copy, delete, layer order,
undo/redo, photo as background, background colour, canvas presets and custom size,
full-resolution PNG saved to Pictures/UrduDesigner, share, autosave of the last design.

## Not built yet
Templates, my-designs list, accounts and sync, premium, ads, AI tools, voice typing,
poetry library, PDF/JPG export, gradient/curve/3D text.
