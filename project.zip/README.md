# VideoDL

Android video downloader built on yt-dlp (via youtubedl-android) + FFmpeg.

## Build
- Android Studio: open this folder, let it sync, Run (or Build > Build APK).
- Cloud: push to GitHub, run the "Build APK" workflow, download the APK artifact.

## Features
- Paste link / share link from any app
- Video (MP4, chosen quality) or Audio (MP3)
- Progress, cancel, saves to Downloads/VideoDL
- "Update yt-dlp engine" button (sites change often; update when downloads fail)

## Notes
- If the library version in app/build.gradle.kts is not found, use the latest
  io.github.junkfood02.youtubedl-android version from Maven Central.
- Only download content you have the right to download.
