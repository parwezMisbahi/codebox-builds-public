# Urdu Designer (clone project) - M1 slice

Install (on your computer, with Node 20+ and Android Studio or a phone with a dev build):

    npm install
    npx expo install expo react react-native @shopify/react-native-skia \
      react-native-gesture-handler react-native-reanimated react-native-safe-area-context \
      expo-file-system expo-media-library expo-sharing
    npm install zustand
    npm install -D typescript @types/react tsx
    # put an open Nastaliq font here (SIL OFL), e.g. Noto Nastaliq Urdu:
    #   assets/fonts/NotoNastaliqUrdu-Regular.ttf
    npx expo run:android      # Skia needs a dev build, Expo Go will not work

`npx expo install` picks versions that match each other. Run `npm test` for the logic tests and `npm run typecheck`.

M1 done means: type an Urdu sentence, it joins correctly in Nastaliq, move/scale/rotate it, undo, export a sharp PNG.
