# MYRAA Mobile (reconstructed source)

Android Studio / Gradle project rebuilt from `MYRAA-Mobile-1.0.0-rc.5-private.apk`.

## Build

1. Install Android Studio (Koala or newer) with Android SDK 35.
2. Open this folder (`File > Open`). Android Studio creates the Gradle wrapper and syncs.
3. Run `app` on a device/emulator, or build an APK:
   `Build > Build APK(s)` (release is signed with the debug key so it installs directly).

Command line, with Gradle 8.7+ and JDK 17 installed:

    gradle wrapper --gradle-version 8.7
    ./gradlew assembleRelease

Output: `app/build/outputs/apk/release/app-release.apk`. Use your own keystore before sharing the APK.

## What is exact and what is reconstructed

| Part | Status |
|------|--------|
| `AndroidManifest.xml`, permissions, queries, service/activity flags | Decoded from the APK, matches |
| `assets/` (web UI bundle, CSS, `personality.txt`) | Copies from the APK, then edited (see below) |
| `res/drawable/myraa_icon.png` | Identical |
| `GeminiAccess`, `LiveVoiceService`, `MainActivity`, `MobileActions` (Java) | **Re-written** from the dex call graph, string constants and the JS bridge contract. Same behaviour and messages, not the original text. Timeouts, history size (20 sent / 40 kept) and token expiry times are best guesses. |
| Web UI (`assets/mobile.html`, `assets/assets/mobile-*.js`) | Minified Vite build output. The original TypeScript/Vite source is **not recoverable** from an APK. Edit the bundle only if you must; otherwise keep it as is. |
| Theme | `Theme.DeviceDefault.NoActionBar` is the closest match to the original theme id |

The Java was syntax-checked but not compiled against the Android SDK in the environment it was written in, so expect to fix small compile errors on the first build.

## Native bridge contract (`window.MyraaNative`)

JS calls: `getState()`, `chat(text, id)`, `cancel()`, `configure(json)`, `checkConnection(json)`,
`clearHistory()`, `clearKey()`, `speak(text)`, `stopSpeech()`, `startLive(id)`, `endLive()`,
`mobileAction(id, name, argsJson)`, `cancelMobileAction(id)`, `openSettings()`, `openFloatingSettings()`.

Native replies by calling `window.MyraaEvents(obj)` with `type` one of:
`reply`, `error`, `settings`, `speech`, `live-token`, `live-error`, `mobile-action-result`.

## Using it

Open Settings inside the app and paste your own Gemini API key. Never put a key in the source.

## Phone control (agent mode)

MYRAA now understands a command in **text chat and Live voice** and runs it on the phone, one step at a time,
until the task is done (read the screen, act, read again). Text chat runs up to 25 steps per message.

The single Gemini tool is `mobile_action`; its schema is in `assets/mobile_action_tool.json` (used by text chat) and
mirrored in the JS bundle (`a3`, used by Live voice). Keep the two in sync if you change it.

| Group | Actions |
|-------|---------|
| Apps and info | `open_app`, `open_url`, `search_youtube`, `play_youtube`, `search_web`, `navigate`, `open_camera`, `open_settings`, `app_info`, `share_text`, `clipboard`, `device_info` |
| Phone controls | `set_alarm`, `set_timer`, `flashlight`, `volume`, `brightness`, `media` |
| Messages and calls (always confirmed) | `whatsapp_message`, `send_sms`, `call`, `answer_call`, `end_call` |
| Notifications | `read_notifications`, `clear_notifications` |
| Touch gestures | `tap_text`, `tap_xy`, `long_press`, `double_tap`, `swipe` (also from screen edge), `drag`, `pinch`, `scroll` |
| Text | `type_text` (replace or append), `text_edit` (select all, copy, cut, paste, clear) |
| System buttons | `press_key`: back, home, recents, notifications, quick_settings, screenshot, lock_screen, power_menu, split_screen, enter |
| Quick Settings | `quick_toggle` (taps a tile such as Wi-Fi or Bluetooth) |
| Waiting | `wait`, `wait_for_text` |

### Live voice call behaviour

The call stays open between commands. MYRAA says what it is about to do, does it, then says the work is done and asks
what next. Saying stop, bas, band karo, close or goodbye makes her say goodbye and end the call (`end_session` tool,
handled in the JS bundle); anything else is treated as the next command.

### Permissions list in Settings

Settings has a **Permissions** section that lists every permission MYRAA needs with its current state. Tap a row to
allow it: normal permissions show Android's dialog (or open app settings if you chose "don't ask again"); special ones
(Accessibility, Notification access, Display over other apps, Modify system settings, Battery, Autostart) open the exact
settings page. The list refreshes when you come back to MYRAA. Autostart and restricted-settings rows cannot be detected
by Android, so they show "Open".

### One-time setup on the phone

1. Accessibility settings: turn on **MYRAA Control** (needed for every screen action and all gestures).
2. Notification access: turn on **MYRAA Notifications** (only for read/clear notifications).
3. Allow **Modify system settings** for MYRAA (only for brightness).
4. Enable **Floating voice controls** in MYRAA Settings so it can open apps while it is behind another app.
5. On HyperOS (Poco): set battery to No restrictions and turn Autostart on, or Android will stop the service.

### Safety rules built in

- Calls, SMS, WhatsApp messages and clearing notifications always show a Yes/Cancel dialog.
- Tapping a label like Pay, Send money, Transfer, Delete, Uninstall, Erase, Reset, Buy or Subscribe asks first.
- MYRAA refuses to read or operate banking and payment apps (package-name list in `MobileActions.SENSITIVE`) and
  never types into password fields.
- The Stop button cancels the running agent loop and any pending action.

### Limits

- Not possible without root or special privileges: silently installing or uninstalling apps, factory reset,
  entering the screen-lock PIN or fingerprint, toggling Wi-Fi/Bluetooth directly (use `quick_toggle`).
- Apps that mark their screen as secure may show nothing to `read_screen`.
- Google Play restricts this kind of accessibility use, so share it as an APK rather than publishing it.
- Not compiled here; expect small fixes on the first build.

## UI: orb instead of the 3D character

The Evelyn 3D model and its textures were removed (APK is about 11 MB smaller and no OpenGL ES 3.0 requirement).
The top area is now a plain animated orb (canvas, `myraaOrb` in the JS bundle) that reacts to state: idle (slow
breathing), listening (follows your voice level), thinking (orbiting dots), talking (follows MYRAA's voice level).
The old Wave/Sit/Stand/Smile buttons are hidden by CSS but still exist in the DOM so the bundle's handlers keep working.

During a Live call, what you say is converted to text and shown big over the orb in blue, and MYRAA's words are shown
in green, updating as you speak (`#caption`). It also stays in the conversation history.

## Live call keeps running in the background

The Live call now lives in the foreground service (notification with Stop, optional floating chip) and no longer depends
on the overlay permission. Two bugs ended it as soon as another app came to the front: `allowBackgroundLive` was tied to
the overlay permission, and the `onStop` lifecycle event did not carry `backgroundLive`, so the page ended the call.
The WebView is also no longer paused while a call is running, and the service holds a partial wake lock (max 2 hours).
Display over other apps is still needed to open apps by voice while MYRAA is in the background.
After a missed `tap_text` the tool now returns the tappable items on screen (with @x,y) so the model can use `tap_xy`.

## Signing

Release and debug builds are signed with `app/myraa-release.jks` (alias `myraa`, passwords in `app/build.gradle`).
SHA-256: 3E:76:96:A4:3D:59:A5:3F:54:EE:8B:93:FE:A9:7A:9A:AB:E9:A2:3F:CC:BC:B1:5F:9A:F5:55:A7:FD:05:D6:B5
Keep the keystore backed up and keep the repo private.

## Wake word (Hey Myraa)

Settings > Permissions > "Wake word: Hey Myraa" turns on `WakeWordService` (microphone foreground service). It uses Android SpeechRecognizer, matches the name "Myra/Maira/Mira/मायरा" in partial results, then opens MainActivity with `myraa.wake` and clicks the voice button to start the Live call. It pauses while a Live call runs. Needs Display over other apps to open from the background (otherwise a Tap-to-talk notification appears). Accuracy depends on the phone speech service; not tested on a device.
