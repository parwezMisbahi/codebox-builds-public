# Widget Maker (Android)
Home screen widgets for any app, setting, link, call, torch, or in-app option.

## Build the APK on GitHub
1. Upload this folder to a new GitHub repo (branch `main`).
2. Open the **Actions** tab. The "Build APK" workflow runs on every push (or run it manually).
3. When it finishes, open the run and download **WidgetMaker-debug-apk**. Unzip it and install the APK.

## Use
Open the app and tap "Add ... widget", or long-press the home screen > Widgets > Widget Maker.
For "In-app option" widgets, enable Widget Maker under Settings > Accessibility.
