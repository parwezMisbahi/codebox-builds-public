# VideoDL

Android video downloader built on yt-dlp (via youtubedl-android) + FFmpeg.

## Build
- Android Studio: open this folder, let it sync, Run (or Build > Build APK).
- Cloud: push to GitHub, run the "Build APK" workflow, download the APK artifact.

## Features
- Paste link / share link from any app
- Video (MP4, chosen quality) or Audio (MP3)
- Progress, cancel, saves to Downloads/VideoDL
- "Update yt-dlp engine" button (sites change often; update when downloads fail)

## Notes
- If the library version in app/build.gradle.kts is not found, use the latest
  io.github.junkfood02.youtubedl-android version from Maven Central.
- Only download content you have the right to download.

## Signing key (important)
`app/videodl.jks` (alias `videodl`, password `videodl2026`) signs every build.
- Keep this file safe and always use the same one. If you lose it, updates
  will not install over the old app.
- For each new version, increase `versionCode` in app/build.gradle.kts
  (and change `versionName`).
- The first install after switching to this key needs one uninstall of the
  old app; after that, updates install directly.
