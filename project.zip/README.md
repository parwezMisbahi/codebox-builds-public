# MYRAA Mobile (reconstructed source)

Android Studio / Gradle project rebuilt from `MYRAA-Mobile-1.0.0-rc.5-private.apk`.

## Build

1. Install Android Studio (Koala or newer) with Android SDK 35.
2. Open this folder (`File > Open`). Android Studio creates the Gradle wrapper and syncs.
3. Run `app` on a device/emulator, or build an APK:
   `Build > Build APK(s)` (release is signed with the debug key so it installs directly).

Command line, with Gradle 8.7+ and JDK 17 installed:

    gradle wrapper --gradle-version 8.7
    ./gradlew assembleRelease

Output: `app/build/outputs/apk/release/app-release.apk`. Use your own keystore before sharing the APK.

## What is exact and what is reconstructed

| Part | Status |
|------|--------|
| `AndroidManifest.xml`, permissions, queries, service/activity flags | Decoded from the APK, matches |
| `assets/` (web UI bundle, CSS, Evelyn PMX model + textures, `personality.txt`) | Byte-identical copies from the APK |
| `res/drawable/myraa_icon.png` | Identical |
| `GeminiAccess`, `LiveVoiceService`, `MainActivity`, `MobileActions` (Java) | **Re-written** from the dex call graph, string constants and the JS bridge contract. Same behaviour and messages, not the original text. Timeouts, history size (20 sent / 40 kept) and token expiry times are best guesses. |
| Web UI (`assets/mobile.html`, `assets/assets/mobile-*.js`) | Minified Vite build output. The original TypeScript/Vite source is **not recoverable** from an APK. Edit the bundle only if you must; otherwise keep it as is. |
| Theme | `Theme.DeviceDefault.NoActionBar` is the closest match to the original theme id |

The Java was syntax-checked but not compiled against the Android SDK in the environment it was written in, so expect to fix small compile errors on the first build.

## Native bridge contract (`window.MyraaNative`)

JS calls: `getState()`, `chat(text, id)`, `cancel()`, `configure(json)`, `checkConnection(json)`,
`clearHistory()`, `clearKey()`, `speak(text)`, `stopSpeech()`, `startLive(id)`, `endLive()`,
`mobileAction(id, name, argsJson)`, `cancelMobileAction(id)`, `openSettings()`, `openFloatingSettings()`.

Native replies by calling `window.MyraaEvents(obj)` with `type` one of:
`reply`, `error`, `settings`, `speech`, `live-token`, `live-error`, `mobile-action-result`.

## Using it

Open Settings inside the app and paste your own Gemini API key. Never put a key in the source.
