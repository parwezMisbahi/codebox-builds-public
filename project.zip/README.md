# Voice Typer

Chhota floating mic overlay: bolo, text overlay mein screen par dikhta hai, Copy dabao aur kahin bhi paste karo.
(Accessibility permission ki zaroorat nahi.)

## APK banana (GitHub)
1. Is folder ko GitHub repo mein push karo (branch `main`). Repo **private** rakho, kyunki signing key isi mein hai.
2. Actions tab -> "Build APK" chalega (ya "Run workflow").
3. Artifact `VoiceTyper-release-apk` download karo, zip kholo, APK install karo.

## Signing key (updates ke liye)
- Key: `keystore/voicetyper.jks`, alias `voicetyper`. Password `app/build.gradle.kts` mein hai.
- Har build isi key se sign hota hai, isliye naya APK purane ke upar update ho jata hai (data bhi bacha rehta hai).
- Is file ki backup rakho. Kho gayi ya badal di to update install nahi hoga, uninstall karna padega.
- Har update se pehle `app/build.gradle.kts` mein `versionCode` badhao (abhi 2).
- Pehle wali (alag key se bani) APK ek baar uninstall karni padegi.

## Pehli baar setup
1. App kholo -> Microphone allow karo.
2. "Display over other apps" allow karo.
3. "Overlay shuru karo".

## Use
- 🎤 dabao aur bolo. Text overlay ke panel mein dikhta hai, Copy button aa jata hai.
- Dobara 🎤 dabao to sunna band. Clear = text saaf.
- UR/EN/HI = language badlo, – = chhota, ✕ = band, ⋮ pakad kar drag karo.
- Speech recognition Google ki service use karti hai (internet chahiye).
