# Voice Typer

Chhota floating mic overlay: bolo ya video ki awaaz sunao, text overlay mein screen par dikhta hai, Copy dabao aur kahin bhi paste karo.
(Accessibility permission ki zaroorat nahi.)

## APK banana (GitHub)
1. Is folder ko GitHub repo mein push karo (branch `main`). Repo **private** rakho, kyunki signing key isi mein hai.
2. Actions tab -> "Build APK" chalega (ya "Run workflow").
3. Artifact `VoiceTyper-release-apk` download karo, zip kholo, APK install karo.

## Signing key (updates ke liye)
- Key: `keystore/voicetyper.jks`, alias `voicetyper`. Password `app/build.gradle.kts` mein hai.
- Har build isi key se sign hota hai, isliye naya APK purane ke upar update ho jata hai (data bhi bacha rehta hai).
- Is file ki backup rakho. Kho gayi ya badal di to update install nahi hoga, uninstall karna padega.
- Har update se pehle `app/build.gradle.kts` mein `versionCode` badhao (abhi 2).
- Pehle wali (alag key se bani) APK ek baar uninstall karni padegi.

## Hinglish (HG)
- Google ki wahi speech language use hoti hai jo Gboard ke Hinglish voice typing mein hoti hai (hi-Latn, agar phone par ho; warna en-IN). Spelling Google khud sahi karta hai, code mein koi word list nahi.
- Agar phir bhi Devanagari aaye to sirf tab fallback transliteration chalti hai.

## Video mode (📺)
- Video/app ki awaaz seedhi system se pakadta hai, mic se nahi, isliye phone ki volume 0 ho tab bhi chalta hai (device par depend).
- Android 13+ chahiye. 📺 dabao -> "Start now" allow karo -> 🎤 dabao.
- Kuch apps (Netflix, kuch DRM/protected apps) apni awaaz capture hone hi nahi deti.
- Permission screen par poori screen allow hoti hai (sirf ek app nahi).
- Video mode mein panel mein "awaaz: X%" dikhta hai. X% hilta hai par text nahi aata = capture theek hai, Google recognizer is tareeke ko support nahi kar raha. X% 0 rahe = us app ki awaaz capture hi nahi ho rahi.
- Dobara 📺 dabao to wapas mic mode.

## Pehli baar setup
1. App kholo -> Microphone allow karo.
2. "Display over other apps" allow karo.
3. "Overlay shuru karo".

## Use
- 🎤 dabao aur bolo. Text overlay ke panel mein dikhta hai, Copy button aa jata hai.
- Dobara 🎤 dabao to sunna band. Clear = text saaf.
- UR/EN/HI = language badlo, – = chhota, ✕ = band, ⋮ pakad kar drag karo.
- Speech recognition Google ki service use karti hai (internet chahiye).
