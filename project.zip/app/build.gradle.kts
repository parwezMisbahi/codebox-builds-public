plugins {
    id("com.android.application")
}

android {
    namespace = "com.myraa.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.myraa.mobile"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.0.0-rc.6"
    }

    // Har update isi key se sign hoga, tabhi naya APK purane ke upar install hoga.
    // keystore/myraa.jks ko kabhi mat khona aur kabhi mat badalna.
    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/myraa.jks")
            storePassword = "7480be0caed548f89bbf"
            keyAlias = "myraa"
            keyPassword = "7480be0caed548f89bbf"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
