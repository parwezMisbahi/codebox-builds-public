plugins {
  alias(libs.plugins.android.application)
}

// Values can be overridden from the GitHub workflow (-PappId=... -PappName=...)
val appIdValue = (findProperty("appId") as String?) ?: "com.docera.parwez"
val appNameValue = (findProperty("appName") as String?) ?: "Docera"

android {
  namespace = "com.docera.parwez"
  compileSdk = 36

  defaultConfig {
    applicationId = appIdValue
    minSdk = 24
    targetSdk = 36
    versionCode = (findProperty("verCode") as String?)?.toIntOrNull() ?: (System.currentTimeMillis() / 1000).toInt()
    versionName = "5.9.3"
    manifestPlaceholders["appLabel"] = appNameValue
    // real phones only (ML Kit ships native libs per CPU; x86 ones are just emulator weight)
    ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // A fixed signing key (created once by the GitHub workflow and reused) so every new
  // build installs as an UPDATE over the previous one without losing app data.
  val ks = rootProject.file("docera.jks")
  signingConfigs {
    if (ks.exists()) {
      create("docera") {
        storeFile = ks
        storePassword = "docera123"
        keyAlias = "docera"
        keyPassword = "docera123"
      }
    }
  }

  buildTypes {
    debug {
      if (ks.exists()) signingConfig = signingConfigs.getByName("docera")
    }
    release {
      if (ks.exists()) signingConfig = signingConfigs.getByName("docera")
      // R8 off on purpose: the app is WebView + JS bridges + ML Kit native libs, and shrinking
      // can silently break them. Release then behaves exactly like the tested debug build.
      isMinifyEnabled = false
      isShrinkResources = false
      isDebuggable = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  // a lint warning must never stop the release build (the debug build never ran lint)
  lint { checkReleaseBuilds = false; abortOnError = false }
  testOptions { unitTests { isIncludeAndroidResources = true } }
}

dependencies {
  implementation("androidx.activity:activity-ktx:1.9.3")
  implementation(libs.androidx.core.ktx)
  implementation("androidx.core:core-splashscreen:1.0.1")
  implementation("androidx.biometric:biometric:1.1.0")
  // Handwriting -> text for the write-over-PDF/video layer (model is downloaded once, then works offline)
  implementation("com.google.mlkit:digital-ink-recognition:18.1.0")
  implementation("androidx.fragment:fragment-ktx:1.8.5")
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.robolectric)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
}
