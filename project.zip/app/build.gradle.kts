plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hami.voicetyper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hami.voicetyper"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    // Har update isi key se sign hoga, tabhi naya APK purane ke upar install hoga.
    // keystore/voicetyper.jks ko kabhi mat khona aur kabhi mat badalna.
    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/voicetyper.jks")
            storePassword = "2cac5f8ab40ded22c6ff"
            keyAlias = "voicetyper"
            keyPassword = "2cac5f8ab40ded22c6ff"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
