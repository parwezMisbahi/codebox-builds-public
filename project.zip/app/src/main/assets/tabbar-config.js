/* =====================================================================
   TABBAR CONFIG  -  tab bar ki saari settings yahin hain.
   Sirf yahan ke numbers badlo, index.html ko chhune ki zaroorat nahi.
   Ye dono bars par lagti hain:
     1) neeche ka main bar  (Home / Folders / Add / Notes / Library)
     2) Library page ka bar (Library / DVL / DSL)
   File save karo -> app dobara kholo -> naya look dikhega.
   ===================================================================== */
window.TABBAR_CFG = {

  /* ---------- GLASS (lens ka look) ---------- */

  /* Bend: lens ke kinare par icon/text kitna mudta (bend hota) hai.
     0 = bilkul nahi, bada number = zyada tedha.  Range 0 - 100 */
  bend: 8,

  /* Edge (px): lens ke gol kinare ki motai jahan bend hota hai.
     Chhota = patla kinara, bada = chauda.  Range 1 - 20 */
  edge: 10,

  /* Chroma split: bend wale hisse mein rang alag-alag (red/green/blue) bikharte hain.
     0 = koi rang nahi bikharta.  Range 0 - 4 */
  chroma: 0.1,

  /* Magnify: dabane par lens ke andar ka size.
     1 = same size, 1 se kam = chhota hota hai, 1 se zyada = bada.  Range 0.3 - 1.4 */
  zoom: 0.91,

  /* Lens width: lens ki chaudai ek tab ki chaudai se kitni zyada (px).
     Minus mein bhi ja sakta hai (patla lens).  Range -24 se 24 */
  grow: 2,

  /* Bar height (px): poore bar ki unchai. Icon aur text size bhi isi ke hisaab se badalte hain.
     Range 36 - 92 */
  barH: 58,

  /* Bar grow on press (px): ungli dabane par poora bar kitna phoolta hai.
     0 = nahi phoolta.  Range 0 - 8 */
  barGrow: 2,

  /* Lens bigger than bar (px): dabane par lens bar se bahar kitna nikalta hai.
     0 = bar ke andar hi rehta hai.  Range 0 - 40 */
  lensOver: 12,


  /* ---------- MOTION (hilne ka andaaz) ---------- */

  /* Stretch: lens tezi se hilte waqt kitna khinchta (lamba hota) hai.
     0 = nahi khinchta.  Range 0 - 0.25 */
  stretch: 0.13,

  /* Spring: lens ko tab par pahunchane wali kheench ki taqat.
     Bada = tez aur jhatke se, chhota = dheema aur narm.  Range 80 - 600 */
  k: 310,

  /* Damping: lens ke jhoolne (bounce) ko kitna rokna hai.
     Chhota = zyada bounce, bada = jaldi ruk jaata hai.  Range 8 - 40 */
  c: 18,


  /* ---------- LOOK ---------- */

  /* Accent colour: chuna hua tab aur lens ke andar ke icon/text ka rang (hex code) */
  acc: '#c67229',

  /* Library page ke bar ki chaudai, screen ka kitna percent.
     50 = aadhi screen, 100 = poori chaudai. Range 40 - 100 */
  libBarWidth: 50

};
