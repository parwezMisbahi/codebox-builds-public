package android.print

import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import java.io.File

/** Writes a WebView's print adapter straight to a PDF file (the callbacks are package-private, so this lives in android.print). */
class PdfPrint(private val attrs: PrintAttributes) {
    fun print(adapter: PrintDocumentAdapter, file: File, cb: (Boolean, String) -> Unit) {
        adapter.onLayout(null, attrs, CancellationSignal(), object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                try {
                    val pfd = ParcelFileDescriptor.open(
                        file,
                        ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
                    )
                    adapter.onWrite(arrayOf(PageRange.ALL_PAGES), pfd, CancellationSignal(), object : PrintDocumentAdapter.WriteResultCallback() {
                        override fun onWriteFinished(pages: Array<out PageRange>?) {
                            try { pfd.close() } catch (_: Exception) {}
                            try { adapter.onFinish() } catch (_: Exception) {}
                            cb(true, "")
                        }

                        override fun onWriteFailed(error: CharSequence?) {
                            try { pfd.close() } catch (_: Exception) {}
                            cb(false, error?.toString() ?: "write failed")
                        }
                    })
                } catch (e: Exception) {
                    cb(false, e.localizedMessage ?: "write failed")
                }
            }

            override fun onLayoutFailed(error: CharSequence?) {
                cb(false, error?.toString() ?: "layout failed")
            }
        }, null)
    }
}
