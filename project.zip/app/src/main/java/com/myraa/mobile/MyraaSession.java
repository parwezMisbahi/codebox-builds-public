package com.myraa.mobile;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

/** Runs when the user invokes the assistant: opens MYRAA and starts the Live voice call. */
final class MyraaSession extends VoiceInteractionSession {
    MyraaSession(Context context) {
        super(context);
    }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        Intent open = new Intent(getContext(), MainActivity.class)
                .putExtra(WakeWordService.EXTRA_WAKE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            getContext().startActivity(open);
        } catch (RuntimeException e) {
            try {
                startAssistantActivity(open);
            } catch (RuntimeException ignored) {
                // nothing more we can do; the user can open MYRAA normally
            }
        }
        hide();
    }
}
