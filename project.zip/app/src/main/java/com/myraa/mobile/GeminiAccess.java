package com.myraa.mobile;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Talks to the Gemini REST API: key/model verification and Live ephemeral tokens.
 * Reconstructed from the shipped MYRAA Mobile 1.0.0-rc.5 build (strings and call graph).
 */
final class GeminiAccess {
    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta/";

    interface ConnectionObserver {
        void opened(HttpsURLConnection connection);
    }

    interface Connections {
        HttpsURLConnection open(URL url) throws IOException;
    }

    static final class Failure extends Exception {
        final String code;
        final int status;

        Failure(String code, int status, String message) {
            super(message);
            this.code = code;
            this.status = status;
        }
    }

    private final Connections connections;

    GeminiAccess() {
        this(url -> (HttpsURLConnection) url.openConnection());
    }

    GeminiAccess(Connections connections) {
        this.connections = connections;
    }

    /** Maps a Google error response to a user-facing failure. */
    static Failure failure(int status, String body) {
        String reason = "";
        String message = "";
        try {
            JSONObject error = new JSONObject(body).optJSONObject("error");
            if (error != null) {
                message = error.optString("message");
                JSONArray details = error.optJSONArray("details");
                if (details != null) {
                    for (int i = 0; i < details.length(); i++) {
                        JSONObject d = details.optJSONObject(i);
                        if (d != null && !d.optString("reason").isEmpty()) {
                            reason = d.optString("reason");
                            break;
                        }
                    }
                }
            }
        } catch (JSONException ignored) {
            // body was not JSON; fall through to the generic HTTP failure
        }

        Map<String, String> messages = new LinkedHashMap<>();
        messages.put("QUOTA_EXCEEDED", "Google's quota for this model is exhausted. Your key may still be valid. Wait for quota to reset or choose another model you can use.");
        messages.put("PROVIDER_UNAVAILABLE", "Google is temporarily unavailable. Your key and conversation were kept. Try again later.");
        messages.put("ACCOUNT_STATE_INVALID", "Google says the service account linked to this key is disabled or deleted. Create a key linked to an active service account in Google AI Studio, or have your project administrator restore it.");
        messages.put("CONSUMER_SUSPENDED", "Google says this key's project or consumer is suspended. Resolve its status in Google AI Studio or Google Cloud, then check the key again. Changing MYRAA's model cannot repair a suspended project.");
        messages.put("API_KEY_INVALID", "Google says this API key is invalid. Create a replacement in Google AI Studio and enter it only in the key field.");
        messages.put("API_KEY_EXPIRED", "Google says this API key has expired. Create a replacement in Google AI Studio.");
        messages.put("API_KEY_SERVICE_BLOCKED", "This key is not allowed to use the Gemini API. Check its API restrictions and linked project in Google Cloud.");
        messages.put("SERVICE_DISABLED", "The Gemini API is disabled for this key's project. Enable the Generative Language API in Google Cloud.");
        messages.put("API_KEY_HTTP_REFERRER_BLOCKED", "This key's website restrictions do not permit this Android app. Review its application restrictions in Google Cloud.");
        messages.put("API_KEY_IP_ADDRESS_BLOCKED", "Google blocked this key because of its allowed IP addresses. Review its application restrictions in Google Cloud.");
        messages.put("API_KEY_ANDROID_APP_BLOCKED", "This key's Android application restrictions do not match MYRAA's package and signing certificate. Review them in Google Cloud.");
        messages.put("MODEL_UNAVAILABLE", "Google could not find this model for your key. Check the model identifier in Settings or choose a model available to your project.");
        messages.put("API_KEY_LEAKED", "Google blocked this key as exposed. Replace it in Google AI Studio and paste the new key only into MYRAA's key field, never into chat.");

        // 1. Explicit reason reported by Google.
        for (Map.Entry<String, String> entry : messages.entrySet()) {
            if (entry.getKey().equals(reason)) {
                return new Failure(entry.getKey(), status, entry.getValue());
            }
        }
        // 2. Reason embedded in the reason string (e.g. "..._API_KEY_INVALID").
        for (Map.Entry<String, String> entry : messages.entrySet()) {
            if (!reason.isEmpty() && reason.contains(entry.getKey())) {
                return new Failure(entry.getKey(), status, entry.getValue());
            }
        }
        // 3. Fall back to message text and HTTP status.
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("leaked") || lower.contains("exposed")) {
            return new Failure("API_KEY_LEAKED", status, messages.get("API_KEY_LEAKED"));
        }
        if (lower.contains("api key not valid")) {
            return new Failure("API_KEY_INVALID", status, messages.get("API_KEY_INVALID"));
        }
        if (status == 429) {
            return new Failure("QUOTA_EXCEEDED", status, messages.get("QUOTA_EXCEEDED"));
        }
        if (status >= 500) {
            return new Failure("PROVIDER_UNAVAILABLE", status, messages.get("PROVIDER_UNAVAILABLE"));
        }
        if (status == 404) {
            return new Failure("MODEL_UNAVAILABLE", status, messages.get("MODEL_UNAVAILABLE"));
        }
        if (status == 403) {
            return new Failure("GOOGLE_ACCESS_DENIED", status,
                    "Google denied this key or project access. Check its project, linked service account and API restrictions in Google AI Studio or Google Cloud.");
        }
        return new Failure("GOOGLE_HTTP_ERROR", status,
                "Google returned HTTP " + status + ". Your key and conversation were kept.");
    }

    static String read(InputStream in, int limit) throws IOException {
        if (in == null) {
            return "";
        }
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = stream.read(buffer)) != -1) {
                if (out.size() + n > limit) {
                    throw new IOException("Response exceeds the size limit.");
                }
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    /** Creates a single-use Gemini Live ephemeral token ("auth_tokens/...") from the saved API key. */
    String createLiveToken(String apiKey, ConnectionObserver observer) throws Exception {
        HttpsURLConnection connection = connections.open(new URL(BASE + "auth_tokens"));
        observer.opened(connection);
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("x-goog-api-key", apiKey);

            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("UTC"));
            long now = System.currentTimeMillis();
            JSONObject body = new JSONObject();
            body.put("uses", 1);
            body.put("expireTime", format.format(new Date(now + 30 * 60 * 1000L)));
            body.put("newSessionExpireTime", format.format(new Date(now + 60 * 1000L)));

            try (OutputStream out = connection.getOutputStream()) {
                out.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) {
                String text = read(connection.getInputStream(), 64 * 1024);
                String name = new JSONObject(text).optString("name");
                if (!name.startsWith("auth_tokens/") || name.length() <= "auth_tokens/".length()) {
                    throw new IOException("Invalid Live token response.");
                }
                return name;
            }
            throw failure(status, read(connection.getErrorStream(), 64 * 1024));
        } finally {
            connection.disconnect();
            observer.opened(null);
        }
    }

    /** Checks the key format, the model id, and that the model supports generateContent. */
    void verify(String apiKey, String model, ConnectionObserver observer) throws Exception {
        if (!apiKey.matches("[A-Za-z0-9._-]{20,300}")) {
            throw new Failure("KEY_FORMAT_INVALID", 0,
                    "Enter a complete Gemini API key without spaces. Both AQ and AIza key formats are supported.");
        }
        if (!model.matches("[A-Za-z0-9._-]{1,100}")) {
            throw new Failure("MODEL_FORMAT_INVALID", 0, "Enter a valid Gemini model identifier.");
        }
        HttpsURLConnection connection = connections.open(new URL(BASE + "models/" + model));
        observer.opened(connection);
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("x-goog-api-key", apiKey);

            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) {
                JSONObject info = new JSONObject(read(connection.getInputStream(), 256 * 1024));
                JSONArray methods = info.optJSONArray("supportedGenerationMethods");
                if (methods != null) {
                    for (int i = 0; i < methods.length(); i++) {
                        if ("generateContent".equals(methods.optString(i))) {
                            return;
                        }
                    }
                }
                throw new Failure("MODEL_CHAT_UNSUPPORTED", status,
                        "This model does not support this app's text chat API. Choose a Gemini text model with generateContent support.");
            }
            throw failure(status, read(connection.getErrorStream(), 64 * 1024));
        } finally {
            connection.disconnect();
            observer.opened(null);
        }
    }
}
