package com.myraa.mobile;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Arrays;
import java.util.Comparator;

/** Lets MYRAA read and clear notifications when the user turns on Notification access. */
public class MyraaNotifications extends NotificationListenerService {
    private static volatile MyraaNotifications instance;

    static boolean isEnabled() {
        return instance != null;
    }

    @Override
    public void onListenerConnected() {
        instance = this;
    }

    @Override
    public void onListenerDisconnected() {
        instance = null;
    }

    /** Newest-first summary of up to 20 active notifications, or null when access is off. */
    static String recent() {
        MyraaNotifications s = instance;
        if (s == null) {
            return null;
        }
        StatusBarNotification[] list;
        try {
            list = s.getActiveNotifications();
        } catch (RuntimeException e) {
            return null;
        }
        if (list == null || list.length == 0) {
            return "No notifications.";
        }
        Arrays.sort(list, new Comparator<StatusBarNotification>() {
            @Override
            public int compare(StatusBarNotification a, StatusBarNotification b) {
                return Long.compare(b.getPostTime(), a.getPostTime());
            }
        });
        PackageManager pm = s.getPackageManager();
        StringBuilder out = new StringBuilder();
        int shown = 0;
        for (StatusBarNotification n : list) {
            if (shown >= 20 || out.length() > 3500) {
                break;
            }
            Bundle x = n.getNotification().extras;
            CharSequence title = x.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = x.getCharSequence(Notification.EXTRA_TEXT);
            if ((title == null || title.length() == 0) && (text == null || text.length() == 0)) {
                continue;
            }
            String app;
            try {
                app = pm.getApplicationLabel(pm.getApplicationInfo(n.getPackageName(), 0)).toString();
            } catch (PackageManager.NameNotFoundException e) {
                app = n.getPackageName();
            }
            out.append(app).append(": ")
                    .append(title == null ? "" : title).append(" - ")
                    .append(text == null ? "" : text.toString().replace('\n', ' ')).append('\n');
            shown++;
        }
        return shown == 0 ? "No notifications." : out.toString();
    }

    static boolean clearAll() {
        MyraaNotifications s = instance;
        if (s == null) {
            return false;
        }
        try {
            s.cancelAllNotifications();
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }
}
