package com.myraa.mobile;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioManager;
import android.media.AudioRecordingConfiguration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Listens for "Hey Myraa" with Android's speech recogniser and opens MYRAA's Live voice call when heard.
 * Runs as a microphone foreground service (persistent notification). Pauses while a Live call uses the mic.
 */
public final class WakeWordService extends Service {
    static final String STOP = "com.myraa.mobile.STOP_WAKE";
    static final String PREF = "wakeWord";
    static final String EXTRA_WAKE = "myraa.wake";
    private static final String CHANNEL = "wake_word";
    private static final int NOTIFICATION_ID = 4102;
    private static final String[] NAMES = {
            "myra", "myraa", "maira", "mayra", "mira", "meera", "mayara", "maya ra",
            "मायरा", "मैरा", "माइरा", "मायरा", "मीरा", "माइरा"};

    static volatile boolean running;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private PowerManager.WakeLock wake;
    private boolean paused;
    private boolean sawLive;
    private long pausedAt;
    private boolean listening;
    private AudioManager audio;
    private int savedNotifVolume = -1;
    private boolean micBusy;
    private Notification.Builder noteBuilder;
    private AudioManager.AudioRecordingCallback recordingCallback;
    private final Runnable busyCheck = this::evaluateMicUse;

    static boolean enabled(Context c) {
        return c.getSharedPreferences("myraa.mobile.v1", MODE_PRIVATE).getBoolean(PREF, false);
    }

    static void setEnabled(Context c, boolean on) {
        SharedPreferences p = c.getSharedPreferences("myraa.mobile.v1", MODE_PRIVATE);
        p.edit().putBoolean(PREF, on).apply();
        Intent i = new Intent(c, WakeWordService.class);
        if (on) {
            try {
                c.startForegroundService(i);
            } catch (RuntimeException e) {
                p.edit().putBoolean(PREF, false).apply();
            }
        } else {
            c.stopService(i);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            getSharedPreferences("myraa.mobile.v1", MODE_PRIVATE).edit().putBoolean(PREF, false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "MYRAA wake word", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 2,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 3,
                new Intent(this, WakeWordService.class).setAction(STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        noteBuilder = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.myraa_icon)
                .setContentTitle("MYRAA is listening for \"Hey Myraa\"")
                .setContentText("Say Hey Myraa to start. Tap Turn off to stop listening.")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.myraa_icon), "Turn off", stop).build());
        Notification n = noteBuilder.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
        if (!running) {
            running = true;
            audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            PowerManager pm = getSystemService(PowerManager.class);
            if (pm != null && wake == null) {
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myraa:wake");
                wake.acquire();
            }
            handler.post(this::startListening);
            handler.postDelayed(watchdog, 1000);
            registerMicWatch();
        }
        return START_STICKY;
    }

    // ------------------------------------------------------------------ listening loop

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (!running) {
                return;
            }
            if (paused) {
                boolean live = LiveVoiceService.running;
                if (live) {
                    sawLive = true;
                }
                long waited = System.currentTimeMillis() - pausedAt;
                if ((sawLive && !live) || (!live && waited > 25000)) {
                    paused = false;
                    sawLive = false;
                    startListening();
                    handler.postDelayed(busyCheck, 1500);
                }
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void muteBeep(boolean mute) {
        if (audio == null) {
            return;
        }
        try {
            if (mute && savedNotifVolume < 0) {
                savedNotifVolume = audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION);
                audio.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
            } else if (!mute && savedNotifVolume >= 0) {
                audio.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0);
                savedNotifVolume = -1;
            }
        } catch (RuntimeException ignored) {
            // Do Not Disturb policy may forbid this; the recogniser beep is harmless.
        }
    }

    private void startListening() {
        if (!running || paused || micBusy || listening) {
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            return;
        }
        destroyRecognizer();
        muteBeep(true);
        recognizer = createRecognizer();
        recognizer.setRecognitionListener(new Listener());
        String lang = getSharedPreferences("myraa.mobile.v1", MODE_PRIVATE).getString("language", "hi-IN");
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        listening = true;
        try {
            recognizer.startListening(i);
        } catch (RuntimeException e) {
            listening = false;
            restart(2000);
        }
    }

    private void restart(long delayMs) {
        listening = false;
        destroyRecognizer();
        if (running && !paused && !micBusy) {
            handler.postDelayed(this::startListening, delayMs);
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
                recognizer.destroy();
            } catch (RuntimeException ignored) {
                // already released
            }
            recognizer = null;
        }
    }

    static boolean isWake(ArrayList<String> heard) {
        if (heard == null) {
            return false;
        }
        for (String h : heard) {
            String t = h.toLowerCase(Locale.ROOT);
            for (String name : NAMES) {
                if (t.contains(name)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Talks to Google's recogniser directly, so this still works when MYRAA is the default assistant. */
    private SpeechRecognizer createRecognizer() {
        ComponentName google = new ComponentName("com.google.android.googlequicksearchbox",
                "com.google.android.voicesearch.serviceapi.GoogleRecognitionService");
        try {
            getPackageManager().getServiceInfo(google, 0);
            return SpeechRecognizer.createSpeechRecognizer(this, google);
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            return SpeechRecognizer.createSpeechRecognizer(this);
        }
    }

    // ------------------------------------------------------------------ other apps using the microphone

    private void registerMicWatch() {
        if (audio == null || recordingCallback != null) {
            return;
        }
        recordingCallback = new AudioManager.AudioRecordingCallback() {
            @Override
            public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) {
                // Wait a moment: our own recogniser starting and stopping also changes this list.
                handler.removeCallbacks(busyCheck);
                handler.postDelayed(busyCheck, 700);
            }
        };
        audio.registerAudioRecordingCallback(recordingCallback, handler);
    }

    /**
     * While we are listening, one active recording is ours (it runs inside the speech service). Any extra
     * recording, or any recording while we are not listening, is another app, so we let go of the microphone.
     */
    private void evaluateMicUse() {
        if (!running || audio == null || paused) {
            return;
        }
        List<AudioRecordingConfiguration> active = audio.getActiveRecordingConfigurations();
        int count = active == null ? 0 : active.size();
        int ours = listening ? 1 : 0;
        boolean others = count > ours;
        if (others && !micBusy) {
            micBusy = true;
            listening = false;
            destroyRecognizer();
            muteBeep(false);
            updateNote("Paused: another app is using the microphone.");
        } else if (!others && micBusy) {
            micBusy = false;
            updateNote("Say Hey Myraa to start. Tap Turn off to stop listening.");
            handler.postDelayed(this::startListening, 800);
        } else if (micBusy) {
            // still busy: check again when the list changes
            handler.postDelayed(busyCheck, 2000);
        }
    }

    private void updateNote(String text) {
        if (noteBuilder == null) {
            return;
        }
        noteBuilder.setContentText(text);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, noteBuilder.build());
        }
    }

    private void triggered() {
        paused = true;
        sawLive = false;
        pausedAt = System.currentTimeMillis();
        listening = false;
        destroyRecognizer();
        muteBeep(false);
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_WAKE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        boolean started = false;
        if (Settings.canDrawOverlays(this)) {
            try {
                startActivity(open);
                started = true;
            } catch (RuntimeException ignored) {
                // fall through to the notification
            }
        }
        if (!started) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("wake_tap", "MYRAA wake tap", NotificationManager.IMPORTANCE_HIGH));
            PendingIntent tap = PendingIntent.getActivity(this, 4, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            nm.notify(4103, new Notification.Builder(this, "wake_tap")
                    .setSmallIcon(R.drawable.myraa_icon)
                    .setContentTitle("Hey! I heard you")
                    .setContentText("Tap to talk to MYRAA (allow Display over other apps to skip this tap).")
                    .setContentIntent(tap)
                    .setAutoCancel(true)
                    .build());
        }
    }

    private final class Listener implements RecognitionListener {
        @Override
        public void onPartialResults(Bundle b) {
            check(b);
        }

        @Override
        public void onResults(Bundle b) {
            if (!check(b)) {
                restart(200);
            }
        }

        private boolean check(Bundle b) {
            if (paused || b == null) {
                return false;
            }
            if (isWake(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))) {
                triggered();
                return true;
            }
            return false;
        }

        @Override
        public void onError(int error) {
            if (paused) {
                return;
            }
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf();
            } else if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                restart(150);
            } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                restart(1500);
            } else {
                restart(2500);
            }
        }

        @Override public void onReadyForSpeech(Bundle p) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float v) { }
        @Override public void onBufferReceived(byte[] b) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onEvent(int t, Bundle b) { }
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (audio != null && recordingCallback != null) {
            audio.unregisterAudioRecordingCallback(recordingCallback);
            recordingCallback = null;
        }
        destroyRecognizer();
        muteBeep(false);
        if (wake != null && wake.isHeld()) {
            wake.release();
        }
        wake = null;
        super.onDestroy();
    }
}
