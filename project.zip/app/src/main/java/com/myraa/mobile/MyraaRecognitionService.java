package com.myraa.mobile;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.RemoteException;
import android.speech.RecognitionListener;
import android.speech.RecognitionService;
import android.speech.SpeechRecognizer;

/**
 * Android requires an assistant to name a recognition service. This one only forwards to Google's
 * recogniser, so speech input in other apps keeps working when MYRAA is the default assistant.
 */
public final class MyraaRecognitionService extends RecognitionService {
    private SpeechRecognizer inner;

    @Override
    protected void onStartListening(Intent intent, Callback callback) {
        release();
        ComponentName google = new ComponentName("com.google.android.googlequicksearchbox",
                "com.google.android.voicesearch.serviceapi.GoogleRecognitionService");
        try {
            getPackageManager().getServiceInfo(google, 0);
            inner = SpeechRecognizer.createSpeechRecognizer(this, google);
        } catch (PackageManager.NameNotFoundException | RuntimeException e) {
            fail(callback, SpeechRecognizer.ERROR_CLIENT);
            return;
        }
        inner.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { try { callback.readyForSpeech(p); } catch (RemoteException ignored) { } }
            @Override public void onBeginningOfSpeech() { try { callback.beginningOfSpeech(); } catch (RemoteException ignored) { } }
            @Override public void onRmsChanged(float v) { try { callback.rmsChanged(v); } catch (RemoteException ignored) { } }
            @Override public void onBufferReceived(byte[] b) { try { callback.bufferReceived(b); } catch (RemoteException ignored) { } }
            @Override public void onEndOfSpeech() { try { callback.endOfSpeech(); } catch (RemoteException ignored) { } }
            @Override public void onError(int e) { fail(callback, e); }
            @Override public void onResults(Bundle b) { try { callback.results(b); } catch (RemoteException ignored) { } }
            @Override public void onPartialResults(Bundle b) { try { callback.partialResults(b); } catch (RemoteException ignored) { } }
            @Override public void onEvent(int t, Bundle b) { }
        });
        try {
            inner.startListening(new Intent(intent));
        } catch (RuntimeException e) {
            fail(callback, SpeechRecognizer.ERROR_CLIENT);
        }
    }

    private void fail(Callback callback, int code) {
        try {
            callback.error(code);
        } catch (RemoteException ignored) {
            // client is gone
        }
    }

    @Override
    protected void onStopListening(Callback callback) {
        if (inner != null) {
            inner.stopListening();
        }
    }

    @Override
    protected void onCancel(Callback callback) {
        release();
    }

    private void release() {
        if (inner != null) {
            try {
                inner.cancel();
                inner.destroy();
            } catch (RuntimeException ignored) {
                // already released
            }
            inner = null;
        }
    }

    @Override
    public void onDestroy() {
        release();
        super.onDestroy();
    }
}
