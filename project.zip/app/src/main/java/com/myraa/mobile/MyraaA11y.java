package com.myraa.mobile;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;

/**
 * Lets MYRAA see the screen and tap, type and scroll in other apps when the user turns it on in
 * Accessibility settings. Used only for actions the user asked MYRAA to perform.
 */
public class MyraaA11y extends AccessibilityService {
    private static volatile MyraaA11y instance;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_NODES = 500;
    private static final int MAX_CHARS = 3500;

    static boolean isEnabled() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Nothing to react to; actions are driven by MYRAA.
    }

    @Override
    public void onInterrupt() {
    }

    // ------------------------------------------------------------------ public actions

    static String readScreen() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null) {
            return "(The screen could not be read.)";
        }
        StringBuilder out = new StringBuilder("App: ").append(root.getPackageName()).append('\n');
        int[] count = {0};
        collect(root, out, count);
        return out.length() == 0 ? "(Nothing readable.)" : out.toString();
    }

    private static void collect(AccessibilityNodeInfo n, StringBuilder out, int[] count) {
        if (n == null || count[0]++ > MAX_NODES || out.length() > MAX_CHARS || !n.isVisibleToUser()) {
            return;
        }
        CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
        if (t != null && t.length() > 0) {
            String tag = n.isEditable() ? "[input] " : n.isClickable() ? "[tap] " : "";
            out.append(tag).append(t.toString().replace('\n', ' ')).append('\n');
        } else if (n.isEditable()) {
            out.append("[input]\n");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            collect(n.getChild(i), out, count);
        }
    }

    static boolean tapText(String text) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || text == null || text.trim().isEmpty()) {
            return false;
        }
        AccessibilityNodeInfo hit = find(root, text.trim().toLowerCase(Locale.ROOT), new int[]{0});
        while (hit != null) {
            if (hit.isClickable() && hit.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            hit = hit.getParent();
        }
        return false;
    }

    private static AccessibilityNodeInfo find(AccessibilityNodeInfo n, String needle, int[] count) {
        if (n == null || count[0]++ > 2000) {
            return null;
        }
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (n.isVisibleToUser()
                && ((t != null && t.toString().toLowerCase(Locale.ROOT).contains(needle))
                || (d != null && d.toString().toLowerCase(Locale.ROOT).contains(needle)))) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), needle, count);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    static boolean typeText(String text) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || text == null) {
            return false;
        }
        AccessibilityNodeInfo field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (field == null || !field.isEditable()) {
            field = firstMatching(root, true, new int[]{0});
        }
        if (field == null) {
            return false;
        }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    static boolean scroll(boolean down) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        AccessibilityNodeInfo list = root == null ? null : firstMatching(root, false, new int[]{0});
        return list != null && list.performAction(down
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    /** First editable node (editable=true) or first scrollable node (editable=false). */
    private static AccessibilityNodeInfo firstMatching(AccessibilityNodeInfo n, boolean editable, int[] count) {
        if (n == null || count[0]++ > 2000) {
            return null;
        }
        if (n.isVisibleToUser() && (editable ? n.isEditable() : n.isScrollable())) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstMatching(n.getChild(i), editable, count);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    static boolean press(String key) {
        MyraaA11y s = instance;
        if (s == null || key == null) {
            return false;
        }
        switch (key.toLowerCase(Locale.ROOT)) {
            case "back": return s.performGlobalAction(GLOBAL_ACTION_BACK);
            case "home": return s.performGlobalAction(GLOBAL_ACTION_HOME);
            case "recents": return s.performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "notifications": return s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            default: return false;
        }
    }

    /** After a WhatsApp draft opens, keeps looking for the Send button for a few seconds and taps it once. */
    static void autoSend() {
        final long deadline = System.currentTimeMillis() + 9000;
        MAIN.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (trySend() || System.currentTimeMillis() > deadline) {
                    return;
                }
                MAIN.postDelayed(this, 400);
            }
        }, 900);
    }

    private static boolean trySend() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || root.getPackageName() == null
                || !root.getPackageName().toString().startsWith("com.whatsapp")) {
            return false;
        }
        String pkg = root.getPackageName().toString();
        List<AccessibilityNodeInfo> byId = root.findAccessibilityNodeInfosByViewId(pkg + ":id/send");
        if (byId != null) {
            for (AccessibilityNodeInfo n : byId) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
        }
        List<AccessibilityNodeInfo> byText = root.findAccessibilityNodeInfosByText("Send");
        if (byText != null) {
            for (AccessibilityNodeInfo n : byText) {
                if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
        }
        return false;
    }
}
