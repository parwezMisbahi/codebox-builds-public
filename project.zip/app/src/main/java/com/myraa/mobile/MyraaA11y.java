package com.myraa.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Locale;

/**
 * Lets MYRAA see the screen and tap, swipe, pinch, type and scroll in other apps when the user
 * turns it on in Accessibility settings. Used only for actions the user asked MYRAA to perform.
 */
public class MyraaA11y extends AccessibilityService {
    interface Done {
        void done(boolean ok);
    }

    private static volatile MyraaA11y instance;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_NODES = 600;
    private static final int MAX_CHARS = 6000;

    static boolean isEnabled() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Nothing to react to; actions are driven by MYRAA.
    }

    @Override
    public void onInterrupt() {
    }

    // ------------------------------------------------------------------ reading the screen

    static int[] screenSize() {
        MyraaA11y s = instance;
        if (s == null) {
            return new int[]{1080, 2400};
        }
        DisplayMetrics m = s.getResources().getDisplayMetrics();
        return new int[]{m.widthPixels, m.heightPixels};
    }

    static String currentPackage() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        return root == null || root.getPackageName() == null ? null : root.getPackageName().toString();
    }

    static String readScreen() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null) {
            return "(The screen could not be read.)";
        }
        int[] size = screenSize();
        StringBuilder out = new StringBuilder("App: ").append(root.getPackageName())
                .append("\nScreen: ").append(size[0]).append('x').append(size[1])
                .append(" px. Coordinates are @x,y (centre of the item).\n");
        int[] count = {0, 0};
        collect(root, out, count);
        return out.toString();
    }

    /** Plain visible text of the current screen (no coordinates), one item per line. Used by read_all. */
    static String readText() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null) {
            return "";
        }
        StringBuilder out = new StringBuilder();
        collectPlain(root, out, new int[]{0});
        return out.toString();
    }

    private static void collectPlain(AccessibilityNodeInfo n, StringBuilder out, int[] count) {
        if (n == null || count[0]++ > MAX_NODES || out.length() > 12000 || !n.isVisibleToUser()) {
            return;
        }
        if (!n.isPassword()) {
            CharSequence t = n.getText() != null && n.getText().length() > 0 ? n.getText() : n.getContentDescription();
            if (t != null && t.length() > 0) {
                out.append(t.toString().replace('\n', ' ')).append('\n');
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            collectPlain(n.getChild(i), out, count);
        }
    }

    private static void collect(AccessibilityNodeInfo n, StringBuilder out, int[] count) {
        if (n == null || count[0]++ > MAX_NODES || out.length() > MAX_CHARS || !n.isVisibleToUser()) {
            return;
        }
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        String at = " @" + r.centerX() + "," + r.centerY();
        CharSequence t = n.getText() != null && n.getText().length() > 0 ? n.getText() : n.getContentDescription();
        if (n.isPassword()) {
            out.append("[input] [password field - MYRAA will not type here]").append(at).append('\n');
        } else if (t != null && t.length() > 0) {
            String tag = n.isEditable() ? "[input] " : n.isClickable() ? "[tap] " : n.isCheckable()
                    ? (n.isChecked() ? "[checked] " : "[unchecked] ") : "";
            if (n.isScrollable()) {
                tag = "[scroll] " + tag;
            }
            out.append(tag).append(t.toString().replace('\n', ' ')).append(at).append('\n');
        } else if (n.isEditable()) {
            out.append("[input]").append(at).append('\n');
        } else if (n.isClickable() && count[1]++ < 25) {
            out.append("[tap] (no label)").append(at).append('\n');
        } else if (n.isScrollable()) {
            out.append("[scroll area]").append(at).append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            collect(n.getChild(i), out, count);
        }
    }

    /** Short list of what can be tapped right now, used to help after a missed tap_text. */
    static String tappableSummary(int max) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null) {
            return "(screen not readable)";
        }
        StringBuilder out = new StringBuilder();
        listTappable(root, out, new int[]{0, 0}, max);
        return out.length() == 0 ? "(none visible)" : out.toString();
    }

    private static void listTappable(AccessibilityNodeInfo n, StringBuilder out, int[] c, int max) {
        if (n == null || c[0]++ > MAX_NODES || c[1] >= max || !n.isVisibleToUser()) {
            return;
        }
        CharSequence t = n.getText() != null && n.getText().length() > 0 ? n.getText() : n.getContentDescription();
        if (n.isClickable() && t != null && t.length() > 0 && !n.isPassword()) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            String label = t.toString().replace('\n', ' ');
            out.append('"').append(label.length() > 60 ? label.substring(0, 60) + "..." : label)
                    .append("\" @").append(r.centerX()).append(',').append(r.centerY()).append("; ");
            c[1]++;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            listTappable(n.getChild(i), out, c, max);
        }
    }

    static boolean hasText(String text) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        return root != null && text != null && !text.trim().isEmpty()
                && find(root, text.trim().toLowerCase(Locale.ROOT), new int[]{0}) != null;
    }

    // ------------------------------------------------------------------ tap / type / scroll by node

    static boolean tapText(String text) {
        return clickText(text, false);
    }

    static boolean longPressText(String text) {
        return clickText(text, true);
    }

    private static boolean clickText(String text, boolean longPress) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || text == null || text.trim().isEmpty()) {
            return false;
        }
        AccessibilityNodeInfo hit = find(root, text.trim().toLowerCase(Locale.ROOT), new int[]{0});
        if (hit == null) {
            return false;
        }
        AccessibilityNodeInfo n = hit;
        while (n != null) {
            if ((longPress ? n.isLongClickable() : n.isClickable())
                    && n.performAction(longPress ? AccessibilityNodeInfo.ACTION_LONG_CLICK
                    : AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            n = n.getParent();
        }
        // No clickable ancestor: touch the middle of the matched item instead.
        Rect r = new Rect();
        hit.getBoundsInScreen(r);
        if (r.isEmpty()) {
            return false;
        }
        return longPress ? longPress(r.centerX(), r.centerY(), null) : tap(r.centerX(), r.centerY(), null);
    }

    private static AccessibilityNodeInfo find(AccessibilityNodeInfo n, String needle, int[] count) {
        if (n == null || count[0]++ > 2500) {
            return null;
        }
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        if (n.isVisibleToUser()
                && ((t != null && t.toString().toLowerCase(Locale.ROOT).contains(needle))
                || (d != null && d.toString().toLowerCase(Locale.ROOT).contains(needle)))) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), needle, count);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    private static AccessibilityNodeInfo focusedInput(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (field == null || !field.isEditable()) {
            field = firstMatching(root, true, new int[]{0});
        }
        return field;
    }

    /** Returns "ok", "no_field", "password" or "failed". */
    static String typeText(String text, boolean append) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || text == null) {
            return "failed";
        }
        AccessibilityNodeInfo field = focusedInput(root);
        if (field == null) {
            return "no_field";
        }
        if (field.isPassword()) {
            return "password";
        }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        String value = text;
        if (append) {
            CharSequence cur = field.getText();
            boolean hint = Build.VERSION.SDK_INT >= 26 && field.isShowingHintText();
            if (cur != null && !hint) {
                value = cur.toString() + text;
            }
        }
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) ? "ok" : "failed";
    }

    /** op: select_all, copy, cut, paste, clear. */
    static boolean edit(String op) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        AccessibilityNodeInfo field = root == null ? null : focusedInput(root);
        if (field == null || op == null || field.isPassword()) {
            return false;
        }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        switch (op.toLowerCase(Locale.ROOT)) {
            case "select_all": {
                CharSequence cur = field.getText();
                Bundle a = new Bundle();
                a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0);
                a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cur == null ? 0 : cur.length());
                return field.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, a);
            }
            case "copy":
                return field.performAction(AccessibilityNodeInfo.ACTION_COPY);
            case "cut":
                return field.performAction(AccessibilityNodeInfo.ACTION_CUT);
            case "paste":
                return field.performAction(AccessibilityNodeInfo.ACTION_PASTE);
            case "clear": {
                Bundle a = new Bundle();
                a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "");
                return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a);
            }
            default:
                return false;
        }
    }

    static boolean scroll(boolean down) {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        AccessibilityNodeInfo list = root == null ? null : firstMatching(root, false, new int[]{0});
        return list != null && list.performAction(down
                ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    /** First editable node (editable=true) or first scrollable node (editable=false). */
    private static AccessibilityNodeInfo firstMatching(AccessibilityNodeInfo n, boolean editable, int[] count) {
        if (n == null || count[0]++ > 2500) {
            return null;
        }
        if (n.isVisibleToUser() && (editable ? n.isEditable() : n.isScrollable())) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstMatching(n.getChild(i), editable, count);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ system buttons

    static boolean press(String key) {
        MyraaA11y s = instance;
        if (s == null || key == null) {
            return false;
        }
        switch (key.toLowerCase(Locale.ROOT)) {
            case "back": return s.performGlobalAction(GLOBAL_ACTION_BACK);
            case "home": return s.performGlobalAction(GLOBAL_ACTION_HOME);
            case "recents": return s.performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "notifications": return s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case "quick_settings": return s.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
            case "power_menu": return s.performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
            case "split_screen": return s.performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN);
            case "screenshot":
                return Build.VERSION.SDK_INT >= 28 && s.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
            case "lock_screen":
                return Build.VERSION.SDK_INT >= 28 && s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
            case "enter": {
                if (Build.VERSION.SDK_INT < 30) {
                    return false;
                }
                AccessibilityNodeInfo root = s.getRootInActiveWindow();
                AccessibilityNodeInfo field = root == null ? null : focusedInput(root);
                return field != null && field.performAction(
                        AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
            }
            default: return false;
        }
    }

    // ------------------------------------------------------------------ touch gestures

    private static boolean dispatch(GestureDescription gesture, final Done done) {
        MyraaA11y s = instance;
        if (s == null) {
            return false;
        }
        return s.dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                if (done != null) {
                    done.done(true);
                }
            }

            @Override
            public void onCancelled(GestureDescription g) {
                if (done != null) {
                    done.done(false);
                }
            }
        }, MAIN);
    }

    private static float cx(float x) {
        return Math.max(1, Math.min(screenSize()[0] - 1, x));
    }

    private static float cy(float y) {
        return Math.max(1, Math.min(screenSize()[1] - 1, y));
    }

    static boolean tap(float x, float y, Done d) {
        Path p = new Path();
        p.moveTo(cx(x), cy(y));
        return dispatch(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(), d);
    }

    static boolean longPress(float x, float y, Done d) {
        Path p = new Path();
        p.moveTo(cx(x), cy(y));
        return dispatch(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 900)).build(), d);
    }

    static boolean doubleTap(float x, float y, Done d) {
        Path a = new Path();
        a.moveTo(cx(x), cy(y));
        Path b = new Path();
        b.moveTo(cx(x), cy(y));
        return dispatch(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(a, 0, 50))
                .addStroke(new GestureDescription.StrokeDescription(b, 160, 50)).build(), d);
    }

    static boolean swipe(float x1, float y1, float x2, float y2, long ms, Done d) {
        Path p = new Path();
        p.moveTo(cx(x1), cy(y1));
        p.lineTo(cx(x2), cy(y2));
        return dispatch(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(50, ms))).build(), d);
    }

    /** direction is where the finger moves: up, down, left or right. fromEdge starts at the screen edge. */
    static boolean swipeDirection(String direction, boolean fromEdge, Done d) {
        int[] sz = screenSize();
        float w = sz[0];
        float h = sz[1];
        switch (direction == null ? "" : direction.toLowerCase(Locale.ROOT)) {
            case "up":
                return swipe(w / 2, fromEdge ? h - 4 : h * 0.75f, w / 2, h * (fromEdge ? 0.45f : 0.25f), 350, d);
            case "down":
                return swipe(w / 2, fromEdge ? 4 : h * 0.25f, w / 2, h * (fromEdge ? 0.6f : 0.75f), 350, d);
            case "left":
                return swipe(fromEdge ? w - 4 : w * 0.8f, h / 2, w * (fromEdge ? 0.4f : 0.2f), h / 2, 350, d);
            case "right":
                return swipe(fromEdge ? 4 : w * 0.2f, h / 2, w * (fromEdge ? 0.6f : 0.8f), h / 2, 350, d);
            default:
                return false;
        }
    }

    /** Two-finger pinch around the centre of the screen. */
    static boolean pinch(boolean zoomIn, Done d) {
        int[] sz = screenSize();
        float cx = sz[0] / 2f;
        float cy = sz[1] / 2f;
        float near = sz[0] * 0.04f;
        float far = sz[0] * 0.28f;
        float from = zoomIn ? near : far;
        float to = zoomIn ? far : near;
        Path a = new Path();
        a.moveTo(cx - from, cy);
        a.lineTo(cx - to, cy);
        Path b = new Path();
        b.moveTo(cx + from, cy);
        b.lineTo(cx + to, cy);
        return dispatch(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(a, 0, 450))
                .addStroke(new GestureDescription.StrokeDescription(b, 0, 450)).build(), d);
    }

    /** Press and hold at (x1,y1), then drag to (x2,y2). */
    static boolean drag(final float x1, final float y1, final float x2, final float y2, final Done d) {
        Path hold = new Path();
        hold.moveTo(cx(x1), cy(y1));
        final GestureDescription.StrokeDescription first =
                new GestureDescription.StrokeDescription(hold, 0, 600, true);
        return dispatch(new GestureDescription.Builder().addStroke(first).build(), new Done() {
            @Override
            public void done(boolean ok) {
                if (!ok) {
                    if (d != null) {
                        d.done(false);
                    }
                    return;
                }
                Path move = new Path();
                move.moveTo(cx(x1), cy(y1));
                move.lineTo(cx(x2), cy(y2));
                GestureDescription.StrokeDescription second = first.continueStroke(move, 0, 700, false);
                if (!dispatch(new GestureDescription.Builder().addStroke(second).build(), d) && d != null) {
                    d.done(false);
                }
            }
        });
    }

    // ------------------------------------------------------------------ WhatsApp auto-send

    /** After a WhatsApp draft opens, keeps looking for the Send button for a few seconds and taps it once. */
    static void autoSend() {
        final long deadline = System.currentTimeMillis() + 9000;
        MAIN.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (trySend() || System.currentTimeMillis() > deadline) {
                    return;
                }
                MAIN.postDelayed(this, 400);
            }
        }, 900);
    }

    private static boolean trySend() {
        MyraaA11y s = instance;
        AccessibilityNodeInfo root = s == null ? null : s.getRootInActiveWindow();
        if (root == null || root.getPackageName() == null
                || !root.getPackageName().toString().startsWith("com.whatsapp")) {
            return false;
        }
        String pkg = root.getPackageName().toString();
        List<AccessibilityNodeInfo> byId = root.findAccessibilityNodeInfosByViewId(pkg + ":id/send");
        if (byId != null) {
            for (AccessibilityNodeInfo n : byId) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
        }
        List<AccessibilityNodeInfo> byText = root.findAccessibilityNodeInfosByText("Send");
        if (byText != null) {
            for (AccessibilityNodeInfo n : byText) {
                if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
        }
        return false;
    }
}
