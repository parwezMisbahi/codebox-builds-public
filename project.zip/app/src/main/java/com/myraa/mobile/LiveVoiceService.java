package com.myraa.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Foreground service that keeps the microphone alive for a Gemini Live call while MYRAA is in the
 * background, with an optional small floating chip ("MYRAA · mic on" + Stop).
 */
public final class LiveVoiceService extends Service {
    static final String STOP = "com.myraa.mobile.STOP_LIVE";
    private static final String CHANNEL = "live_voice";
    private static final int NOTIFICATION_ID = 4101;

    static volatile boolean overlayVisible;
    static volatile boolean running;

    private static volatile LiveVoiceService current;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable hideCaption = this::removeCaption;
    private TextView captionView;
    private PowerManager.WakeLock wake;
    private LinearLayout chip;
    private WindowManager windows;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            end();
            return START_NOT_STICKY;
        }

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(
                new NotificationChannel(CHANNEL, "MYRAA Live voice", NotificationManager.IMPORTANCE_LOW));

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, LiveVoiceService.class).setAction(STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.myraa_icon)
                .setContentTitle("MYRAA Live · microphone on")
                .setContentText("Listening. You can use other apps while talking. Say stop or tap Stop to end.")
                .setContentIntent(open)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_CALL)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.myraa_icon), "Stop", stop).build())
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        running = true;
        current = this;
        if (wake == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myraa:live");
            wake.acquire(2 * 60 * 60 * 1000L);
        }

        // No floating chip on screen: stop the call from the notification's Stop button.
        return START_NOT_STICKY;
    }

    /** Live subtitles over other apps: what the user says (blue) and MYRAA's reply (green). Not touchable. */
    static void caption(String role, String text, boolean appVisible) {
        LiveVoiceService s = current;
        if (s != null) {
            s.ui.post(() -> s.showCaption(role, text, appVisible));
        }
    }

    private void showCaption(String role, String text, boolean appVisible) {
        if (appVisible || text == null || text.trim().isEmpty() || !Settings.canDrawOverlays(this)) {
            removeCaption();
            return;
        }
        if (captionView == null) {
            windows = getSystemService(WindowManager.class);
            captionView = new TextView(this);
            captionView.setTextSize(18f);
            captionView.setMaxLines(4);
            captionView.setPadding(36, 22, 36, 22);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.argb(210, 16, 19, 23));
            bg.setCornerRadius(40f);
            captionView.setBackground(bg);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            params.y = 240;
            params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.9f);
            try {
                windows.addView(captionView, params);
            } catch (RuntimeException e) {
                captionView = null;
                return;
            }
        }
        captionView.setTextColor("user".equals(role) ? Color.rgb(124, 196, 255) : Color.rgb(124, 227, 161));
        captionView.setText(text);
        ui.removeCallbacks(hideCaption);
        ui.postDelayed(hideCaption, 5000);
    }

    private void removeCaption() {
        ui.removeCallbacks(hideCaption);
        if (captionView != null && windows != null) {
            try {
                windows.removeView(captionView);
            } catch (RuntimeException ignored) {
                // already detached
            }
        }
        captionView = null;
    }

    private void end() {
        removeCaption();
        // Tell the activity (and through it the web page) that the call was stopped from outside.
        sendBroadcast(new Intent(STOP).setPackage(getPackageName()));
        stopForeground(true);
        stopSelf();
        running = false;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        end();
    }

    @Override
    public void onDestroy() {
        removeCaption();
        if (current == this) {
            current = null;
        }
        if (chip != null && windows != null) {
            try {
                windows.removeView(chip);
            } catch (RuntimeException ignored) {
                // view already detached
            }
        }
        chip = null;
        overlayVisible = false;
        running = false;
        if (wake != null && wake.isHeld()) {
            wake.release();
        }
        wake = null;
        super.onDestroy();
    }
}
