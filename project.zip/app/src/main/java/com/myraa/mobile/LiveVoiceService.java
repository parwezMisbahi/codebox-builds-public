package com.myraa.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Foreground service that keeps the microphone alive for a Gemini Live call while MYRAA is in the
 * background, with an optional small floating chip ("MYRAA · mic on" + Stop).
 */
public final class LiveVoiceService extends Service {
    static final String STOP = "com.myraa.mobile.STOP_LIVE";
    private static final String CHANNEL = "live_voice";
    private static final int NOTIFICATION_ID = 4101;

    static volatile boolean overlayVisible;
    static volatile boolean running;

    private PowerManager.WakeLock wake;
    private LinearLayout chip;
    private WindowManager windows;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            end();
            return START_NOT_STICKY;
        }

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(
                new NotificationChannel(CHANNEL, "MYRAA Live voice", NotificationManager.IMPORTANCE_LOW));

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, LiveVoiceService.class).setAction(STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.myraa_icon)
                .setContentTitle("MYRAA Live · microphone on")
                .setContentText("Listening. You can use other apps while talking. Say stop or tap Stop to end.")
                .setContentIntent(open)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_CALL)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.myraa_icon), "Stop", stop).build())
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        running = true;
        if (wake == null) {
            PowerManager pm = getSystemService(PowerManager.class);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "myraa:live");
            wake.acquire(2 * 60 * 60 * 1000L);
        }

        // No floating chip on screen: stop the call from the notification's Stop button.
        return START_NOT_STICKY;
    }

    private void end() {
        // Tell the activity (and through it the web page) that the call was stopped from outside.
        sendBroadcast(new Intent(STOP).setPackage(getPackageName()));
        stopForeground(true);
        stopSelf();
        running = false;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        end();
    }

    @Override
    public void onDestroy() {
        if (chip != null && windows != null) {
            try {
                windows.removeView(chip);
            } catch (RuntimeException ignored) {
                // view already detached
            }
        }
        chip = null;
        overlayVisible = false;
        running = false;
        if (wake != null && wake.isHeld()) {
            wake.release();
        }
        wake = null;
        super.onDestroy();
    }
}
