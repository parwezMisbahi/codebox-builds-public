package com.myraa.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Bundle;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Hosts the bundled MYRAA web UI in a locked-down WebView and exposes the native services to it as
 * {@code window.MyraaNative}. Native -> web events go through {@code window.MyraaEvents(obj)}.
 *
 * Reconstructed from MYRAA Mobile 1.0.0-rc.5; behaviour follows the shipped bytecode, but code
 * structure and some constants (timeouts, history size) are best-effort.
 */
public class MainActivity extends Activity {
    private static final String TAG = "MyraaWeb";
    private static final String PREFS = "myraa.mobile.v1";
    private static final String KEY_ALIAS = "myraa.mobile.gemini.v1";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String PAGE = ORIGIN + "/assets/mobile.html";
    private static final int MICROPHONE_REQUEST = 7301;
    private static final int WAKE_REQUEST = 7302;
    private boolean wakeAfterPermission;
    private boolean wakePending;
    private static final int PERM_REQUEST = 7501;
    private static final String DEFAULT_MODEL = "gemini-3.5-flash";
    private static final String DEFAULT_LIVE_MODEL = "gemini-3.1-flash-live-preview";
    private static final String MODEL_PATTERN = "[A-Za-z0-9._-]{1,100}";
    private static final String ANDROID_NOTE =
            "You are on Android and you CAN operate this phone for the user with the mobile_action tool. "
                    + "When the user asks for something on the phone, do it with the tool instead of describing it; "
                    + "keep going step by step until the task is finished. "
                    + "Method: open the app (open_app, open_url, search_*), then read_screen to see what is visible "
                    + "(each item has @x,y), then act with tap_text, tap_xy, type_text, scroll, swipe, long_press, "
                    + "double_tap, drag, pinch, text_edit or press_key, then read_screen again to check the result. "
                    + "Use wait or wait_for_text when a page is loading. "
                    + "If an action returns blocked, permission_required or not_found, adapt (scroll, another label, "
                    + "coordinates) or tell the user exactly what to enable or do. "
                    + "Never type passwords, never operate banking or payment apps, and ask the user before anything "
                    + "that spends money, deletes data or sends a message you were not asked to send. "
                    + "To open a video or search result, read_screen and use tap_xy on that item's @x,y (video items "
                    + "usually contain 'views', 'minutes' or 'play video'); do not guess labels. "
                    + "The call keeps running while you work inside other apps. "
                    + "Only say a step happened if the tool result confirms it. "
                    + "Voice and avatar controls are available through visible buttons.";
    private static final String LIVE_NOTE =
            " This is a live voice call: speak in short natural sentences in the user's language. "
                    + "For a phone task, say in a few words what you are about to do, do it with mobile_action, "
                    + "and as soon as it is finished say clearly that the work is done (for example "
                    + "\"Kaam ho gaya\") and ask what to do next. Stay on the call and take the next command. "
                    + "If the user says stop, bas, band karo, close or goodbye, say a short goodbye and then call "
                    + "end_session. Never end the call on your own otherwise.";
    private static final int MAX_AGENT_STEPS = 25;
    private static final int HISTORY_SENT = 20;
    private static final int HISTORY_KEPT = 40;

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final ExecutorService liveNetwork = Executors.newSingleThreadExecutor();
    private final ExecutorService settingsNetwork = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger();
    private final AtomicInteger liveGeneration = new AtomicInteger();
    private final AtomicInteger settingsGeneration = new AtomicInteger();
    private final Object chatLock = new Object();
    private final Object settingsLock = new Object();
    private final GeminiAccess provider = new GeminiAccess();

    private volatile HttpsURLConnection activeConnection;
    private volatile HttpsURLConnection liveConnection;
    private volatile HttpsURLConnection settingsConnection;
    private volatile boolean foreground;
    private volatile boolean ttsReady;

    private boolean busy;
    private boolean allowBackgroundLive;
    private int rendererFailures;
    private String pendingLiveId;
    private Runnable pendingUiAction;
    private String personality = "";
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private WebView web;
    private MobileActions mobileActions;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Map<String, CompletableFuture<JSONObject>> agentWaiters = new ConcurrentHashMap<>();

    private final BroadcastReceiver stopLiveReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            cancelLive();
            if (web != null) {
                web.evaluateJavascript("window.dispatchEvent(new Event('myraa:stop-live'))", null);
            }
        }
    };

    // ====================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(16, 19, 23));
        getWindow().setNavigationBarColor(Color.rgb(16, 19, 23));

        try (InputStream in = getAssets().open("personality.txt")) {
            personality = new String(readLimited(in, 16 * 1024), StandardCharsets.UTF_8).trim();
        } catch (IOException e) {
            personality = "You are MYRAA. Match Hindi, Hinglish or English. Be honest about your capabilities.";
        }

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        emit(json("type", "speech", "active", true));
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        emit(json("type", "speech", "active", false));
                    }

                    @Override
                    public void onError(String utteranceId) {
                        emit(json("type", "speech", "active", false));
                        error("tts", null, "The installed speech engine could not speak. Text remains available.");
                    }
                });
            }
        });

        mobileActions = new MobileActions(this, (id, result) -> {
            CompletableFuture<JSONObject> waiter = agentWaiters.remove(id);
            if (waiter != null) {
                waiter.complete(result);
            } else {
                emit(json("type", "mobile-action-result", "id", id, "result", result));
            }
        });

        IntentFilter filter = new IntentFilter(LiveVoiceService.STOP);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopLiveReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stopLiveReceiver, filter);
        }

        wakePending = getIntent() != null && getIntent().getBooleanExtra(WakeWordService.EXTRA_WAKE, false);
        createWebView();
        if (WakeWordService.enabled(this) && !WakeWordService.running
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            WakeWordService.setEnabled(this, true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        if (pendingUiAction != null) {
            Runnable action = pendingUiAction;
            pendingUiAction = null;
            action.run();
        }
        if (pendingLiveId != null
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            String id = pendingLiveId;
            pendingLiveId = null;
            provisionLive(id);
        }
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:true,backgroundLive:"
                    + allowBackgroundLive + "}}))", null);
            if (wakePending) {
                wakePending = false;
                startVoiceFromWake();
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(WakeWordService.EXTRA_WAKE, false)) {
            intent.removeExtra(WakeWordService.EXTRA_WAKE);
            wakePending = true;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:false,backgroundLive:"
                    + allowBackgroundLive + ",permissionPrompt:" + (pendingLiveId != null) + "}}))", null);
            if (!(allowBackgroundLive && LiveVoiceService.running)) {
                web.onPause();
            }
        }
        if (!allowBackgroundLive && pendingLiveId == null) {
            cancelLive();
        }
        if (tts != null) {
            tts.stop();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        foreground = false;
        if (!allowBackgroundLive) {
            cancelLive();
        }
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:false,backgroundLive:"
                    + allowBackgroundLive + "}}))", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (mobileActions != null) {
            mobileActions.close();
        }
        try {
            unregisterReceiver(stopLiveReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        cancelLive();
        network.shutdownNow();
        generation.incrementAndGet();
        HttpsURLConnection c = activeConnection;
        if (c != null) {
            c.disconnect();
        }
        liveNetwork.shutdownNow();
        liveGeneration.incrementAndGet();
        settingsNetwork.shutdownNow();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (web != null) {
            web.removeJavascriptInterface("MyraaNative");
            web.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MobileActions.CONTACTS_REQUEST) {
            mobileActions.permissionResult();
            return;
        }
        if (requestCode == PERM_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] != PackageManager.PERMISSION_GRANTED
                    && permissions.length > 0 && !shouldShowRequestPermissionRationale(permissions[0])) {
                // Denied with "don't ask again": the only way left is Android's app settings page.
                try {
                    openAppDetails();
                } catch (RuntimeException ignored) {
                    // nothing more to do
                }
            }
            emit(json("type", "permissions"));
            return;
        }
        if (requestCode == WAKE_REQUEST) {
            if (wakeAfterPermission && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                WakeWordService.setEnabled(this, true);
            }
            wakeAfterPermission = false;
            return;
        }
        if (requestCode == MICROPHONE_REQUEST) {
            String id = pendingLiveId;
            pendingLiveId = null;
            if (id == null) {
                return;
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                provisionLive(id);
            } else {
                emit(json("type", "live-error", "id", id,
                        "message", "Microphone permission was denied. You can enable it in Android app settings."));
            }
        }
    }

    // ====================================================================== WebView

    private void createWebView() {
        PackageInfo webView = WebView.getCurrentWebViewPackage();
        if (webView != null && webView.versionName != null) {
            try {
                int major = Integer.parseInt(webView.versionName.split("\\.")[0]);
                if (major < 100) {
                    showWebViewError("Update Android System WebView to version 100 or later, then tap to retry. Your settings and conversations are safe.");
                    return;
                }
            } catch (NumberFormatException ignored) {
                // unknown version string: try anyway
            }
        }
        try {
            web = new WebView(this);
            web.setBackgroundColor(Color.rgb(16, 19, 23));
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setMediaPlaybackRequiresUserGesture(false);
            s.setSupportMultipleWindows(false);
            CookieManager.getInstance().setAcceptCookie(false);
            web.addJavascriptInterface(new NativeBridge(), "MyraaNative");
            web.setWebViewClient(new AppClient());
            web.setWebChromeClient(new AppChrome());
            setContentView(web);
            web.loadUrl(PAGE);
        } catch (RuntimeException e) {
            showWebViewError("Android WebView could not start. Check that Android System WebView is installed and enabled, then tap to retry.");
        }
    }

    private void showWebViewError(String message) {
        TextView view = new TextView(this);
        view.setText(message);
        view.setTextColor(Color.rgb(230, 234, 240));
        view.setBackgroundColor(Color.rgb(16, 19, 23));
        view.setPadding(48, 96, 48, 48);
        view.setGravity(Gravity.CENTER);
        view.setOnClickListener(v -> createWebView());
        setContentView(view);
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream("Blocked".getBytes(StandardCharsets.UTF_8)));
    }

    private final class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost())) {
                return blocked();
            }
            String path = uri.getPath();
            if (path == null || !path.startsWith("/assets/") || path.contains("..") || path.contains("\\")) {
                return blocked();
            }
            String asset = path.substring("/assets/".length());
            String ext = asset.contains(".") ? asset.substring(asset.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT) : "";
            String mime;
            switch (ext) {
                case "html": mime = "text/html"; break;
                case "js": mime = "text/javascript"; break;
                case "css": mime = "text/css"; break;
                case "json": mime = "application/json"; break;
                case "png": mime = "image/png"; break;
                case "jpg":
                case "jpeg": mime = "image/jpeg"; break;
                case "bmp": mime = "image/bmp"; break;
                default: mime = "application/octet-stream";
            }
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Content-Security-Policy",
                    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                            + "connect-src 'self' wss://generativelanguage.googleapis.com; object-src 'none'; "
                            + "frame-src 'none'; base-uri 'none'; form-action 'none'");
            try {
                return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, getAssets().open(asset));
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<String, String>(),
                        new ByteArrayInputStream(new byte[0]));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return true; // never navigate away from the bundled page
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            Log.i(TAG, "Bundled page ready");
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            Log.e(TAG, "Resource error " + error.getErrorCode() + ": " + request.getUrl().getPath());
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            cancelLive();
            view.destroy();
            web = null;
            rendererFailures++;
            TextView message = new TextView(MainActivity.this);
            message.setText("MYRAA's graphics engine stopped. Your settings and history are safe. Tap to retry, or restart the app.");
            message.setTextColor(Color.rgb(230, 234, 240));
            message.setBackgroundColor(Color.rgb(16, 19, 23));
            message.setPadding(48, 96, 48, 48);
            message.setOnClickListener(v -> {
                rendererFailures = 0;
                createWebView();
            });
            setContentView(message);
            return true;
        }
    }

    private final class AppChrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> {
                boolean trusted = foreground
                        && ORIGIN.equals(request.getOrigin().toString().replaceAll("/$", ""))
                        && web != null && PAGE.equals(web.getUrl())
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                boolean audioOnly = request.getResources().length == 1
                        && "android.webkit.resource.AUDIO_CAPTURE".equals(request.getResources()[0]);
                if (trusted && audioOnly) {
                    request.grant(request.getResources());
                } else {
                    request.deny();
                }
            });
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage message) {
            if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                Log.e(TAG, "Bundled page reported an error.");
            }
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("MYRAA")
                    .setMessage(message)
                    .setPositiveButton("Confirm", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }
    }

    // ====================================================================== JS bridge

    private final class NativeBridge {
        @JavascriptInterface
        public String getState() {
            return state().toString();
        }

        @JavascriptInterface
        public void chat(String text, String id) {
            startChat(id, text);
        }

        @JavascriptInterface
        public void cancel() {
            generation.incrementAndGet();
            runOnUiThread(MainActivity.this::cancelAgentActions);
            HttpsURLConnection c = activeConnection;
            if (c != null) {
                c.disconnect();
            }
            synchronized (chatLock) {
                busy = false;
            }
        }

        @JavascriptInterface
        public void configure(String json) {
            configureSettings(json, false);
        }

        @JavascriptInterface
        public void checkConnection(String json) {
            configureSettings(json, true);
        }

        @JavascriptInterface
        public void clearHistory() {
            cancel();
            prefs.edit().putString("history", "[]").commit();
        }

        @JavascriptInterface
        public void clearKey() {
            cancel();
            synchronized (settingsLock) {
                settingsGeneration.incrementAndGet();
                HttpsURLConnection c = settingsConnection;
                if (c != null) {
                    c.disconnect();
                }
            }
            prefs.edit().remove("keyCipher").remove("keyIv").remove("keyVerifiedAt")
                    .remove("verifiedModel").remove("providerErrorCode").commit();
            emit(json("type", "settings", "status", "cleared", "state", state(), "message", "Saved API key removed."));
        }

        @JavascriptInterface
        public void speak(String text) {
            speakText(text);
        }

        @JavascriptInterface
        public void stopSpeech() {
            if (tts != null) {
                tts.stop();
            }
            emit(json("type", "speech", "active", false));
        }

        @JavascriptInterface
        public void startLive(String id) {
            if (id == null || !id.matches("[A-Za-z0-9-]{1,80}")) {
                return;
            }
            runOnUiThread(() -> {
                cancelLive();
                if (!foreground) {
                    emit(json("type", "live-error", "id", id, "message", "Open MYRAA to start live voice."));
                    return;
                }
                List<String> missing = new ArrayList<>();
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(Manifest.permission.RECORD_AUDIO);
                }
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(Manifest.permission.POST_NOTIFICATIONS);
                }
                if (missing.isEmpty()) {
                    provisionLive(id);
                } else {
                    pendingLiveId = id;
                    requestPermissions(missing.toArray(new String[0]), MICROPHONE_REQUEST);
                }
            });
        }

        @JavascriptInterface
        public void endLive() {
            runOnUiThread(MainActivity.this::cancelLive);
        }

        @JavascriptInterface
        public void mobileAction(String id, String name, String argsJson) {
            if (id == null || argsJson == null || argsJson.length() > 8000) {
                return;
            }
            runOnUiThread(() -> dispatchMobileAction(id, name, argsJson));
        }

        @JavascriptInterface
        public String getPermissions() {
            return permissionsJson();
        }

        @JavascriptInterface
        public void openPermission(String key) {
            runOnUiThread(() -> openPermissionPage(key));
        }

        @JavascriptInterface
        public void cancelMobileAction(String id) {
            runOnUiThread(() -> mobileActions.cancel(id));
        }

        @JavascriptInterface
        public void openFloatingSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
        }
    }

    // ====================================================================== state / events

    private JSONObject state() {
        String model = prefs.getString("model", DEFAULT_MODEL);
        boolean keyConfigured = prefs.contains("keyCipher");
        boolean keyVerified = keyConfigured && prefs.getLong("keyVerifiedAt", 0L) > 0L
                && model.equals(prefs.getString("verifiedModel", ""));
        JSONArray history;
        try {
            history = new JSONArray(prefs.getString("history", "[]"));
        } catch (JSONException e) {
            history = new JSONArray();
        }
        return json(
                "history", history,
                "model", model,
                "quality", prefs.getString("quality", "low"),
                "language", prefs.getString("language", "hi-IN"),
                "spokenReplies", prefs.getBoolean("spokenReplies", false),
                "keyConfigured", keyConfigured,
                "keyVerified", keyVerified,
                "providerErrorCode", prefs.getString("providerErrorCode", ""),
                "ttsAvailable", ttsReady,
                "version", "1.0.0-rc.5",
                "floatingControlsAllowed", Settings.canDrawOverlays(this),
                "liveModel", prefs.getString("liveModel", DEFAULT_LIVE_MODEL));
    }

    private static JSONObject json(Object... pairs) {
        JSONObject object = new JSONObject();
        try {
            for (int i = 0; i + 1 < pairs.length; i += 2) {
                object.put(String.valueOf(pairs[i]), pairs[i + 1]);
            }
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
        return object;
    }

    private void emit(JSONObject event) {
        runOnUiThread(() -> {
            if (isFinishing() || web == null) {
                return;
            }
            web.evaluateJavascript("window.MyraaEvents&&window.MyraaEvents(" + event.toString() + ")", null);
        });
    }

    private void error(String service, String id, String message) {
        JSONObject e = json("type", "error", "service", service, "message", message);
        try {
            if (id != null) {
                e.put("id", id);
            }
        } catch (JSONException ignored) {
            // unreachable: id is a plain string
        }
        emit(e);
    }

    // ====================================================================== API key storage

    private SecretKey secretKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) {
            return (SecretKey) store.getKey(KEY_ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }

    private void writeKey(SharedPreferences.Editor editor, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey());
        byte[] encrypted = cipher.doFinal(key.getBytes(StandardCharsets.UTF_8));
        editor.putString("keyCipher", Base64.encodeToString(encrypted, Base64.NO_WRAP));
        editor.putString("keyIv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
    }

    private String readKey() {
        if (!prefs.contains("keyCipher")) {
            return "";
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            byte[] iv = Base64.decode(prefs.getString("keyIv", ""), Base64.NO_WRAP);
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), new GCMParameterSpec(128, iv));
            byte[] plain = cipher.doFinal(Base64.decode(prefs.getString("keyCipher", ""), Base64.NO_WRAP));
            return new String(plain, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static byte[] readLimited(InputStream in, int limit) throws IOException {
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = stream.read(buffer)) != -1) {
                if (out.size() + n > limit) {
                    throw new IOException("Response exceeds the size limit.");
                }
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        }
    }

    // ====================================================================== settings

    private void configureSettings(String requestJson, boolean checkOnly) {
        final JSONObject request;
        final String model;
        final String liveModel;
        final String quality;
        final String language;
        final String key;
        try {
            request = new JSONObject(requestJson);
            model = request.optString("model", prefs.getString("model", DEFAULT_MODEL)).trim();
            liveModel = request.optString("liveModel", prefs.getString("liveModel", DEFAULT_LIVE_MODEL)).trim();
            quality = request.optString("quality", prefs.getString("quality", "low"));
            language = request.optString("language", prefs.getString("language", "hi-IN"));
            key = request.optString("key", "").trim();
        } catch (JSONException e) {
            emit(json("type", "settings", "status", "error", "code", "SETTINGS_INVALID",
                    "message", "Check the model identifier, graphics, language and key fields. Previous settings were kept."));
            return;
        }
        String invalid = null;
        if (!model.matches(MODEL_PATTERN)) {
            invalid = "Enter a valid Gemini model identifier.";
        } else if (!liveModel.matches(MODEL_PATTERN)) {
            invalid = "Enter a valid Live voice model identifier.";
        } else if (!Arrays.asList("low", "balanced", "high").contains(quality)) {
            invalid = "Invalid graphics preset.";
        } else if (!Arrays.asList("hi-IN", "en-IN", "en-US").contains(language)) {
            invalid = "Invalid language.";
        }
        if (invalid != null) {
            emit(json("type", "settings", "status", "error", "code", "SETTINGS_INVALID", "message", invalid));
            return;
        }

        final int gen = settingsGeneration.incrementAndGet();
        String progress = checkOnly ? "Checking Google key and model access…"
                : key.isEmpty() ? "Saving settings…" : "Checking the new key before saving…";
        emit(json("type", "settings", "status", "checking", "message", progress));

        settingsNetwork.execute(() -> {
            try {
                String apiKey = key.isEmpty() ? readKey() : key;
                boolean mustVerify = checkOnly || !key.isEmpty();
                if (mustVerify) {
                    if (apiKey.isEmpty()) {
                        throw new GeminiAccess.Failure("KEY_MISSING", 0,
                                "Enter a new key in this field, or save one before checking the connection.");
                    }
                    provider.verify(apiKey, model, connection -> {
                        synchronized (settingsLock) {
                            settingsConnection = connection;
                            if (connection != null && settingsGeneration.get() != gen) {
                                connection.disconnect();
                            }
                        }
                    });
                }
                if (settingsGeneration.get() != gen) {
                    return;
                }
                SharedPreferences.Editor editor = prefs.edit();
                if (!checkOnly) {
                    editor.putString("model", model).putString("quality", quality)
                            .putString("language", language).putString("liveModel", liveModel);
                    if (request.has("spokenReplies")) {
                        editor.putBoolean("spokenReplies", request.optBoolean("spokenReplies"));
                    }
                    if (!key.isEmpty()) {
                        writeKey(editor, key);
                    }
                }
                if (mustVerify) {
                    editor.putLong("keyVerifiedAt", System.currentTimeMillis());
                    editor.putString("verifiedModel", model);
                    editor.remove("providerErrorCode");
                } else if (!model.equals(prefs.getString("verifiedModel", ""))) {
                    editor.remove("keyVerifiedAt").remove("verifiedModel");
                }
                boolean committed = editor.commit();
                if (settingsGeneration.get() != gen) {
                    return;
                }
                if (!committed) {
                    emit(json("type", "settings", "status", "error", "code", "SAVE_FAILED",
                            "message", "The settings could not be saved on this device."));
                    return;
                }
                emit(json("type", "settings", "status", checkOnly ? "checked" : "saved", "state", state(),
                        "message", checkOnly
                                ? "Google accepted the key and this model supports text chat. Send a message to test replies."
                                : "Settings saved."));
            } catch (GeminiAccess.Failure f) {
                if (settingsGeneration.get() == gen) {
                    emit(json("type", "settings", "status", "error", "code", f.code,
                            "message", f.getMessage() + (f.status > 0 ? " The previous key and settings were kept." : "")));
                }
            } catch (Exception e) {
                if (settingsGeneration.get() == gen) {
                    emit(json("type", "settings", "status", "error", "code", "CONNECTION_FAILED",
                            "message", "Could not check or save settings. Check your connection and try again. The previous key and settings were kept."));
                }
            }
        });
    }

    // ====================================================================== permissions list

    private static String runtimePermission(String key) {
        switch (key == null ? "" : key) {
            case "mic": return Manifest.permission.RECORD_AUDIO;
            case "contacts": return Manifest.permission.READ_CONTACTS;
            case "phone": return Manifest.permission.CALL_PHONE;
            case "sms": return Manifest.permission.SEND_SMS;
            case "answer_calls": return Manifest.permission.ANSWER_PHONE_CALLS;
            case "notifications": return Build.VERSION.SDK_INT >= 33 ? "android.permission.POST_NOTIFICATIONS" : null;
            default: return null;
        }
    }

    private boolean serviceListed(String settingName) {
        String list = Settings.Secure.getString(getContentResolver(), settingName);
        return list != null && list.contains(getPackageName() + "/");
    }

    private JSONObject permissionRow(String key, String title, String hint, String status) {
        return json("key", key, "title", title, "hint", hint, "status", status);
    }

    private String runtimeStatus(String key) {
        String perm = runtimePermission(key);
        if (perm == null) {
            return "granted";
        }
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED ? "granted" : "missing";
    }

    private String permissionsJson() {
        JSONArray out = new JSONArray();
        out.put(permissionRow("accessibility", "Accessibility: MYRAA Control",
                "Required for tap, swipe, type, scroll, screenshot and reading other apps.",
                MyraaA11y.isEnabled() || serviceListed("enabled_accessibility_services") ? "granted" : "missing"));
        out.put(permissionRow("restricted", "Restricted settings (APK installs)",
                "If Accessibility or Notification access is greyed out: App info, three-dot menu, Allow restricted settings.",
                "unknown"));
        out.put(permissionRow("overlay", "Display over other apps",
                "Needed to open apps by voice while MYRAA is in the background, and shows the small Stop chip during a call.",
                Settings.canDrawOverlays(this) ? "granted" : "missing"));
        out.put(permissionRow("mic", "Microphone", "Needed for Live voice.", runtimeStatus("mic")));
        out.put(permissionRow("wake_word", "Wake word: Hey Myraa",
                "Tap to turn on or off. MYRAA listens in the background (notification shown) and starts the voice call when you say Hey Myraa.",
                WakeWordService.enabled(this) && WakeWordService.running ? "granted" : "missing"));
        out.put(permissionRow("contacts", "Contacts", "Finds the person by name for calls and messages.", runtimeStatus("contacts")));
        out.put(permissionRow("phone", "Phone: make calls", "Places a call after you confirm.", runtimeStatus("phone")));
        out.put(permissionRow("answer_calls", "Phone: answer and end calls", "For answer call and end call commands.", runtimeStatus("answer_calls")));
        out.put(permissionRow("sms", "SMS", "Sends a text message after you confirm.", runtimeStatus("sms")));
        out.put(permissionRow("notifications", "Notifications", "Shows the Live voice call notification.", runtimeStatus("notifications")));
        out.put(permissionRow("notification_access", "Notification access",
                "Lets MYRAA read and clear your notifications when you ask.",
                serviceListed("enabled_notification_listeners") ? "granted" : "missing"));
        out.put(permissionRow("write_settings", "Modify system settings", "Needed only to change brightness.",
                Settings.System.canWrite(this) ? "granted" : "missing"));
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        out.put(permissionRow("battery", "Battery: no restrictions",
                "Keeps the call alive in the background. On Poco/HyperOS also set Battery saver to No restrictions.",
                pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()) ? "granted" : "missing"));
        out.put(permissionRow("autostart", "Autostart (Xiaomi / Poco)",
                "Turn Autostart on for MYRAA so the service restarts after Android stops it.", "unknown"));
        out.put(permissionRow("app_settings", "All app permissions", "Opens MYRAA's page in Android settings.", "unknown"));
        return out.toString();
    }

    private void toggleWakeWord() {
        if (WakeWordService.enabled(this) && WakeWordService.running) {
            WakeWordService.setEnabled(this, false);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            wakeAfterPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, WAKE_REQUEST);
            return;
        }
        WakeWordService.setEnabled(this, true);
    }

    /** Clicks the voice button once the page is ready, so "Hey Myraa" starts the Live call. */
    private void startVoiceFromWake() {
        if (web == null) {
            return;
        }
        web.evaluateJavascript("(function(){var n=0;var t=setInterval(function(){var b=document.getElementById('voice');"
                + "if(b){clearInterval(t);if(b.getAttribute('aria-pressed')!=='true'){b.click();}}"
                + "else if(++n>40){clearInterval(t);}},300);})()", null);
    }

    private void openAppDetails() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    private void openPermissionPage(String key) {
        try {
            if ("wake_word".equals(key)) {
                toggleWakeWord();
                return;
            }
            String perm = runtimePermission(key);
            if (perm != null) {
                if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
                    openAppDetails();
                } else {
                    requestPermissions(new String[]{perm}, PERM_REQUEST);
                }
                return;
            }
            Uri self = Uri.parse("package:" + getPackageName());
            switch (key == null ? "" : key) {
                case "accessibility":
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    break;
                case "notification_access":
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    break;
                case "overlay":
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, self));
                    break;
                case "write_settings":
                    startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, self));
                    break;
                case "notifications":
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                    break;
                case "battery":
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    break;
                case "autostart":
                    try {
                        startActivity(new Intent().setComponent(new ComponentName("com.miui.securitycenter",
                                "com.miui.permcenter.autostart.AutoStartManagementActivity")));
                    } catch (RuntimeException e) {
                        openAppDetails();
                    }
                    break;
                default:
                    openAppDetails();
            }
        } catch (RuntimeException e) {
            try {
                openAppDetails();
            } catch (RuntimeException ignored) {
                error("settings", null, "Android could not open that settings page.");
            }
        }
    }

    // ====================================================================== phone actions

    /** Runs one mobile_action on the UI thread, handling overlay permission and confirmation dialogs. */
    private void dispatchMobileAction(String id, String name, String argsJson) {
        String act = "";
        try {
            act = new JSONObject(argsJson).optString("action");
        } catch (JSONException ignored) {
            // fall through to execute, which reports invalid input
        }
        final boolean needsDialog = mobileActions.needsDialog(argsJson);
        final boolean screen = mobileActions.isScreenAction(argsJson);
        if (!foreground) {
            boolean launches = needsDialog || "open_app".equals(act) || "search_youtube".equals(act)
                    || "search_web".equals(act) || "play_youtube".equals(act) || "navigate".equals(act)
                    || "open_camera".equals(act) || "open_settings".equals(act)
                    || "set_alarm".equals(act) || "set_timer".equals(act) || "open_url".equals(act)
                    || "share_text".equals(act) || "app_info".equals(act);
            // Starting an activity from the background needs the overlay permission.
            if (launches && !Settings.canDrawOverlays(MainActivity.this)) {
                deliverActionResult(id, json(
                        "status", "permission_required",
                        "message", "Return to MYRAA or enable Floating voice controls in Settings to switch apps by voice while MYRAA is behind another app."));
                return;
            }
            // Confirmation dialogs need MYRAA to be visible first.
            if (needsDialog) {
                if (pendingUiAction != null) {
                    deliverActionResult(id, json("status", "busy", "message", "Finish the current confirmation first."));
                    return;
                }
                pendingUiAction = () -> mobileActions.execute(id, name, argsJson);
                startActivity(new Intent(MainActivity.this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP));
                return;
            }
        } else if (screen && !needsDialog) {
            // MYRAA is in front: step aside so the action lands on the app behind it.
            moveTaskToBack(true);
            uiHandler.postDelayed(() -> mobileActions.execute(id, name, argsJson), 800);
            return;
        }
        mobileActions.execute(id, name, argsJson);
    }

    private void deliverActionResult(String id, JSONObject result) {
        CompletableFuture<JSONObject> waiter = agentWaiters.remove(id);
        if (waiter != null) {
            waiter.complete(result);
        } else {
            emit(json("type", "mobile-action-result", "id", id, "result", result));
        }
    }

    /** Called from the chat thread: runs one tool call on the phone and waits for its result. */
    private JSONObject runAgentAction(String name, JSONObject args, int gen) {
        if (!"mobile_action".equals(name)) {
            return json("status", "unsupported", "message", "That tool is unavailable.");
        }
        final String callId = "agent-" + UUID.randomUUID();
        final CompletableFuture<JSONObject> future = new CompletableFuture<>();
        agentWaiters.put(callId, future);
        runOnUiThread(() -> dispatchMobileAction(callId, "mobile_action", args.toString()));
        try {
            return future.get(90, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            runOnUiThread(() -> mobileActions.cancel(callId));
            return json("status", "timeout", "message", "The phone action timed out.");
        } catch (Exception e) {
            return json("status", "cancelled", "message", "The action was cancelled.");
        } finally {
            agentWaiters.remove(callId);
        }
    }

    private void cancelAgentActions() {
        for (Map.Entry<String, CompletableFuture<JSONObject>> e : agentWaiters.entrySet()) {
            CompletableFuture<JSONObject> f = agentWaiters.remove(e.getKey());
            if (f != null) {
                f.complete(json("status", "cancelled", "message", "Action cancelled."));
            }
        }
    }

    private JSONObject toolDeclaration() throws IOException, JSONException {
        try (InputStream in = getAssets().open("mobile_action_tool.json")) {
            return new JSONObject(new String(readLimited(in, 64 * 1024), StandardCharsets.UTF_8));
        }
    }

    // ====================================================================== text chat

    private void startChat(String id, String text) {
        String message = text == null ? "" : text.trim();
        if (message.isEmpty() || message.length() > 8000) {
            error("text", id, "Enter a message between 1 and 8000 characters.");
            return;
        }
        final int gen;
        synchronized (chatLock) {
            if (busy) {
                error("text", id, "A reply is already running. Stop it or wait.");
                return;
            }
            busy = true;
            gen = generation.incrementAndGet();
        }
        try {
            network.execute(() -> runChat(gen, id, message));
        } catch (RuntimeException e) {
            synchronized (chatLock) {
                busy = false;
            }
            error("text", id, "Network request failed. Check your connection.");
        }
    }

    /** One generateContent request. Returns null when the chat was cancelled meanwhile. */
    private JSONObject generate(String key, String model, JSONObject body, int gen) throws Exception {
        HttpsURLConnection connection = (HttpsURLConnection) new URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
        activeConnection = connection;
        if (generation.get() != gen) {
            connection.disconnect();
            return null;
        }
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(60000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("x-goog-api-key", key);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int status = connection.getResponseCode();
            if (status >= 200 && status < 300) {
                return new JSONObject(new String(readLimited(connection.getInputStream(), 1024 * 1024), StandardCharsets.UTF_8));
            }
            String errorBody = new String(readLimited(connection.getErrorStream(), 64 * 1024), StandardCharsets.UTF_8);
            throw GeminiAccess.failure(status, errorBody);
        } finally {
            connection.disconnect();
        }
    }

    private void runChat(int gen, String id, String text) {
        try {
            String key = readKey();
            if (key.isEmpty()) {
                error("text", id, "Add your Gemini API key in Settings.");
                return;
            }
            String model = prefs.getString("model", DEFAULT_MODEL);
            if (!model.matches(MODEL_PATTERN)) {
                error("text", id, "Invalid saved model identifier.");
                return;
            }

            JSONArray history = new JSONArray(prefs.getString("history", "[]"));
            JSONArray contents = new JSONArray();
            for (int i = Math.max(0, history.length() - HISTORY_SENT); i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                contents.put(json("role", entry.getString("role"),
                        "parts", new JSONArray().put(json("text", entry.getString("text")))));
            }
            contents.put(json("role", "user", "parts", new JSONArray().put(json("text", text))));

            JSONArray tools = new JSONArray().put(json("functionDeclarations", new JSONArray().put(toolDeclaration())));
            String answer;
            int steps = 0;
            // Agent loop: the model may call mobile_action several times (read screen, tap, type...)
            // before it gives its final text reply.
            while (true) {
                JSONObject body = json(
                        "systemInstruction", json("parts", new JSONArray().put(json("text", personality + "\n\n" + ANDROID_NOTE))),
                        "contents", contents,
                        "tools", tools,
                        "generationConfig", json("maxOutputTokens", 2048));
                JSONObject response = generate(key, model, body, gen);
                if (response == null || generation.get() != gen) {
                    return;
                }
                JSONArray candidates = response.optJSONArray("candidates");
                JSONObject content = candidates == null || candidates.length() == 0
                        ? null : candidates.getJSONObject(0).optJSONObject("content");
                if (content == null) {
                    error("text", id, "No reply was returned. The request may have been blocked by the provider.");
                    return;
                }
                JSONArray parts = content.optJSONArray("parts");
                if (parts == null) {
                    parts = new JSONArray();
                }
                StringBuilder reply = new StringBuilder();
                List<JSONObject> calls = new ArrayList<>();
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.getJSONObject(i);
                    JSONObject call = part.optJSONObject("functionCall");
                    if (call != null) {
                        calls.add(call);
                    } else if (!part.optBoolean("thought")) {
                        reply.append(part.optString("text"));
                    }
                }
                if (calls.isEmpty()) {
                    answer = reply.toString().trim();
                    break;
                }
                if (++steps > MAX_AGENT_STEPS) {
                    answer = "I stopped after " + MAX_AGENT_STEPS + " steps without finishing. Tell me what to do next.";
                    break;
                }
                // Keep the model turn exactly as returned (it may carry thought signatures).
                if (!content.has("role")) {
                    content.put("role", "model");
                }
                contents.put(content);
                JSONArray results = new JSONArray();
                for (JSONObject call : calls) {
                    if (generation.get() != gen) {
                        return;
                    }
                    String name = call.optString("name");
                    JSONObject args = call.optJSONObject("args");
                    JSONObject outcome = runAgentAction(name, args == null ? new JSONObject() : args, gen);
                    results.put(json("functionResponse", json("name", name, "response", json("result", outcome))));
                }
                contents.put(json("role", "user", "parts", results));
            }
            if (generation.get() != gen) {
                return;
            }
            if (answer.isEmpty()) {
                error("text", id, "The provider returned no text reply.");
                return;
            }

            JSONArray saved = new JSONArray();
            for (int i = Math.max(0, history.length() + 2 - HISTORY_KEPT); i < history.length(); i++) {
                saved.put(history.getJSONObject(i));
            }
            long now = System.currentTimeMillis();
            saved.put(json("role", "user", "text", text, "at", now));
            saved.put(json("role", "model", "text", answer, "at", now));
            boolean persisted = prefs.edit().putString("history", saved.toString()).remove("providerErrorCode").commit();
            emit(json("type", "reply", "id", id, "text", answer));
            if (!persisted) {
                error("text", id, "The reply arrived but history could not be saved.");
            }
            if (prefs.getBoolean("spokenReplies", false)) {
                speakText(answer);
            }
        } catch (GeminiAccess.Failure f) {
            if (generation.get() == gen) {
                prefs.edit().putString("providerErrorCode", f.code).putLong("keyVerifiedAt", 0L).commit();
                error("text", id, f.getMessage());
            }
        } catch (SocketTimeoutException e) {
            if (generation.get() == gen) {
                error("text", id, "The provider timed out. Your previous conversation is safe.");
            }
        } catch (Exception e) {
            if (generation.get() == gen) {
                error("text", id, "Network request failed. Check your connection.");
            }
        } finally {
            if (generation.get() == gen) {
                synchronized (chatLock) {
                    busy = false;
                }
            }
        }
    }

    // ====================================================================== speech

    private void speakText(String text) {
        runOnUiThread(() -> {
            if (!ttsReady || tts == null) {
                error("tts", null, "No ready Android text-to-speech engine is available. Text chat still works.");
                return;
            }
            Locale locale = Locale.forLanguageTag(prefs.getString("language", "hi-IN"));
            int language = tts.setLanguage(locale);
            if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                error("tts", null, "This speech engine does not have the selected language installed.");
                return;
            }
            int max = Math.max(200, TextToSpeech.getMaxSpeechInputLength());
            for (int start = 0; start < text.length(); start += max) {
                String chunk = text.substring(start, Math.min(text.length(), start + max));
                int mode = start == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
                if (tts.speak(chunk, mode, null, "myraa-reply") != TextToSpeech.SUCCESS) {
                    error("tts", null, "The installed speech engine could not start.");
                    return;
                }
            }
        });
    }

    // ====================================================================== Gemini Live

    private void cancelLive() {
        liveGeneration.incrementAndGet();
        pendingLiveId = null;
        stopService(new Intent(this, LiveVoiceService.class));
        HttpsURLConnection c = liveConnection;
        if (c != null) {
            c.disconnect();
        }
    }

    /** Starts the mic foreground service, then fetches a one-use Live token and hands it to the page. */
    private void provisionLive(String id) {
        final int gen = liveGeneration.incrementAndGet();
        // The call lives in a foreground service with a notification, so it never depends on the overlay permission.
        allowBackgroundLive = true;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            Intent service = new Intent(this, LiveVoiceService.class);
            try {
                startForegroundService(service);
            } catch (RuntimeException e) {
                emit(json("type", "live-error", "id", id,
                        "message", "Could not start Gemini Live. Check the saved key, network and Live model access in Settings."));
                return;
            }
        }
        liveNetwork.execute(() -> {
            try {
                String key = readKey();
                if (key.isEmpty()) {
                    throw new IOException("Missing key");
                }
                String token = provider.createLiveToken(key, connection -> {
                    liveConnection = connection;
                    if (connection != null && liveGeneration.get() != gen) {
                        connection.disconnect();
                    }
                });
                if (liveGeneration.get() != gen) {
                    return;
                }
                String liveModel = prefs.getString("liveModel", DEFAULT_LIVE_MODEL);
                if (!liveModel.matches(MODEL_PATTERN)) {
                    liveModel = DEFAULT_LIVE_MODEL;
                }
                final String model = liveModel;
                runOnUiThread(() -> emit(json(
                        "type", "live-token", "id", id, "token", token, "model", model, "voice", "Aoede",
                        "backgroundLive", allowBackgroundLive,
                        "instruction", personality + "\n\n" + ANDROID_NOTE + LIVE_NOTE)));
            } catch (Exception e) {
                if (liveGeneration.get() == gen) {
                    runOnUiThread(MainActivity.this::cancelLive);
                    String message = e instanceof GeminiAccess.Failure
                            ? e.getMessage()
                            : "Could not start Gemini Live. Check the saved key, network and Live model access in Settings.";
                    emit(json("type", "live-error", "id", id, "message", message));
                }
            }
        });
    }
}
