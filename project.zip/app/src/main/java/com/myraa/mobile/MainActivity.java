package com.myraa.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Hosts the bundled MYRAA web UI in a locked-down WebView and exposes the native services to it as
 * {@code window.MyraaNative}. Native -> web events go through {@code window.MyraaEvents(obj)}.
 *
 * Reconstructed from MYRAA Mobile 1.0.0-rc.5; behaviour follows the shipped bytecode, but code
 * structure and some constants (timeouts, history size) are best-effort.
 */
public class MainActivity extends Activity {
    private static final String TAG = "MyraaWeb";
    private static final String PREFS = "myraa.mobile.v1";
    private static final String KEY_ALIAS = "myraa.mobile.gemini.v1";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String PAGE = ORIGIN + "/assets/mobile.html";
    private static final int MICROPHONE_REQUEST = 7301;
    private static final String DEFAULT_MODEL = "gemini-3.5-flash";
    private static final String DEFAULT_LIVE_MODEL = "gemini-3.1-flash-live-preview";
    private static final String MODEL_PATTERN = "[A-Za-z0-9._-]{1,100}";
    private static final String ANDROID_NOTE =
            "You are on Android. You cannot control other apps or files. Do not claim a device action occurred. "
                    + "Voice and avatar controls are available through visible buttons.";
    private static final int HISTORY_SENT = 20;
    private static final int HISTORY_KEPT = 40;

    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final ExecutorService liveNetwork = Executors.newSingleThreadExecutor();
    private final ExecutorService settingsNetwork = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger();
    private final AtomicInteger liveGeneration = new AtomicInteger();
    private final AtomicInteger settingsGeneration = new AtomicInteger();
    private final Object chatLock = new Object();
    private final Object settingsLock = new Object();
    private final GeminiAccess provider = new GeminiAccess();

    private volatile HttpsURLConnection activeConnection;
    private volatile HttpsURLConnection liveConnection;
    private volatile HttpsURLConnection settingsConnection;
    private volatile boolean foreground;
    private volatile boolean ttsReady;

    private boolean busy;
    private boolean allowBackgroundLive;
    private int rendererFailures;
    private String pendingLiveId;
    private Runnable pendingUiAction;
    private String personality = "";
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private WebView web;
    private MobileActions mobileActions;

    private final BroadcastReceiver stopLiveReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            cancelLive();
            if (web != null) {
                web.evaluateJavascript("window.dispatchEvent(new Event('myraa:stop-live'))", null);
            }
        }
    };

    // ====================================================================== lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(16, 19, 23));
        getWindow().setNavigationBarColor(Color.rgb(16, 19, 23));

        try (InputStream in = getAssets().open("personality.txt")) {
            personality = new String(readLimited(in, 16 * 1024), StandardCharsets.UTF_8).trim();
        } catch (IOException e) {
            personality = "You are MYRAA. Match Hindi, Hinglish or English. Be honest about your capabilities.";
        }

        tts = new TextToSpeech(this, status -> {
            ttsReady = status == TextToSpeech.SUCCESS;
            if (ttsReady) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        emit(json("type", "speech", "active", true));
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        emit(json("type", "speech", "active", false));
                    }

                    @Override
                    public void onError(String utteranceId) {
                        emit(json("type", "speech", "active", false));
                        error("tts", null, "The installed speech engine could not speak. Text remains available.");
                    }
                });
            }
        });

        mobileActions = new MobileActions(this, (id, result) ->
                emit(json("type", "mobile-action-result", "id", id, "result", result)));

        IntentFilter filter = new IntentFilter(LiveVoiceService.STOP);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopLiveReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stopLiveReceiver, filter);
        }

        createWebView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        if (pendingUiAction != null) {
            Runnable action = pendingUiAction;
            pendingUiAction = null;
            action.run();
        }
        if (pendingLiveId != null
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            String id = pendingLiveId;
            pendingLiveId = null;
            provisionLive(id);
        }
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:true,backgroundLive:"
                    + allowBackgroundLive + "}}))", null);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:false,backgroundLive:"
                    + allowBackgroundLive + ",permissionPrompt:" + (pendingLiveId != null) + "}}))", null);
            web.onPause();
        }
        if (!allowBackgroundLive && pendingLiveId == null) {
            cancelLive();
        }
        if (tts != null) {
            tts.stop();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        foreground = false;
        if (!allowBackgroundLive) {
            cancelLive();
        }
        if (web != null) {
            web.evaluateJavascript("window.dispatchEvent(new CustomEvent('myraa:lifecycle',{detail:{active:false}}))", null);
        }
    }

    @Override
    protected void onDestroy() {
        if (mobileActions != null) {
            mobileActions.close();
        }
        try {
            unregisterReceiver(stopLiveReceiver);
        } catch (IllegalArgumentException ignored) {
            // not registered
        }
        cancelLive();
        network.shutdownNow();
        generation.incrementAndGet();
        HttpsURLConnection c = activeConnection;
        if (c != null) {
            c.disconnect();
        }
        liveNetwork.shutdownNow();
        liveGeneration.incrementAndGet();
        settingsNetwork.shutdownNow();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (web != null) {
            web.removeJavascriptInterface("MyraaNative");
            web.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MobileActions.CONTACTS_REQUEST) {
            mobileActions.permissionResult();
            return;
        }
        if (requestCode == MICROPHONE_REQUEST) {
            String id = pendingLiveId;
            pendingLiveId = null;
            if (id == null) {
                return;
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                provisionLive(id);
            } else {
                emit(json("type", "live-error", "id", id,
                        "message", "Microphone permission was denied. You can enable it in Android app settings."));
            }
        }
    }

    // ====================================================================== WebView

    private void createWebView() {
        PackageInfo webView = WebView.getCurrentWebViewPackage();
        if (webView != null && webView.versionName != null) {
            try {
                int major = Integer.parseInt(webView.versionName.split("\\.")[0]);
                if (major < 100) {
                    showWebViewError("Update Android System WebView to version 100 or later, then tap to retry. Your settings and conversations are safe.");
                    return;
                }
            } catch (NumberFormatException ignored) {
                // unknown version string: try anyway
            }
        }
        try {
            web = new WebView(this);
            web.setBackgroundColor(Color.rgb(16, 19, 23));
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setMediaPlaybackRequiresUserGesture(false);
            s.setSupportMultipleWindows(false);
            CookieManager.getInstance().setAcceptCookie(false);
            web.addJavascriptInterface(new NativeBridge(), "MyraaNative");
            web.setWebViewClient(new AppClient());
            web.setWebChromeClient(new AppChrome());
            setContentView(web);
            web.loadUrl(PAGE);
        } catch (RuntimeException e) {
            showWebViewError("Android WebView could not start. Check that Android System WebView is installed and enabled, then tap to retry.");
        }
    }

    private void showWebViewError(String message) {
        TextView view = new TextView(this);
        view.setText(message);
        view.setTextColor(Color.rgb(230, 234, 240));
        view.setBackgroundColor(Color.rgb(16, 19, 23));
        view.setPadding(48, 96, 48, 48);
        view.setGravity(Gravity.CENTER);
        view.setOnClickListener(v -> createWebView());
        setContentView(view);
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream("Blocked".getBytes(StandardCharsets.UTF_8)));
    }

    private final class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost())) {
                return blocked();
            }
            String path = uri.getPath();
            if (path == null || !path.startsWith("/assets/") || path.contains("..") || path.contains("\\")) {
                return blocked();
            }
            String asset = path.substring("/assets/".length());
            String ext = asset.contains(".") ? asset.substring(asset.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT) : "";
            String mime;
            switch (ext) {
                case "html": mime = "text/html"; break;
                case "js": mime = "text/javascript"; break;
                case "css": mime = "text/css"; break;
                case "json": mime = "application/json"; break;
                case "png": mime = "image/png"; break;
                case "jpg":
                case "jpeg": mime = "image/jpeg"; break;
                case "bmp": mime = "image/bmp"; break;
                default: mime = "application/octet-stream";
            }
            Map<String, String> headers = new HashMap<>();
            headers.put("X-Content-Type-Options", "nosniff");
            headers.put("Content-Security-Policy",
                    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                            + "connect-src 'self' wss://generativelanguage.googleapis.com; object-src 'none'; "
                            + "frame-src 'none'; base-uri 'none'; form-action 'none'");
            try {
                return new WebResourceResponse(mime, "UTF-8", 200, "OK", headers, getAssets().open(asset));
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<String, String>(),
                        new ByteArrayInputStream(new byte[0]));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return true; // never navigate away from the bundled page
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            Log.i(TAG, "Bundled page ready");
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            Log.e(TAG, "Resource error " + error.getErrorCode() + ": " + request.getUrl().getPath());
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            cancelLive();
            view.destroy();
            web = null;
            rendererFailures++;
            TextView message = new TextView(MainActivity.this);
            message.setText("MYRAA's graphics engine stopped. Your settings and history are safe. Tap to retry, or restart the app.");
            message.setTextColor(Color.rgb(230, 234, 240));
            message.setBackgroundColor(Color.rgb(16, 19, 23));
            message.setPadding(48, 96, 48, 48);
            message.setOnClickListener(v -> {
                rendererFailures = 0;
                createWebView();
            });
            setContentView(message);
            return true;
        }
    }

    private final class AppChrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> {
                boolean trusted = foreground
                        && ORIGIN.equals(request.getOrigin().toString().replaceAll("/$", ""))
                        && web != null && PAGE.equals(web.getUrl())
                        && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                boolean audioOnly = request.getResources().length == 1
                        && "android.webkit.resource.AUDIO_CAPTURE".equals(request.getResources()[0]);
                if (trusted && audioOnly) {
                    request.grant(request.getResources());
                } else {
                    request.deny();
                }
            });
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage message) {
            if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                Log.e(TAG, "Bundled page reported an error.");
            }
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("MYRAA")
                    .setMessage(message)
                    .setPositiveButton("Confirm", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .show();
            return true;
        }
    }

    // ====================================================================== JS bridge

    private final class NativeBridge {
        @JavascriptInterface
        public String getState() {
            return state().toString();
        }

        @JavascriptInterface
        public void chat(String text, String id) {
            startChat(id, text);
        }

        @JavascriptInterface
        public void cancel() {
            generation.incrementAndGet();
            HttpsURLConnection c = activeConnection;
            if (c != null) {
                c.disconnect();
            }
            synchronized (chatLock) {
                busy = false;
            }
        }

        @JavascriptInterface
        public void configure(String json) {
            configureSettings(json, false);
        }

        @JavascriptInterface
        public void checkConnection(String json) {
            configureSettings(json, true);
        }

        @JavascriptInterface
        public void clearHistory() {
            cancel();
            prefs.edit().putString("history", "[]").commit();
        }

        @JavascriptInterface
        public void clearKey() {
            cancel();
            synchronized (settingsLock) {
                settingsGeneration.incrementAndGet();
                HttpsURLConnection c = settingsConnection;
                if (c != null) {
                    c.disconnect();
                }
            }
            prefs.edit().remove("keyCipher").remove("keyIv").remove("keyVerifiedAt")
                    .remove("verifiedModel").remove("providerErrorCode").commit();
            emit(json("type", "settings", "status", "cleared", "state", state(), "message", "Saved API key removed."));
        }

        @JavascriptInterface
        public void speak(String text) {
            speakText(text);
        }

        @JavascriptInterface
        public void stopSpeech() {
            if (tts != null) {
                tts.stop();
            }
            emit(json("type", "speech", "active", false));
        }

        @JavascriptInterface
        public void startLive(String id) {
            if (id == null || !id.matches("[A-Za-z0-9-]{1,80}")) {
                return;
            }
            runOnUiThread(() -> {
                cancelLive();
                if (!foreground) {
                    emit(json("type", "live-error", "id", id, "message", "Open MYRAA to start live voice."));
                    return;
                }
                List<String> missing = new ArrayList<>();
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(Manifest.permission.RECORD_AUDIO);
                }
                if (Build.VERSION.SDK_INT >= 33
                        && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(Manifest.permission.POST_NOTIFICATIONS);
                }
                if (missing.isEmpty()) {
                    provisionLive(id);
                } else {
                    pendingLiveId = id;
                    requestPermissions(missing.toArray(new String[0]), MICROPHONE_REQUEST);
                }
            });
        }

        @JavascriptInterface
        public void endLive() {
            runOnUiThread(MainActivity.this::cancelLive);
        }

        @JavascriptInterface
        public void mobileAction(String id, String name, String argsJson) {
            if (id == null || argsJson == null || argsJson.length() > 8000) {
                return;
            }
            runOnUiThread(() -> {
                if (!foreground) {
                    // Contact pickers need a visible activity; other actions need overlay permission to start from background.
                    if (!Settings.canDrawOverlays(MainActivity.this)) {
                        emit(json("type", "mobile-action-result", "id", id, "result", json(
                                "status", "permission_required",
                                "message", "Return to MYRAA or enable Floating voice controls in Settings to switch apps by voice while MYRAA is behind another app.")));
                        return;
                    }
                    boolean whatsappDraft = false;
                    try {
                        whatsappDraft = "whatsapp_message".equals(new JSONObject(argsJson).optString("action"));
                    } catch (JSONException ignored) {
                        // fall through to execute, which reports invalid input
                    }
                    if (whatsappDraft) {
                        if (pendingUiAction != null) {
                            emit(json("type", "mobile-action-result", "id", id, "result", json(
                                    "status", "busy", "message", "Finish the current recipient selection first.")));
                            return;
                        }
                        pendingUiAction = () -> mobileActions.execute(id, name, argsJson);
                        startActivity(new Intent(MainActivity.this, MainActivity.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP));
                        return;
                    }
                }
                mobileActions.execute(id, name, argsJson);
            });
        }

        @JavascriptInterface
        public void cancelMobileAction(String id) {
            runOnUiThread(() -> mobileActions.cancel(id));
        }

        @JavascriptInterface
        public void openFloatingSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()))));
        }
    }

    // ====================================================================== state / events

    private JSONObject state() {
        String model = prefs.getString("model", DEFAULT_MODEL);
        boolean keyConfigured = prefs.contains("keyCipher");
        boolean keyVerified = keyConfigured && prefs.getLong("keyVerifiedAt", 0L) > 0L
                && model.equals(prefs.getString("verifiedModel", ""));
        JSONArray history;
        try {
            history = new JSONArray(prefs.getString("history", "[]"));
        } catch (JSONException e) {
            history = new JSONArray();
        }
        return json(
                "history", history,
                "model", model,
                "quality", prefs.getString("quality", "low"),
                "language", prefs.getString("language", "hi-IN"),
                "spokenReplies", prefs.getBoolean("spokenReplies", false),
                "keyConfigured", keyConfigured,
                "keyVerified", keyVerified,
                "providerErrorCode", prefs.getString("providerErrorCode", ""),
                "ttsAvailable", ttsReady,
                "version", "1.0.0-rc.5",
                "floatingControlsAllowed", Settings.canDrawOverlays(this),
                "liveModel", prefs.getString("liveModel", DEFAULT_LIVE_MODEL));
    }

    private static JSONObject json(Object... pairs) {
        JSONObject object = new JSONObject();
        try {
            for (int i = 0; i + 1 < pairs.length; i += 2) {
                object.put(String.valueOf(pairs[i]), pairs[i + 1]);
            }
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
        return object;
    }

    private void emit(JSONObject event) {
        runOnUiThread(() -> {
            if (isFinishing() || web == null) {
                return;
            }
            web.evaluateJavascript("window.MyraaEvents&&window.MyraaEvents(" + event.toString() + ")", null);
        });
    }

    private void error(String service, String id, String message) {
        JSONObject e = json("type", "error", "service", service, "message", message);
        try {
            if (id != null) {
                e.put("id", id);
            }
        } catch (JSONException ignored) {
            // unreachable: id is a plain string
        }
        emit(e);
    }

    // ====================================================================== API key storage

    private SecretKey secretKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (store.containsAlias(KEY_ALIAS)) {
            return (SecretKey) store.getKey(KEY_ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }

    private void writeKey(SharedPreferences.Editor editor, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey());
        byte[] encrypted = cipher.doFinal(key.getBytes(StandardCharsets.UTF_8));
        editor.putString("keyCipher", Base64.encodeToString(encrypted, Base64.NO_WRAP));
        editor.putString("keyIv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
    }

    private String readKey() {
        if (!prefs.contains("keyCipher")) {
            return "";
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            byte[] iv = Base64.decode(prefs.getString("keyIv", ""), Base64.NO_WRAP);
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), new GCMParameterSpec(128, iv));
            byte[] plain = cipher.doFinal(Base64.decode(prefs.getString("keyCipher", ""), Base64.NO_WRAP));
            return new String(plain, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static byte[] readLimited(InputStream in, int limit) throws IOException {
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = stream.read(buffer)) != -1) {
                if (out.size() + n > limit) {
                    throw new IOException("Response exceeds the size limit.");
                }
                out.write(buffer, 0, n);
            }
            return out.toByteArray();
        }
    }

    // ====================================================================== settings

    private void configureSettings(String requestJson, boolean checkOnly) {
        final JSONObject request;
        final String model;
        final String liveModel;
        final String quality;
        final String language;
        final String key;
        try {
            request = new JSONObject(requestJson);
            model = request.optString("model", prefs.getString("model", DEFAULT_MODEL)).trim();
            liveModel = request.optString("liveModel", prefs.getString("liveModel", DEFAULT_LIVE_MODEL)).trim();
            quality = request.optString("quality", prefs.getString("quality", "low"));
            language = request.optString("language", prefs.getString("language", "hi-IN"));
            key = request.optString("key", "").trim();
        } catch (JSONException e) {
            emit(json("type", "settings", "status", "error", "code", "SETTINGS_INVALID",
                    "message", "Check the model identifier, graphics, language and key fields. Previous settings were kept."));
            return;
        }
        String invalid = null;
        if (!model.matches(MODEL_PATTERN)) {
            invalid = "Enter a valid Gemini model identifier.";
        } else if (!liveModel.matches(MODEL_PATTERN)) {
            invalid = "Enter a valid Live voice model identifier.";
        } else if (!Arrays.asList("low", "balanced", "high").contains(quality)) {
            invalid = "Invalid graphics preset.";
        } else if (!Arrays.asList("hi-IN", "en-IN", "en-US").contains(language)) {
            invalid = "Invalid language.";
        }
        if (invalid != null) {
            emit(json("type", "settings", "status", "error", "code", "SETTINGS_INVALID", "message", invalid));
            return;
        }

        final int gen = settingsGeneration.incrementAndGet();
        String progress = checkOnly ? "Checking Google key and model access…"
                : key.isEmpty() ? "Saving settings…" : "Checking the new key before saving…";
        emit(json("type", "settings", "status", "checking", "message", progress));

        settingsNetwork.execute(() -> {
            try {
                String apiKey = key.isEmpty() ? readKey() : key;
                boolean mustVerify = checkOnly || !key.isEmpty();
                if (mustVerify) {
                    if (apiKey.isEmpty()) {
                        throw new GeminiAccess.Failure("KEY_MISSING", 0,
                                "Enter a new key in this field, or save one before checking the connection.");
                    }
                    provider.verify(apiKey, model, connection -> {
                        synchronized (settingsLock) {
                            settingsConnection = connection;
                            if (connection != null && settingsGeneration.get() != gen) {
                                connection.disconnect();
                            }
                        }
                    });
                }
                if (settingsGeneration.get() != gen) {
                    return;
                }
                SharedPreferences.Editor editor = prefs.edit();
                if (!checkOnly) {
                    editor.putString("model", model).putString("quality", quality)
                            .putString("language", language).putString("liveModel", liveModel);
                    if (request.has("spokenReplies")) {
                        editor.putBoolean("spokenReplies", request.optBoolean("spokenReplies"));
                    }
                    if (!key.isEmpty()) {
                        writeKey(editor, key);
                    }
                }
                if (mustVerify) {
                    editor.putLong("keyVerifiedAt", System.currentTimeMillis());
                    editor.putString("verifiedModel", model);
                    editor.remove("providerErrorCode");
                } else if (!model.equals(prefs.getString("verifiedModel", ""))) {
                    editor.remove("keyVerifiedAt").remove("verifiedModel");
                }
                boolean committed = editor.commit();
                if (settingsGeneration.get() != gen) {
                    return;
                }
                if (!committed) {
                    emit(json("type", "settings", "status", "error", "code", "SAVE_FAILED",
                            "message", "The settings could not be saved on this device."));
                    return;
                }
                emit(json("type", "settings", "status", checkOnly ? "checked" : "saved", "state", state(),
                        "message", checkOnly
                                ? "Google accepted the key and this model supports text chat. Send a message to test replies."
                                : "Settings saved."));
            } catch (GeminiAccess.Failure f) {
                if (settingsGeneration.get() == gen) {
                    emit(json("type", "settings", "status", "error", "code", f.code,
                            "message", f.getMessage() + (f.status > 0 ? " The previous key and settings were kept." : "")));
                }
            } catch (Exception e) {
                if (settingsGeneration.get() == gen) {
                    emit(json("type", "settings", "status", "error", "code", "CONNECTION_FAILED",
                            "message", "Could not check or save settings. Check your connection and try again. The previous key and settings were kept."));
                }
            }
        });
    }

    // ====================================================================== text chat

    private void startChat(String id, String text) {
        String message = text == null ? "" : text.trim();
        if (message.isEmpty() || message.length() > 8000) {
            error("text", id, "Enter a message between 1 and 8000 characters.");
            return;
        }
        final int gen;
        synchronized (chatLock) {
            if (busy) {
                error("text", id, "A reply is already running. Stop it or wait.");
                return;
            }
            busy = true;
            gen = generation.incrementAndGet();
        }
        try {
            network.execute(() -> runChat(gen, id, message));
        } catch (RuntimeException e) {
            synchronized (chatLock) {
                busy = false;
            }
            error("text", id, "Network request failed. Check your connection.");
        }
    }

    private void runChat(int gen, String id, String text) {
        try {
            String key = readKey();
            if (key.isEmpty()) {
                error("text", id, "Add your Gemini API key in Settings.");
                return;
            }
            String model = prefs.getString("model", DEFAULT_MODEL);
            if (!model.matches(MODEL_PATTERN)) {
                error("text", id, "Invalid saved model identifier.");
                return;
            }

            JSONArray history = new JSONArray(prefs.getString("history", "[]"));
            JSONArray contents = new JSONArray();
            for (int i = Math.max(0, history.length() - HISTORY_SENT); i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                contents.put(json("role", entry.getString("role"),
                        "parts", new JSONArray().put(json("text", entry.getString("text")))));
            }
            contents.put(json("role", "user", "parts", new JSONArray().put(json("text", text))));

            JSONObject body = json(
                    "systemInstruction", json("parts", new JSONArray().put(json("text", personality + "\n\n" + ANDROID_NOTE))),
                    "contents", contents,
                    "generationConfig", json("maxOutputTokens", 1024));

            HttpsURLConnection connection = (HttpsURLConnection) new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
            activeConnection = connection;
            if (generation.get() != gen) {
                connection.disconnect();
                return;
            }
            try {
                connection.setInstanceFollowRedirects(false);
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(60000);
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("x-goog-api-key", key);
                try (OutputStream out = connection.getOutputStream()) {
                    out.write(body.toString().getBytes(StandardCharsets.UTF_8));
                }
                int status = connection.getResponseCode();
                String payload;
                if (status >= 200 && status < 300) {
                    payload = new String(readLimited(connection.getInputStream(), 1024 * 1024), StandardCharsets.UTF_8);
                } else {
                    String errorBody = new String(readLimited(connection.getErrorStream(), 64 * 1024), StandardCharsets.UTF_8);
                    throw GeminiAccess.failure(status, errorBody);
                }

                JSONObject response = new JSONObject(payload);
                JSONArray candidates = response.optJSONArray("candidates");
                if (candidates == null || candidates.length() == 0) {
                    error("text", id, "No reply was returned. The request may have been blocked by the provider.");
                    return;
                }
                StringBuilder reply = new StringBuilder();
                JSONArray parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts");
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.getJSONObject(i);
                    if (!part.optBoolean("thought")) {
                        reply.append(part.optString("text"));
                    }
                }
                String answer = reply.toString().trim();
                if (generation.get() != gen) {
                    return;
                }
                if (answer.isEmpty()) {
                    error("text", id, "The provider returned no text reply.");
                    return;
                }

                JSONArray saved = new JSONArray();
                for (int i = Math.max(0, history.length() + 2 - HISTORY_KEPT); i < history.length(); i++) {
                    saved.put(history.getJSONObject(i));
                }
                long now = System.currentTimeMillis();
                saved.put(json("role", "user", "text", text, "at", now));
                saved.put(json("role", "model", "text", answer, "at", now));
                boolean persisted = prefs.edit().putString("history", saved.toString()).remove("providerErrorCode").commit();
                emit(json("type", "reply", "id", id, "text", answer));
                if (!persisted) {
                    error("text", id, "The reply arrived but history could not be saved.");
                }
                if (prefs.getBoolean("spokenReplies", false)) {
                    speakText(answer);
                }
            } finally {
                connection.disconnect();
            }
        } catch (GeminiAccess.Failure f) {
            if (generation.get() == gen) {
                prefs.edit().putString("providerErrorCode", f.code).putLong("keyVerifiedAt", 0L).commit();
                error("text", id, f.getMessage());
            }
        } catch (SocketTimeoutException e) {
            if (generation.get() == gen) {
                error("text", id, "The provider timed out. Your previous conversation is safe.");
            }
        } catch (Exception e) {
            if (generation.get() == gen) {
                error("text", id, "Network request failed. Check your connection.");
            }
        } finally {
            if (generation.get() == gen) {
                synchronized (chatLock) {
                    busy = false;
                }
            }
        }
    }

    // ====================================================================== speech

    private void speakText(String text) {
        runOnUiThread(() -> {
            if (!ttsReady || tts == null) {
                error("tts", null, "No ready Android text-to-speech engine is available. Text chat still works.");
                return;
            }
            Locale locale = Locale.forLanguageTag(prefs.getString("language", "hi-IN"));
            int language = tts.setLanguage(locale);
            if (language == TextToSpeech.LANG_MISSING_DATA || language == TextToSpeech.LANG_NOT_SUPPORTED) {
                error("tts", null, "This speech engine does not have the selected language installed.");
                return;
            }
            int max = Math.max(200, TextToSpeech.getMaxSpeechInputLength());
            for (int start = 0; start < text.length(); start += max) {
                String chunk = text.substring(start, Math.min(text.length(), start + max));
                int mode = start == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
                if (tts.speak(chunk, mode, null, "myraa-reply") != TextToSpeech.SUCCESS) {
                    error("tts", null, "The installed speech engine could not start.");
                    return;
                }
            }
        });
    }

    // ====================================================================== Gemini Live

    private void cancelLive() {
        liveGeneration.incrementAndGet();
        pendingLiveId = null;
        stopService(new Intent(this, LiveVoiceService.class));
        HttpsURLConnection c = liveConnection;
        if (c != null) {
            c.disconnect();
        }
    }

    /** Starts the mic foreground service, then fetches a one-use Live token and hands it to the page. */
    private void provisionLive(String id) {
        final int gen = liveGeneration.incrementAndGet();
        allowBackgroundLive = Settings.canDrawOverlays(this);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            Intent service = new Intent(this, LiveVoiceService.class);
            try {
                startForegroundService(service);
            } catch (RuntimeException e) {
                emit(json("type", "live-error", "id", id,
                        "message", "Could not start Gemini Live. Check the saved key, network and Live model access in Settings."));
                return;
            }
        }
        liveNetwork.execute(() -> {
            try {
                String key = readKey();
                if (key.isEmpty()) {
                    throw new IOException("Missing key");
                }
                String token = provider.createLiveToken(key, connection -> {
                    liveConnection = connection;
                    if (connection != null && liveGeneration.get() != gen) {
                        connection.disconnect();
                    }
                });
                if (liveGeneration.get() != gen) {
                    return;
                }
                String liveModel = prefs.getString("liveModel", DEFAULT_LIVE_MODEL);
                if (!liveModel.matches(MODEL_PATTERN)) {
                    liveModel = DEFAULT_LIVE_MODEL;
                }
                final String model = liveModel;
                runOnUiThread(() -> emit(json(
                        "type", "live-token", "id", id, "token", token, "model", model, "voice", "Aoede",
                        "backgroundLive", allowBackgroundLive,
                        "instruction", personality + "\n\n" + ANDROID_NOTE)));
            } catch (Exception e) {
                if (liveGeneration.get() == gen) {
                    runOnUiThread(MainActivity.this::cancelLive);
                    String message = e instanceof GeminiAccess.Failure
                            ? e.getMessage()
                            : "Could not start Gemini Live. Check the saved key, network and Live model access in Settings.";
                    emit(json("type", "live-error", "id", id, "message", message));
                }
            }
        });
    }
}
