package com.myraa.mobile;

import android.service.voice.VoiceInteractionService;

/** Lets Android list MYRAA as a "Default digital assistant app" (power button / home long-press / corner swipe). */
public final class MyraaVoiceInteractionService extends VoiceInteractionService {
}
