package com.myraa.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Executes the single Gemini tool "mobile_action": open an app, search YouTube/web, or open a
 * WhatsApp draft. Nothing is ever sent automatically; the user taps Send in WhatsApp.
 */
final class MobileActions {
    static final int CONTACTS_REQUEST = 7401;
    private static final String ID_PATTERN = "[A-Za-z0-9-]{1,80}";

    interface Result {
        void complete(String id, JSONObject result);
    }

    interface Launcher {
        Intent app(String normalizedName);
        boolean installed(String packageName);
        boolean open(Intent intent);
    }

    interface Contacts {
        List<Recipient> find(String name);
        boolean needsPermission();
    }

    static final class Recipient {
        final String name;
        final String phone;

        Recipient(String name, String phone) {
            this.name = name;
            this.phone = phone;
        }
    }

    private final Activity activity;
    private final Result result;
    private final Launcher launcher;
    private final Contacts contacts;
    private final Map<String, JSONObject> completed = new LinkedHashMap<>();
    private AlertDialog chooser;
    private String chooserId;
    private Runnable pending;
    private Runnable pendingDenied;
    private String pendingPerm = Manifest.permission.READ_CONTACTS;
    private String pendingId;

    MobileActions(Activity activity, Result result) {
        this(activity, result, new Launcher() {
            @Override
            public Intent app(String normalizedName) {
                PackageManager pm = activity.getPackageManager();
                Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                for (ResolveInfo info : pm.queryIntentActivities(query, 0)) {
                    String label = normalize(info.loadLabel(pm).toString());
                    if (label.equals(normalizedName)) {
                        return new Intent(Intent.ACTION_MAIN)
                                .addCategory(Intent.CATEGORY_LAUNCHER)
                                .setClassName(info.activityInfo.packageName, info.activityInfo.name);
                    }
                }
                return null;
            }

            @Override
            public boolean installed(String packageName) {
                try {
                    activity.getPackageManager().getPackageInfo(packageName, 0);
                    return true;
                } catch (PackageManager.NameNotFoundException e) {
                    return false;
                }
            }

            @Override
            public boolean open(Intent intent) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(intent);
                    return true;
                } catch (RuntimeException e) {
                    return false;
                }
            }
        }, new Contacts() {
            @Override
            public List<Recipient> find(String name) {
                List<Recipient> found = new ArrayList<>();
                Set<String> seen = new HashSet<>();
                String escaped = name.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
                ContentResolver resolver = activity.getContentResolver();
                String[] projection = {
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER};
                try (Cursor c = resolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection,
                        "display_name LIKE ? ESCAPE '\\'", new String[]{"%" + escaped + "%"},
                        "display_name ASC")) {
                    while (c != null && c.moveToNext() && found.size() < 20) {
                        String display = c.getString(0);
                        if (display == null || display.isEmpty()) {
                            continue;
                        }
                        String number = international(
                                c.getString(2) != null && !c.getString(2).isEmpty() ? c.getString(2) : c.getString(1),
                                activity);
                        if (number != null && seen.add(display + "|" + number)) {
                            found.add(new Recipient(display, number));
                        }
                    }
                }
                // Prefer exact (normalised) name matches when there are any.
                List<Recipient> exact = new ArrayList<>();
                for (Recipient r : found) {
                    if (normalize(r.name).equals(normalize(name))) {
                        exact.add(r);
                    }
                }
                return exact.isEmpty() ? found : exact;
            }

            @Override
            public boolean needsPermission() {
                return activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED;
            }
        });
    }

    MobileActions(Activity activity, Result result, Launcher launcher, Contacts contacts) {
        this.activity = activity;
        this.result = result;
        this.launcher = launcher;
        this.contacts = contacts;
    }

    // ------------------------------------------------------------------ helpers

    static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private JSONObject status(String status, String message) {
        try {
            return new JSONObject().put("status", status).put("message", message);
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
    }

    private void finish(String id, String status, String message) {
        JSONObject r = status(status, message);
        completed.put(id, r);
        while (completed.size() > 32) {
            Iterator<String> it = completed.keySet().iterator();
            it.next();
            it.remove();
        }
        if (id.equals(chooserId)) {
            chooserId = null;
        }
        if (id.equals(pendingId)) {
            pendingId = null;
            pending = null;
            pendingDenied = null;
        }
        result.complete(id, r);
    }

    /** Converts a user-typed or stored number to a bare international number, or null. */
    static String international(String raw, Activity activity) {
        if (raw == null) {
            return null;
        }
        String number = raw.replaceAll("[ ()-]", "");
        if (number.startsWith("00")) {
            number = "+" + number.substring(2);
        }
        if (number.matches("\\+[1-9][0-9]{7,14}")) {
            return number.substring(1);
        }
        // Local number: use the SIM/network country, falling back to the app language.
        String country = null;
        TelephonyManager tm = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm != null && tm.getNetworkCountryIso() != null && tm.getNetworkCountryIso().length() == 2) {
            country = tm.getNetworkCountryIso().toUpperCase(Locale.ROOT);
        }
        if (country == null) {
            SharedPreferences prefs = activity.getSharedPreferences("myraa.mobile.v1", Context.MODE_PRIVATE);
            String language = prefs.getString("language", "hi-IN");
            country = language.endsWith("-IN") ? "IN" : "US";
        }
        String e164 = PhoneNumberUtils.formatNumberToE164(number, country);
        return e164 == null ? null : e164.substring(1);
    }

    private String whatsapp() {
        if (launcher.installed("com.whatsapp")) {
            return "com.whatsapp";
        }
        if (launcher.installed("com.whatsapp.w4b")) {
            return "com.whatsapp.w4b";
        }
        return null;
    }

    static Intent draft(String phone, String message, String packageName) {
        if (phone == null || !phone.matches("[1-9][0-9]{7,14}") || message == null
                || message.trim().isEmpty() || message.length() > 4000) {
            throw new IllegalArgumentException("A valid recipient and message are required.");
        }
        Uri uri = Uri.parse("https://wa.me/" + phone).buildUpon().appendQueryParameter("text", message).build();
        return new Intent(Intent.ACTION_VIEW, uri).setPackage(packageName);
    }

    static Intent search(String kind, String query) {
        if (query == null || query.trim().isEmpty() || query.length() > 500) {
            throw new IllegalArgumentException("Say what you want to search for.");
        }
        Uri.Builder builder = "youtube".equals(kind)
                ? Uri.parse("https://www.youtube.com/results").buildUpon().appendQueryParameter("search_query", query.trim())
                : Uri.parse("https://www.google.com/search").buildUpon().appendQueryParameter("q", query.trim());
        return new Intent(Intent.ACTION_VIEW, builder.build()).addCategory(Intent.CATEGORY_BROWSABLE);
    }

    // ------------------------------------------------------------------ actions

    void execute(String id, String name, String argsJson) {
        if (id == null || !id.matches(ID_PATTERN)) {
            return;
        }
        if (completed.containsKey(id)) {
            result.complete(id, completed.get(id));
            return;
        }
        if (!"mobile_action".equals(name)) {
            finish(id, "unsupported", "That mobile action is unavailable.");
            return;
        }
        try {
            JSONObject args = new JSONObject(argsJson);
            String action = args.optString("action");
            if ("open_app".equals(action)) {
                openApp(id, args.optString("app"));
            } else if ("whatsapp_message".equals(action)) {
                message(id, args.optString("recipient"), args.optString("message"));
            } else if ("search_youtube".equals(action) || "search_web".equals(action)) {
                boolean youtube = "search_youtube".equals(action);
                Intent intent = search(youtube ? "youtube" : "web", args.optString("query"));
                // Prefer YouTube / Chrome when installed; otherwise let Android pick a handler.
                if (youtube && launcher.installed("com.google.android.youtube")) {
                    intent.setPackage("com.google.android.youtube");
                } else if (!youtube && launcher.installed("com.android.chrome")) {
                    intent.setPackage("com.android.chrome");
                }
                if (launcher.open(intent)) {
                    finish(id, "opened", (youtube ? "YouTube" : "Browser") + " search opened.");
                    return;
                }
                if (intent.getPackage() != null) {
                    Intent fallback = new Intent(intent).setPackage(null);
                    if (launcher.open(fallback)) {
                        finish(id, "opened", (youtube ? "YouTube" : "Browser") + " search opened.");
                        return;
                    }
                }
                finish(id, "unavailable", "No app can open this search on this device.");
            } else if (!extended(id, action, args)) {
                finish(id, "unsupported", "That action is not supported.");
            }
        } catch (IllegalArgumentException e) {
            finish(id, "invalid", e.getMessage());
        } catch (JSONException | RuntimeException e) {
            finish(id, "failed", "Android could not complete this action. Nothing was sent.");
        }
    }

    private void openApp(String id, String requested) {
        String app = normalize(requested);
        if (app.isEmpty() || app.length() > 100) {
            finish(id, "invalid", "Say which app to open.");
            return;
        }
        Intent intent = null;
        String label = requested.trim();
        if (Arrays.asList("whatsapp", "व्हाट्सएप", "wp", "wa", "whats app").contains(app)) {
            String pkg = whatsapp();
            if (pkg == null) {
                finish(id, "not_installed", "WhatsApp is not installed on this Android device.");
                return;
            }
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")).setPackage(pkg);
            label = "WhatsApp";
        } else if (Arrays.asList("youtube", "you tube", "यूट्यूब").contains(app)
                && launcher.installed("com.google.android.youtube")) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    .setPackage("com.google.android.youtube");
            label = "YouTube";
        } else if (Arrays.asList("chrome", "google chrome", "browser", "क्रोम").contains(app)
                && launcher.installed("com.android.chrome")) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                    .setPackage("com.android.chrome");
            label = "Chrome";
        } else {
            intent = launcher.app(app);
        }
        if (intent == null) {
            finish(id, "not_installed", "No installed app matches that name.");
            return;
        }
        if (launcher.open(intent)) {
            finish(id, "opened", "Opened " + label + ".");
        } else {
            finish(id, "unavailable", "Android could not open " + label + ".");
        }
    }

    private void message(String id, String recipientText, String messageText) {
        String pkg = whatsapp();
        if (pkg == null) {
            finish(id, "not_installed", "WhatsApp is not installed on this Android device.");
            return;
        }
        String recipient = recipientText == null ? "" : recipientText.trim();
        String text = messageText == null ? "" : messageText.trim();
        if (recipient.isEmpty() || recipient.length() > 100 || text.isEmpty() || text.length() > 4000) {
            finish(id, "invalid", "Tell me the recipient and the complete message.");
            return;
        }
        if (chooser != null && !id.equals(chooserId)) {
            finish(id, "busy", "Finish the current contact selection first.");
            return;
        }

        // A phone number was spoken/typed instead of a contact name.
        if (recipient.matches("\\+?[0-9 ()-]+")) {
            String digits = recipient.replaceAll("[ ()+-]", "");
            if (recipient.startsWith("00")) {
                digits = digits.substring(2);
            }
            boolean hasCountryCode = recipient.startsWith("+") || recipient.startsWith("00");
            if (!hasCountryCode || !digits.matches("[1-9][0-9]{7,14}")) {
                finish(id, "invalid", "Include the country code in the recipient phone number, for example +91.");
                return;
            }
            openDraft(id, new Recipient(recipient, digits), text);
            return;
        }

        // Contact name: needs Contacts permission.
        if (contacts.needsPermission()) {
            if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                pendingId = id;
                pendingPerm = Manifest.permission.READ_CONTACTS;
                pendingDenied = null;
                pending = () -> message(id, recipientText, messageText);
                activity.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_REQUEST);
            }
            return;
        }
        final List<Recipient> matches = contacts.find(recipient);
        if (matches.isEmpty()) {
            finish(id, "not_found",
                    "No matching contact with a usable phone number was found. Give the full saved name or an international phone number.");
            return;
        }
        if (matches.size() == 1) {
            openDraft(id, matches.get(0), text);
            return;
        }
        String[] items = new String[matches.size()];
        for (int i = 0; i < items.length; i++) {
            items[i] = matches.get(i).name + " · +" + matches.get(i).phone;
        }
        chooserId = id;
        chooser = new AlertDialog.Builder(activity)
                .setTitle("Which " + recipient + "?")
                .setItems(items, (dialog, which) -> openDraft(id, matches.get(which), text))
                .setNegativeButton("Cancel", (dialog, which) -> finish(id, "cancelled", "Message cancelled. Nothing was sent."))
                .setOnCancelListener(dialog -> finish(id, "cancelled", "Message cancelled. Nothing was sent."))
                .show();
    }

    private void openDraft(String id, Recipient recipient, String text) {
        chooser = null;
        confirm(id, "Send WhatsApp message?",
                "To: " + recipient.name + " (+" + recipient.phone + ")\n\n" + text,
                () -> doDraft(id, recipient, text));
    }

    private void doDraft(String id, Recipient recipient, String text) {
        String pkg = whatsapp();
        if (pkg != null && launcher.open(draft(recipient.phone, text, pkg))) {
            if (MyraaA11y.isEnabled()) {
                MyraaA11y.autoSend();
                finish(id, "sent_attempted", "WhatsApp opened for " + recipient.name
                        + " and MYRAA is pressing Send now.");
            } else {
                finish(id, "draft_opened", "WhatsApp draft opened for " + recipient.name
                        + ". Tap Send in WhatsApp (turn on MYRAA Control in Accessibility settings to let MYRAA press Send)." );
            }
        } else {
            finish(id, "unavailable", "WhatsApp could not open this recipient. Nothing was sent.");
        }
    }

    // ------------------------------------------------------------------ shared helpers

    /** Yes/Cancel dialog; nothing happens until the user taps Yes. */
    private void confirm(String id, String title, String body, Runnable yes) {
        chooserId = id;
        chooser = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(body)
                .setPositiveButton("Yes", (dialog, which) -> {
                    chooser = null;
                    chooserId = null;
                    yes.run();
                })
                .setNegativeButton("Cancel", (dialog, which) -> finish(id, "cancelled", "Cancelled. Nothing was done."))
                .setOnCancelListener(dialog -> finish(id, "cancelled", "Cancelled. Nothing was done."))
                .show();
    }

    /** Asks for a runtime permission, then runs onGranted (or onDenied, or reports permission_required). */
    private void requestPerm(String id, String permission, Runnable onGranted, Runnable onDenied) {
        if (activity.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            onGranted.run();
            return;
        }
        pendingId = id;
        pendingPerm = permission;
        pending = onGranted;
        pendingDenied = onDenied;
        activity.requestPermissions(new String[]{permission}, CONTACTS_REQUEST);
    }

    /** Resolves a spoken contact name or phone number to one recipient (asks when ambiguous). */
    private void resolve(String id, String recipientText, java.util.function.Consumer<Recipient> next) {
        String recipient = recipientText == null ? "" : recipientText.trim();
        if (recipient.isEmpty() || recipient.length() > 100) {
            finish(id, "invalid", "Tell me who.");
            return;
        }
        if (chooser != null && !id.equals(chooserId)) {
            finish(id, "busy", "Finish the current selection first.");
            return;
        }
        if (recipient.matches("\\+?[0-9 ()-]+")) {
            String number = international(recipient, activity);
            if (number == null || !number.matches("[1-9][0-9]{7,14}")) {
                finish(id, "invalid", "That phone number looks invalid. Include the country code, for example +91.");
                return;
            }
            next.accept(new Recipient(recipient, number));
            return;
        }
        requestPerm(id, Manifest.permission.READ_CONTACTS, () -> {
            List<Recipient> matches = contacts.find(recipient);
            if (matches.isEmpty()) {
                finish(id, "not_found", "No matching contact with a phone number was found. Give the full saved name or a number.");
            } else if (matches.size() == 1) {
                next.accept(matches.get(0));
            } else {
                String[] items = new String[matches.size()];
                for (int i = 0; i < items.length; i++) {
                    items[i] = matches.get(i).name + " · +" + matches.get(i).phone;
                }
                chooserId = id;
                chooser = new AlertDialog.Builder(activity)
                        .setTitle("Which " + recipient + "?")
                        .setItems(items, (dialog, which) -> next.accept(matches.get(which)))
                        .setNegativeButton("Cancel", (dialog, which) -> finish(id, "cancelled", "Cancelled. Nothing was done."))
                        .setOnCancelListener(dialog -> finish(id, "cancelled", "Cancelled. Nothing was done."))
                        .show();
            }
        }, () -> finish(id, "permission_required",
                "Contacts access was denied. Use a full phone number or allow Contacts in Android settings."));
    }

    private boolean launch(Intent intent, String pkg) {
        if (pkg != null && launcher.installed(pkg)) {
            Intent targeted = new Intent(intent).setPackage(pkg);
            if (launcher.open(targeted)) {
                return true;
            }
        }
        return launcher.open(intent);
    }

    private void openOrFail(String id, Intent intent, String pkg, String ok, String fail) {
        if (launch(intent, pkg)) {
            finish(id, "opened", ok);
        } else {
            finish(id, "unavailable", fail);
        }
    }

    // ------------------------------------------------------------------ extended actions

    private boolean extended(String id, String action, JSONObject args) {
        switch (action) {
            case "call":
                resolve(id, args.optString("recipient"), r -> confirm(id, "Call?",
                        r.name + " (+" + r.phone + ")", () -> placeCall(id, r)));
                return true;
            case "send_sms":
                sms(id, args.optString("recipient"), args.optString("message"));
                return true;
            case "play_youtube":
                playYoutube(id, args.optString("query"));
                return true;
            case "set_alarm": {
                int h = args.optInt("hour", -1);
                int m = args.optInt("minute", 0);
                if (h < 0 || h > 23 || m < 0 || m > 59) {
                    finish(id, "invalid", "Give the alarm time as hour (0-23) and minute.");
                    return true;
                }
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "MYRAA"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                openOrFail(id, i, null, String.format(Locale.ROOT, "Alarm set for %02d:%02d.", h, m),
                        "No clock app could set the alarm.");
                return true;
            }
            case "set_timer": {
                int sec = args.optInt("seconds", -1);
                if (sec < 1 || sec > 86400) {
                    finish(id, "invalid", "Give the timer length in seconds (1 to 86400).");
                    return true;
                }
                Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "MYRAA"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                openOrFail(id, i, null, "Timer started for " + sec + " seconds.", "No clock app could start the timer.");
                return true;
            }
            case "flashlight":
                flashlight(id, !"off".equalsIgnoreCase(args.optString("state", "on")));
                return true;
            case "navigate": {
                String q = args.optString("query").trim();
                if (q.isEmpty()) {
                    finish(id, "invalid", "Say where to navigate.");
                    return true;
                }
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q)));
                if (!launch(i, "com.google.android.apps.maps")) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)));
                    openOrFail(id, i, null, "Opened maps for " + q + ".", "No maps app is available.");
                } else {
                    finish(id, "opened", "Navigation to " + q + " started.");
                }
                return true;
            }
            case "open_camera":
                openOrFail(id, new Intent(MediaStore.ACTION_IMAGE_CAPTURE), null, "Camera opened.", "No camera app is available.");
                return true;
            case "volume":
                volume(id, args.optString("direction"), args.optInt("level", -1));
                return true;
            case "open_settings":
                openSettings(id, args.optString("setting"));
                return true;
            case "read_screen":
            case "tap_text":
            case "type_text":
            case "scroll":
            case "press_key":
                accessibility(id, action, args);
                return true;
            default:
                return false;
        }
    }

    private void placeCall(String id, Recipient r) {
        Uri tel = Uri.parse("tel:+" + r.phone);
        requestPerm(id, Manifest.permission.CALL_PHONE, () -> {
            if (launcher.open(new Intent(Intent.ACTION_CALL, tel))) {
                finish(id, "calling", "Calling " + r.name + ".");
            } else {
                finish(id, "unavailable", "Android could not place the call.");
            }
        }, () -> {
            if (launcher.open(new Intent(Intent.ACTION_DIAL, tel))) {
                finish(id, "dialer_opened", "Phone permission denied, so the dialer is open with " + r.name + ". Tap call.");
            } else {
                finish(id, "permission_required", "Phone permission was denied.");
            }
        });
    }

    private void sms(String id, String recipientText, String messageText) {
        String text = messageText == null ? "" : messageText.trim();
        if (text.isEmpty() || text.length() > 1000) {
            finish(id, "invalid", "Tell me the complete SMS text.");
            return;
        }
        resolve(id, recipientText, r -> confirm(id, "Send SMS?",
                "To: " + r.name + " (+" + r.phone + ")\n\n" + text, () -> requestPerm(id, Manifest.permission.SEND_SMS, () -> {
                    try {
                        SmsManager sm = Build.VERSION.SDK_INT >= 31
                                ? activity.getSystemService(SmsManager.class) : SmsManager.getDefault();
                        sm.sendMultipartTextMessage("+" + r.phone, null, sm.divideMessage(text), null, null);
                        finish(id, "sent", "SMS sent to " + r.name + ".");
                    } catch (RuntimeException e) {
                        finish(id, "failed", "Android could not send the SMS.");
                    }
                }, () -> {
                    Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:+" + r.phone)).putExtra("sms_body", text);
                    if (launcher.open(i)) {
                        finish(id, "draft_opened", "SMS permission denied. SMS draft opened; tap send.");
                    } else {
                        finish(id, "permission_required", "SMS permission was denied.");
                    }
                })));
    }

    private void playYoutube(String id, String query) {
        final String q = query == null ? "" : query.trim();
        if (q.isEmpty() || q.length() > 500) {
            finish(id, "invalid", "Say what to play.");
            return;
        }
        new Thread(() -> {
            String videoId = firstVideoId(q);
            activity.runOnUiThread(() -> {
                if (completed.containsKey(id)) {
                    return;
                }
                Intent i;
                if (videoId != null) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + videoId))
                            .addCategory(Intent.CATEGORY_BROWSABLE);
                } else {
                    i = search("youtube", q);
                }
                openOrFail(id, i, "com.google.android.youtube",
                        videoId != null ? "Playing \"" + q + "\" on YouTube." : "Could not pick a video, opened YouTube search for " + q + ".",
                        "YouTube could not be opened.");
            });
        }).start();
    }

    /** Looks up the first video result of a YouTube search. Returns null when it cannot. */
    static String firstVideoId(String query) {
        HttpURLConnection c = null;
        try {
            Uri u = Uri.parse("https://www.youtube.com/results").buildUpon()
                    .appendQueryParameter("search_query", query)
                    .appendQueryParameter("sp", "EgIQAQ==").build();
            c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0 && out.size() < 2_000_000) {
                    out.write(buf, 0, n);
                }
                Matcher m = Pattern.compile("\"videoId\":\"([A-Za-z0-9_-]{11})\"").matcher(out.toString("UTF-8"));
                return m.find() ? m.group(1) : null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    private void flashlight(String id, boolean on) {
        try {
            CameraManager cm = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
            for (String cid : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(cid);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(cid, on);
                    finish(id, "done", "Flashlight turned " + (on ? "on" : "off") + ".");
                    return;
                }
            }
            finish(id, "unavailable", "This device has no flashlight.");
        } catch (CameraAccessException | RuntimeException e) {
            finish(id, "failed", "Android could not switch the flashlight.");
        }
    }

    private void volume(String id, String direction, int level) {
        AudioManager am = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if (level >= 0 && level <= 100) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(max * level / 100f), AudioManager.FLAG_SHOW_UI);
            finish(id, "done", "Volume set to " + level + "%.");
            return;
        }
        int adjust;
        switch (direction == null ? "" : direction.toLowerCase(Locale.ROOT)) {
            case "up": adjust = AudioManager.ADJUST_RAISE; break;
            case "down": adjust = AudioManager.ADJUST_LOWER; break;
            case "mute": adjust = AudioManager.ADJUST_MUTE; break;
            case "unmute": adjust = AudioManager.ADJUST_UNMUTE; break;
            default:
                finish(id, "invalid", "Say up, down, mute, unmute, or a level from 0 to 100.");
                return;
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, adjust, AudioManager.FLAG_SHOW_UI);
        finish(id, "done", "Volume " + direction + ".");
    }

    private void openSettings(String id, String setting) {
        String a;
        switch (setting == null ? "" : setting.toLowerCase(Locale.ROOT)) {
            case "wifi": a = Settings.ACTION_WIFI_SETTINGS; break;
            case "bluetooth": a = Settings.ACTION_BLUETOOTH_SETTINGS; break;
            case "airplane": a = Settings.ACTION_AIRPLANE_MODE_SETTINGS; break;
            case "location": a = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
            case "display": a = Settings.ACTION_DISPLAY_SETTINGS; break;
            case "sound": a = Settings.ACTION_SOUND_SETTINGS; break;
            case "battery": a = Intent.ACTION_POWER_USAGE_SUMMARY; break;
            case "accessibility": a = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
            default: a = Settings.ACTION_SETTINGS;
        }
        openOrFail(id, new Intent(a), null, "Settings opened.", "Android could not open settings.");
    }

    private void accessibility(String id, String action, JSONObject args) {
        if (!MyraaA11y.isEnabled()) {
            launcher.open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish(id, "permission_required",
                    "Turn on MYRAA Control in Accessibility settings, then ask again.");
            return;
        }
        String text = args.optString("text");
        switch (action) {
            case "read_screen":
                finish(id, "ok", "Screen contents:\n" + MyraaA11y.readScreen());
                break;
            case "tap_text": {
                boolean ok = MyraaA11y.tapText(text);
                finish(id, ok ? "done" : "not_found",
                        ok ? "Tapped \"" + text + "\"." : "Nothing on screen matched \"" + text + "\".");
                break;
            }
            case "type_text": {
                boolean ok = MyraaA11y.typeText(text);
                finish(id, ok ? "done" : "not_found", ok ? "Typed the text." : "No text field is focused.");
                break;
            }
            case "scroll": {
                boolean down = !"up".equalsIgnoreCase(args.optString("direction", "down"));
                boolean ok = MyraaA11y.scroll(down);
                finish(id, ok ? "done" : "not_found", ok ? "Scrolled." : "Nothing scrollable on screen.");
                break;
            }
            default: {
                boolean ok = MyraaA11y.press(args.optString("key"));
                finish(id, ok ? "done" : "invalid",
                        ok ? "Pressed " + args.optString("key") + "." : "Say back, home, recents or notifications.");
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    void permissionResult() {
        if (pending == null) {
            return;
        }
        Runnable next = pending;
        Runnable denied = pendingDenied;
        String id = pendingId;
        pending = null;
        pendingDenied = null;
        if (activity.checkSelfPermission(pendingPerm) == PackageManager.PERMISSION_GRANTED) {
            next.run();
        } else if (denied != null) {
            denied.run();
        } else {
            finish(id, "permission_required",
                    "Permission was denied. Allow it in Android app settings and try again.");
        }
    }

    void cancel(String id) {
        if (id == null || !id.matches(ID_PATTERN)) {
            return;
        }
        if (id.equals(chooserId) && chooser != null) {
            AlertDialog dialog = chooser;
            chooser = null;
            dialog.dismiss();
        }
        if (!completed.containsKey(id)) {
            finish(id, "cancelled", "Action cancelled. Nothing was sent.");
        }
    }

    void close() {
        if (chooser != null) {
            chooser.dismiss();
            chooser = null;
        }
    }
}
