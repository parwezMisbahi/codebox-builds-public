package com.myraa.mobile;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Executes the single Gemini tool "mobile_action": open an app, search YouTube/web, or open a
 * WhatsApp draft. Nothing is ever sent automatically; the user taps Send in WhatsApp.
 */
final class MobileActions {
    static final int CONTACTS_REQUEST = 7401;
    private static final String ID_PATTERN = "[A-Za-z0-9-]{1,80}";

    interface Result {
        void complete(String id, JSONObject result);
    }

    interface Launcher {
        Intent app(String normalizedName);
        boolean installed(String packageName);
        boolean open(Intent intent);
    }

    interface Contacts {
        List<Recipient> find(String name);
        boolean needsPermission();
    }

    static final class Recipient {
        final String name;
        final String phone;

        Recipient(String name, String phone) {
            this.name = name;
            this.phone = phone;
        }
    }

    private final Activity activity;
    private final Result result;
    private final Launcher launcher;
    private final Contacts contacts;
    private final Map<String, JSONObject> completed = new LinkedHashMap<>();
    private AlertDialog chooser;
    private String chooserId;
    private Runnable pending;
    private String pendingId;

    MobileActions(Activity activity, Result result) {
        this(activity, result, new Launcher() {
            @Override
            public Intent app(String normalizedName) {
                PackageManager pm = activity.getPackageManager();
                Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                for (ResolveInfo info : pm.queryIntentActivities(query, 0)) {
                    String label = normalize(info.loadLabel(pm).toString());
                    if (label.equals(normalizedName)) {
                        return new Intent(Intent.ACTION_MAIN)
                                .addCategory(Intent.CATEGORY_LAUNCHER)
                                .setClassName(info.activityInfo.packageName, info.activityInfo.name);
                    }
                }
                return null;
            }

            @Override
            public boolean installed(String packageName) {
                try {
                    activity.getPackageManager().getPackageInfo(packageName, 0);
                    return true;
                } catch (PackageManager.NameNotFoundException e) {
                    return false;
                }
            }

            @Override
            public boolean open(Intent intent) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(intent);
                    return true;
                } catch (RuntimeException e) {
                    return false;
                }
            }
        }, new Contacts() {
            @Override
            public List<Recipient> find(String name) {
                List<Recipient> found = new ArrayList<>();
                Set<String> seen = new HashSet<>();
                String escaped = name.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
                ContentResolver resolver = activity.getContentResolver();
                String[] projection = {
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER};
                try (Cursor c = resolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection,
                        "display_name LIKE ? ESCAPE '\\'", new String[]{"%" + escaped + "%"},
                        "display_name ASC")) {
                    while (c != null && c.moveToNext() && found.size() < 20) {
                        String display = c.getString(0);
                        if (display == null || display.isEmpty()) {
                            continue;
                        }
                        String number = international(
                                c.getString(2) != null && !c.getString(2).isEmpty() ? c.getString(2) : c.getString(1),
                                activity);
                        if (number != null && seen.add(display + "|" + number)) {
                            found.add(new Recipient(display, number));
                        }
                    }
                }
                // Prefer exact (normalised) name matches when there are any.
                List<Recipient> exact = new ArrayList<>();
                for (Recipient r : found) {
                    if (normalize(r.name).equals(normalize(name))) {
                        exact.add(r);
                    }
                }
                return exact.isEmpty() ? found : exact;
            }

            @Override
            public boolean needsPermission() {
                return activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                        != PackageManager.PERMISSION_GRANTED;
            }
        });
    }

    MobileActions(Activity activity, Result result, Launcher launcher, Contacts contacts) {
        this.activity = activity;
        this.result = result;
        this.launcher = launcher;
        this.contacts = contacts;
    }

    // ------------------------------------------------------------------ helpers

    static String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private JSONObject status(String status, String message) {
        try {
            return new JSONObject().put("status", status).put("message", message);
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
    }

    private void finish(String id, String status, String message) {
        JSONObject r = status(status, message);
        completed.put(id, r);
        while (completed.size() > 32) {
            Iterator<String> it = completed.keySet().iterator();
            it.next();
            it.remove();
        }
        if (id.equals(chooserId)) {
            chooserId = null;
        }
        if (id.equals(pendingId)) {
            pendingId = null;
            pending = null;
        }
        result.complete(id, r);
    }

    /** Converts a user-typed or stored number to a bare international number, or null. */
    static String international(String raw, Activity activity) {
        if (raw == null) {
            return null;
        }
        String number = raw.replaceAll("[ ()-]", "");
        if (number.startsWith("00")) {
            number = "+" + number.substring(2);
        }
        if (number.matches("\\+[1-9][0-9]{7,14}")) {
            return number.substring(1);
        }
        // Local number: use the SIM/network country, falling back to the app language.
        String country = null;
        TelephonyManager tm = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
        if (tm != null && tm.getNetworkCountryIso() != null && tm.getNetworkCountryIso().length() == 2) {
            country = tm.getNetworkCountryIso().toUpperCase(Locale.ROOT);
        }
        if (country == null) {
            SharedPreferences prefs = activity.getSharedPreferences("myraa.mobile.v1", Context.MODE_PRIVATE);
            String language = prefs.getString("language", "hi-IN");
            country = language.endsWith("-IN") ? "IN" : "US";
        }
        String e164 = PhoneNumberUtils.formatNumberToE164(number, country);
        return e164 == null ? null : e164.substring(1);
    }

    private String whatsapp() {
        if (launcher.installed("com.whatsapp")) {
            return "com.whatsapp";
        }
        if (launcher.installed("com.whatsapp.w4b")) {
            return "com.whatsapp.w4b";
        }
        return null;
    }

    static Intent draft(String phone, String message, String packageName) {
        if (phone == null || !phone.matches("[1-9][0-9]{7,14}") || message == null
                || message.trim().isEmpty() || message.length() > 4000) {
            throw new IllegalArgumentException("A valid recipient and message are required.");
        }
        Uri uri = Uri.parse("https://wa.me/" + phone).buildUpon().appendQueryParameter("text", message).build();
        return new Intent(Intent.ACTION_VIEW, uri).setPackage(packageName);
    }

    static Intent search(String kind, String query) {
        if (query == null || query.trim().isEmpty() || query.length() > 500) {
            throw new IllegalArgumentException("Say what you want to search for.");
        }
        Uri.Builder builder = "youtube".equals(kind)
                ? Uri.parse("https://www.youtube.com/results").buildUpon().appendQueryParameter("search_query", query.trim())
                : Uri.parse("https://www.google.com/search").buildUpon().appendQueryParameter("q", query.trim());
        return new Intent(Intent.ACTION_VIEW, builder.build()).addCategory(Intent.CATEGORY_BROWSABLE);
    }

    // ------------------------------------------------------------------ actions

    void execute(String id, String name, String argsJson) {
        if (id == null || !id.matches(ID_PATTERN)) {
            return;
        }
        if (completed.containsKey(id)) {
            result.complete(id, completed.get(id));
            return;
        }
        if (!"mobile_action".equals(name)) {
            finish(id, "unsupported", "That mobile action is unavailable.");
            return;
        }
        try {
            JSONObject args = new JSONObject(argsJson);
            String action = args.optString("action");
            if ("open_app".equals(action)) {
                openApp(id, args.optString("app"));
            } else if ("whatsapp_message".equals(action)) {
                message(id, args.optString("recipient"), args.optString("message"));
            } else if ("search_youtube".equals(action) || "search_web".equals(action)) {
                boolean youtube = "search_youtube".equals(action);
                Intent intent = search(youtube ? "youtube" : "web", args.optString("query"));
                // Prefer YouTube / Chrome when installed; otherwise let Android pick a handler.
                if (youtube && launcher.installed("com.google.android.youtube")) {
                    intent.setPackage("com.google.android.youtube");
                } else if (!youtube && launcher.installed("com.android.chrome")) {
                    intent.setPackage("com.android.chrome");
                }
                if (launcher.open(intent)) {
                    finish(id, "opened", (youtube ? "YouTube" : "Browser") + " search opened.");
                    return;
                }
                if (intent.getPackage() != null) {
                    Intent fallback = new Intent(intent).setPackage(null);
                    if (launcher.open(fallback)) {
                        finish(id, "opened", (youtube ? "YouTube" : "Browser") + " search opened.");
                        return;
                    }
                }
                finish(id, "unavailable", "No app can open this search on this device.");
            } else {
                finish(id, "unsupported",
                        "Supported actions: open an app, search YouTube or the web, and prepare a WhatsApp message.");
            }
        } catch (IllegalArgumentException e) {
            finish(id, "invalid", e.getMessage());
        } catch (JSONException | RuntimeException e) {
            finish(id, "failed", "Android could not complete this action. Nothing was sent.");
        }
    }

    private void openApp(String id, String requested) {
        String app = normalize(requested);
        if (app.isEmpty() || app.length() > 100) {
            finish(id, "invalid", "Say which app to open.");
            return;
        }
        Intent intent = null;
        String label = requested.trim();
        if (Arrays.asList("whatsapp", "व्हाट्सएप", "wp", "wa", "whats app").contains(app)) {
            String pkg = whatsapp();
            if (pkg == null) {
                finish(id, "not_installed", "WhatsApp is not installed on this Android device.");
                return;
            }
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")).setPackage(pkg);
            label = "WhatsApp";
        } else if (Arrays.asList("youtube", "you tube", "यूट्यूब").contains(app)
                && launcher.installed("com.google.android.youtube")) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    .setPackage("com.google.android.youtube");
            label = "YouTube";
        } else if (Arrays.asList("chrome", "google chrome", "browser", "क्रोम").contains(app)
                && launcher.installed("com.android.chrome")) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
                    .setPackage("com.android.chrome");
            label = "Chrome";
        } else {
            intent = launcher.app(app);
        }
        if (intent == null) {
            finish(id, "not_installed", "No installed app matches that name.");
            return;
        }
        if (launcher.open(intent)) {
            finish(id, "opened", "Opened " + label + ".");
        } else {
            finish(id, "unavailable", "Android could not open " + label + ".");
        }
    }

    private void message(String id, String recipientText, String messageText) {
        String pkg = whatsapp();
        if (pkg == null) {
            finish(id, "not_installed", "WhatsApp is not installed on this Android device.");
            return;
        }
        String recipient = recipientText == null ? "" : recipientText.trim();
        String text = messageText == null ? "" : messageText.trim();
        if (recipient.isEmpty() || recipient.length() > 100 || text.isEmpty() || text.length() > 4000) {
            finish(id, "invalid", "Tell me the recipient and the complete message.");
            return;
        }
        if (chooser != null && !id.equals(chooserId)) {
            finish(id, "busy", "Finish the current contact selection first.");
            return;
        }

        // A phone number was spoken/typed instead of a contact name.
        if (recipient.matches("\\+?[0-9 ()-]+")) {
            String digits = recipient.replaceAll("[ ()+-]", "");
            if (recipient.startsWith("00")) {
                digits = digits.substring(2);
            }
            boolean hasCountryCode = recipient.startsWith("+") || recipient.startsWith("00");
            if (!hasCountryCode || !digits.matches("[1-9][0-9]{7,14}")) {
                finish(id, "invalid", "Include the country code in the recipient phone number, for example +91.");
                return;
            }
            openDraft(id, new Recipient(recipient, digits), text);
            return;
        }

        // Contact name: needs Contacts permission.
        if (contacts.needsPermission()) {
            if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                pendingId = id;
                pending = () -> message(id, recipientText, messageText);
                activity.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, CONTACTS_REQUEST);
            }
            return;
        }
        final List<Recipient> matches = contacts.find(recipient);
        if (matches.isEmpty()) {
            finish(id, "not_found",
                    "No matching contact with a usable phone number was found. Give the full saved name or an international phone number.");
            return;
        }
        if (matches.size() == 1) {
            openDraft(id, matches.get(0), text);
            return;
        }
        String[] items = new String[matches.size()];
        for (int i = 0; i < items.length; i++) {
            items[i] = matches.get(i).name + " · +" + matches.get(i).phone;
        }
        chooserId = id;
        chooser = new AlertDialog.Builder(activity)
                .setTitle("Which " + recipient + "?")
                .setItems(items, (dialog, which) -> openDraft(id, matches.get(which), text))
                .setNegativeButton("Cancel", (dialog, which) -> finish(id, "cancelled", "Message cancelled. Nothing was sent."))
                .setOnCancelListener(dialog -> finish(id, "cancelled", "Message cancelled. Nothing was sent."))
                .show();
    }

    private void openDraft(String id, Recipient recipient, String text) {
        chooser = null;
        String pkg = whatsapp();
        if (pkg != null && launcher.open(draft(recipient.phone, text, pkg))) {
            finish(id, "draft_opened", "WhatsApp draft opened for " + recipient.name
                    + ". Review it and tap Send in WhatsApp; MYRAA has not sent it.");
        } else {
            finish(id, "unavailable", "WhatsApp could not open this recipient. Nothing was sent.");
        }
    }

    // ------------------------------------------------------------------ lifecycle

    void permissionResult() {
        if (pending == null) {
            return;
        }
        Runnable next = pending;
        String id = pendingId;
        pending = null;
        if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            next.run();
        } else {
            finish(id, "permission_required",
                    "Contacts access was denied. Use a full international phone number or allow Contacts in Android app settings.");
        }
    }

    void cancel(String id) {
        if (id == null || !id.matches(ID_PATTERN)) {
            return;
        }
        if (id.equals(chooserId) && chooser != null) {
            AlertDialog dialog = chooser;
            chooser = null;
            dialog.dismiss();
        }
        if (!completed.containsKey(id)) {
            finish(id, "cancelled", "Action cancelled. Nothing was sent.");
        }
    }

    void close() {
        if (chooser != null) {
            chooser.dismiss();
            chooser = null;
        }
    }
}
