package com.widgetmaker.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MacroService : AccessibilityService() {
    companion object {
        @Volatile var running = false
        @Volatile var pkg: String? = null
        @Volatile var text: String? = null
        @Volatile var until = 0L
    }

    override fun onServiceConnected() { running = true }
    override fun onUnbind(intent: android.content.Intent?): Boolean { running = false; return super.onUnbind(intent) }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val p = pkg ?: return
        val t = text ?: return
        if (System.currentTimeMillis() > until) { pkg = null; return }
        if (e.packageName?.toString() != p) return
        val root = rootInActiveWindow ?: return
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { pkg = null; return }
        }
    }

    override fun onInterrupt() {}
}
