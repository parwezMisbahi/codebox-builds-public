package com.widgetmaker.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.*

class ConfigActivity : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID
    private val cfg = Cfg()
    private lateinit var preview: ImageView
    private lateinit var area: LinearLayout
    private lateinit var labelEt: EditText
    private val iconViews = LinkedHashMap<String, ImageView>()
    private val apps = ArrayList<Pair<String, String>>()

    private val types = listOf("App shortcut" to "app", "Phone setting" to "setting", "Open link" to "link",
        "Call number" to "call", "Torch toggle" to "torch", "In-app option" to "macro")
    private val settingsList = listOf(
        "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS, "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "Display and brightness" to Settings.ACTION_DISPLAY_SETTINGS, "Sound and volume" to Settings.ACTION_SOUND_SETTINGS,
        "Battery saver" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "Airplane mode" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "Location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "NFC" to Settings.ACTION_NFC_SETTINGS,
        "Storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "Date and time" to Settings.ACTION_DATE_SETTINGS,
        "Accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS, "All settings" to Settings.ACTION_SETTINGS)
    private val colors = intArrayOf(0xFF5B5BF0.toInt(), 0xFFE5484D.toInt(), 0xFF12A594.toInt(),
        0xFFF5A524.toInt(), 0xFFD6409F.toInt(), 0xFF2B2F3A.toInt())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        wid = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        cfg.size = sizeOf(AppWidgetManager.getInstance(this), wid)
        loadApps()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))

        val title = TextView(this); title.text = "Create widget"; title.textSize = 24f
        title.setTypeface(null, android.graphics.Typeface.BOLD); root.addView(title)

        preview = ImageView(this)
        preview.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)).also { it.topMargin = dp(12) }
        preview.setBackgroundColor(0xFF2B2F4A.toInt())
        preview.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(preview)

        labelEt = EditText(this); labelEt.hint = "Widget label"
        labelEt.onText { cfg.label = it; refresh() }
        area = LinearLayout(this); area.orientation = LinearLayout.VERTICAL

        root.addView(lbl("Type"))
        root.addView(spinner(types.map { it.first }, 0) { i ->
            cfg.type = types[i].second; cfg.value = ""; cfg.extra = ""; cfg.target = ""; buildArea()
        })
        root.addView(area)
        root.addView(lbl("Label")); root.addView(labelEt)

        root.addView(lbl("Icon"))
        val grid = GridLayout(this); grid.columnCount = 6
        for (name in Icons.map.keys) {
            val iv = ImageView(this)
            val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            Renderer.icon(Canvas(bmp), name, 12f, 12f, 72f, 0xFF222222.toInt())
            iv.setImageBitmap(bmp)
            iv.layoutParams = GridLayout.LayoutParams().also { it.width = dp(48); it.height = dp(48); it.setMargins(dp(2), dp(2), dp(2), dp(2)) }
            iv.setOnClickListener { cfg.icon = name; refresh() }
            iconViews[name] = iv; grid.addView(iv)
        }
        root.addView(grid)

        root.addView(lbl("Colour"))
        val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
        for (col in colors) {
            val v = View(this)
            val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(col)
            v.background = g
            v.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).also { it.rightMargin = dp(10) }
            v.setOnClickListener { cfg.color = col; refresh() }
            row.addView(v)
        }
        root.addView(row)

        val styleKeys = listOf("solid", "grad", "glass"); val shapeKeys = listOf("r1", "r2", "r3")
        root.addView(lbl("Style"))
        root.addView(spinner(listOf("Solid", "Gradient", "Glass"), 1) { cfg.style = styleKeys[it]; refresh() })
        root.addView(lbl("Shape"))
        root.addView(spinner(listOf("Round", "Soft", "Sharp"), 1) { cfg.shape = shapeKeys[it]; refresh() })

        val save = Button(this); save.text = "Add widget"
        save.setOnClickListener { save() }
        root.addView(save)

        val sv = ScrollView(this); sv.addView(root); setContentView(sv)
        refresh()
    }

    private fun save() {
        if (cfg.type == "link" && cfg.value.isNotBlank() && !cfg.value.contains("://")) cfg.value = "https://" + cfg.value
        if (cfg.value.isBlank() || (cfg.type == "macro" && cfg.extra.isBlank())) {
            Toast.makeText(this, "Fill in the option first", Toast.LENGTH_SHORT).show(); return
        }
        if (cfg.label.isBlank()) cfg.label = cfg.target.ifBlank { "Widget" }
        Store.save(this, wid, cfg)
        BaseProvider.push(this, AppWidgetManager.getInstance(this), wid)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        finish()
    }

    private fun buildArea() {
        area.removeAllViews()
        when (cfg.type) {
            "app" -> area.addView(spinner(apps.map { it.first }, 0) { i ->
                cfg.value = apps[i].second; cfg.target = apps[i].first; labelEt.setText(apps[i].first) })
            "setting" -> area.addView(spinner(settingsList.map { it.first }, 0) { i ->
                cfg.value = settingsList[i].second; cfg.target = settingsList[i].first; labelEt.setText(settingsList[i].first) })
            "link" -> {
                val e = EditText(this); e.hint = "https://example.com"
                e.inputType = InputType.TYPE_TEXT_VARIATION_URI
                e.onText { cfg.value = it.trim(); cfg.target = it.trim() }
                area.addView(e)
            }
            "call" -> {
                val e = EditText(this); e.hint = "Phone number"; e.inputType = InputType.TYPE_CLASS_PHONE
                e.onText { cfg.value = it.trim(); cfg.target = it.trim() }
                area.addView(e)
            }
            "torch" -> { cfg.value = "torch"; cfg.target = "Torch"; labelEt.setText("Torch"); cfg.icon = "torch"; refresh() }
            "macro" -> {
                area.addView(spinner(apps.map { it.first }, 0) { i -> cfg.value = apps[i].second; cfg.target = apps[i].first })
                val e = EditText(this); e.hint = "Text of the option to tap, e.g. Status"
                e.onText { cfg.extra = it.trim(); cfg.target = it.trim(); if (labelEt.text.isBlank()) labelEt.setText(it.trim()) }
                area.addView(e)
                val n = TextView(this); n.text = "Needs the Widget Maker Accessibility service to be on."; n.textSize = 12f
                area.addView(n)
            }
        }
        refresh()
    }

    private fun refresh() {
        preview.setImageBitmap(Renderer.render(cfg.copy(label = cfg.label.ifBlank { "Widget" })))
        for ((k, v) in iconViews) v.setBackgroundColor(if (k == cfg.icon) 0x33000000 else Color.TRANSPARENT)
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }.distinct().sortedBy { it.first.lowercase() }
        apps.addAll(list)
    }

    private fun lbl(t: String): TextView {
        val v = TextView(this); v.text = t; v.textSize = 13f; v.setPadding(0, dp(16), 0, dp(4)); return v
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        if (sel in items.indices) s.setSelection(sel)
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    private fun EditText.onText(f: (String) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { f(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }
}
