package com.widgetmaker.app

import android.app.Activity
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.widget.Toast

class ActionActivity : Activity() {
    companion object { var torchOn = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.getStringExtra("type")) {
            "torch" -> toggleTorch()
            "macro" -> runMacro(intent.getStringExtra("pkg") ?: "", intent.getStringExtra("text") ?: "")
        }
        finish()
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Torch not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runMacro(pkg: String, text: String) {
        if (!MacroService.running) {
            Toast.makeText(this, "Turn on Widget Maker in Accessibility settings first", Toast.LENGTH_LONG).show()
        }
        MacroService.pkg = pkg
        MacroService.text = text
        MacroService.until = System.currentTimeMillis() + 8000
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }
}
