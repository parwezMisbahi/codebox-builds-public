package com.widgetmaker.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        fun tv(t: String, sz: Float, bold: Boolean = false): TextView {
            val v = TextView(this); v.text = t; v.textSize = sz
            if (bold) v.setTypeface(null, Typeface.BOLD)
            v.setPadding(0, 0, 0, (12 * d).toInt()); return v
        }
        fun btn(t: String, f: () -> Unit): Button {
            val b = Button(this); b.text = t; b.setOnClickListener { f() }; return b
        }
        root.addView(tv("Widget Maker", 26f, true))
        root.addView(tv("Make a home screen widget for any app, setting, link or action.", 14f))
        val list = listOf<Pair<String, Class<*>>>(
            "Small (1×1)" to SmallProvider::class.java,
            "Wide (2×1)" to WideProvider::class.java,
            "Large (2×2)" to LargeProvider::class.java
        )
        for ((n, c) in list) root.addView(btn("Add $n widget") { pin(c) })
        root.addView(tv("\nIn-app options (like WhatsApp: Status) need the Accessibility service.", 13f))
        root.addView(btn("Enable Accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        val sv = ScrollView(this); sv.addView(root); setContentView(sv)
    }

    private fun pin(c: Class<*>) {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, c), null, null)
        } else {
            Toast.makeText(this, "Long-press the home screen, open Widgets and pick Widget Maker", Toast.LENGTH_LONG).show()
        }
    }
}
