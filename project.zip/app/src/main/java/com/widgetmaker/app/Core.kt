package com.widgetmaker.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.widget.RemoteViews
import androidx.core.graphics.PathParser
import org.json.JSONObject

data class Cfg(
    var type: String = "app", var target: String = "", var value: String = "", var extra: String = "",
    var label: String = "", var icon: String = "star", var color: Int = 0xFF5B5BF0.toInt(),
    var style: String = "grad", var shape: String = "r2", var size: String = "s2"
)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("wm", Context.MODE_PRIVATE)
    fun save(c: Context, id: Int, f: Cfg) {
        val o = JSONObject()
        o.put("type", f.type); o.put("target", f.target); o.put("value", f.value); o.put("extra", f.extra)
        o.put("label", f.label); o.put("icon", f.icon); o.put("color", f.color)
        o.put("style", f.style); o.put("shape", f.shape); o.put("size", f.size)
        sp(c).edit().putString("w$id", o.toString()).apply()
    }
    fun load(c: Context, id: Int): Cfg? {
        val s = sp(c).getString("w$id", null) ?: return null
        return try {
            val o = JSONObject(s)
            Cfg(o.getString("type"), o.getString("target"), o.getString("value"), o.getString("extra"),
                o.getString("label"), o.getString("icon"), o.getInt("color"),
                o.getString("style"), o.getString("shape"), o.getString("size"))
        } catch (e: Exception) { null }
    }
    fun delete(c: Context, id: Int) { sp(c).edit().remove("w$id").apply() }
}

// SVG path data (24x24 grid, stroke icons)
object Icons {
    val map = linkedMapOf(
        "chat" to "M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z",
        "play" to "M7 4.5v15l12-7.5z",
        "camera" to "M4 8h3l2-3h6l2 3h3v11H4z M8.5 13.5 a3.5,3.5 0 1,0 7,0 a3.5,3.5 0 1,0 -7,0",
        "globe" to "M3 12 a9,9 0 1,0 18,0 a9,9 0 1,0 -18,0 M3 12h18 M12 3c3.5 3.5 3.5 14.5 0 18 M12 3c-3.5 3.5-3.5 14.5 0 18",
        "phone" to "M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z",
        "map" to "M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z M9.5 10 a2.5,2.5 0 1,0 5,0 a2.5,2.5 0 1,0 -5,0",
        "wifi" to "M2 9a15 15 0 0 1 20 0 M5 12.5a10 10 0 0 1 14 0 M8.5 16a5 5 0 0 1 7 0 M12 19.5h.01",
        "bt" to "M7 7l10 10-5 4V3l5 4L7 17",
        "torch" to "M8 2h8v5l-2 3v12h-4V10L8 7z",
        "sun" to "M8 12 a4,4 0 1,0 8,0 a4,4 0 1,0 -8,0 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1.5 1.5 M17.5 17.5L19 19 M5 19l1.5-1.5 M17.5 6.5L19 5",
        "mute" to "M6 17h12l-2-3v-4a4 4 0 0 0-8 0v4z M10 20h4 M3 3l18 18",
        "bat" to "M3 8h16v9H3z M21 11v3 M7 12.5h5",
        "down" to "M12 4v11 M7 11l5 5 5-5 M5 20h14",
        "moon" to "M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z",
        "star" to "M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z",
        "music" to "M9 18V5l11-2v13 M4 18 a2.5,2.5 0 1,0 5,0 a2.5,2.5 0 1,0 -5,0 M15 16 a2.5,2.5 0 1,0 5,0 a2.5,2.5 0 1,0 -5,0",
        "clock" to "M3 12 a9,9 0 1,0 18,0 a9,9 0 1,0 -18,0 M12 7v5l3 2",
        "home" to "M4 11l8-7 8 7v9h-5v-6H9v6H4z",
        "lock" to "M5 11h14v10H5z M8 11V8a4 4 0 0 1 8 0v3",
        "note" to "M6 3h9l4 4v14H6z M9 12h7 M9 16h7"
    )
}

object Renderer {
    fun icon(c: Canvas, name: String, x: Float, y: Float, size: Float, color: Int) {
        val path = PathParser.createPathFromPathData(Icons.map[name] ?: Icons.map["star"]!!)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f; p.color = color
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        c.save(); c.translate(x, y); val s = size / 24f; c.scale(s, s); c.drawPath(path, p); c.restore()
    }

    private fun fit(t: String, p: Paint, maxW: Float): String {
        val n = p.breakText(t, true, maxW, null)
        return if (n < t.length) t.substring(0, maxOf(n - 1, 0)) + "…" else t
    }

    private fun darken(col: Int): Int {
        val h = FloatArray(3); Color.colorToHSV(col, h); h[2] *= 0.62f; return Color.HSVToColor(h)
    }

    fun render(cfg: Cfg): Bitmap {
        val w: Int; val h: Int
        when (cfg.size) { "s1" -> { w = 256; h = 256 }; "s2" -> { w = 512; h = 256 }; else -> { w = 512; h = 512 } }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val rect = RectF(6f, 6f, w - 6f, h - 6f)
        val m = minOf(w, h).toFloat()
        val r = when (cfg.shape) { "r1" -> m / 2f; "r2" -> m * 0.22f; else -> m * 0.06f }
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        when (cfg.style) {
            "grad" -> bg.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), cfg.color, darken(cfg.color), Shader.TileMode.CLAMP)
            "glass" -> bg.color = Color.argb(80, 255, 255, 255)
            else -> bg.color = cfg.color
        }
        c.drawRoundRect(rect, r, r, bg)
        if (cfg.style == "glass") {
            val st = Paint(Paint.ANTI_ALIAS_FLAG)
            st.style = Paint.Style.STROKE; st.strokeWidth = 3f; st.color = Color.argb(150, 255, 255, 255)
            c.drawRoundRect(rect, r, r, st)
        }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = Color.WHITE; tp.typeface = Typeface.DEFAULT_BOLD
        val label = cfg.label
        when (cfg.size) {
            "s1" -> {
                icon(c, cfg.icon, (w - 96f) / 2f, 50f, 96f, Color.WHITE)
                tp.textSize = 30f; tp.textAlign = Paint.Align.CENTER
                c.drawText(fit(label, tp, w - 48f), w / 2f, 205f, tp)
            }
            "s2" -> {
                icon(c, cfg.icon, 48f, (h - 104f) / 2f, 104f, Color.WHITE)
                tp.textSize = 44f
                c.drawText(fit(label, tp, w - 210f), 178f, h / 2f + 15f, tp)
            }
            else -> {
                icon(c, cfg.icon, (w - 200f) / 2f, 90f, 200f, Color.WHITE)
                tp.textSize = 56f; tp.textAlign = Paint.Align.CENTER
                c.drawText(fit(label, tp, w - 80f), w / 2f, h - 80f, tp)
            }
        }
        return b
    }
}

object Actions {
    fun pending(ctx: Context, c: Cfg, id: Int): PendingIntent {
        val i: Intent = when (c.type) {
            "app" -> ctx.packageManager.getLaunchIntentForPackage(c.value) ?: Intent()
            "setting" -> Intent(c.value)
            "link" -> Intent(Intent.ACTION_VIEW, Uri.parse(c.value))
            "call" -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.value)))
            else -> Intent(ctx, ActionActivity::class.java)
                .putExtra("type", c.type).putExtra("pkg", c.value).putExtra("text", c.extra)
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
}

fun sizeOf(m: AppWidgetManager, id: Int): String {
    val n = m.getAppWidgetInfo(id)?.provider?.className ?: ""
    return when { n.contains("Small") -> "s1"; n.contains("Large") -> "s3"; else -> "s2" }
}

open class BaseProvider : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) { ids.forEach { push(ctx, m, it) } }
    override fun onDeleted(ctx: Context, ids: IntArray) { ids.forEach { Store.delete(ctx, it) } }
    companion object {
        fun push(ctx: Context, m: AppWidgetManager, id: Int) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            val cfg = Store.load(ctx, id)
            if (cfg == null) {
                val tmp = Cfg(label = "Tap to set up", icon = "star", size = sizeOf(m, id), color = 0xFF2B2F3A.toInt())
                rv.setImageViewBitmap(R.id.img, Renderer.render(tmp))
                val i = Intent(ctx, ConfigActivity::class.java)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                rv.setOnClickPendingIntent(R.id.img,
                    PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            } else {
                rv.setImageViewBitmap(R.id.img, Renderer.render(cfg))
                rv.setOnClickPendingIntent(R.id.img, Actions.pending(ctx, cfg, id))
            }
            m.updateAppWidget(id, rv)
        }
    }
}
class SmallProvider : BaseProvider()
class WideProvider : BaseProvider()
class LargeProvider : BaseProvider()
