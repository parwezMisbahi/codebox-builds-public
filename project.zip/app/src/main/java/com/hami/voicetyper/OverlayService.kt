package com.hami.voicetyper

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.ParcelFileDescriptor
import java.io.IOException
import java.io.OutputStream
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Chhota floating overlay: mic / language / minimize / close.
 * Bola hua text overlay ke panel mein screen par dikhta hai, aur Copy button se copy hota hai.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.hami.voicetyper.STOP"
        const val ACTION_CAPTURE_GRANTED = "com.hami.voicetyper.CAPTURE_GRANTED"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_ID = "voicetyper_overlay"
        private const val NOTIF_ID = 17

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var root: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var textView: TextView
    private lateinit var actionRow: LinearLayout
    private lateinit var copyPill: TextView
    private lateinit var micBtn: TextView
    private lateinit var langBtn: TextView
    private lateinit var toggleBtn: TextView
    private val extraViews = mutableListOf<View>()

    private var viewAdded = false
    private var collapsed = false

    private val committed = StringBuilder()
    private var partial = ""

    private var recognizer: SpeechRecognizer? = null
    private var wantListening = false
    private val handler = Handler(Looper.getMainLooper())
    private var lastToast = 0L

    private val restartRunnable = Runnable { beginRecognition() }

    // ---- video (system audio) mode
    private lateinit var videoBtn: TextView
    private var projection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    @Volatile private var capturing = false
    @Volatile private var videoMode = false
    private val sinkLock = Any()
    private var sink: OutputStream? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Service start nahi hui: mic permission check karo", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission chahiye", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        buildOverlay()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_CAPTURE_GRANTED -> {
                @Suppress("DEPRECATION")
                val data = intent?.getParcelableExtra<Intent>("data")
                startCapture(intent?.getIntExtra("code", 0) ?: 0, data)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopCapture()
        running = false
        handler.removeCallbacks(restartRunnable)
        wantListening = false
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
        if (viewAdded) {
            try {
                wm.removeView(root)
            } catch (_: Exception) {
            }
            viewAdded = false
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ notification

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Voice Typer", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
        else Notification.Builder(this)
        @Suppress("DEPRECATION")
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Voice Typer chal raha hai")
            .setContentText("Overlay ka mic dabao aur bolo")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Band karo", stop)
            .build()
    }

    // ----------------------------------------------------------------- overlay

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun makeBtn(label: String, sizeDp: Int, bg: Int, textSp: Float, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = textSp
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = circle(bg)
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
                marginStart = dp(4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makePill(label: String, bg: Int, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(7), dp(16), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(bg)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(8) }
            setOnClickListener { onClick() }
        }
    }

    private fun buildOverlay() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xEE202124.toInt())
            }
        }

        // ---- text panel (upar): bola hua text + Copy / Clear
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(6))
            visibility = View.GONE
        }

        textView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            maxWidth = dp(270)
            setLineSpacing(0f, 1.15f)
        }
        scroll = object : ScrollView(this@OverlayService) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                super.onMeasure(
                    widthMeasureSpec,
                    MeasureSpec.makeMeasureSpec(dp(130), MeasureSpec.AT_MOST)
                )
            }
        }.apply {
            isVerticalScrollBarEnabled = false
            addView(textView)
        }

        copyPill = makePill("Copy", 0xFF1E8E3E.toInt()) { copyText() }
        val clearPill = makePill("Clear", 0x44FFFFFF) { clearText() }
        actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, 0)
            visibility = View.GONE
            addView(copyPill)
            addView(clearPill)
        }

        panel.addView(scroll)
        panel.addView(actionRow)

        // ---- control row (neeche)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val handle = TextView(this).apply {
            text = "⋮"
            setTextColor(0xFF9AA0A6.toInt())
            textSize = 20f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(44))
        }
        attachDrag(handle)

        micBtn = makeBtn("🎤", 44, 0xFF43A047.toInt(), 20f) { toggleListening() }
        langBtn = makeBtn(Langs.tags[Prefs.langIndex(this)], 38, 0x44FFFFFF, 12f) { cycleLanguage() }
        videoBtn = makeBtn("📺", 38, 0x44FFFFFF, 16f) { toggleVideoMode() }
        val closeBtn = makeBtn("✕", 34, 0x66E53935, 14f) { stopSelf() }
        toggleBtn = makeBtn("–", 34, 0x44FFFFFF, 16f) { collapsed = !collapsed; applyCollapsed() }

        extraViews.addAll(listOf(langBtn, videoBtn, closeBtn))

        row.addView(handle)
        row.addView(micBtn)
        row.addView(langBtn)
        row.addView(videoBtn)
        row.addView(toggleBtn)
        row.addView(closeBtn)

        root.addView(panel)
        root.addView(row)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(220)
        }

        try {
            wm.addView(root, params)
            viewAdded = true
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay nahi dikh saka", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun attachDrag(v: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val dm = resources.displayMetrics
                    val maxX = (dm.widthPixels - root.width).coerceAtLeast(0)
                    val maxY = (dm.heightPixels - root.height).coerceAtLeast(0)
                    params.x = (startX + (e.rawX - touchX).toInt()).coerceIn(0, maxX)
                    params.y = (startY + (e.rawY - touchY).toInt()).coerceIn(0, maxY)
                    if (viewAdded) wm.updateViewLayout(root, params)
                }
            }
            true
        }
    }

    private fun applyCollapsed() {
        extraViews.forEach { it.visibility = if (collapsed) View.GONE else View.VISIBLE }
        toggleBtn.text = if (collapsed) "+" else "–"
        refreshPanel()
    }

    private fun updateUi() {
        (micBtn.background as GradientDrawable)
            .setColor(if (wantListening) 0xFFE53935.toInt() else 0xFF43A047.toInt())
        micBtn.invalidate()
    }

    // ------------------------------------------------------------- text panel

    private fun refreshPanel() {
        val hasCommitted = committed.isNotEmpty()
        val shown = buildString {
            append(committed)
            if (partial.isNotBlank()) {
                if (isNotEmpty()) append(' ')
                append(partial)
            }
        }
        val visible = !collapsed && (shown.isNotBlank() || wantListening)
        panel.visibility = if (visible) View.VISIBLE else View.GONE
        textView.text = if (shown.isNotBlank()) shown else "Boliye…"
        textView.alpha = if (shown.isNotBlank()) 1f else 0.6f
        actionRow.visibility = if (hasCommitted) View.VISIBLE else View.GONE
        // naya text aaye to neeche tak scroll
        scroll.post { scroll.scrollTo(0, textView.height) }
        if (viewAdded) wm.updateViewLayout(root, params)
    }

    private fun fixScript(t: String): String =
        if (Langs.isHinglish(Prefs.langIndex(this))) Hinglish.toRoman(t) else t

    private fun setPartial(t: String) {
        partial = fixScript(t)
        refreshPanel()
    }

    private fun commit(text: String) {
        if (committed.isNotEmpty()) committed.append(' ')
        committed.append(fixScript(text))
        partial = ""
        refreshPanel()
    }

    private fun clearText() {
        committed.setLength(0)
        partial = ""
        refreshPanel()
    }

    private fun copyText() {
        val t = committed.toString().trim()
        if (t.isEmpty()) return
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("voice", t))
            copyPill.text = "Copied ✓"
            handler.postDelayed({ copyPill.text = "Copy" }, 1500)
        } catch (e: Exception) {
            Toast.makeText(this, "Copy nahi ho saka", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- language

    private fun cycleLanguage() {
        val next = (Prefs.langIndex(this) + 1) % Langs.codes.size
        Prefs.setLangIndex(this, next)
        langBtn.text = Langs.tags[next]
        if (wantListening) {
            try {
                recognizer?.cancel()
            } catch (_: Exception) {
            }
            scheduleRestart(250)
        }
    }

    // ------------------------------------------------------------- recognition

    private fun toggleListening() {
        if (wantListening) stopListening() else startListening()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle app kholkar mic permission do")
            return
        }
        wantListening = true
        updateUi()
        partial = ""
        refreshPanel()
        beginRecognition()
    }

    private fun stopListening() {
        wantListening = false
        handler.removeCallbacks(restartRunnable)
        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }
        partial = ""
        updateUi()
        refreshPanel()
    }

    private fun scheduleRestart(delayMs: Long) {
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delayMs)
    }

    private fun resetRecognizer() {
        try {
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
    }

    private fun recognizerIntent(): Intent {
        val code = Langs.codes[Prefs.langIndex(this)]
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, code)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, code)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
    }

    // ------------------------------------------------------- video (system audio)

    private fun updateVideoUi() {
        (videoBtn.background as GradientDrawable)
            .setColor(if (videoMode) 0xFF1E88E5.toInt() else 0x44FFFFFF)
        videoBtn.invalidate()
    }

    private fun toggleVideoMode() {
        if (Build.VERSION.SDK_INT < 33) {
            toast("Video sound ke liye Android 13 ya upar chahiye")
            return
        }
        if (videoMode) {
            stopCapture()
            toast("Video mode band: ab mic se sunega")
            if (wantListening) restartRecognitionNow()
        } else {
            try {
                startActivity(
                    Intent(this, CaptureRequestActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                toast("Permission screen nahi khul saki")
            }
        }
    }

    private fun restartRecognitionNow() {
        try {
            recognizer?.cancel()
        } catch (_: Exception) {
        }
        closeSink()
        scheduleRestart(200)
    }

    private fun startCapture(code: Int, data: Intent?) {
        if (data == null || Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle app kholkar mic permission do")
            return
        }
        try {
            val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(NOTIF_ID, buildNotification(), type)

            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    handler.post {
                        if (capturing) {
                            stopCapture()
                            toast("Video capture band ho gaya")
                        }
                    }
                }
            }, handler)
            projection = p

            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 8192) * 2)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                throw IllegalStateException("AudioRecord init nahi hua")
            }
            audioRecord = rec
            rec.startRecording()
            capturing = true
            videoMode = true
            captureThread = Thread({ captureLoop(rec) }, "vt-capture").also { it.start() }
            updateVideoUi()
            toast("Video mode ON: ab video ki awaaz suni jayegi")
            if (wantListening) restartRecognitionNow()
        } catch (e: Exception) {
            stopCapture()
            toast("Video sound capture shuru nahi hui")
        }
    }

    private fun captureLoop(rec: AudioRecord) {
        val buf = ByteArray(3200)
        while (capturing) {
            val n = try {
                rec.read(buf, 0, buf.size)
            } catch (e: Exception) {
                -1
            }
            if (n <= 0) {
                if (!capturing) break
                try {
                    Thread.sleep(20)
                } catch (_: InterruptedException) {
                    break
                }
                continue
            }
            val s = synchronized(sinkLock) { sink } ?: continue
            try {
                s.write(buf, 0, n)
            } catch (e: IOException) {
                closeSink()
            }
        }
    }

    private fun stopCapture() {
        capturing = false
        videoMode = false
        closeSink()
        try {
            audioRecord?.stop()
        } catch (_: Exception) {
        }
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null
        captureThread = null
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null
        if (::videoBtn.isInitialized) updateVideoUi()
    }

    private fun closeSink() {
        val s = synchronized(sinkLock) {
            val x = sink
            sink = null
            x
        }
        try {
            s?.close()
        } catch (_: Exception) {
        }
    }

    private fun beginRecognition() {
        if (!wantListening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Google Speech / Voice service install ya enable karo")
            stopListening()
            return
        }
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(listener)
                }
            }
            val intent = recognizerIntent()
            var readEnd: ParcelFileDescriptor? = null
            if (videoMode && capturing && Build.VERSION.SDK_INT >= 33) {
                closeSink()
                val pipe = ParcelFileDescriptor.createPipe()
                readEnd = pipe[0]
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, readEnd)
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                intent.putExtra(
                    RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT
                )
                intent.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, SAMPLE_RATE)
                synchronized(sinkLock) {
                    sink = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
                }
            }
            recognizer?.startListening(intent)
            try {
                readEnd?.close()
            } catch (_: Exception) {
            }
        } catch (e: Exception) {
            resetRecognizer()
            scheduleRestart(700)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) setPartial(t)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            closeSink()
            if (text.isNotEmpty()) commit(text) else setPartial("")
            if (wantListening) scheduleRestart(100)
        }

        override fun onError(error: Int) {
            closeSink()
            if (!wantListening) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    setPartial("")
                    scheduleRestart(150)
                }

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT,
                11 /* ERROR_SERVER_DISCONNECTED */ -> {
                    resetRecognizer()
                    scheduleRestart(700)
                }

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    toast("Mic permission do")
                    stopListening()
                }

                else -> {
                    toast("Awaaz ka error ($error). Internet / language check karo")
                    stopListening()
                }
            }
        }
    }

    private fun toast(msg: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastToast < 2500) return
        lastToast = now
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
