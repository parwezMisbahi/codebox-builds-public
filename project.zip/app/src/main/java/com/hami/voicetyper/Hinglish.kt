package com.hami.voicetyper

/**
 * Devanagari (Hindi) text ko Roman (Hinglish) mein badalta hai.
 * Angrezi ke alfaaz jo pehle se Latin mein hain, jaise hain rehte hain.
 * Spelling andaazi hoti hai (kisi ek standard par nahi), par padhne layak hoti hai.
 */
object Hinglish {

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'ळ' to "l", 'व' to "v",
        'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
        'क़' to "q", 'ख़' to "kh", 'ग़' to "g", 'ज़' to "z",
        'ड़' to "r", 'ढ़' to "rh", 'फ़' to "f", 'य़' to "y"
    )

    private val nukta = mapOf(
        'क' to "q", 'ख' to "kh", 'ग' to "g", 'ज' to "z",
        'ड' to "r", 'ढ' to "rh", 'फ' to "f", 'य' to "y"
    )

    private val vowels = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "oo",
        'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au",
        'ऑ' to "o", 'ऍ' to "e"
    )

    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "oo",
        'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ॅ' to "e", 'ॉ' to "o"
    )

    private const val VIRAMA = '्'
    private const val NUKTA = '़'

    private val overrides = mapOf(
        "men" to "mein",
        "yah" to "yeh",
        "vah" to "woh",
        "ham" to "hum",
        "nahin" to "nahi"
    )

    private class Syl(var c: String, var v: String?, var explicit: Boolean) {
        var coda = ""
    }

    fun toRoman(text: String): String {
        if (text.none { it in 'ऀ'..'ॿ' }) return text

        val out = StringBuilder()
        val word = ArrayList<Syl>()

        fun flush() {
            val n = word.size
            if (n == 0) return
            if (n > 1 && word[n - 1].v == null) word[n - 1].v = ""
            for (k in 1 until n - 1) {
                val s = word[k]
                if (s.v != null) continue
                val prev = word[k - 1]
                val next = word[k + 1]
                if (prev.v != "" && next.explicit && next.v != "") s.v = ""
            }
            val sb = StringBuilder()
            for (s in word) sb.append(s.c).append(s.v ?: "a").append(s.coda)
            val roman = sb.toString()
            out.append(overrides[roman] ?: roman)
            word.clear()
        }

        var i = 0
        while (i < text.length) {
            val ch = text[i]
            val cr = cons[ch]
            when {
                ch == 'ज' && i + 2 < text.length && text[i + 1] == VIRAMA && text[i + 2] == 'ञ' -> {
                    word.add(Syl("gy", null, false))
                    i += 2
                }
                cr != null -> {
                    var r: String = cr
                    if (i + 1 < text.length && text[i + 1] == NUKTA) {
                        r = nukta[ch] ?: r
                        i++
                    }
                    word.add(Syl(r, null, false))
                }
                vowels.containsKey(ch) -> word.add(Syl("", vowels[ch], true))
                matras.containsKey(ch) -> {
                    val l = word.lastOrNull()
                    if (l != null && l.v == null) {
                        l.v = matras[ch]
                        l.explicit = true
                    }
                }
                ch == VIRAMA -> {
                    val l = word.lastOrNull()
                    if (l != null && l.v == null) {
                        l.v = ""
                        l.explicit = true
                    }
                }
                ch == 'ं' || ch == 'ँ' -> word.lastOrNull()?.let { it.coda += "n" }
                ch == 'ः' -> word.lastOrNull()?.let { it.coda += "h" }
                ch == NUKTA -> {}
                else -> {
                    flush()
                    when {
                        ch in '०'..'९' -> out.append('0' + (ch - '०'))
                        ch == '।' || ch == '॥' -> out.append('.')
                        else -> out.append(ch)
                    }
                }
            }
            i++
        }
        flush()
        return out.toString()
    }
}
