package com.hami.voicetyper

import android.content.Context

object Langs {
    val codes = listOf("ur-PK", "en-US", "hi-IN")
    val tags = listOf("UR", "EN", "HI")
    val names = listOf("Urdu (اردو)", "English", "Hindi (हिन्दी)")
}

object Prefs {
    private const val FILE = "voicetyper"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun langIndex(c: Context): Int =
        sp(c).getInt("lang", 0).coerceIn(0, Langs.codes.lastIndex)

    fun setLangIndex(c: Context, i: Int) {
        sp(c).edit().putInt("lang", i).apply()
    }
}
