package com.hami.voicetyper

import android.content.Context

object Langs {
    // Hinglish = Hindi recognition (hi-IN) + Roman mein transliteration
    val codes = listOf("ur-PK", "en-US", "hi-IN", "hi-IN")
    val tags = listOf("UR", "EN", "HI", "HG")
    val names = listOf("Urdu (اردو)", "English", "Hindi (हिन्दी)", "Hinglish (Roman letters)")

    fun isHinglish(index: Int) = index == 3
}

object Prefs {
    private const val FILE = "voicetyper"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun langIndex(c: Context): Int =
        sp(c).getInt("lang", 0).coerceIn(0, Langs.codes.lastIndex)

    fun setLangIndex(c: Context, i: Int) {
        sp(c).edit().putInt("lang", i).apply()
    }
}
