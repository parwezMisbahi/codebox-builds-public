package com.hami.voicetyper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var micStatus: TextView
    private lateinit var micBtn: Button
    private lateinit var overlayStatus: TextView
    private lateinit var overlayBtn: Button
    private lateinit var startBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // --------------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun card() = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.parseColor("#DADCE0"))
    }

    private fun margins(top: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun text(s: String, sp: Float, bold: Boolean = false, color: String = "#202124") =
        TextView(this).apply {
            text = s
            textSize = sp
            setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun permissionCard(title: String, desc: String, status: TextView, btn: Button): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = card()
            layoutParams = margins(10)
        }
        box.addView(text(title, 16f, true))
        box.addView(text(desc, 13f, false, "#5F6368"))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        status.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(status)
        row.addView(btn)
        box.addView(row)
        return box
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(32))
        }

        col.addView(text("🎤 Voice Typer", 26f, true))
        col.addView(text("Bolo, aur text screen par aa jayega. Copy dabao aur kahin bhi paste karo.", 14f, false, "#5F6368"))

        micStatus = text("", 14f)
        micBtn = Button(this).apply { text = "Allow"; setOnClickListener { askMic() } }
        col.addView(permissionCard("1. Microphone", "Awaaz sunne ke liye.", micStatus, micBtn))

        overlayStatus = text("", 14f)
        overlayBtn = Button(this).apply {
            text = "Allow"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        col.addView(
            permissionCard(
                "2. Display over other apps",
                "Chhota floating mic aur text dikhane ke liye.",
                overlayStatus, overlayBtn
            )
        )

        // language
        val langBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = card()
            layoutParams = margins(14)
        }
        langBox.addView(text("Bolne ki zubaan", 16f, true))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val current = Prefs.langIndex(this)
        Langs.names.forEachIndexed { i, n ->
            group.addView(RadioButton(this).apply {
                id = 1000 + i
                text = n
                isChecked = i == current
            })
        }
        group.setOnCheckedChangeListener { _, checked -> Prefs.setLangIndex(this, checked - 1000) }
        langBox.addView(group)
        langBox.addView(text("Overlay par UR/EN/HI button se bhi badal sakte ho.", 12f, false, "#5F6368"))
        col.addView(langBox)

        startBtn = Button(this).apply {
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E8E3E"))
                cornerRadius = dp(14).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
            ).apply { topMargin = dp(18) }
            setOnClickListener { toggleOverlay() }
        }
        col.addView(startBtn)

        col.addView(
            text(
                "Use: overlay shuru karo → 🎤 dabao aur bolo → text overlay mein dikhega → Copy dabao. " +
                        "Dobara 🎤 dabao to band. Clear = text saaf, – = chhota karo, ✕ = band.",
                12f, false, "#5F6368"
            ).apply { layoutParams = margins(12) }
        )

        return ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F1F3F4"))
            addView(col)
        }
    }

    // ---------------------------------------------------------------- actions

    private fun askMic() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
        if (!micGranted() && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            // permanently denied -> app settings
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else {
            val i = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            handler.postDelayed({ moveTaskToBack(true) }, 400)
        }
        handler.postDelayed({ refresh() }, 600)
    }

    // ----------------------------------------------------------------- status

    private fun micGranted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun setStatus(tv: TextView, btn: Button, ok: Boolean) {
        tv.text = if (ok) "✅ Ho gaya" else "❌ Baaki hai"
        tv.setTextColor(Color.parseColor(if (ok) "#1E8E3E" else "#D93025"))
        btn.isEnabled = !ok
        btn.alpha = if (ok) 0.45f else 1f
    }

    private fun refresh() {
        val mic = micGranted()
        val ov = Settings.canDrawOverlays(this)
        setStatus(micStatus, micBtn, mic)
        setStatus(overlayStatus, overlayBtn, ov)

        val ready = mic && ov
        val running = OverlayService.running
        startBtn.isEnabled = ready || running
        startBtn.alpha = if (ready || running) 1f else 0.5f
        startBtn.text = if (running) "Overlay band karo" else "Overlay shuru karo"
    }
}
