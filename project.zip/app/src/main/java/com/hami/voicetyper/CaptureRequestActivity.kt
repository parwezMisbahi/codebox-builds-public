package com.hami.voicetyper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

/**
 * Transparent activity: system audio capture ki permission (MediaProjection) maangti hai
 * aur result OverlayService ko de kar band ho jati hai.
 */
class CaptureRequestActivity : Activity() {

    private val reqCode = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), reqCode)
        } catch (e: Exception) {
            Toast.makeText(this, "Permission screen nahi khul saki", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_CAPTURE_GRANTED)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startService(i)
        } else {
            Toast.makeText(this, "Video sound ki permission nahi mili", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
