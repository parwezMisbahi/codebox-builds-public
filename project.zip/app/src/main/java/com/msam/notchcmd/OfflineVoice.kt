package com.msam.notchcmd

import android.content.Context

/** Bolne ke do tariqe: "google" (default) = assistant ka apna mic, Google ka recognizer (wahi jo Chrome ka Web Speech / VoiceNote.html use karta hai); "gboard" = Gboard ka mic. Keyboard se likhna dono mein chalta hai. */
object OfflineVoice {
    private fun sp(c: Context) = c.getSharedPreferences("offvoice", Context.MODE_PRIVATE)
    /** Gboard mic se bolne ke baad itne ms khamoshi to command apne aap chalegi. Default 4 sec */
    fun gboard(c: Context): Int = sp(c).getInt("gb4", 4000)
    fun nextGboard(c: Context): Int {
        val l = listOf(2000, 3000, 4000, 5000, 8000)
        val n = l[(l.indexOf(gboard(c)) + 1) % l.size]
        sp(c).edit().putInt("gb4", n).apply(); return n
    }
    /** Panel khulte hi Gboard ka mic assistant khud dabaye (default ON) */
    fun gbMic(c: Context): Boolean = sp(c).getBoolean("gbmic", true)
    fun toggleGbMic(c: Context): Boolean { val n = !gbMic(c); sp(c).edit().putBoolean("gbmic", n).apply(); return n }
    fun engine(c: Context): String = sp(c).getString("engine", "google") ?: "google"
    fun setEngine(c: Context, e: String) { sp(c).edit().putString("engine", e).apply() }
    /** true = purana Gboard-mic mode */
    fun useGboard(c: Context): Boolean = engine(c) == "gboard" && gboard(c) > 0
}
