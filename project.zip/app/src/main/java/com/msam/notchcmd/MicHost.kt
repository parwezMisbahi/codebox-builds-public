package com.msam.notchcmd

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager

/**
 * Transparent activity with no UI. Android only gives the microphone to a FOREGROUND app. The notch panel is just an
 * overlay on top of the home screen or another app, so the speech recognizer answered "error 9" (no permission).
 * While this invisible activity is on screen ZOKI counts as foreground, like Chrome does for VoiceNote.
 * Touches pass through it; the panel (an overlay) stays above it.
 */
class MicHost : Activity() {
    companion object {
        @Volatile var alive: MicHost? = null
        @Volatile var resumed = false

        fun ensure(c: Context) {
            if (alive != null) return
            try {
                c.startActivity(Intent(c, MicHost::class.java).addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS))
            } catch (_: Exception) {}
        }

        fun release() {
            val a = alive; alive = null; resumed = false
            try { a?.finish() } catch (_: Exception) {}
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        alive = this
        try { setShowWhenLocked(true) } catch (_: Throwable) {}
        window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        try { overridePendingTransition(0, 0) } catch (_: Throwable) {}
    }

    override fun onResume() { super.onResume(); resumed = true }
    override fun onPause() { super.onPause(); resumed = false }
    override fun onDestroy() { super.onDestroy(); if (alive === this) alive = null; resumed = false }
    override fun finish() { super.finish(); try { overridePendingTransition(0, 0) } catch (_: Throwable) {} }
}
