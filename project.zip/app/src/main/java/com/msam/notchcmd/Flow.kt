package com.msam.notchcmd

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Custom automations ("flows"): you build your own list of steps in the app, give it a name and a repeat count,
 * and say / tap "flow <name>" to run it. Steps are turned into the normal ZOKI steps by OverlayService.
 *
 * Example (PDF page -> AI -> Docera, again and again):
 *   open drive -> wait 2 -> screenshot -> ask AI (with the screenshot) -> save answer to Docera note "Page {n}"
 *   -> open drive -> next page (stop at the end)      repeat: until the end / N times
 *
 * {n} inside any text is replaced with the round number (1, 2, 3 ...).
 */
data class FStep(val t: String, val v: String = "", val v2: String = "")

/** repeat: 1 = once, N = N rounds, 0 = until Stop (or until a "next page" step sees the end). gap = seconds between rounds. */
data class AutoFlow(val name: String, val repeat: Int, val gap: Int, val steps: List<FStep>)

object FlowStore {
    private fun p(c: Context) = c.getSharedPreferences("flows", Context.MODE_PRIVATE)

    fun all(c: Context): List<AutoFlow> {
        val out = ArrayList<AutoFlow>()
        try {
            val a = JSONArray(p(c).getString("l", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val sa = o.optJSONArray("steps") ?: JSONArray()
                val st = ArrayList<FStep>()
                for (k in 0 until sa.length()) {
                    val s = sa.getJSONObject(k)
                    st.add(FStep(s.optString("t"), s.optString("v"), s.optString("v2")))
                }
                out.add(AutoFlow(o.optString("name"), o.optInt("repeat", 1), o.optInt("gap", 2), st))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun write(c: Context, l: List<AutoFlow>) {
        val a = JSONArray()
        l.forEach { f ->
            val sa = JSONArray()
            f.steps.forEach { sa.put(JSONObject().put("t", it.t).put("v", it.v).put("v2", it.v2)) }
            a.put(JSONObject().put("name", f.name).put("repeat", f.repeat).put("gap", f.gap).put("steps", sa))
        }
        p(c).edit().putString("l", a.toString()).apply()
    }

    fun put(c: Context, f: AutoFlow) {
        val nm = f.name.trim()
        if (nm.isEmpty()) return
        val l = ArrayList(all(c).filter { !it.name.equals(nm, true) })
        l.add(f.copy(name = nm, repeat = f.repeat.coerceIn(0, 999), gap = f.gap.coerceIn(0, 600)))
        write(c, l)
    }

    fun remove(c: Context, name: String) { write(c, all(c).filter { !it.name.equals(name, true) }) }

    fun find(c: Context, spoken: String): AutoFlow? {
        val s = spoken.trim().lowercase(Locale.ROOT)
        if (s.isEmpty()) return null
        return all(c).firstOrNull { it.name.trim().lowercase(Locale.ROOT) == s }
    }

    /** What the builder screen shows: step types and the fields each one needs (value lists are [value, label] pairs). */
    fun typesJson(): JSONArray {
        fun opts(vararg x: Pair<String, String>) = JSONArray().apply { x.forEach { put(JSONArray().put(it.first).put(it.second)) } }
        fun t(k: String, label: String, hint: String, f1: String? = null, ph: String = "", f1o: JSONArray? = null, f2: String? = null, f2o: JSONArray? = null) =
            JSONObject().put("k", k).put("label", label).put("hint", hint).put("f1", f1 ?: JSONObject.NULL).put("ph", ph)
                .put("f1o", f1o ?: JSONObject.NULL).put("f2", f2 ?: JSONObject.NULL).put("f2o", f2o ?: JSONObject.NULL)
        val ai = JSONArray().put(JSONArray().put("").put("My default AI app"))
        ResearchPrefs.ALL.forEach { ai.put(JSONArray().put(it.label).put(it.label)) }
        return JSONArray()
            .put(t("open", "Open an app", "Brings the app to the front", "App name", "drive"))
            .put(t("snap", "Take a screenshot", "Keeps the picture for the next AI step (Android 11 or newer)"))
            .put(t("ask", "Send to AI app and get the answer", "Sends the screenshot (if taken) and your question, waits, copies the answer",
                "What should the AI do?", "Read this page and write all the text", null, "Which AI app", ai))
            .put(t("save", "Save the answer to a Docera note", "Pastes the copied answer into a new Docera note",
                "Note title ({n} = round number)", "Page {n}", null, "Note content",
                opts("" to "Text only", "img" to "Text + the screenshot")))
            .put(t("next", "Next page / scroll", "Moves the screen forward so the next round sees new content",
                "How", "", opts("scrolldown" to "Scroll one screen down", "swu" to "Swipe up", "swl" to "Swipe left", "swr" to "Swipe right", "swd" to "Swipe down"),
                "At the end", opts("" to "Keep going", "end" to "Stop everything if the screen did not change")))
            .put(t("tap", "Tap a button / text", "Taps something on the screen by its text", "Text on screen", "Next"))
            .put(t("type", "Type text", "Types into the text box on screen", "Text", ""))
            .put(t("wait", "Wait", "Pause so the app can load", "Seconds (1-120)", "3"))
            .put(t("back", "Back button", "Presses Back"))
            .put(t("home", "Home button", "Goes to the home screen"))
            .put(t("say", "Speak", "ZOKI says this out loud", "Text", ""))
            .put(t("cmd", "Any ZOKI command", "Runs any command you can type to ZOKI (e.g. wifi on karo)", "Command", "wifi on karo"))
    }
}

/** Screenshot helpers for flows (the picture comes from NotchA11y.takeShot). */
object FlowShot {
    fun save(c: Context, bmp: Bitmap): String? {
        return try {
            val d = File(c.cacheDir, "flow").apply { mkdirs() }
            d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 3_600_000L) it.delete() }
            val f = File(d, "shot_" + System.nanoTime() + ".jpg")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            f.absolutePath
        } catch (_: Throwable) { null }
    }

    /** Tiny grey fingerprint (24x24) of a screenshot, used to see whether the screen changed. */
    fun sig(bmp: Bitmap): IntArray? {
        return try {
            val s = Bitmap.createScaledBitmap(bmp, 24, 24, true)
            val out = IntArray(24 * 24)
            for (y in 0 until 24) for (x in 0 until 24) {
                val px = s.getPixel(x, y)
                out[y * 24 + x] = (((px shr 16) and 255) * 3 + ((px shr 8) and 255) * 6 + (px and 255)) / 10
            }
            if (s !== bmp) s.recycle()
            out
        } catch (_: Throwable) { null }
    }

    fun same(a: IntArray?, b: IntArray?): Boolean {
        if (a == null || b == null || a.size != b.size) return false
        var sum = 0L
        for (i in a.indices) sum += Math.abs(a[i] - b[i])
        return sum.toDouble() / a.size < 2.0
    }
}
