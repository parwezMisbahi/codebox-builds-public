package com.msam.notchcmd

import android.app.Activity
import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Base64
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * The whole app UI is drawn by one WebView (assets/index.html).
 * The native screens still build their views (so every setting and the chat keep working exactly as before) but they stay
 * invisible: this class sends their view tree to the page as JSON about twice a second (faster right after a tap),
 * and turns taps / typing / switches in the page into the matching action on the real native view.
 *
 * source()   = the native root view to show (settings: the current page; chat: the whole chat screen)
 * navItems   = optional bottom nav (icon name, label); navPick(i) is called when the user taps another item.
 */
class WebUi(
    private val ctx: Activity,
    private val t: Style.T,
    private val source: () -> View?,
    private val navItems: List<Pair<String, String>>? = null,
    private val navPick: ((Int) -> Unit)? = null,
    private val hdrItems: List<Pair<String, String>>? = null,
    private val hdrPick: ((Int) -> Unit)? = null
) {
    private val d = ctx.resources.displayMetrics.density
    private val h = Handler(Looper.getMainLooper())
    private val reg = SparseArray<View>()
    private var nid = 0
    private var ready = false
    private var last = ""
    private var navSel = 0
    private var fast = 0
    private var running = false
    private val imgCache = HashMap<String, String>()

    private inner class Bridge {
        @JavascriptInterface fun ready() { ctx.runOnUiThread { ready = true; pushCfg(); last = ""; try { sync() } catch (_: Throwable) {} } }
        @JavascriptInterface fun act(id: Int, kind: String, v: String) { ctx.runOnUiThread { doAct(id, kind, v) } }
        @JavascriptInterface fun hdr(i: Int) { ctx.runOnUiThread { hdrPick?.invoke(i); kick() } }
        @JavascriptInterface fun nav(i: Int) { ctx.runOnUiThread { navSel = i; navPick?.invoke(i); kick() } }
    }

    val web: WebView = WebView(ctx).apply {
        setBackgroundColor(t.bg1)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isHapticFeedbackEnabled = false
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false
        settings.textZoom = 100
        settings.setSupportZoom(false)
        addJavascriptInterface(Bridge(), "ZB")
        loadUrl("file:///android_asset/index.html")
    }

    // ------------------------------------------------------------------ polling
    private val poll = object : Runnable {
        override fun run() {
            if (!running) return
            if (ready) try { sync() } catch (_: Throwable) {}
            val delay = if (fast > 0) { fast--; 60L } else 450L
            h.postDelayed(this, delay)
        }
    }
    private fun startPoll() { if (!running) { running = true; h.post(poll) } }
    private fun stopPoll() { running = false; h.removeCallbacks(poll) }
    private fun kick() { fast = 14; if (running) { h.removeCallbacks(poll); h.postDelayed(poll, 40) } }

    init {
        ctx.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        ctx.application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: Activity) { if (a === ctx) startPoll() }
            override fun onActivityPaused(a: Activity) { if (a === ctx) stopPoll() }
            override fun onActivityDestroyed(a: Activity) {
                if (a === ctx) { stopPoll(); ctx.application.unregisterActivityLifecycleCallbacks(this); try { web.destroy() } catch (_: Throwable) {} }
            }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
        })
        startPoll()
    }


    // ------------------------------------------------------------------ page <-> native
    private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun pushCfg() {
        val pill = if (t.light) "rgba(255,255,255,.6)" else "rgba(${Color.red(t.bg2)},${Color.green(t.bg2)},${Color.blue(t.bg2)},.6)"
        val cfg = JSONObject().put("bg1", hex(t.bg1)).put("bg2", hex(t.bg2)).put("tx", hex(t.text)).put("sub", hex(t.sub))
            .put("a1", hex(t.a1)).put("a2", hex(t.a2)).put("bt", hex(t.btnText)).put("st", hex(t.stroke))
            .put("light", t.light).put("pill", pill)
        if (navItems != null) {
            val arr = JSONArray()
            navItems.forEach { arr.put(JSONArray().put(it.first).put(it.second)) }
            cfg.put("nav", arr).put("sel", navSel)
        }
        if (hdrItems != null) {
            val arr = JSONArray()
            hdrItems.forEach { arr.put(JSONArray().put(it.first).put(it.second)) }
            cfg.put("hdr", arr)
        }
        web.evaluateJavascript("setup($cfg)", null)
    }

    /** move the nav blob when the page changed by other means (back button, a category row) */
    fun navSelect(i: Int) {
        if (navItems == null || i < -1 || i >= navItems.size || i == navSel) return
        navSel = i
        if (ready) web.evaluateJavascript("sel($i)", null)
    }

    /** scroll the page to a native view (used when the chat jumps to a setting) */
    fun scrollTo(view: View) {
        for (k in 0 until reg.size()) if (reg.valueAt(k) === view) { web.evaluateJavascript("scrollToNode(${reg.keyAt(k)})", null); return }
    }

    private fun doAct(id: Int, kind: String, v: String) {
        val view = reg.get(id)
        if (view != null) try {
            when (kind) {
                "click" -> view.performClick()
                "long" -> view.performLongClick()
                "check" -> (view as? CompoundButton)?.isChecked = (v == "1")
                "text" -> (view as? EditText)?.let { if (it.text.toString() != v) { it.setText(v); it.setSelection(v.length) } }
                "sel" -> (view as? Spinner)?.setSelection(v.toIntOrNull() ?: 0)
                "enter" -> (view as? EditText)?.let {
                    val a = it.imeOptions and EditorInfo.IME_MASK_ACTION
                    it.onEditorAction(if (a == 0 || a == EditorInfo.IME_ACTION_UNSPECIFIED) EditorInfo.IME_ACTION_DONE else a)
                }
            }
        } catch (_: Throwable) {}
        kick()
    }

    fun sync() {
        val root = source() ?: return
        reg.clear(); nid = 0
        val tree = ser(root, true, 0) ?: return
        val o = JSONObject().put("key", System.identityHashCode(root).toString())
            .put("full", root is FrameLayout && root !is ScrollView).put("tree", tree)
        val s = o.toString()
        if (s == last) return
        last = s
        web.evaluateJavascript("render($s)", null)
    }

    // ------------------------------------------------------------------ view tree -> JSON
    private fun dpi(px: Int) = Math.round(px / d)
    private fun r1(x: Float) = Math.round(x * 10f) / 10.0
    private fun col(c: Int): String = String.format(Locale.US, "rgba(%d,%d,%d,%.3f)", Color.red(c), Color.green(c), Color.blue(c), Color.alpha(c) / 255f)
    private fun arr4(a: Int, b: Int, c: Int, e: Int) = JSONArray().put(dpi(a)).put(dpi(b)).put(dpi(c)).put(dpi(e))   // CSS order: top right bottom left

    private fun paintOf(dr: Drawable?, o: JSONObject, depth: Int = 0) {
        if (dr == null || depth > 3) return
        try {
            when (dr) {
                is ColorDrawable -> o.put("bg", col(dr.color))
                is GradientDrawable -> {
                    val cs = dr.colors
                    if (cs != null && cs.size >= 2) o.put("gr", JSONArray().put(col(cs.first())).put(col(cs.last())))
                    else dr.color?.let { o.put("bg", col(it.defaultColor)) }
                    val rr = dr.cornerRadii
                    if (dr.shape == GradientDrawable.OVAL) o.put("r", 999)
                    else if (rr != null && rr.size >= 8)      // bubbles with a small "tail" corner: tl, tr, br, bl
                        o.put("rr", JSONArray().put(Math.round(rr[0] / d)).put(Math.round(rr[2] / d)).put(Math.round(rr[4] / d)).put(Math.round(rr[6] / d)))
                    else { val r = dr.cornerRadius; if (r > 0f) o.put("r", Math.round(r / d)) }
                }
                is RippleDrawable -> {
                    if (dr.numberOfLayers > 0) {
                        val l0 = dr.getDrawable(0)
                        if (l0 !== dr.findDrawableByLayerId(android.R.id.mask)) paintOf(l0, o, depth + 1)
                    }
                }
                is LayerDrawable -> if (dr.numberOfLayers > 0) paintOf(dr.getDrawable(0), o, depth + 1)
            }
        } catch (_: Throwable) {}
    }

    private fun imgSrc(v: ImageView): String? {
        val dr = v.drawable ?: return null
        val bm0 = (dr as? BitmapDrawable)?.bitmap
        val key = if (bm0 != null) "b" + System.identityHashCode(bm0)
                  else "d" + System.identityHashCode(dr.constantState ?: dr) + "_" + System.identityHashCode(v.colorFilter) + "_" + v.width
        imgCache[key]?.let { return it }
        val out = ByteArrayOutputStream()
        val mime: String
        try {
            if (bm0 != null) {
                val sc = minOf(1f, 360f / maxOf(bm0.width, bm0.height))
                val b = if (sc < 1f) Bitmap.createScaledBitmap(bm0, (bm0.width * sc).toInt().coerceAtLeast(1), (bm0.height * sc).toInt().coerceAtLeast(1), true) else bm0
                b.compress(Bitmap.CompressFormat.JPEG, 78, out); mime = "image/jpeg"
            } else {
                val pw = (if (v.width > 0) v.width else (24 * d).toInt()).times(2).coerceIn(48, 320)
                val ph = (if (v.height > 0) v.height else (24 * d).toInt()).times(2).coerceIn(48, 320)
                val b = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
                val dd = dr.constantState?.newDrawable()?.mutate() ?: dr
                dd.setBounds(v.paddingLeft * 2, v.paddingTop * 2, pw - v.paddingRight * 2, ph - v.paddingBottom * 2)
                dd.colorFilter = v.colorFilter
                dd.draw(Canvas(b))
                b.compress(Bitmap.CompressFormat.PNG, 100, out); mime = "image/png"
            }
        } catch (_: Throwable) { return null }
        val s = "data:$mime;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        if (imgCache.size > 120) imgCache.clear()
        imgCache[key] = s
        return s
    }

    private fun ser(v: View, root: Boolean, depth: Int): JSONObject? {
        if (!root && v.visibility != View.VISIBLE) return null
        if (depth > 40) return null
        val o = JSONObject()
        val id = nid++
        reg.put(id, v); o.put("id", id)
        if (v.hasOnClickListeners() && v !is CompoundButton && v !is EditText && v !is Spinner) o.put("c", 1)
        if (v.isLongClickable && v !is EditText) o.put("l", 1)

        val lp = v.layoutParams
        if (lp != null) {
            if (lp.width > 0) o.put("w", dpi(lp.width)) else if (lp.width == -1) o.put("w", -1)
            if (lp.height > 0) o.put("h", dpi(lp.height)) else if (lp.height == -1) o.put("h", -1)
            if (lp is LinearLayout.LayoutParams) {
                if (lp.weight > 0f) o.put("fl", lp.weight.toDouble())
                if (lp.gravity != -1) o.put("lg", lp.gravity)
            }
            if (lp is FrameLayout.LayoutParams && lp.gravity != -1) o.put("lg", lp.gravity)
            if (lp is ViewGroup.MarginLayoutParams && (lp.leftMargin != 0 || lp.topMargin != 0 || lp.rightMargin != 0 || lp.bottomMargin != 0))
                o.put("m", arr4(lp.topMargin, lp.rightMargin, lp.bottomMargin, lp.leftMargin))
        }
        if ((v.paddingLeft or v.paddingTop or v.paddingRight or v.paddingBottom) != 0)
            o.put("p", arr4(v.paddingTop, v.paddingRight, v.paddingBottom, v.paddingLeft))
        if (!root && v.alpha < 0.999f) o.put("a", Math.round(v.alpha * 1000f) / 1000.0)
        if (!root && (v.translationX != 0f || v.translationY != 0f)) o.put("tr", JSONArray().put(r1(v.translationX / d)).put(r1(v.translationY / d)))
        paintOf(v.background, o)
        (v.tag as? String)?.let { o.put("tag", it) }

        when {
            v is EditText -> {
                o.put("k", "e").put("tx", v.text.toString()).put("hint", v.hint?.toString() ?: "")
                o.put("sz", r1(v.textSize / d)).put("col", col(v.currentTextColor))
                val ity = v.inputType
                if ((ity and InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) o.put("ml", 1)
                val vr = ity and InputType.TYPE_MASK_VARIATION
                if ((ity and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT && vr == InputType.TYPE_TEXT_VARIATION_PASSWORD) o.put("pw", 1)
                if ((ity and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER) {
                    if (vr == InputType.TYPE_NUMBER_VARIATION_PASSWORD) o.put("pw", 1) else o.put("num", 1)
                }
            }
            v is Spinner -> {
                val ad = v.adapter
                val ops = JSONArray()
                if (ad != null) for (i in 0 until ad.count) ops.put(ad.getItem(i)?.toString() ?: "")
                o.put("k", "sp").put("o", ops).put("s", v.selectedItemPosition)
            }
            v is CompoundButton -> {
                if (v is Switch) o.put("k", "sw").put("on", v.isChecked)
                else o.put("k", "cb").put("on", v.isChecked).put("tx", v.text.toString())
                    .put("sz", r1(v.textSize / d)).put("col", col(v.currentTextColor))
            }
            v is Button -> {
                o.put("k", "b").put("tx", v.text.toString()).put("sz", r1(v.textSize / d)).put("col", col(v.currentTextColor))
                if (!v.isEnabled) o.put("en", false)
                if (v.typeface?.isBold == true) o.put("bd", 1)
            }
            v is TextView -> {
                o.put("k", "t").put("tx", v.text.toString()).put("sz", r1(v.textSize / d)).put("col", col(v.currentTextColor))
                if (v.maxWidth in 1..100000) o.put("mxw", dpi(v.maxWidth))
                if (v.typeface?.isBold == true) o.put("bd", 1)
                o.put("tg", v.gravity)
            }
            v is ImageView -> {
                o.put("k", "i")
                imgSrc(v)?.let { o.put("src", it) }
                o.put("mw", if (v.width > 0) dpi(v.width) else 24).put("mh", if (v.height > 0) dpi(v.height) else 24)
                if (v.scaleType == ImageView.ScaleType.CENTER_CROP) o.put("cc", 1)
                if (v.clipToOutline && !o.has("r")) o.put("r", 12)
            }
            v is ViewGroup -> {
                o.put("k", "v")
                if (v is ScrollView) o.put("sc", "y")
                else if (v is HorizontalScrollView) o.put("sc", "x")
                else if (v is LinearLayout) { o.put("o", if (v.orientation == LinearLayout.HORIZONTAL) "h" else "v"); o.put("pg", v.gravity) }
                else {
                    o.put("fm", 1)
                    val w = lp?.width ?: -1; val hh = lp?.height ?: -1
                    if (root || (w > 0 && hh > 0) || (w == -1 && hh == -1)) o.put("fa", 1)
                }
                val ch = JSONArray()
                for (i in 0 until v.childCount) ser(v.getChildAt(i), false, depth + 1)?.let { ch.put(it) }
                o.put("ch", ch)
            }
            else -> o.put("k", "v")
        }
        return o
    }
}
