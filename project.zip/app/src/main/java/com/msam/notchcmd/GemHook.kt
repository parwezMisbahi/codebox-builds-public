package com.msam.notchcmd

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * "Hey Google" -> Gemini khulta hai -> ZOKI usay band karke apna panel (aur mic) khol deta hai.
 * Google ke hotword ko ZOKI sun nahi sakta; ye sirf Gemini ki window dikhne par chalta hai (Accessibility se).
 * Gemini ek pal ke liye dikh sakta hai, ye is trick ki limit hai.
 */
object GemHook {
    private const val GOOGLE_APP = "com.google.android.googlequicksearchbox"
    // Gemini/assistant overlay ki class ke naam mein aksar ye lafz hote hain (Google app version se badal sakte hain)
    private val clsWords = listOf("opa", "assistant", "voice", "gemini", "robin", "velvet.ui.assist")
    private val h = Handler(Looper.getMainLooper())
    private var last = 0L

    private fun sp(c: Context) = c.getSharedPreferences("gemhook", Context.MODE_PRIVATE)

    /** Switch ON = Gemini khulte hi ZOKI khule */
    fun on(c: Context): Boolean = sp(c).getBoolean("on", true)
    fun setOn(c: Context, v: Boolean) { sp(c).edit().putBoolean("on", v).apply() }

    /** true = Google app ki KOI bhi window pe ZOKI khule (class filter band). Agar normal Gemini pe trigger na ho to ON karo. */
    fun any(c: Context): Boolean = sp(c).getBoolean("any", false)
    fun setAny(c: Context, v: Boolean) { sp(c).edit().putBoolean("any", v).apply() }

    /** Google app ki aakhri window class (test/debug ke liye) */
    fun lastClass(c: Context): String = sp(c).getString("cls", "") ?: ""

    /** @return true agar ye event Gemini trigger tha aur handle ho gaya */
    fun onEvent(s: AccessibilityService, e: AccessibilityEvent): Boolean {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return false
        if (e.packageName?.toString() != GOOGLE_APP) return false
        val cls = e.className?.toString() ?: ""
        sp(s).edit().putString("cls", cls).apply()
        if (!on(s)) return false
        if (!any(s) && clsWords.none { cls.lowercase().contains(it) }) return false
        val now = SystemClock.uptimeMillis()
        if (now - last < 4000) return true   // ek hi baar chale
        last = now
        // 1) Gemini band
        try { s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) } catch (_: Exception) {}
        // 2) thodi der baad ZOKI panel: Gemini mic chhod de tab mic ZOKI ko mile
        h.postDelayed({
            try { s.startForegroundService(Intent(s, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {}
        }, 350)
        return true
    }
}
