package com.msam.notchcmd

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The whole app screen is HTML (assets/app.html). This class is the only door between that page and the phone:
 *   page -> phone:  ZB.call(name, json)   (see call() below, one `when` branch per action)
 *   phone -> page:  ZB.call("getState")   (everything the page shows, built from the real stores)
 *   the page asks again by itself every few seconds and whenever the app comes back to the front (refresh()).
 * The chat screen (ChatActivity) is still native; the page opens it with "openChat".
 */
class AppUi(private val ctx: Activity) {
    private val h = Handler(Looper.getMainLooper())

    val web: WebView = WebView(ctx).apply {
        setBackgroundColor(0xFFFFF5F5.toInt())
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = false
        settings.textZoom = 100
        settings.setSupportZoom(false)
        addJavascriptInterface(Bridge(), "ZB")
        loadUrl("file:///android_asset/app.html")
    }

    init {
        ctx.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        ctx.window.statusBarColor = 0xFFFFF5F5.toInt()
        ctx.window.navigationBarColor = 0xFFFFF5F5.toInt()
        @Suppress("DEPRECATION")
        ctx.window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            (if (Build.VERSION.SDK_INT >= 26) View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0)
    }

    /** the page asks the phone again (app came back to the front, a permission screen closed ...) */
    fun refresh() { web.evaluateJavascript("window.ZOKI&&ZOKI.refresh&&ZOKI.refresh()", null) }

    /** open one of the pages from outside (chat -> "open settings") */
    fun goPage(name: String) { web.evaluateJavascript("window.ZOKI&&ZOKI.go&&ZOKI.go(${JSONObject.quote(name)})", null) }

    /** Android back button: true = the page used it */
    fun back(done: (Boolean) -> Unit) {
        web.evaluateJavascript("(window.ZOKI_back?ZOKI_back():false)", ValueCallback<String> { v -> done(v == "true") })
    }

    private fun toast(t: String) { ctx.runOnUiThread { Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show() } }
    private fun startCmd(cmd: String) { ctx.runOnUiThread { try { ctx.startForegroundService(Intent(ctx, OverlayService::class.java).putExtra("cmd", cmd)) } catch (_: Exception) {} } }
    private fun open(i: Intent) { ctx.runOnUiThread { try { ctx.startActivity(i) } catch (_: Exception) { try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {} } } }
    private fun nprefs() = ctx.getSharedPreferences("n", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ state: phone -> page
    private fun serviceRunning(): Boolean = try {
        @Suppress("DEPRECATION")
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getRunningServices(200).any { it.service.className == OverlayService::class.java.name }
    } catch (_: Exception) { false }

    private fun listenerOn() = (Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: "").contains(ctx.packageName)

    private fun perms(): JSONObject {
        fun g(p: String) = ctx.checkSelfPermission(p) == 0
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return JSONObject()
            .put("overlay", Settings.canDrawOverlays(ctx))
            .put("mic", g(Manifest.permission.RECORD_AUDIO))
            .put("contacts", g(Manifest.permission.READ_CONTACTS))
            .put("call", g(Manifest.permission.CALL_PHONE))
            .put("notif", Build.VERSION.SDK_INT < 33 || g(Manifest.permission.POST_NOTIFICATIONS))
            .put("brightness", Settings.System.canWrite(ctx))
            .put("photos", GptImage.hasPerm(ctx))
            .put("acc", NotchA11y.inst != null)
            .put("alarms", Scheduler.canExact(ctx))
            .put("battery", pm.isIgnoringBatteryOptimizations(ctx.packageName))
            .put("usage", UsageGuard.hasAccess(ctx))
            .put("listener", listenerOn())
    }

    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private fun hhmm(s: Sched) = "%02d:%02d".format(s.hh, s.mm)
    private fun daysOf(mask: Int) = JSONArray().also { a -> for (d in 0..6) if (mask and (1 shl d) != 0) a.put(d) }

    private fun appLabel(pkg: String): String = try {
        val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun settingsJson(): JSONObject {
        val c = ctx
        val lead = intArrayOf(0, 5, 10, 30, 60)
        val leadLabels = listOf("Off", "5 min", "10 min", "30 min", "1 hour")
        val names = AutoChat.names(c)
        return JSONObject()
            .put("postUsing", if (ChannelPrefs.business(c)) "WhatsApp Business" else "WhatsApp")
            .put("fbUsing", if (FbPrefs.lite(c)) "Facebook Lite" else "Facebook")
            .put("channel", ChannelPrefs.name(c)).put("page", FbPrefs.pageName(c)).put("profile", FbPrefs.profileName(c))
            .put("statusShare", ChannelPrefs.shareStatus(c)).put("forward", ChannelPrefs.shareChats(c))
            .put("groups", ChannelPrefs.targets(c).joinToString("\n"))
            .put("dataOff", ChannelPrefs.cleanup(c))
            .put("titleOn", PostTitle.on(c)).put("titles", PostTitle.list(c).joinToString("\n"))
            .put("titleMode", listOf("One by one", "Random", "All together")[PostTitle.mode(c).coerceIn(0, 2)])
            .put("titlePos", listOf("Top", "End", "Top and end")[PostTitle.pos(c)])
            .put("poster", PosterPrefs.always(c)).put("gptImage", PosterPrefs.gpt(c)).put("footer", if (PosterPrefs.hasFooter(c)) PosterPrefs.footer(c) else "")
            .put("lead", leadLabels[lead.indexOf(Scheduler.lead(c)).coerceAtLeast(0)])
            .put("shake", ShakePrefs.on(c)).put("shakes", ShakePrefs.count(c).toString()).put("strength", if (ShakePrefs.hard(c)) "Hard" else "Normal")
            .put("digest", DigestStore.on(c)).put("helper", AutoReplyPrefs.on(c)).put("skipGroups", AutoReplyPrefs.skipGroups(c))
            .put("reply1", AutoReplyPrefs.t1(c)).put("reply2", AutoReplyPrefs.t2(c))
            .put("autoReply", names.isNotEmpty()).put("autoReplyTo", names.joinToString(", "))
            .put("unlock", Unlocker.unlockOn(c)).put("touchGuard", Guard.on(c)).put("lockEnd", Guard.lockEnd(c))
            .put("pickup", Guard.motion(c)).put("sens", listOf("Low", "Medium", "High")[Guard.sens(c).coerceIn(0, 2)])
            .put("charger", Guard.unplug(c)).put("data", Unlocker.dataOn(c)).put("pin", Unlocker.pinLen(c) > 0)
            .put("voice", UsageGuard.voiceOn(c)).put("myName", if (UsageGuard.hasName(c)) UsageGuard.userName(c) else "")
            .put("ai", ResearchPrefs.selected(c).label)
            .put("llmProv", LlmBrain.provider(c)).put("llmKey", LlmBrain.apiKey(c))
            .put("dailyLimit", (UsageGuard.screenLimit(c) / 60.0).let { if (it == Math.floor(it)) it.toInt().toString() else "%.1f".format(Locale.US, it) })
    }

    private fun stateJson(): String {
        val c = ctx
        val o = JSONObject()
        o.put("real", true)
        o.put("running", serviceRunning())
        o.put("mj", nprefs().getBoolean("wake", false))
        o.put("perms", perms())
        val all = Scheduler.load(c)
        val sa = JSONArray()
        all.filter { it.grp.isBlank() }.forEach {
            sa.put(JSONObject().put("id", it.id).put("time", hhmm(it)).put("days", daysOf(it.days)).put("cmd", it.cmd).put("on", it.on)
                .apply { if (it.at > 0L) put("date", dayFmt.format(Date(it.at))) })
        }
        o.put("sched", sa)
        val pa = JSONArray()
        all.filter { it.grp.isNotBlank() }.groupBy { it.grp }.forEach { (name, l0) ->
            val l = l0.sortedBy { it.at }
            val now = System.currentTimeMillis()
            val items = JSONArray()
            l.forEach { items.put(JSONObject().put("id", it.id).put("date", dayFmt.format(Date(it.at))).put("at", it.at).put("topic", Scheduler.splitCmd(it.cmd).second).put("on", it.on)) }
            pa.put(JSONObject().put("id", name).put("name", name).put("time", hhmm(l[0]))
                .put("target", Scheduler.splitCmd(l[0].cmd).first.ifBlank { "channel post" })
                .put("on", l.any { it.on && it.at > now } || l.all { it.on }).put("items", items))
        }
        o.put("plans", pa)
        val po = JSONArray()
        PostLog.load(c).forEach { po.put(JSONObject().put("t", it.time).put("kind", it.kind).put("topic", it.topic).put("ok", it.ok).put("note", it.note).put("cmd", it.cmd)) }
        o.put("posts", po)
        val ro = JSONArray()
        RoutineStore.all(c).forEach { (k, v) -> ro.put(JSONObject().put("id", k).put("name", k).put("cmds", JSONArray(v))) }
        o.put("routines", ro)
        val to = JSONArray()
        TriggerStore.load(c).forEach { to.put(JSONObject().put("id", it.type).put("ev", TriggerStore.label(it.type)).put("cmd", it.cmd).put("on", it.on)) }
        o.put("triggers", to)
        val tt = JSONArray(); TriggerStore.TYPES.forEach { tt.put(JSONObject().put("k", it.first).put("label", it.second)) }
        o.put("triggerTypes", tt)
        val lo = JSONArray()
        UsageGuard.limits(c).forEach { (pkg, m) -> lo.put(JSONObject().put("pkg", pkg).put("app", appLabel(pkg)).put("min", m)) }
        o.put("limits", lo)
        o.put("aiOptions", JSONArray(ResearchPrefs.ALL.map { it.label }))
        o.put("set", settingsJson())
        return o.toString()
    }

    private var appsCache: String? = null
    private fun appsJson(): String {
        appsCache?.let { return it }
        val pm = ctx.packageManager
        val a = JSONArray()
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }.filter { it.first != ctx.packageName }.sortedBy { it.second.lowercase() }
            .forEach { a.put(JSONObject().put("pkg", it.first).put("label", it.second)) }
        return a.toString().also { appsCache = it }
    }

    // ------------------------------------------------------------------ settings: page -> phone
    private fun setSetting(k: String, v: Any?) {
        val c = ctx
        val s = v?.toString() ?: ""
        val b = v == true || s == "true"
        fun idx(list: List<String>) = list.indexOf(s).coerceAtLeast(0)
        when (k) {
            "mj" -> { nprefs().edit().putBoolean("wake", b).apply()
                if (b && !Settings.canDrawOverlays(c)) toast("Give the overlay permission first (Setup)")
                else ctx.runOnUiThread { try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("wake", b)) } catch (_: Exception) {} } }
            "postUsing" -> if ((s == "WhatsApp Business") != ChannelPrefs.business(c)) ChannelPrefs.toggleBusiness(c)
            "fbUsing" -> if ((s == "Facebook Lite") != FbPrefs.lite(c)) FbPrefs.toggleLite(c)
            "channel" -> ChannelPrefs.setName(c, s)
            "page" -> FbPrefs.setPageName(c, s)
            "profile" -> FbPrefs.setProfileName(c, s)
            "statusShare" -> if (b != ChannelPrefs.shareStatus(c)) ChannelPrefs.toggleShareStatus(c)
            "forward" -> if (b != ChannelPrefs.shareChats(c)) ChannelPrefs.toggleShareChats(c)
            "groups" -> ChannelPrefs.setTargets(c, s)
            "dataOff" -> { if (b != ChannelPrefs.cleanup(c)) ChannelPrefs.toggleCleanup(c); if (b != FbPrefs.cleanup(c)) FbPrefs.toggleCleanup(c) }
            "titleOn" -> if (b != PostTitle.on(c)) PostTitle.toggle(c)
            "titles" -> PostTitle.setList(c, s)
            "titleMode" -> PostTitle.setMode(c, idx(listOf("One by one", "Random", "All together")))
            "titlePos" -> PostTitle.setPos(c, idx(listOf("Top", "End", "Top and end")))
            "poster" -> if (b != PosterPrefs.always(c)) PosterPrefs.toggleAlways(c)
            "gptImage" -> if (b != PosterPrefs.gpt(c)) PosterPrefs.toggleGpt(c)
            "footer" -> PosterPrefs.setFooter(c, s)
            "lead" -> { Scheduler.setLead(c, intArrayOf(0, 5, 10, 30, 60)[idx(listOf("Off", "5 min", "10 min", "30 min", "1 hour"))]); Scheduler.armAll(c) }
            "shake" -> ShakePrefs.setOn(c, b)
            "shakes" -> ShakePrefs.setCount(c, s.toIntOrNull() ?: 3)
            "strength" -> ShakePrefs.setHard(c, s == "Hard")
            "digest" -> { if (b && !listenerOn()) toast("Turn on notification access first"); DigestStore.setOn(c, b) }
            "helper" -> AutoReplyPrefs.setOn(c, b)
            "skipGroups" -> AutoReplyPrefs.setSkipGroups(c, b)
            "reply1" -> AutoReplyPrefs.setTexts(c, s, AutoReplyPrefs.t2(c))
            "reply2" -> AutoReplyPrefs.setTexts(c, AutoReplyPrefs.t1(c), s)
            "unlock" -> Unlocker.setUnlockOn(c, b)
            "touchGuard" -> Guard.setOn(c, b)
            "lockEnd" -> Guard.setLockEnd(c, b)
            "pickup" -> Guard.setMotion(c, b)
            "sens" -> Guard.setSens(c, idx(listOf("Low", "Medium", "High")))
            "charger" -> Guard.setUnplug(c, b)
            "data" -> Unlocker.setDataOn(c, b)
            "voice" -> UsageGuard.setVoiceOn(c, b)
            "myName" -> UsageGuard.setUserName(c, s)
            "ai" -> ResearchPrefs.ALL.firstOrNull { it.label == s }?.let { ResearchPrefs.select(c, it.key) }
            "llmProv" -> LlmBrain.setOnline(c, s, LlmBrain.apiKey(c), "")
            "llmKey" -> LlmBrain.setOnline(c, LlmBrain.provider(c).let { if (it == "off" && s.isNotBlank()) "gemini" else it }, s, "")
            "dailyLimit" -> UsageGuard.setScreenLimit(c, Math.round((s.toDoubleOrNull() ?: 0.0) * 60).toInt())
        }
    }

    // ------------------------------------------------------------------ actions: page -> phone
    private inner class Bridge {
        @JavascriptInterface fun call(name: String, json: String): String {
            val a = try { JSONObject(if (json.isBlank()) "{}" else json) } catch (_: Exception) { JSONObject() }
            return try { act(name, a) } catch (e: Throwable) { toast("Error: " + (e.message ?: name)); "" }
        }
    }

    private fun mask(a: JSONObject): Int { var m = 0; val d = a.optJSONArray("days"); if (d != null) for (i in 0 until d.length()) m = m or (1 shl d.getInt(i)); return m }
    private fun hm(t: String): Pair<Int, Int> { val p = t.split(":"); return Pair(p.getOrNull(0)?.toIntOrNull() ?: 8, p.getOrNull(1)?.toIntOrNull() ?: 0) }

    private fun act(name: String, a: JSONObject): String {
        val c = ctx
        when (name) {
            "getState" -> return stateJson()
            "getApps" -> return appsJson()
            "setting" -> setSetting(a.optString("k").removePrefix("set."), a.opt("v"))
            "svc" -> if (a.optBoolean("on")) {
                if (!Settings.canDrawOverlays(c)) toast("Give the overlay permission first")
                else ctx.runOnUiThread { try { c.startForegroundService(Intent(c, OverlayService::class.java)) } catch (_: Exception) {} }
            } else ctx.runOnUiThread { c.stopService(Intent(c, OverlayService::class.java)) }
            "perm" -> askPerm(a.optString("name"))
            "runCommand" -> { startCmd(a.optString("cmd")); toast("Sent to ZOKI") }
            "openChat" -> open(Intent(c, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
            "diag" -> if (Settings.canDrawOverlays(c)) startCmd("check app") else toast("Give the overlay permission first")
            "testBox" -> if (Settings.canDrawOverlays(c)) ctx.runOnUiThread { try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("show", true)) } catch (_: Exception) {} } else toast("Give the overlay permission first")
            "guide" -> toast(Guide.save(c))
            "assistant" -> open(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            "runDigest" -> startCmd("digest")
            "testVoice" -> ctx.runOnUiThread { try { c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("say", "Yes " + UsageGuard.userName(c) + ", I'm ready")) } catch (_: Exception) {} }
            "dump" -> {
                val acc = NotchA11y.inst
                if (acc == null) toast("Turn on Accessibility first")
                else { toast("Open that screen within 8 sec")
                    h.postDelayed({ val d = acc.dump()
                        (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("dump", d))
                        toast("Copied (${d.lines().size} lines)") }, 8000) }
            }
            "clearAiMemory" -> { LlmBrain.forget(c); toast("AI memory cleared") }
            "clearDigest" -> { DigestStore.clear(c); toast("Cleared") }
            "clearPosts" -> PostLog.clear(c)
            "setPin" -> { val p = a.optString("pin")
                if (p.length in 4..16 && p.all { it.isDigit() }) { Unlocker.setPin(c, p); toast("${p.length}-digit PIN saved") } else toast("PIN must be 4 to 16 digits") }
            "clearPin" -> Unlocker.clearPin(c)
            // schedules
            "schedAdd" -> { val (hh, mm) = hm(a.optString("time")); Scheduler.add(c, hh, mm, a.optString("cmd"), mask(a)) }
            "schedEdit" -> { Scheduler.remove(c, a.optInt("id")); val (hh, mm) = hm(a.optString("time")); val s = Scheduler.add(c, hh, mm, a.optString("cmd"), mask(a)); if (!a.optBoolean("on", true)) Scheduler.setOn(c, s.id, false) }
            "schedDel" -> Scheduler.remove(c, a.optInt("id"))
            "schedOn" -> Scheduler.setOn(c, a.optInt("id"), a.optBoolean("on"))
            "planAdd" -> {
                val topics = a.optJSONArray("topics")?.let { t -> (0 until t.length()).map { t.getString(it) } } ?: emptyList()
                val (hh, mm) = hm(a.optString("time"))
                if (topics.isNotEmpty()) Scheduler.addPlan(c, a.optString("name").ifBlank { "Plan" }, hh, mm, Calendar.getInstance(), a.optString("target", "channel post"), topics)
            }
            "planDel" -> Scheduler.removePlan(c, a.optString("id"))
            "planOn" -> Scheduler.setPlanOn(c, a.optString("id"), a.optBoolean("on"))
            // automation
            "routineAdd" -> { val l = a.optJSONArray("cmds"); if (l != null) RoutineStore.put(c, a.optString("name"), (0 until l.length()).map { l.getString(it) }) }
            "routineDel" -> RoutineStore.remove(c, a.optString("id"))
            "triggerAdd" -> TriggerStore.set(c, a.optString("type"), a.optString("cmd"), 20)
            "triggerDel" -> TriggerStore.remove(c, a.optString("id"))
            "limitSet" -> UsageGuard.setLimit(c, a.optString("pkg"), a.optInt("min"))
            "autoReplyStart" -> AutoChat.start(c, a.optString("to").split(",", "\n").map { it.trim() }.filter { it.isNotEmpty() }, 8)
            "autoReplyStop" -> AutoChat.clear(c)
        }
        return "ok"
    }

    private fun askPerm(n: String) {
        val c = ctx
        val pkg = Uri.parse("package:" + c.packageName)
        ctx.runOnUiThread {
            try {
                when (n) {
                    "overlay" -> c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg))
                    "mic", "contacts", "call", "notif" -> {
                        val l = ArrayList(listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ANSWER_PHONE_CALLS))
                        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
                        c.requestPermissions(l.toTypedArray(), 1)
                    }
                    "brightness" -> c.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg))
                    "photos" -> c.requestPermissions(if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 2)
                    "acc" -> c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    "alarms" -> if (Build.VERSION.SDK_INT >= 31) c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg)) else Unit
                    "battery" -> c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    "usage" -> c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    "listener" -> c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            } catch (_: Exception) { try { c.startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {} }
        }
    }
}
