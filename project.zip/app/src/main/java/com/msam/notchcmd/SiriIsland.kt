package com.msam.notchcmd

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * The compact assistant: a black glass capsule that sits around the camera hole, with soft coloured light flowing
 * along its bottom edge and a slowly turning rainbow rim (like Siri's island). It loops forever.
 * level (0..1) = how loud you speak: the light swells. energy = idle 0.25 / listening 0.6 / working 1.
 */
class SiriIsland(ctx: Context) : View(ctx) {
    @Volatile var level = 0f
    @Volatile var energy = 0.3f

    private val d = resources.displayMetrics.density
    private val base = intArrayOf(0xFF3D7BFF.toInt(), 0xFF2FD6FF.toInt(), 0xFF9A5BFF.toInt(), 0xFFFF5FA8.toInt(), 0xFFFFA24A.toInt())
    private val shaders = Array(base.size) { i ->
        val c = base[i] and 0x00FFFFFF
        RadialGradient(0f, 0f, 1f, intArrayOf(c or 0xD0000000.toInt(), c or 0x66000000, c), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * d }
    private var sweep: SweepGradient? = null
    private val m = Matrix()
    private val clip = Path()
    private val rimRect = RectF()
    private val bg = 0xFF040509.toInt()

    // loop animation: ek chamak (shimmer) baar baar bayen se dayen guzarti hai
    private val shimmer = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shimmerShader: android.graphics.LinearGradient? = null
    private var phase = 0f
    private var lastT = 0L
    private var sl = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val r = h / 2f
        clip.reset(); clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW)
        val inset = rim.strokeWidth / 2f
        rimRect.set(inset, inset, w - inset, h - inset)
        shimmerShader = android.graphics.LinearGradient(0f, 0f, w * 0.45f, 0f, intArrayOf(0x00FFFFFF, 0x40FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        sweep = SweepGradient(w / 2f, h / 2f,
            intArrayOf(0xCC3D7BFF.toInt(), 0xCC2FD6FF.toInt(), 0x339A5BFF, 0xCCFF5FA8.toInt(), 0xCCFFA24A.toInt(), 0x333D7BFF, 0xCC3D7BFF.toInt()),
            floatArrayOf(0f, 0.18f, 0.36f, 0.55f, 0.72f, 0.88f, 1f))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastT = System.nanoTime()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val now = System.nanoTime()
        val dt = ((now - lastT) / 1_000_000_000f).coerceIn(0f, 0.1f); lastT = now
        sl += (level - sl) * 0.2f
        val e = energy
        phase += dt * (0.55f + 0.9f * e + 0.8f * sl)
        val p = phase

        c.save()
        c.clipPath(clip)
        c.drawColor(bg)
        val a = (60 + 90 * e + 50 * sl).toInt().coerceIn(0, 255)
        for (i in base.indices) {
            val x = w * (0.5f + 0.34f * sin(p * (0.9f + 0.19f * i) + i * 1.37f))
            val y = h * (0.97f + 0.08f * sin(p * (1.25f + 0.13f * i) + i * 2.1f))
            val r = h * (0.34f + 0.22f * sl + 0.06f * sin(p * 1.7f + i))
            c.save()
            c.translate(x, y)
            c.scale(r * 2.1f, r)
            glow.shader = shaders[i]; glow.alpha = a
            c.drawCircle(0f, 0f, 1f, glow)
            c.restore()
        }
        // loop: chamak 2.6 sec mein ek baar poori capsule par guzarti hai
        val ss = shimmerShader
        if (ss != null) {
            val t = ((now / 1_000_000L) % 2600L) / 2600f
            m.setTranslate(-w * 0.45f + t * (w * 1.45f), 0f); ss.setLocalMatrix(m)
            shimmer.shader = ss
            c.drawRect(0f, 0f, w, h, shimmer)
        }
        c.restore()

        val sw = sweep
        if (sw != null) {
            m.setRotate(p * 55f, w / 2f, h / 2f); sw.setLocalMatrix(m)
            rim.shader = sw
            c.drawRoundRect(rimRect, h / 2f, h / 2f, rim)
        }
    }
}
