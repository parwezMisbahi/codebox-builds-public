package com.msam.notchcmd

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Wikipedia se seedhi jankari (koi API key nahi). Search -> pehla page -> uska shuruati hissa. Background thread se bulao. */
object Wiki {
    class Result(val title: String, val text: String, val url: String, val lang: String)
    @Volatile var lastError = ""

    private fun get(u: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 6_000; c.readTimeout = 10_000
            c.setRequestProperty("User-Agent", "NotchCmd/1.0 (Android assistant; contact: app user)")
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) { lastError = "Wikipedia error ${c.responseCode}"; null }
            else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) { lastError = "No internet / Wikipedia unreachable"; null }
        finally { try { c?.disconnect() } catch (_: Exception) {} }
    }

    private fun one(topic: String, lang: String): Result? {
        val q = URLEncoder.encode(topic, "UTF-8")
        val u = "https://$lang.wikipedia.org/w/api.php?action=query&format=json&utf8=1&redirects=1" +
            "&generator=search&gsrsearch=$q&gsrlimit=1&prop=extracts%7Cinfo&exintro=1&explaintext=1&exlimit=1&inprop=url"
        val body = get(u) ?: return null
        return try {
            val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return null
            val k = pages.keys(); if (!k.hasNext()) return null
            val p = pages.getJSONObject(k.next())
            val ex = p.optString("extract").trim()
            if (ex.isBlank()) return null
            Result(p.optString("title"), trim(ex, 1100), p.optString("fullurl"), lang)
        } catch (_: Exception) { null }
    }

    /** lambe text ko aakhri poore vaakya par kaato */
    private fun trim(s: String, max: Int): String {
        val t = s.replace(Regex("\\n{3,}"), "\n\n").trim()
        if (t.length <= max) return t
        val cut = t.substring(0, max)
        val i = maxOf(cut.lastIndexOf(". "), cut.lastIndexOf("।"), cut.lastIndexOf("? "))
        return (if (i > max / 2) cut.substring(0, i + 1) else cut.trimEnd() + "…")
    }

    /** pasandida zubaan pehle, na mile to English */
    fun lookup(topic: String, lang: String): Result? {
        lastError = ""
        val t = topic.trim(); if (t.isEmpty()) return null
        return one(t, lang) ?: if (lang != "en") one(t, "en") else null
    }
}
