package com.codebox.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

class PublishResult(val url: String, val repo: String, val live: Boolean, val files: Int, val changed: Boolean)

/**
 * Publishes a project folder as a website on GitHub Pages.
 * Repo <user>/<name> (public, created by CodeBox) -> one commit through the Git Data API (only changed files are
 * uploaded) -> Pages enabled on the default branch -> wait until GitHub reports the site as built.
 * Needs a token with scope `repo`. No Actions workflow is involved.
 */
class WebPublish(private val token: String, private val progress: (String) -> Unit) {
    private class Resp(val code: Int, val text: String)

    companion object {
        const val MARKER = "CodeBox web publish"
        private val SKIP = setOf(".git", ".gradle", "node_modules", "build", "builds", ".idea")
        private const val MAX_FILES = 1500
        private const val MAX_FILE = 20L * 1024 * 1024
        private const val MAX_TOTAL = 100L * 1024 * 1024

        fun slug(name: String): String {
            val s = name.trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-', '.', '_').take(60)
            return s.ifEmpty { "site" }
        }
    }

    private fun req(method: String, path: String, body: String? = null): Resp {
        val c = URL("https://api.github.com$path").openConnection() as HttpURLConnection
        c.requestMethod = method // Android's OkHttp-based HttpURLConnection accepts PATCH
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.setRequestProperty("User-Agent", "CodeBox")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Resp(code, text)
    }

    private fun msg(r: Resp): String = try {
        JSONObject(r.text).optString("message", r.text.take(200))
    } catch (e: Exception) { "HTTP ${r.code}" }

    private fun fail(what: String, r: Resp): Nothing {
        val hint = when (r.code) {
            401 -> " -> token galat ya expire ho gaya"
            403 -> " -> token me 'repo' scope check karo (ya thodi der baad try karo, GitHub rate limit)"
            404 -> " -> token ke scopes (repo) check karo"
            else -> ""
        }
        throw IllegalStateException("$what: ${msg(r)}$hint")
    }

    private class Entry(val path: String, val bytes: ByteArray) {
        val sha: String = run {
            val md = MessageDigest.getInstance("SHA-1")
            md.update("blob ${bytes.size}\u0000".toByteArray())
            md.update(bytes)
            md.digest().joinToString("") { "%02x".format(it) }
        }
    }

    private fun collect(dir: File): List<Entry> {
        val out = ArrayList<Entry>()
        var total = 0L
        dir.walkTopDown().onEnter { it == dir || it.name !in SKIP }.filter { it.isFile }.forEach { f ->
            if (f.name == ".DS_Store") return@forEach
            if (f.length() > MAX_FILE) throw IllegalStateException("${f.name} 20MB se badi hai, GitHub Pages ke liye chhoti karo")
            total += f.length()
            if (total > MAX_TOTAL) throw IllegalStateException("Project 100MB se bada hai")
            if (out.size >= MAX_FILES) throw IllegalStateException("Files bahut zyada hain (max $MAX_FILES)")
            out.add(Entry(f.relativeTo(dir).path.replace(File.separatorChar, '/'), f.readBytes()))
        }
        if (out.isEmpty()) throw IllegalStateException("Project khali hai")
        return out
    }

    private fun encPath(p: String) = p.split('/').joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    fun publish(dir: File, repoName: String): PublishResult {
        if (File(dir, "settings.gradle.kts").exists() || File(dir, "settings.gradle").exists()) {
            throw IllegalStateException("Ye Android project hai, website nahi. Pehle HTML wala project kholo")
        }
        val entries = ArrayList(collect(dir))
        if (entries.none { it.path == "index.html" }) {
            val entry = WebApk.pickEntry(dir) ?: throw IllegalStateException("Project me koi .html file nahi mili")
            val html = "<!doctype html><meta charset=\"utf-8\"><meta http-equiv=\"refresh\" content=\"0; url=${encPath(entry)}\">" +
                "<script>location.replace(\"${encPath(entry)}\")</script><a href=\"${encPath(entry)}\">Open</a>"
            entries.add(Entry("index.html", html.toByteArray()))
        }
        if (entries.none { it.path == ".nojekyll" }) entries.add(Entry(".nojekyll", ByteArray(0)))

        progress("GitHub account check...")
        val me = req("GET", "/user")
        if (me.code != 200) fail("GitHub login fail", me)
        val login = JSONObject(me.text).getString("login")
        val repo = "$login/$repoName"

        progress("Repo check...")
        var r = req("GET", "/repos/$repo")
        var created = false
        if (r.code == 404) {
            progress("Public repo bana raha hoon ($repoName)...")
            r = req("POST", "/user/repos", JSONObject().put("name", repoName).put("private", false)
                .put("auto_init", true).put("description", MARKER).toString())
            if (r.code !in 200..299) fail("Repo nahi ban saki", r)
            created = true
        } else if (r.code != 200) {
            fail("Repo check fail", r)
        } else {
            val j = JSONObject(r.text)
            if (j.optString("description") != MARKER) {
                throw IllegalStateException("'$repoName' naam ki repo pehle se hai aur CodeBox ne nahi banayi. Overwrite se bachne ke liye doosra naam do")
            }
            if (j.optBoolean("private")) {
                throw IllegalStateException("'$repoName' private hai. Free GitHub Pages ke liye repo public chahiye, doosra naam do")
            }
        }
        val branch = JSONObject(r.text).optString("default_branch", "main")

        // current head (a fresh repo needs a moment until auto_init finished)
        var parent = ""
        for (i in 1..10) {
            val ref = req("GET", "/repos/$repo/git/ref/heads/$branch")
            if (ref.code == 200) { parent = JSONObject(ref.text).getJSONObject("object").getString("sha"); break }
            Thread.sleep(2000)
        }
        if (parent.isEmpty()) throw IllegalStateException("Repo ki branch ready nahi hui, dobara try karo")
        val headCommit = req("GET", "/repos/$repo/git/commits/$parent")
        if (headCommit.code != 200) fail("Commit read fail", headCommit)
        val oldTree = JSONObject(headCommit.text).getJSONObject("tree").getString("sha")

        val existing = HashSet<String>()
        val old = req("GET", "/repos/$repo/git/trees/$oldTree?recursive=1")
        if (old.code == 200) {
            val jo = JSONObject(old.text)
            if (!jo.optBoolean("truncated")) {
                val arr = jo.optJSONArray("tree")
                if (arr != null) for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    if (e.optString("type") == "blob") existing.add(e.getString("sha"))
                }
            }
        }

        val toUpload = entries.filter { it.sha !in existing }.distinctBy { it.sha }
        var done = 0
        for (e in toUpload) {
            done++
            progress("Files upload ho rahi hain ($done/${toUpload.size})...")
            val b = JSONObject().put("content", Base64.encodeToString(e.bytes, Base64.NO_WRAP)).put("encoding", "base64")
            var p = req("POST", "/repos/$repo/git/blobs", b.toString())
            if (p.code >= 500 || p.code == 403) { Thread.sleep(3000); p = req("POST", "/repos/$repo/git/blobs", b.toString()) }
            if (p.code !in 200..201) fail("Upload fail (${e.path})", p)
        }

        progress("Site commit ho rahi hai...")
        val tree = JSONArray()
        entries.forEach {
            tree.put(JSONObject().put("path", it.path).put("mode", "100644").put("type", "blob").put("sha", it.sha))
        }
        val t = req("POST", "/repos/$repo/git/trees", JSONObject().put("tree", tree).toString())
        if (t.code !in 200..201) fail("Tree fail", t)
        val newTree = JSONObject(t.text).getString("sha")

        val changed = newTree != oldTree || created
        if (newTree != oldTree) {
            val c = req("POST", "/repos/$repo/git/commits", JSONObject()
                .put("message", "CodeBox: publish").put("tree", newTree).put("parents", JSONArray().put(parent)).toString())
            if (c.code !in 200..201) fail("Commit fail", c)
            val sha = JSONObject(c.text).getString("sha")
            val u = req("PATCH", "/repos/$repo/git/refs/heads/$branch", JSONObject().put("sha", sha).put("force", true).toString())
            if (u.code != 200) fail("Branch update fail", u)
        }

        progress("GitHub Pages on kar raha hoon...")
        val pg = req("GET", "/repos/$repo/pages")
        if (pg.code == 404) {
            val en = req("POST", "/repos/$repo/pages", JSONObject()
                .put("source", JSONObject().put("branch", branch).put("path", "/")).toString())
            if (en.code !in 200..201 && en.code != 409) fail("Pages on nahi hua", en)
        } else if (pg.code != 200) fail("Pages check fail", pg)

        var url = "https://$login.github.io/${if (repoName.equals("$login.github.io", true)) "" else repoName}"
        var live = false
        if (changed) {
            val t0 = System.currentTimeMillis()
            while (System.currentTimeMillis() - t0 < 180_000) {
                Thread.sleep(4000)
                val el = (System.currentTimeMillis() - t0) / 1000
                progress("Site build ho rahi hai (${el}s)...")
                val b = req("GET", "/repos/$repo/pages/builds/latest")
                if (b.code != 200) continue
                val j = JSONObject(b.text)
                when (j.optString("status")) {
                    "built" -> { live = true; break }
                    "errored" -> throw IllegalStateException("Pages build fail: " + j.optJSONObject("error")?.optString("message", "") )
                }
            }
        } else live = true

        val info = req("GET", "/repos/$repo/pages")
        if (info.code == 200) {
            val h = JSONObject(info.text).optString("html_url")
            if (h.isNotEmpty()) url = h
        }
        if (!url.endsWith("/")) url += "/"
        return PublishResult(url, repo, live, entries.size, changed)
    }

    /** Turns the Pages site off (the repo and its files stay on GitHub). */
    fun unpublish(repo: String) {
        val r = req("DELETE", "/repos/$repo/pages")
        if (r.code != 204 && r.code != 404) fail("Unpublish fail", r)
    }
}
