package com.codebox.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.widget.Toast

/** Receives PackageInstaller session results: launches the system confirm screen or reports errors. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    try {
                        ctx.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (t: Throwable) {
                        Toast.makeText(ctx, "Install screen nahi khuli: ${t.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS ->
                Toast.makeText(ctx, "Install ho gaya", Toast.LENGTH_SHORT).show()
            PackageInstaller.STATUS_FAILURE_ABORTED ->
                Toast.makeText(ctx, "Install cancel hua", Toast.LENGTH_SHORT).show()
            PackageInstaller.STATUS_FAILURE_CONFLICT, PackageInstaller.STATUS_FAILURE_INCOMPATIBLE ->
                Toast.makeText(
                    ctx,
                    "Install nahi hua: purani app alag key se bani hai. Pehle purani app uninstall karo. ($msg)",
                    Toast.LENGTH_LONG
                ).show()
            else ->
                Toast.makeText(ctx, "Install fail ($status): $msg", Toast.LENGTH_LONG).show()
        }
    }
}
