package com.codebox.app

import android.content.ContentResolver
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** All projects live in <filesDir>/projects/<name>/ . Every path from JS is checked to stay inside. */
class ProjectStore(filesDir: File) {
    val root: File = File(filesDir, "projects").apply { mkdirs() }
    private val rootPath = root.canonicalPath
    private val histRoot: File = File(filesDir, "history").apply { mkdirs() }

    fun resolve(rel: String): File {
        val f = File(root, rel).canonicalFile
        if (f.path != rootPath && !f.path.startsWith(rootPath + File.separator)) {
            throw SecurityException("Invalid path")
        }
        return f
    }

    fun projects(): JSONArray {
        val arr = JSONArray()
        root.listFiles()?.filter { it.isDirectory }
            ?.sortedBy { it.name.lowercase() }
            ?.forEach { arr.put(it.name) }
        return arr
    }

    fun list(rel: String): JSONArray {
        val arr = JSONArray()
        resolve(rel).listFiles()
            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            ?.forEach { arr.put(JSONObject().put("name", it.name).put("dir", it.isDirectory)) }
        return arr
    }

    fun uniqueName(base: String): String {
        val clean = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifEmpty { "project" }
        var name = clean
        var i = 2
        while (File(root, name).exists()) {
            name = "$clean-$i"
            i++
        }
        return name
    }

    fun readText(rel: String): String {
        val f = resolve(rel)
        if (!f.isFile) throw IllegalArgumentException("File nahi mili")
        if (f.length() > 2_000_000) throw IllegalArgumentException("File bahut badi hai (2MB se zyada)")
        val bytes = f.readBytes()
        val probe = minOf(bytes.size, 8000)
        for (i in 0 until probe) {
            if (bytes[i].toInt() == 0) throw IllegalArgumentException("Binary file hai, editor me nahi khulegi")
        }
        return String(bytes, Charsets.UTF_8)
    }

    fun writeText(rel: String, text: String) {
        val f = resolve(rel)
        f.parentFile?.mkdirs()
        f.writeText(text, Charsets.UTF_8)
        try { snapshot(rel, text) } catch (_: Exception) {}
    }

    /* ---------- history: every save keeps a copy (last 40 per file) ---------- */

    private fun histDir(rel: String) = File(histRoot, rel.replace("%", "%25").replace("/", "%2F"))
    private fun relOf(dirName: String) = dirName.replace("%2F", "/").replace("%25", "%")

    private fun snapshot(rel: String, text: String) {
        if (text.length > 1_000_000) return
        val d = histDir(rel).apply { mkdirs() }
        val files = d.listFiles()?.filter { it.name.toLongOrNull() != null }?.sortedBy { it.name.toLong() } ?: emptyList()
        if (files.isNotEmpty() && files.last().readText(Charsets.UTF_8) == text) return
        File(d, System.currentTimeMillis().toString()).writeText(text, Charsets.UTF_8)
        (files.size + 1 - 40).let { extra -> if (extra > 0) files.take(extra).forEach { it.delete() } }
    }

    fun histFiles(project: String): JSONArray {
        val arr = JSONArray()
        val rows = histRoot.listFiles()?.filter { it.isDirectory }?.mapNotNull { d ->
            val rel = relOf(d.name)
            if (!rel.startsWith("$project/")) return@mapNotNull null
            val times = d.listFiles()?.mapNotNull { it.name.toLongOrNull() } ?: return@mapNotNull null
            if (times.isEmpty()) return@mapNotNull null
            try { if (!resolve(rel).isFile) return@mapNotNull null } catch (_: Exception) { return@mapNotNull null }
            Triple(rel, times.max(), times.size)
        }?.sortedByDescending { it.second } ?: emptyList()
        rows.forEach { arr.put(JSONObject().put("p", it.first).put("t", it.second).put("n", it.third)) }
        return arr
    }

    fun histList(rel: String): JSONArray {
        val arr = JSONArray()
        histDir(rel).listFiles()?.filter { it.name.toLongOrNull() != null }
            ?.sortedByDescending { it.name.toLong() }
            ?.forEach { arr.put(JSONObject().put("t", it.name.toLong()).put("size", it.length())) }
        return arr
    }

    fun histRead(rel: String, t: Long): String {
        val f = File(histDir(rel), t.toString())
        if (!f.isFile) throw IllegalArgumentException("Version nahi mili")
        return f.readText(Charsets.UTF_8)
    }

    fun createFile(rel: String) {
        val f = resolve(rel)
        if (f.exists()) throw IllegalArgumentException("Pehle se maujood hai")
        f.parentFile?.mkdirs()
        f.createNewFile()
    }

    fun createDir(rel: String) {
        val f = resolve(rel)
        if (f.exists()) throw IllegalArgumentException("Pehle se maujood hai")
        f.mkdirs()
    }

    fun remove(rel: String) {
        val f = resolve(rel)
        if (f.path == rootPath) throw SecurityException("Invalid path")
        f.deleteRecursively()
    }

    fun rename(rel: String, newRel: String) {
        val from = resolve(rel)
        val to = resolve(newRel)
        if (to.exists()) throw IllegalArgumentException("Is naam se pehle se kuch hai")
        to.parentFile?.mkdirs()
        if (!from.renameTo(to)) throw IllegalStateException("Rename fail ho gaya")
    }

    fun createEmptyProject(name: String): String {
        val n = uniqueName(name)
        File(root, n).mkdirs()
        return n
    }

    fun createProject(name: String): String {
        val n = uniqueName(name)
        val dir = File(root, n).apply { mkdirs() }
        File(dir, "index.html").writeText(
            """<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>$n</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <h1>Hello, $n!</h1>
  <button id="btn">Click me</button>
  <script src="script.js"></script>
</body>
</html>
"""
        )
        File(dir, "style.css").writeText(
            "body {\n  font-family: sans-serif;\n  padding: 24px;\n}\n"
        )
        File(dir, "script.js").writeText(
            "document.getElementById('btn').addEventListener('click', () => {\n  alert('It works!');\n});\n"
        )
        return n
    }

    /** Extracts a zip into a new project folder. Protects against zip-slip. */
    fun unzip(input: InputStream, baseName: String): String {
        val name = uniqueName(baseName)
        val dest = File(root, name).apply { mkdirs() }
        val destPath = dest.canonicalPath
        try {
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                var e: ZipEntry? = zin.nextEntry
                while (e != null) {
                    val entryName = e.name
                    val skip = entryName.startsWith("__MACOSX") || entryName.endsWith(".DS_Store")
                    val out = File(dest, entryName).canonicalFile
                    if (!skip && out.path.startsWith(destPath + File.separator)) {
                        if (e.isDirectory) {
                            out.mkdirs()
                        } else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zin.copyTo(it) }
                        }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            flattenSingleRoot(dest)
        } catch (t: Throwable) {
            dest.deleteRecursively()
            throw t
        }
        return name
    }

    private val skipDirs = setOf(".gradle", ".git", "node_modules", "build")

    fun isAndroidProject(project: String): Boolean {
        val d = resolve(project)
        return File(d, "settings.gradle.kts").exists() || File(d, "settings.gradle").exists()
    }

    /** Names the app passes to addJavascriptInterface(...), so the preview can fake them. */
    fun bridgeNames(project: String): JSONArray {
        val dir = resolve(project)
        val names = LinkedHashSet<String>()
        val re = Regex("addJavascriptInterface\\s*\\([\\s\\S]{0,200}?,\\s*\"([A-Za-z_][A-Za-z0-9_]*)\"\\s*\\)")
        dir.walkTopDown()
            .onEnter { it == dir || it.name !in skipDirs }
            .filter { it.isFile && (it.extension == "kt" || it.extension == "java") && it.length() < 1_000_000 }
            .forEach { f -> re.findAll(f.readText()).forEach { names.add(it.groupValues[1]) } }
        if (names.isEmpty() && isAndroidProject(project)) names.add("Android")
        val arr = JSONArray()
        names.forEach { arr.put(it) }
        return arr
    }

    /** The app's own web UI: an html file under an assets folder (index.html preferred). */
    fun webEntry(project: String): String? {
        val dir = resolve(project)
        val sep = File.separator
        val cands = dir.walkTopDown()
            .onEnter { it == dir || it.name !in skipDirs }
            .filter {
                it.isFile && (it.extension.lowercase() == "html" || it.extension.lowercase() == "htm") &&
                    it.path.contains(sep + "assets" + sep)
            }
            .toList()
        if (cands.isEmpty()) return null
        val best = cands.sortedWith(compareBy({ it.name != "index.html" }, { it.path.length })).first()
        return project + "/" + best.relativeTo(dir).path.replace(File.separatorChar, '/')
    }

    /* ---------- import of loose files and whole folders ---------- */

    private val heavyDirs = setOf(".git", ".gradle", "node_modules", "build")

    private fun safeName(n: String): String? {
        val s = n.trim()
        if (s.isEmpty() || s == "." || s == ".." || s.contains('/') || s.contains('\\')) return null
        return s
    }

    private fun uniqueIn(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val suffix = if (dot > 0) name.substring(dot) else ""
        var i = 2
        while (f.exists()) {
            f = File(dir, "$stem-$i$suffix")
            i++
        }
        return f
    }

    private fun copyUri(resolver: ContentResolver, uri: Uri, dest: File) {
        val input = resolver.openInputStream(uri) ?: throw IllegalStateException("File khul nahi saki")
        input.use { i -> FileOutputStream(dest).use { i.copyTo(it) } }
    }

    /** Copies one picked file into <project>/<dirRel>. Never overwrites: a clash becomes name-2.ext. */
    fun importFile(resolver: ContentResolver, uri: Uri, dirRel: String, name: String): String {
        val dir = resolve(dirRel)
        if (!dir.isDirectory) throw IllegalArgumentException("Folder nahi mila")
        val n = safeName(name) ?: "file"
        val dest = uniqueIn(dir, n)
        copyUri(resolver, uri, dest)
        return dest.name
    }

    /** Copies a picked folder into a new project. Skips .git, .gradle, build and node_modules. */
    fun importTree(resolver: ContentResolver, tree: DocumentFile): String {
        val name = uniqueName(tree.name ?: "folder")
        val dest = File(root, name).apply { mkdirs() }
        try {
            copyTree(resolver, tree, dest)
        } catch (t: Throwable) {
            dest.deleteRecursively()
            throw t
        }
        return name
    }

    private fun copyTree(resolver: ContentResolver, src: DocumentFile, dest: File) {
        for (c in src.listFiles()) {
            val n = safeName(c.name ?: continue) ?: continue
            if (c.isDirectory) {
                if (n in heavyDirs) continue
                copyTree(resolver, c, File(dest, n).apply { mkdirs() })
            } else if (c.isFile) {
                copyUri(resolver, c.uri, uniqueIn(dest, n))
            }
        }
    }

    /** If the zip had one top-level folder (project/...), move its content up one level. */
    private fun flattenSingleRoot(dest: File) {
        val children = dest.listFiles() ?: return
        if (children.size != 1 || !children[0].isDirectory) return
        val tmp = File(dest, ".__flatten_tmp")
        if (!children[0].renameTo(tmp)) return
        tmp.listFiles()?.forEach { it.renameTo(File(dest, it.name)) }
        tmp.deleteRecursively()
    }

    fun zipProject(name: String, out: OutputStream, forBuild: Boolean = false) {
        val dir = resolve(name)
        if (!dir.isDirectory) throw IllegalArgumentException("Project nahi mila")
        val skip = setOf(".gradle", ".git", "node_modules", "build", "builds")
        ZipOutputStream(out).use { zos ->
            dir.walkTopDown().onEnter { !forBuild || it == dir || it.name !in skip }.filter { it.isFile }.forEach { f ->
                val rel = f.relativeTo(dir).path.replace(File.separatorChar, '/')
                zos.putNextEntry(ZipEntry(rel))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
