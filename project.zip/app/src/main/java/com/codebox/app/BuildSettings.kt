package com.codebox.app

import java.io.File

/**
 * codebox-build.yml in the project root: per-build app name, package name, icon, version and signing key.
 * The cloud workflow (assets/cloud-build.yml) reads it; every line is optional. Created once, never overwritten.
 */
object BuildSettings {
    const val FILE = "codebox-build.yml"

    fun template(appName: String? = null): String = """# CodeBox build settings - har APK build par ye file apply hoti hai.
# Jo line chahiye uski '#' hata kar value badlo. Khali/comment = project jaisa hai waisa.

# App ka naam (launcher me dikhta hai)
${if (appName.isNullOrBlank()) "# app_name: My App" else "app_name: " + appName.replace("\n", " ")}

# Package name (applicationId). Badalne par phone par ye alag app ban jaati hai.
# package_name: com.mycompany.myapp

# Icon: project me koi PNG/JPG (square, 512x512 behtar) rakho, uska path likho
# icon: icon.png

# Version
# version_name: 1.0
# version_code: 1

# Signing key: apni keystore (.jks/.p12) project me rakho. Na likho to CodeBox ki fixed debug key use hoti hai.
# Dhyan: public build repo me ye file/keystore sabko dikhegi - signing ke liye Private repo use karo.
# keystore: release.jks
# keystore_password: mypassword
# key_alias: mykey
# key_password: mypassword   # na likho to keystore_password hi use hota hai
"""

    /** Adds the template to Gradle projects that don't have one yet. */
    fun ensure(dir: File, appName: String? = null) {
        val gradle = File(dir, "settings.gradle.kts").exists() || File(dir, "settings.gradle").exists()
        val f = File(dir, FILE)
        if (gradle && !f.exists()) f.writeText(template(appName), Charsets.UTF_8)
    }
}
