package com.codebox.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONObject

/** Exposed to the editor UI as `window.Android`. Every method returns {"ok":bool,"data":...,"error":"..."}. */
class Bridge(private val a: MainActivity) {

    private fun ok(v: Any? = true): String = JSONObject().put("ok", true).put("data", v).toString()
    private fun err(e: Throwable): String =
        JSONObject().put("ok", false).put("error", e.message ?: e.toString()).toString()

    private inline fun safe(f: () -> Any?): String = try {
        ok(f())
    } catch (e: Throwable) {
        err(e)
    }

    @JavascriptInterface
    fun projects(): String = safe { a.store.projects() }

    @JavascriptInterface
    fun list(rel: String): String = safe { a.store.list(rel) }

    @JavascriptInterface
    fun search(project: String, q: String): String = safe { a.store.search(project, q) }

    @JavascriptInterface
    fun read(rel: String): String = safe { a.store.readText(rel) }

    @JavascriptInterface
    fun write(rel: String, text: String): String = safe { a.store.writeText(rel, text); true }

    @JavascriptInterface
    fun histFiles(project: String): String = safe { a.store.resolve(project); a.store.histFiles(project) }

    @JavascriptInterface
    fun histList(rel: String): String = safe { a.store.resolve(rel); a.store.histList(rel) }

    @JavascriptInterface
    fun histRead(rel: String, t: String): String = safe { a.store.resolve(rel); a.store.histRead(rel, t.toLong()) }

    @JavascriptInterface
    fun tokenHint(): String = safe { a.prefs().getString("gh_token", null)?.takeLast(4) ?: "" }

    @JavascriptInterface
    fun createFile(rel: String): String = safe { a.store.createFile(rel); true }

    @JavascriptInterface
    fun createDir(rel: String): String = safe { a.store.createDir(rel); true }

    @JavascriptInterface
    fun remove(rel: String): String = safe { a.store.remove(rel); true }

    @JavascriptInterface
    fun rename(rel: String, newRel: String): String = safe { a.store.rename(rel, newRel); true }

    @JavascriptInterface
    fun createEmptyProject(name: String): String = safe { a.store.createEmptyProject(name) }

    @JavascriptInterface
    fun createProject(name: String): String = safe { a.store.createProject(name) }

    @JavascriptInterface
    fun importZip(): String = safe {
        a.runOnUiThread { a.launchZipPicker() }
        true
    }

    /** Pick a zip and replace the code of an existing project with it (settings, icon, keystore, builds stay). */
    @JavascriptInterface
    fun replaceFromZip(project: String): String = safe {
        a.store.resolve(project) // validate
        a.runOnUiThread { a.launchZipReplace(project) }
        true
    }

    @JavascriptInterface
    fun zipDecision(mode: String): String = safe {
        a.zipDecision(mode)
        true
    }

    @JavascriptInterface
    fun importFiles(dirRel: String): String = safe {
        a.store.resolve(dirRel) // validate
        a.runOnUiThread { a.launchFilesPicker(dirRel) }
        true
    }

    @JavascriptInterface
    fun importFolder(): String = safe {
        a.runOnUiThread { a.launchFolderPicker() }
        true
    }

    @JavascriptInterface
    fun exportZip(project: String): String = safe {
        a.store.resolve(project) // validate
        a.pendingExport = project
        a.runOnUiThread { a.launchZipExport(project) }
        true
    }

    /** Plain preview, same as Spck: no fake native bridge, so the page's own browser fallback runs. */
    @JavascriptInterface
    fun preview(rel: String): String = safe { startPreview(rel, false); true }

    /** Preview with fake native bridge objects (for UIs that only work when `Android` exists). */
    @JavascriptInterface
    fun previewMock(rel: String): String = safe { startPreview(rel, true); true }

    /** Preview inside a fake phone (status bar, notification shade, nav buttons, recents, overlay). */
    @JavascriptInterface
    fun previewPhone(rel: String): String = safe { startPreview(rel, false, true); true }

    private fun startPreview(rel: String, mock: Boolean, phone: Boolean = false) {
        val f = a.store.resolve(rel)
        if (!f.isFile) throw IllegalArgumentException("File nahi mili")
        val project = rel.substringBefore('/')
        val mocks = if (mock && a.store.isAndroidProject(project)) a.store.bridgeNames(project).toString() else "[]"
        a.runOnUiThread {
            a.startActivity(
                Intent(a, PreviewActivity::class.java)
                    .putExtra("path", f.path)
                    .putExtra("mocks", mocks)
                    .putExtra("phone", phone)
            )
        }
    }

    /** HTML / Web to APK: writes a WebView wrapper project and returns its name; the UI then runs the normal cloud build on it. */
    @JavascriptInterface
    fun webApk(source: String, name: String, url: String, entry: String): String = safe {
        WebApk.generate(a, a.store, source, name, url, entry)
    }

    /** Every .html/.htm file in a project (skips build folders), shallow ones first. */
    @JavascriptInterface
    fun htmlFiles(project: String): String = safe { a.store.htmlFiles(project) }

    /** Pick one .html file from the phone; it becomes a new project that can be run right away. */
    @JavascriptInterface
    fun importHtml(): String = safe { a.runOnUiThread { a.launchHtmlPicker() }; true }

    @JavascriptInterface
    fun webEntry(project: String): String = safe {
        JSONObject().put("entry", a.store.webEntry(project) ?: JSONObject.NULL)
    }

    @JavascriptInterface
    fun toast(msg: String) {
        a.runOnUiThread { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show() }
    }

    /* ---------- GitHub cloud build ---------- */

    @JavascriptInterface
    fun hasToken(): String = safe { !a.prefs().getString("gh_token", null).isNullOrEmpty() }

    @JavascriptInterface
    fun setToken(t: String): String = safe {
        val v = t.trim()
        require(v.matches(Regex("[A-Za-z0-9_\\-]{20,}"))) { "Token ka format galat lagta hai" }
        a.prefs().edit().putString("gh_token", v).apply()
        true
    }

    @JavascriptInterface
    fun repoMode(): String = safe { a.prefs().getString("repo_mode", "private") }

    @JavascriptInterface
    fun setRepoMode(mode: String): String = safe {
        require(mode == "private" || mode == "public") { "Mode galat hai" }
        a.prefs().edit().putString("repo_mode", mode).apply()
        true
    }

    @JavascriptInterface
    fun clearToken(): String = safe { a.prefs().edit().remove("gh_token").apply(); true }

    @JavascriptInterface
    fun build(project: String): String = safe {
        a.store.resolve(project) // validate
        a.startBuild(project)
        true
    }

    /** Install any .apk that lives inside a project (e.g. <project>/builds/x.apk). */
    @JavascriptInterface
    fun installApkFile(rel: String): String = safe {
        require(rel.endsWith(".apk", true)) { "Ye APK file nahi hai" }
        a.store.resolve(rel)
        a.runOnUiThread { a.installApk(rel) }
        true
    }

    @JavascriptInterface
    fun listApks(): String = safe { a.listApks() }

    @JavascriptInterface
    fun saveApk(rel: String): String = safe { a.saveApkToDownloads(rel) }

    @JavascriptInterface
    fun buildState(): String = safe { org.json.JSONObject(a.buildState()) }

    @JavascriptInterface
    fun ackBuild(): String = safe { a.ackBuild(); true }

    @JavascriptInterface
    fun publishWeb(project: String, repoName: String): String = safe {
        a.store.resolve(project) // validate
        a.startPublish(project, repoName)
        true
    }

    @JavascriptInterface
    fun publishedSites(): String = safe { a.publishedSites() }

    @JavascriptInterface
    fun unpublishWeb(project: String): String = safe { a.unpublish(project); true }

    @JavascriptInterface
    fun openUrl(url: String): String = safe {
        val host = Uri.parse(url).host ?: ""
        require(url.startsWith("https://") && (host == "github.com" || host.endsWith(".github.io"))) { "Sirf github.com / github.io links allowed hain" }
        a.runOnUiThread { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        true
    }

    @JavascriptInterface
    fun copy(text: String): String = safe {
        a.runOnUiThread {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("log", text))
        }
        true
    }
}
