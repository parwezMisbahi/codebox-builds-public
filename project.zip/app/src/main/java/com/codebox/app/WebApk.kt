package com.codebox.app

import android.content.Context
import java.io.File

/**
 * "HTML to APK" and "Web to APK": writes a tiny WebView Android project (a normal Gradle project)
 * into <projects>/<name>-apk/. The existing GitHub cloud build then turns it into an APK, so no new
 * build system is needed. HTML mode bundles a project's files in assets/www, URL mode loads a website.
 */
object WebApk {
    private val skip = setOf(".git", ".gradle", "node_modules", "build", "builds")
    private const val MAX_BYTES = 60L * 1024 * 1024

    private fun asset(ctx: Context, name: String): String =
        ctx.assets.open("webapk/$name").bufferedReader().use { it.readText() }

    private fun xmlEscape(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\\", "\\\\").replace("'", "\\'").replace("\"", "\\\"")
        .replace("\n", " ")

    /** Valid Java package segment from the app name (letters/digits only, starts with a letter). */
    private fun pkgSegment(name: String): String {
        val s = name.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }.take(24)
        return if (s.isEmpty()) "app" + (name.hashCode() and 0xffff) else if (s[0].isDigit()) "a$s" else s
    }

    private fun write(f: File, text: String) {
        f.parentFile?.mkdirs()
        f.writeText(text, Charsets.UTF_8)
    }

    /** Path (relative to the project, '/' separated) of the html file the APK should open. */
    fun pickEntry(dir: File): String? {
        if (File(dir, "index.html").isFile) return "index.html"
        val all = dir.walkTopDown()
            .onEnter { it == dir || it.name !in skip }
            .filter { it.isFile && (it.extension.equals("html", true) || it.extension.equals("htm", true)) }
            .toList()
        val best = all.minWithOrNull(compareBy({ it.relativeTo(dir).path.count { c -> c == File.separatorChar } }, { it.name })) ?: return null
        return best.relativeTo(dir).path.replace(File.separatorChar, '/')
    }

    /**
     * @param source project folder name for HTML mode, or null/empty for URL mode
     * @return name of the generated project (ready for the normal cloud build)
     */
    fun generate(ctx: Context, store: ProjectStore, source: String?, appName: String, url: String?, entryOverride: String?): String {
        val html = !source.isNullOrEmpty()
        val label = appName.trim().ifEmpty { if (html) source!! else "Web App" }

        var target: String
        val srcDir: File? = if (html) store.resolve(source!!) else null
        if (srcDir != null) {
            if (!srcDir.isDirectory) throw IllegalArgumentException("Project nahi mila")
            if (File(srcDir, "settings.gradle.kts").exists() || File(srcDir, "settings.gradle").exists()) {
                throw IllegalArgumentException("Ye Android project hai, ise seedha Build APK se banao")
            }
            target = entryOverride?.takeIf { it.isNotEmpty() && File(srcDir, it).isFile } ?: pickEntry(srcDir)
                ?: throw IllegalArgumentException("Is project me koi .html file nahi hai")
        } else {
            target = (url ?: "").trim()
            if (target.isEmpty()) throw IllegalArgumentException("Website ka link daalo")
            if (!target.contains("://")) target = "https://$target"
            if (!Regex("^https?://[^\\s/]+.*$").matches(target)) throw IllegalArgumentException("Link sahi nahi hai")
        }

        val safe = label.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifEmpty { "web" }
        val genName = "$safe-apk"
        val out = store.resolve(genName)
        if (srcDir != null && out == srcDir) throw IllegalArgumentException("Ye project already APK wrapper hai")
        if (out.exists() && !File(out, "app/src/main/assets/webapk.txt").isFile) {
            throw IllegalArgumentException("'$genName' naam ka project pehle se hai. App ka naam badal do.")
        }
        // regenerate: wipe old sources but keep earlier built APKs
        // keep user's build settings + icon across regeneration
        val keep = setOf("builds", BuildSettings.FILE, "icon.png", "icon.jpg", "icon.jpeg", "icon.webp", "release.jks", "release.keystore")
        if (out.exists()) out.listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
        out.mkdirs()

        val pkg = "com.codebox.web." + pkgSegment(label)
        fun fill(t: String) = t.replace("__PKG__", pkg).replace("__LABEL__", xmlEscape(label))

        write(File(out, "settings.gradle.kts"), asset(ctx, "settings.gradle.kts"))
        write(File(out, "build.gradle.kts"), asset(ctx, "build.gradle.kts"))
        write(File(out, "gradle.properties"), asset(ctx, "gradle.properties"))
        BuildSettings.ensure(out)
        write(File(out, "app/build.gradle.kts"), fill(asset(ctx, "app.build.gradle.kts")))
        val main = File(out, "app/src/main")
        write(File(main, "AndroidManifest.xml"), asset(ctx, "AndroidManifest.xml"))
        write(File(main, "res/values/themes.xml"), asset(ctx, "themes.xml"))
        write(File(main, "res/values/strings.xml"), fill(asset(ctx, "strings.xml")))
        write(File(main, "res/drawable/ic_launcher.xml"), asset(ctx, "ic_launcher.xml"))
        write(File(main, "java/" + pkg.replace('.', '/') + "/MainActivity.kt"), fill(asset(ctx, "MainActivity.kt.txt")))
        write(File(main, "assets/webapk.txt"), (if (html) "html" else "url") + "\n" + target + "\n")

        if (srcDir != null) {
            val www = File(main, "assets/www")
            var total = 0L
            srcDir.walkTopDown().onEnter { it == srcDir || it.name !in skip }.filter { it.isFile }.forEach { f ->
                total += f.length()
                if (total > MAX_BYTES) throw IllegalArgumentException("Project bahut bada hai (60 MB se zyada)")
                val dest = File(www, f.relativeTo(srcDir).path)
                dest.parentFile?.mkdirs()
                f.copyTo(dest, overwrite = true)
            }
        }
        return genName
    }
}
