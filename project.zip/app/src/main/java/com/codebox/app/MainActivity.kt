package com.codebox.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var web: WebView
    lateinit var store: ProjectStore
    var pendingExport: String? = null
    @Volatile private var foreground = false

    override fun onResume() {
        super.onResume()
        foreground = true
        BuildService.listener = { json -> emit("build", json) }
        // app was reopened: show the current/finished build and resume polling if needed
        if (::web.isInitialized) emit("buildRefresh", buildState())
    }

    override fun onPause() {
        foreground = false
        BuildService.listener = null
        super.onPause()
    }

    fun prefs(): SharedPreferences = getSharedPreferences("codebox", Context.MODE_PRIVATE)

    private val zipPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importZip(uri)
        }

    private val zipExporter =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val project = pendingExport
            pendingExport = null
            if (uri != null && project != null) exportZip(project, uri)
        }

    var pendingImportDir: String? = null

    private val filesPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val dir = pendingImportDir
            pendingImportDir = null
            if (dir != null && uris.isNotEmpty()) importFiles(dir, uris)
        }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) importFolder(uri)
        }

    fun launchFilesPicker(dirRel: String) {
        pendingImportDir = dirRel
        filesPicker.launch(arrayOf("*/*"))
    }

    private val htmlPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importHtmlFile(uri)
        }

    fun launchHtmlPicker() {
        htmlPicker.launch(arrayOf("text/html", "application/xhtml+xml", "text/plain", "application/octet-stream"))
    }

    private fun importHtmlFile(uri: Uri) {
        val fname = rawName(uri, "page.html")
        thread {
            try {
                val name = store.importSingleHtml(contentResolver, uri, fname)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    fun launchFolderPicker() {
        folderPicker.launch(null)
    }

    fun launchZipPicker() {
        zipPicker.launch(
            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
    }

    fun launchZipExport(project: String) {
        zipExporter.launch("$project.zip")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(filesDir)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.handleBack ? window.handleBack() : false)") { r ->
                    if (r != "true") finish()
                }
            }
        })
    }

    fun emit(type: String, payload: String) {
        val js = "window.onNative && window.onNative(${JSONObject.quote(type)}, ${JSONObject.quote(payload)})"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun rawName(uri: Uri, fallback: String): String {
        var name = fallback
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
        }
        return name
    }

    private fun displayName(uri: Uri): String =
        rawName(uri, "project").removeSuffix(".zip").removeSuffix(".ZIP")

    private fun importFiles(dirRel: String, uris: List<Uri>) {
        thread {
            try {
                var n = 0
                uris.forEach { u ->
                    store.importFile(contentResolver, u, dirRel, rawName(u, "file"))
                    n++
                }
                emit("filesImported", JSONObject().put("dir", dirRel).put("count", n).toString())
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun importFolder(uri: Uri) {
        thread {
            try {
                val tree = DocumentFile.fromTreeUri(this, uri)
                    ?: throw IllegalStateException("Folder khul nahi saka")
                val name = store.importTree(contentResolver, tree)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun importZip(uri: Uri) {
        val base = displayName(uri)
        thread {
            try {
                val input = contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Zip khul nahi saki")
                val name = store.unzip(input, base)
                emit("imported", name)
            } catch (t: Throwable) {
                emit("error", "Import fail: " + (t.message ?: t.toString()))
            }
        }
    }

    private fun exportZip(project: String, uri: Uri) {
        thread {
            try {
                val out = contentResolver.openOutputStream(uri)
                    ?: throw IllegalStateException("Save location nahi khuli")
                store.zipProject(project, out)
                emit("exported", project)
            } catch (t: Throwable) {
                emit("error", "Export fail: " + (t.message ?: t.toString()))
            }
        }
    }

    /* ---------- web publish (GitHub Pages) ---------- */

    @Volatile private var publishing = false

    fun publishedSites(): JSONObject = try {
        JSONObject(prefs().getString("pub_sites", "{}") ?: "{}")
    } catch (_: Throwable) { JSONObject() }

    private fun pubEvent(stage: String, project: String, vararg extra: Pair<String, Any>) {
        val o = JSONObject().put("stage", stage).put("project", project)
        extra.forEach { o.put(it.first, it.second) }
        emit("publish", o.toString())
    }

    fun startPublish(project: String, repoName: String) {
        val token = prefs().getString("gh_token", null)
        if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
        if (publishing) throw IllegalStateException("Publish pehle se chal raha hai")
        val dir = store.resolve(project)
        if (!dir.isDirectory) throw IllegalArgumentException("Project nahi mila")
        val name = WebPublish.slug(repoName.ifBlank { project })
        publishing = true
        thread {
            try {
                val r = WebPublish(token) { m -> pubEvent("progress", project, "msg" to m) }.publish(dir, name)
                val sites = publishedSites()
                sites.put(project, JSONObject().put("url", r.url).put("repo", r.repo).put("time", System.currentTimeMillis()))
                prefs().edit().putString("pub_sites", sites.toString()).apply()
                pubEvent("done", project, "url" to r.url, "repo" to r.repo, "live" to r.live, "files" to r.files, "changed" to r.changed)
            } catch (t: Throwable) {
                pubEvent("fail", project, "msg" to (t.message ?: t.toString()))
            } finally {
                publishing = false
            }
        }
    }

    fun unpublish(project: String) {
        val token = prefs().getString("gh_token", null)
        if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
        val sites = publishedSites()
        val repo = sites.optJSONObject(project)?.optString("repo") ?: throw IllegalStateException("Ye project published nahi hai")
        thread {
            try {
                WebPublish(token) { }.unpublish(repo)
                sites.remove(project)
                prefs().edit().putString("pub_sites", sites.toString()).apply()
                pubEvent("unpublished", project)
            } catch (t: Throwable) {
                pubEvent("fail", project, "msg" to (t.message ?: t.toString()))
            }
        }
    }

    /* ---------- cloud build (GitHub Actions) ---------- */

    private fun buildEvent(stage: String, vararg extra: Pair<String, String>) {
        val o = JSONObject().put("stage", stage)
        extra.forEach { o.put(it.first, it.second) }
        emit("build", o.toString())
    }

    fun startBuild(project: String) {
        val token = prefs().getString("gh_token", null)
        if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
        if (BuildService.running || BuildService.state(this).optString("stage") == "progress") {
            throw IllegalStateException("Build pehle se chal raha hai")
        }
        askNotificationPermission()
        BuildService.start(this, project)
    }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Called by the UI on start/resume: current build state (also restarts polling if the process was killed). */
    fun buildState(): String {
        if (BuildService.needsResume(this)) {
            try { BuildService.start(this, null) } catch (_: Throwable) {}
        }
        return BuildService.state(this).toString()
    }

    fun ackBuild() {
        BuildService.saveState(this, BuildService.state(this).put("seen", true))
    }

    fun installApk(rel: String? = null) {
        val path = rel ?: BuildService.state(this).optString("apk")
        val apk = if (path.isNullOrEmpty()) null else store.resolve(path)
        if (apk == null || !apk.isFile) {
            emit("error", "Pehle build karo, APK nahi mili")
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            emit("error", "CodeBox ko install allow karo, phir Install dobara dabao")
            return
        }
        try {
            installViaSession(apk)
        } catch (t: Throwable) {
            // fallback: classic VIEW intent
            try {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (t2: Throwable) {
                emit("error", "Install start nahi hua: ${t2.message}")
            }
        }
    }

    private fun installViaSession(apk: File) {
        val pi = packageManager.packageInstaller
        val params = android.content.pm.PackageInstaller.SessionParams(
            android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )
        params.setSize(apk.length())
        val id = pi.createSession(params)
        pi.openSession(id).use { session ->
            apk.inputStream().use { input ->
                session.openWrite("base.apk", 0, apk.length()).use { out ->
                    input.copyTo(out)
                    session.fsync(out)
                }
            }
            val intent = Intent(this, InstallReceiver::class.java).setPackage(packageName)
            val flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
            val pending = android.app.PendingIntent.getBroadcast(this, id, intent, flags)
            session.commit(pending.intentSender)
        }
    }

    /** All built APKs across projects: [{project,name,path,size,time}], newest first. */
    fun listApks(): org.json.JSONArray {
        val out = ArrayList<JSONObject>()
        store.root.listFiles()?.filter { it.isDirectory }?.forEach { proj ->
            File(proj, "builds").listFiles()?.filter { it.isFile && it.name.endsWith(".apk", true) }?.forEach { f ->
                out.add(
                    JSONObject().put("project", proj.name).put("name", f.name)
                        .put("path", f.relativeTo(store.root).path.replace(File.separatorChar, '/'))
                        .put("size", f.length()).put("time", f.lastModified())
                )
            }
        }
        out.sortByDescending { it.optLong("time") }
        return org.json.JSONArray(out)
    }

    /** Copies an APK into the public Downloads/CodeBox folder so any file manager can see it. */
    fun saveApkToDownloads(rel: String): String {
        val apk = store.resolve(rel)
        require(apk.isFile && apk.name.endsWith(".apk", true)) { "APK nahi mili" }
        if (Build.VERSION.SDK_INT >= 29) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, apk.name)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/CodeBox")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Downloads me file nahi ban saki")
            contentResolver.openOutputStream(uri)!!.use { o -> apk.inputStream().use { it.copyTo(o) } }
        } else {
            val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "CodeBox")
            dir.mkdirs()
            apk.copyTo(File(dir, apk.name), overwrite = true)
        }
        return "Download/CodeBox/" + apk.name
    }
}
