package com.codebox.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

/**
 * Runs the GitHub APK build as a foreground service, so it keeps going when the app is
 * closed or swiped from recents. State lives in SharedPreferences ("build_state"), so a
 * killed process can resume polling the same GitHub run.
 */
class BuildService : Service() {

    companion object {
        const val CH_PROGRESS = "build_progress"
        const val CH_DONE = "build_done"
        const val NOTIF_PROGRESS = 41
        const val NOTIF_DONE = 42
        const val EXTRA_PROJECT = "project"

        @Volatile var running = false
        /** Set by MainActivity while it is alive, to get live updates in the UI. */
        @Volatile var listener: ((String) -> Unit)? = null

        private fun prefs(c: Context) = c.getSharedPreferences("codebox", Context.MODE_PRIVATE)

        fun state(c: Context): JSONObject =
            try { JSONObject(prefs(c).getString("build_state", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

        fun saveState(c: Context, o: JSONObject) {
            prefs(c).edit().putString("build_state", o.toString()).apply()
        }

        fun start(c: Context, project: String?) {
            val i = Intent(c, BuildService::class.java)
            if (project != null) i.putExtra(EXTRA_PROJECT, project)
            ContextCompat.startForegroundService(c, i)
        }

        /** True when state says a build was running but no service is alive (process was killed). */
        fun needsResume(c: Context): Boolean {
            val s = state(c)
            return !running && s.optString("stage") == "progress"
        }
    }

    private var lock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        val n = progressNotif("Build shuru ho raha hai...")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_PROGRESS, n)
        }
        // System restart after the process was killed: only continue if a build was really in progress.
        if (intent == null && state(this).optString("stage") != "progress") {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY
        running = true

        val project = intent?.getStringExtra(EXTRA_PROJECT)
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "codebox:build").apply { acquire(55 * 60 * 1000L) }

        thread { work(project) }
        return START_STICKY
    }

    private fun work(newProject: String?) {
        val store = ProjectStore(filesDir)
        var st = state(this)
        val token = getSharedPreferences("codebox", Context.MODE_PRIVATE).getString("gh_token", null)
        var project = newProject ?: st.optString("project")
        try {
            if (token.isNullOrEmpty()) throw IllegalStateException("GitHub token set nahi hai")
            val workflow = assets.open("cloud-build.yml").use { it.readBytes() }
            val outDir = File(store.resolve(project), "builds")
            val isPublic = getSharedPreferences("codebox", Context.MODE_PRIVATE).getString("repo_mode", "private") == "public"
            val builder = CloudBuild(token, cacheDir, workflow, outDir, isPublic) { m -> progress(project, m) }

            val res: BuildResult
            if (newProject != null) {
                st = JSONObject().put("project", project).put("stage", "progress")
                    .put("msg", "Project zip ban rahi hai...").put("seen", false)
                saveState(this, st)
                push(st)
                val zip = File(cacheDir, "project.zip")
                zip.outputStream().use { store.zipProject(project, it, forBuild = true) }
                res = builder.run(zip, project) { repo, runId ->
                    saveState(this, state(this).put("repo", repo).put("runId", runId))
                }
                zip.delete()
            } else {
                // resume after the process was killed
                val repo = st.optString("repo")
                val runId = st.optLong("runId", 0L)
                if (repo.isEmpty() || runId == 0L) {
                    throw IllegalStateException("Build shuru hone se pehle app band ho gaya tha. Dobara Build dabao.")
                }
                progress(project, "Build ka status dobara check ho raha hai...")
                res = builder.resume(repo, runId, project)
            }

            val apk = res.apk
            if (apk != null) {
                val rel = apk.relativeTo(store.root).path.replace(File.separatorChar, '/')
                finishState(project, "done", "Build ready", "", rel)
                notifyDone("APK ready: ${apk.name}", "Tap karke app kholo aur Install dabao")
            } else {
                writeErrorLog(store, project, res.message, res.log)
                finishState(project, "fail", res.message, res.log, "")
                notifyDone("Build fail hua", res.message)
            }
        } catch (t: Throwable) {
            val m = t.message ?: t.toString()
            finishState(project, "fail", m, "", "")
            notifyDone("Build fail hua", m)
        } finally {
            running = false
            try { lock?.release() } catch (_: Throwable) {}
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun writeErrorLog(store: ProjectStore, project: String, msg: String, log: String) {
        try {
            val d = File(store.resolve(project), "builds").apply { mkdirs() }
            File(d, "last-build-error.log").writeText(msg + "\n\n" + log)
        } catch (_: Throwable) {}
    }

    private fun progress(project: String, m: String) {
        val st = state(this).put("project", project).put("stage", "progress").put("msg", m)
        saveState(this, st)
        push(st)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_PROGRESS, progressNotif(m))
    }

    private fun finishState(project: String, stage: String, msg: String, log: String, apkRel: String) {
        val st = state(this).put("project", project).put("stage", stage).put("msg", msg)
            .put("log", log).put("apk", apkRel).put("seen", false)
        saveState(this, st)
        push(st)
    }

    private fun push(st: JSONObject) {
        try { listener?.invoke(st.toString()) } catch (_: Throwable) {}
    }

    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun progressNotif(text: String): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH_PROGRESS) else Notification.Builder(this)
        return b.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("CodeBox: APK build")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent())
            .build()
    }

    private fun notifyDone(title: String, text: String) {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH_DONE) else Notification.Builder(this)
        val n = b.setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_DONE, n)
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "APK build progress", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "APK build result", NotificationManager.IMPORTANCE_DEFAULT))
    }
}
