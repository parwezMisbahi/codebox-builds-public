package com.focusly.app

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Shared look of the block screens (app block, full-screen hold): clean Docera style, follows the phone's light / dark mode. */
object CoverUi {
    private fun dark(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private fun px(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun bgOf(d: Boolean) = if (d) 0xFF0F1112.toInt() else 0xFFF4F2EE.toInt()
    private fun cardOf(d: Boolean) = if (d) 0xFF1A1C1E.toInt() else 0xFFFFFFFF.toInt()
    private fun txOf(d: Boolean) = if (d) 0xFFEDEDEB.toInt() else 0xFF16181A.toInt()
    private fun muOf(d: Boolean) = if (d) 0xFF8F8E8B.toInt() else 0xFF8A8884.toInt()
    private fun tileOf(d: Boolean) = if (d) 0xFF26282A.toInt() else 0xFFF3F2EF.toInt()
    private fun prOf(d: Boolean) = if (d) 0xFF5FE3C0.toInt() else 0xFF0E8F76.toInt()
    private fun ptOf(d: Boolean) = if (d) 0xFF062018.toInt() else 0xFFFFFFFF.toInt()

    private fun text(c: Context, t: String, sp: Float, col: Int, bold: Boolean) = TextView(c).apply {
        text = t; textSize = sp; setTextColor(col); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** Subtitle line ("It is focus time now"). */
    fun why(c: Context, t: String): TextView = text(c, t, 15f, muOf(dark(c)), false).apply { setPadding(px(c, 8), px(c, 6), px(c, 8), 0) }

    /** Time-left line. */
    fun time(c: Context): TextView = text(c, "", 15f, prOf(dark(c)), true).apply { setPadding(0, px(c, 10), 0, px(c, 22)) }

    /** Filled accent button (Go Home). */
    fun primary(c: Context, label: String, onClick: () -> Unit): Button {
        val d = dark(c)
        return Button(c).apply {
            text = label; isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(ptOf(d)); stateListAnimator = null
            background = GradientDrawable().apply { cornerRadius = px(c, 18).toFloat(); setColor(prOf(d)) }
            setOnClickListener { onClick() }
        }
    }

    /** Soft grey button (Class Player, Emergency). */
    fun soft(c: Context, b: Button, label: String? = null): Button {
        val d = dark(c)
        return b.apply {
            if (label != null) text = label
            isAllCaps = false; textSize = 14f; setTextColor(txOf(d)); stateListAnimator = null
            background = GradientDrawable().apply { cornerRadius = px(c, 18).toFloat(); setColor(tileOf(d)) }
        }
    }

    /** Red button (Stop alarm). */
    fun danger(c: Context, b: Button): Button = b.apply {
        isAllCaps = false; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); stateListAnimator = null
        background = GradientDrawable().apply { cornerRadius = px(c, 18).toFloat(); setColor(0xFFD9534F.toInt()) }
    }

    /** Whole screen: page background + one white rounded card in the middle holding [buttons] in order. */
    fun screen(c: Context, title: String, why: TextView, time: TextView, buttons: List<View>): LinearLayout {
        val d = dark(c)
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(c, 22), px(c, 28), px(c, 22), px(c, 22))
            background = GradientDrawable().apply { cornerRadius = px(c, 28).toFloat(); setColor(cardOf(d)) }
            val tile = text(c, "🔒", 30f, txOf(d), false).apply {
                background = GradientDrawable().apply { cornerRadius = px(c, 22).toFloat(); setColor(tileOf(d)) }
            }
            addView(tile, LinearLayout.LayoutParams(px(c, 72), px(c, 72)))
            addView(text(c, title, 23f, txOf(d), true).apply { setPadding(0, px(c, 16), 0, 0) })
            addView(why); addView(time)
            for (b in buttons) addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(c, 52)).apply { topMargin = px(c, 10) })
        }
        return LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true
            setPadding(px(c, 20), px(c, 20), px(c, 20), px(c, 20))
            setBackgroundColor(bgOf(d))
            addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }
}
