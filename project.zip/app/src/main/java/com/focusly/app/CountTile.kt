package com.focusly.app

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import org.json.JSONObject

/** Saved settings of the countdown tile. Modes: 0 auto (lock/focus/block), 1 day countdown, 2 timer, 3 stopwatch, 4 next reminder. */
object TileCfg {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun mode(c: Context) = sp(c).getInt("t_mode", 0)
    fun dayTs(c: Context) = sp(c).getLong("t_dts", 0L)
    fun dayTitle(c: Context) = sp(c).getString("t_dt", "") ?: ""
    fun timerLenMin(c: Context) = sp(c).getInt("t_tl", 25)
    fun timerEnd(c: Context) = sp(c).getLong("t_te", 0L)
    fun timerPaused(c: Context) = sp(c).getLong("t_tp", 0L)
    fun swStart(c: Context) = sp(c).getLong("t_ss", 0L)
    fun swElapsed(c: Context) = sp(c).getLong("t_se", 0L)

    fun nextReminder(c: Context): Pair<String, Long>? {
        val now = System.currentTimeMillis()
        var best: Pair<String, Long>? = null
        try {
            for (r in Store.reminders(c)) {
                if (!r.on) continue
                var at = r.at
                if (r.daily && at < now) { val day = 86_400_000L; at += ((now - at) / day + 1) * day }
                if (at > now && (best == null || at < best!!.second)) best = Pair(r.title, at)
            }
        } catch (_: Throwable) {}
        return best
    }

    fun next(c: Context) {
        var m = mode(c)
        for (i in 0 until 5) {
            m = (m + 1) % 5
            val ok = when (m) { 1 -> dayTs(c) > 0L; 4 -> nextReminder(c) != null; else -> true }
            if (ok) break
        }
        sp(c).edit().putInt("t_mode", m).apply()
    }

    fun setMode(c: Context, m: Int) = sp(c).edit().putInt("t_mode", m).apply()
    fun setDay(c: Context, title: String, ts: Long) = sp(c).edit().putString("t_dt", title.take(24)).putLong("t_dts", ts).apply()

    fun timer(c: Context, action: String, min: Int) {
        val now = System.currentTimeMillis(); val e = sp(c).edit()
        when (action) {
            "start" -> { val left = if (timerPaused(c) > 0L) timerPaused(c) else timerLenMin(c) * 60_000L; e.putLong("t_te", now + left).putLong("t_tp", 0L) }
            "pause" -> { val te = timerEnd(c); if (te > 0L) e.putLong("t_tp", (te - now).coerceAtLeast(0L)).putLong("t_te", 0L) }
            "reset" -> e.putLong("t_te", 0L).putLong("t_tp", 0L)
            "len" -> e.putInt("t_tl", min.coerceIn(1, 1440)).putLong("t_te", 0L).putLong("t_tp", 0L)
        }
        e.apply()
    }

    fun sw(c: Context, action: String) {
        val now = System.currentTimeMillis(); val e = sp(c).edit()
        when (action) {
            "start" -> if (swStart(c) == 0L) e.putLong("t_ss", now)
            "pause" -> if (swStart(c) > 0L) e.putLong("t_se", swElapsed(c) + (now - swStart(c))).putLong("t_ss", 0L)
            "reset" -> e.putLong("t_ss", 0L).putLong("t_se", 0L)
        }
        e.apply()
    }

    fun json(c: Context): String = JSONObject().put("mode", mode(c)).put("dt", dayTitle(c)).put("dts", dayTs(c))
        .put("tl", timerLenMin(c)).put("tRun", timerEnd(c) > 0L).put("tPaused", timerPaused(c) > 0L)
        .put("sRun", swStart(c) > 0L).put("sEl", swElapsed(c)).toString()
}

/** Notification-bar tile: tap = switch view (auto countdown / day countdown / timer / stopwatch / next reminder). */
class CountTile : TileService() {
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000L) } }

    override fun onStartListening() { h.removeCallbacks(loop); h.post(loop) }
    override fun onStopListening() { h.removeCallbacks(loop) }

    override fun onClick() { TileCfg.next(applicationContext); refresh() }

    /** Two short lines inside the circle, e.g. 11h / 27m. */
    private fun timeIcon(top: String, bottom: String): Icon {
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = 56f; cv.drawText(top, size / 2f, 56f, p)
        p.textSize = 48f; cv.drawText(bottom, size / 2f, 110f, p)
        return Icon.createWithBitmap(bmp)
    }

    private fun parts(ms: Long): Pair<String, String> {
        val sec = (ms + 999L) / 1000L
        val hh = sec / 3600; val mm = (sec % 3600) / 60; val ss = sec % 60
        return if (hh > 0) Pair("${hh}h", "${mm}m") else if (mm > 0) Pair("${mm}m", "${ss}s") else Pair("$ss", "sec")
    }

    private fun set(t: Tile, active: Boolean, a: String?, b: String?, label: String, sub: String) {
        t.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.icon = if (a != null && b != null) timeIcon(a, b) else Icon.createWithResource(this, R.drawable.ic_tile)
        t.label = label
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = sub
    }

    private fun refresh() {
        val t = qsTile ?: return
        val c = applicationContext
        val now = System.currentTimeMillis()
        when (TileCfg.mode(c)) {
            1 -> {
                val ts = TileCfg.dayTs(c)
                if (ts <= 0L) set(t, false, null, null, "Day countdown", "Not set")
                else {
                    val d = (ts - now + 86_399_999L) / 86_400_000L
                    val title = TileCfg.dayTitle(c).ifEmpty { "Day countdown" }
                    if (d > 0) set(t, true, "${d}d", "left", title, "$d days left") else set(t, true, "Today", "", title, "Today")
                }
            }
            2 -> {
                val te = TileCfg.timerEnd(c)
                if (te > 0L) {
                    val left = te - now
                    if (left > 0) { val (a, b) = parts(left); set(t, true, a, b, "Timer", Blocker.format(left)) }
                    else set(t, true, "0", "done", "Timer", "Finished")
                } else {
                    val ms = if (TileCfg.timerPaused(c) > 0L) TileCfg.timerPaused(c) else TileCfg.timerLenMin(c) * 60_000L
                    val (a, b) = parts(ms); set(t, false, a, b, "Timer", if (TileCfg.timerPaused(c) > 0L) "Paused" else "Ready")
                }
            }
            3 -> {
                val run = TileCfg.swStart(c) > 0L
                val el = TileCfg.swElapsed(c) + (if (run) now - TileCfg.swStart(c) else 0L)
                val (a, b) = parts(el - (el % 1000L))
                set(t, run, a, b, "Stopwatch", if (run) "Running" else "Stopped")
            }
            4 -> {
                val r = TileCfg.nextReminder(c)
                if (r == null) set(t, false, null, null, "Reminder", "None")
                else { val (a, b) = parts(r.second - now); set(t, true, a, b, r.first.take(24), "Next reminder") }
            }
            else -> {
                var left = 0L
                var what = ""
                fun cand(ms: Long, w: String) { if (ms > 0 && (left == 0L || ms < left)) { left = ms; what = w } }
                try { cand(Lock.until(c) - now, "Phone lock") } catch (_: Throwable) {}
                try { val p = Pomo.st(c); if (p.running) cand(p.leftMs, if (p.focus) "Focus" else "Break") } catch (_: Throwable) {}
                try { cand(Hold.left(c), "Screen block") } catch (_: Throwable) {}
                try { Store.rules(c).filter { ruleBlocking(it, c) }.forEach { cand(ruleLeftPublic(it), "Block rule") } } catch (_: Throwable) {}
                if (left > 0) { val (a, b) = parts(left); set(t, true, a, b, what, Blocker.format(left)) }
                else set(t, false, null, null, "Focusly", "No timer")
            }
        }
        t.updateTile()
    }
}

/** One-time cleanup: the location feature was removed, so drop saved places and every place link. */
object NoLoc {
    fun run(c: Context) {
        try { if (Places.all(c).isNotEmpty()) Places.save(c, emptyList()) } catch (_: Throwable) {}
        try { val rs = Store.rules(c); if (rs.any { it.pls.isNotEmpty() }) Store.saveRules(c, rs.map { it.copy(pls = emptyList()) }) } catch (_: Throwable) {}
        try { Lock.setPls(c, emptyList()) } catch (_: Throwable) {}
    }
}
