package com.focusly.app

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.IntentFilter
import android.os.PowerManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.core.app.NotificationCompat
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar

/** "780-900,1200-1260" -> [(780,900),(1200,1260)] : daily gap hours inside which the rule does NOT block. */
fun gapList(r: Rule): List<Pair<Int, Int>> = r.gaps.split(",").mapNotNull { t ->
    val a = t.split("-"); val s = a.getOrNull(0)?.toIntOrNull(); val e = a.getOrNull(1)?.toIntOrNull()
    if (s != null && e != null && s != e) Pair(s, e) else null
}

/** Day this occurrence of the window belongs to (an overnight window after midnight still belongs to yesterday). */
private fun occDay(r: Rule, now: Int): Long = java.time.LocalDate.now().toEpochDay() - (if (r.start > r.end && now < r.end) 1 else 0)

/** Fixed date range set, and we are inside it (the rule is "running", even during a gap). */
fun inDateRange(r: Rule): Boolean {
    if (r.d1 == 0L && r.d2 == 0L) return false
    val today = java.time.LocalDate.now().toEpochDay()
    return (r.d1 == 0L || today >= r.d1) && (r.d2 == 0L || today <= r.d2)
}

fun isActive(r: Rule, ctx: Context): Boolean {
    if (r.lim > 0) return r.pkg != "*" && Usage.get(ctx, r.pkg) >= r.lim * 60_000L // daily limit used up
    val c = Calendar.getInstance()
    if (r.days.isNotEmpty() && c.get(Calendar.DAY_OF_WEEK) !in r.days) return false
    val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    val inWin = if (r.start <= r.end) now in r.start until r.end else now >= r.start || now < r.end
    if (!inWin) return false
    if (r.d1 != 0L || r.d2 != 0L) { // fixed dates (e.g. 12-10-2026 to 20-10-2026)
        val day = occDay(r, now)
        if ((r.d1 != 0L && day < r.d1) || (r.d2 != 0L && day > r.d2)) return false
    }
    for ((a, b) in gapList(r)) if (if (a <= b) now in a until b else now >= a || now < b) return false // gap hours
    return true
}

/** Milliseconds until the (currently active) rule ends. */
fun ruleLeftPublic(r: Rule): Long = ruleLeftMs(r)
private fun ruleLeftMs(r: Rule): Long {
    val c = Calendar.getInstance()
    val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    var endMin = if (r.end > now) r.end - now else r.end + 1440 - now
    // a whole-day rule with a last date shows the time up to the end of that date
    if (r.d2 != 0L && r.start == 0 && r.end == 1440 && r.days.isEmpty()) endMin += ((r.d2 - java.time.LocalDate.now().toEpochDay()).coerceAtLeast(0L) * 1440L).toInt()
    // the next gap (later today) ends the running block earlier
    for ((a, _) in gapList(r)) if (a > now && a - now < endMin) endMin = a - now
    return (endMin * 60_000L - c.get(Calendar.SECOND) * 1000L).coerceAtLeast(1000L)
}

/** Milliseconds until midnight. */
fun midnightMs(): Long {
    val c = Calendar.getInstance()
    c.add(Calendar.DAY_OF_YEAR, 1)
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return (c.timeInMillis - System.currentTimeMillis()).coerceAtLeast(1000L)
}

/** A rule that is blocking right now (schedule window active and, for location rules, the place not reached yet). */
fun ruleBlocking(r: Rule, ctx: Context) = r.on && isActive(r, ctx) && !Presence.done(ctx, r)

/** A rule that can not be edited / deleted now: its window is running (a Block-place rule stays locked even while you are outside the place). */
fun ruleLocked(r: Rule, ctx: Context) = r.on && ((isActive(r, ctx) && (Presence.live(r) || !Presence.done(ctx, r))) || inDateRange(r)) // a running date-range rule stays locked even during its gap

fun accessibilityOn(c: Context) =
    (Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(c.packageName)

object Blocker {
    class BInfo(val left: Long, val why: String)

    /** Longest running block that covers [pkg] right now (schedule, daily limit, goal link, Phone Lock), left = 0 -> not blocked. */
    fun info(ctx: Context, pkg: String): BInfo {
        if (Gap.active(ctx) || Emerg.active(ctx, pkg)) return BInfo(0L, "") // unblock window / emergency pass running
        if (pkg in Allow.get(ctx)) { // "Kabhi block nahi" apps: only a rule that has "Kabhi-block-nahi apps ko bhi block karo" (inc) ON can block them (e.g. namaz time)
            var inc = BInfo(0L, "")
            for (r in Store.rules(ctx)) {
                if (!r.on || !r.inc || !(r.pkg == pkg || (r.pkg == "*" && r.lim == 0)) || !isActive(r, ctx) || Presence.done(ctx, r)) continue
                if (r.lim > 0) { if (midnightMs() > inc.left) inc = BInfo(midnightMs(), "Aaj ki ${r.lim} min ki limit poori ho gayi") }
                else { val l = ruleLeftMs(r); if (l > inc.left) inc = BInfo(l, Presence.why(ctx, r)) }
            }
            return inc
        }
        var best = BInfo(0L, "")
        val exempt = pkg in Allow.get(ctx) // reading apps etc.: skipped by every "all apps" block
        fun cand(l: Long, w: String) { if (l > best.left) best = BInfo(l, w) }
        val lock = Lock.until(ctx) - System.currentTimeMillis()
        if (lock > 0 && !exempt && !Presence.lockDone(ctx)) cand(lock, Presence.lockWhy(ctx))
        val bed = Bed.leftMs(ctx)
        if (bed > 0 && !exempt && pkg !in Bed.EXEMPT) cand(bed, "Sone ka time - subah ${Bed.endText(ctx)} baje khulega")
        val pomo = Pomo.focusLeft(ctx)
        if (pomo > 0 && !exempt) cand(pomo, "Pomodoro focus is running - wait for the break")
        for (r in Store.rules(ctx)) {
            if (!r.on || !(r.pkg == pkg || (r.pkg == "*" && r.lim == 0 && !exempt)) || !isActive(r, ctx) || Presence.done(ctx, r)) continue
            if (r.lim > 0) cand(midnightMs(), "Aaj ki ${r.lim} min ki limit poori ho gayi")
            else cand(ruleLeftMs(r), Presence.why(ctx, r))
        }
        for (g in GoalStore.load(ctx)) {
            if ((pkg in g.lp || ("*" in g.lp && !exempt)) && g.linkActive()) cand(midnightMs(), "Complete the goal first: ${g.name} ${g.progress}/${g.need()} ${g.unit}")
        }
        return best
    }

    fun blockedLeft(ctx: Context, pkg: String): Long = info(ctx, pkg).left

    /** True while ANY block is running right now. */
    fun anyActive(ctx: Context): Boolean = !Gap.active(ctx) && (
        Bed.active(ctx) || Hold.left(ctx) > 0 || Lock.until(ctx) > System.currentTimeMillis() || Pomo.focusLeft(ctx) > 0 ||
            Store.rules(ctx).any { ruleBlocking(it, ctx) } || GoalStore.load(ctx).any { it.linkActive() })

    fun limitPkgs(ctx: Context): Set<String> = Store.rules(ctx).filter { it.on && it.lim > 0 && it.pkg != "*" }.map { it.pkg }.toSet()

    fun anyConfigured(ctx: Context) = Bed.on(ctx) || Hold.left(ctx) > 0 || Pomo.running(ctx) || Lock.until(ctx) > System.currentTimeMillis() ||
        Store.rules(ctx).any { it.on } || GoalStore.load(ctx).any { it.lp.isNotEmpty() }

    /** Apps that can never be blocked, so the phone always stays usable (calls, emergency, settings, home, keyboard). */
    fun protectedPackages(ctx: Context): Set<String> {
        val s = mutableSetOf(
            ctx.packageName, "android", "com.android.settings", "com.android.systemui", "com.android.phone",
            "com.android.server.telecom", "com.android.dialer", "com.google.android.dialer", "com.samsung.android.dialer",
            "com.samsung.android.incallui", "com.android.emergency", "com.google.android.apps.safetyhub",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller", "com.android.packageinstaller"
        )
        val pm = ctx.packageManager
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
            pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {}
        try {
            ctx.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) }
        } catch (_: Exception) {}
        try {
            (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "")
                .substringBefore('/').takeIf { it.isNotEmpty() }?.let { s.add(it) }
        } catch (_: Exception) {}
        return s
    }

    /**
     * Turns the blocker service back on by itself. Works only after the one-time grant:
     *   adb shell pm grant com.focusly.app android.permission.WRITE_SECURE_SETTINGS
     */
    fun tryEnableService(ctx: Context): Boolean {
        if (BlockService.connected) return true
        if (ctx.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val me = ComponentName(ctx, BlockService::class.java).flattenToString()
            val cur = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val others = cur.split(':').filter { it.isNotBlank() && it != me }
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, others.joinToString(":"))
            Settings.Secure.putString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, (others + me).joinToString(":"))
            Settings.Secure.putInt(ctx.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (_: Throwable) { false }
    }

    fun format(ms: Long): String {
        val totalMin = (ms + 59_999L) / 60_000L
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }
}

/**
 * App blocker (same engine as Docera's).
 *
 * 1. Looks at which app windows are on screen (package name + position only, no content read).
 * 2. EVERY window that belongs to a blocked app gets its own solid "app blocked" overlay drawn exactly
 *    over THAT window (full-screen app -> whole screen, split-screen half / floating window -> only that
 *    window). The overlay swallows every touch, so the blocked app can not be used.
 * 3. The overlay shows only the "app blocked" message and one "Go home" button.
 * 4. It disappears by itself when the window is gone or the schedule / lock time is over.
 *
 * Focusly itself, Settings, Phone, the launcher and the keyboard are never covered.
 */
class BlockService : AccessibilityService() {

    companion object {
        /** True while Android has this service bound and running. */
        @Volatile var connected: Boolean = false
        @Volatile private var inst: BlockService? = null
        /** Re-check right now (called when a full-screen hold starts). */
        fun poke() { inst?.let { s -> s.handler.post { s.evaluate() } } }
        private const val DOWN_ID = 4242
        private const val POLL_MS = 400L
        private const val IDLE_MS = 10_000L // catches a schedule starting while an app is already open
        private const val PROTECTED_TTL_MS = 60_000L
    }

    private data class Hit(val id: Int, val pkg: String, val remMs: Long, val rect: Rect, val why: String)
    private class Cover(val view: View, val time: TextView, val em: Button?, val key: String, val why: TextView?)

    val handler = Handler(Looper.getMainLooper())
    private val covers = HashMap<Int, Cover>()
    private var protectedCache: Set<String> = emptySet()
    private var protectedAt = 0L
    private val evalRunnable = Runnable { evaluate() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        connected = true
        inst = this
        KeepService.start(this)
        try { getSystemService(NotificationManager::class.java).cancel(DOWN_ID) } catch (_: Throwable) {}
        screenOn = try { getSystemService(PowerManager::class.java).isInteractive } catch (_: Throwable) { true }
        try {
            registerReceiver(screenRx, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT) })
        } catch (_: Throwable) {}
        handler.post(evalRunnable)
    }

    /** Count usage only while the screen is on. */
    private var screenOn = true
    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) { trackUsage(null); screenOn = false } else { screenOn = true; fgSince = SystemClock.elapsedRealtime(); handler.post(evalRunnable) }
        }
    }

    /** Somebody switched the blocker off while a block / limit / goal link exists -> tell them. */
    private fun notifyDown() {
        try {
            if (!Blocker.anyConfigured(this)) return
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fb", "Blocker status", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(this, 7, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(DOWN_ID, NotificationCompat.Builder(this, "fb").setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Focusly blocker stopped").setContentText("Blocking will not work. Tap to turn Focusly back ON in Accessibility.")
                .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_MAX).build())
        } catch (_: Throwable) {}
    }

    override fun onUnbind(intent: Intent?): Boolean {
        connected = false
        inst = null
        try { unregisterReceiver(screenRx) } catch (_: Throwable) {}
        handler.removeCallbacksAndMessages(null)
        removeAllCovers()
        try { dimView?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Throwable) {}
        dimView = null
        notifyDown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        val was = connected
        connected = false
        inst = null
        try { unregisterReceiver(screenRx) } catch (_: Throwable) {}
        handler.removeCallbacksAndMessages(null)
        removeAllCovers()
        try { dimView?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Throwable) {}
        dimView = null
        if (was) notifyDown()
        super.onDestroy()
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (protectedCache.isEmpty() || now - protectedAt > PROTECTED_TTL_MS) {
            protectedCache = Blocker.protectedPackages(this)
            protectedAt = now
        }
        return protectedCache
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Never let an exception escape: a crash here would take Focusly's process down with it.
        try {
            if (event == null) return
            val t = event.eventType
            if (t == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED || t == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || t == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                try { wordsHandle(event) } catch (_: Throwable) {}
            }
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && t != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
            handler.removeCallbacks(evalRunnable)
            handler.postDelayed(evalRunnable, 60L)
        } catch (_: Throwable) {}
    }

    // ---------- Search block (words typed anywhere + browser URL bar) ----------
    private var kwLast = 0L
    private var kwScan = 0L
    private val browsers = setOf("com.android.chrome", "org.chromium.chrome", "org.mozilla.firefox", "org.mozilla.fenix", "com.sec.android.app.sbrowser",
        "com.brave.browser", "com.microsoft.emmx", "com.opera.browser", "com.opera.mini.native", "com.duckduckgo.mobile.android",
        "com.kiwibrowser.browser", "com.vivaldi.browser", "com.mi.globalbrowser", "com.UCMobile.intl", "com.android.browser")

    private var kwBackAt = -100_000L

    private fun wordsHandle(event: AccessibilityEvent) {
        if (!Words.on(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        val t = event.eventType
        if (t == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (event.isPassword) return
            val txt = event.text?.joinToString(" ")
            if (Words.hit(this, txt) != null) {
                try { // clear the field so it is empty when the person comes back
                    val src = event.source
                    if (src != null) {
                        val b = android.os.Bundle()
                        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
                        src.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                    }
                } catch (_: Throwable) {}
                wordBlock(pkg, false)
            }
        } else {
            if (pkg == "com.android.systemui") return
            val now = SystemClock.elapsedRealtime()
            if (now - kwScan < 1200L) return
            kwScan = now
            val root = rootInActiveWindow ?: return
            val rp = root.packageName?.toString() ?: return
            if (rp == packageName || rp == "com.android.systemui") return
            val isBrowser = rp in browsers
            val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(root)
            var n = 0
            while (stack.isNotEmpty() && n < 700) {
                val x = stack.removeLast(); n++
                if (x.isPassword) continue
                val tx = x.text?.toString()
                val cd = x.contentDescription?.toString()
                if (isBrowser) {
                    val id = x.viewIdResourceName?.lowercase() ?: ""
                    if ((id.contains("url") || id.contains("omnibox") || id.contains("search_box") || id.contains("location_bar")) && Words.hit(this, tx) != null) { wordBlock(rp, true); return }
                }
                if (x.isVisibleToUser && (Words.hitScreen(this, tx) != null || Words.hitScreen(this, cd) != null)) { wordBlock(rp, true); return }
                for (i in 0 until x.childCount) x.getChild(i)?.let { stack.add(it) }
            }
        }
    }

    /** [screen]: found on the page itself. First time: Back (leaves the page); if it is still there, Home. */
    private fun wordBlock(pkg: String, screen: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - kwLast < 2500L) return
        kwLast = now
        try { Report.addBlock(this, pkg) } catch (_: Throwable) {}
        Toast.makeText(this, "Focusly: ye search block hai", Toast.LENGTH_LONG).show()
        if (screen && now - kwBackAt > 8000L) { kwBackAt = now; performGlobalAction(GLOBAL_ACTION_BACK) }
        else performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /** ALL on-screen app windows that belong to a blocked app (full screen, split-screen, floating). */
    private var callUp = false
    private var fgNow: String? = null
    private var guardNeeded = false
    private val settingsPkgs = setOf("com.android.settings", "com.samsung.android.settings", "com.android.packageinstaller",
        "com.google.android.packageinstaller", "com.google.android.permissioncontroller", "com.android.permissioncontroller")

    /** Does this window show Focusly (its name / package)? Used by strict mode on Settings pages. */
    private fun mentionsMe(root: AccessibilityNodeInfo): Boolean {
        val me = "focusly"
        val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(root)
        var n = 0
        while (stack.isNotEmpty() && n < 500) {
            val x = stack.removeLast(); n++
            val t = (x.text?.toString() ?: "") + " " + (x.contentDescription?.toString() ?: "")
            if (t.contains(me, true)) return true
            for (i in 0 until x.childCount) x.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    private fun findBlockedWindows(): List<Hit> {
        callUp = false; fgNow = null; guardNeeded = false
        ytRect = null; ytBottom = null; ytReel = false; ytSearch = false; ytBar = null
        val shieldWanted = try { Shield.active(this) } catch (_: Throwable) { false }
        val strictOn = Strict.wanted(this) && Blocker.anyActive(this)
        val list = try { windows } catch (_: Throwable) { null } ?: return emptyList()
        val prot = protectedSet()
        val res = ArrayList<Hit>()
        for (w in list) {
            try {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val root = w.root ?: continue
                val p = root.packageName?.toString()
                if (strictOn && p != null && p in settingsPkgs && mentionsMe(root)) guardNeeded = true
                if (shieldWanted && p != null && p in Shield.YT && w.isActive) {
                    val wr = Rect(); w.getBoundsInScreen(wr)
                    ytRect = wr
                    if (Shield.mode(this) == "auto" || Shield.srch(this)) ytBottom = scanPlayer(root, wr)
                }
                try { root.recycle() } catch (_: Throwable) {}
                if (w.isActive && p != null) fgNow = p
                if (p != null && (p.contains("incallui") || p == "com.android.server.telecom" || p.contains("emergency") || p == "com.android.phone")) callUp = true
                if (p == null || p == packageName || p in prot) continue
                val bi = Blocker.info(this, p)
                val rem = bi.left
                if (rem <= 0L) continue
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.width() <= 0 || r.height() <= 0) continue
                res.add(Hit(w.id, p, rem, r, bi.why))
            } catch (_: Throwable) {}
        }
        return res
    }

    fun evaluate() {
        try {
            val hits0 = findBlockedWindows()
            trackUsage(fgNow)
            try { updateDim() } catch (_: Throwable) {}
            if (guardNeeded) {
                performGlobalAction(GLOBAL_ACTION_HOME)
                Toast.makeText(this, "Strict mode: Focusly settings are locked while a block is active", Toast.LENGTH_LONG).show()
            }
            val holdLeft = Hold.left(this)
            val showHold = holdLeft > 0 && !Gap.active(this) && !Emerg.active(this, "hold") && !callUp &&
                (fgNow == null || fgNow !in Allow.get(this))
            if (showHold) showHold(holdLeft) else removeHold()
            val hits = if (showHold) emptyList() else hits0 // the full-screen hold already covers everything
            val liveIds = hits.map { it.id }.toSet()
            for (id in covers.keys.toList()) if (id !in liveIds) removeCover(id)
            for (hit in hits) {
                try { showOrUpdateCover(hit) } catch (_: Throwable) {}
            }
            try { updateShield(hits.any { it.pkg in Shield.YT } || showHold) } catch (_: Throwable) {}
        } catch (_: Throwable) {
        } finally {
            handler.removeCallbacks(evalRunnable)
            var next = -1L
            if (covers.isNotEmpty() || holdCover != null) next = POLL_MS
            else if (try { Gap.active(this) || Emerg.anyActive(this) || Hold.left(this) > 0 } catch (_: Throwable) { false }) next = 2000L
            else if (try { Blocker.anyConfigured(this) } catch (_: Throwable) { false }) {
                val fast = fgPkg != null && (try { fgPkg in Blocker.limitPkgs(this) || Strict.wanted(this) } catch (_: Throwable) { false })
                next = if (fast) 3000L else IDLE_MS
            }
            val fgy = fgNow
            if (fgy != null && fgy in Shield.YT && (try { Shield.on(this) } catch (_: Throwable) { false }) && (next < 0L || next > 600L)) next = 600L // shield follows the YouTube screen
            if (next < 0L && screenOn && fgPkg != null) next = IDLE_MS // keep counting screen time for the usage report
            if (next > 0L && next > 15_000L) next = 15_000L
            if (try { Bed.on(this) } catch (_: Throwable) { false } && (next < 0L || next > 20_000L)) next = 20_000L // bedtime dimming follows the clock
            if (next > 0L) handler.postDelayed(evalRunnable, next)
        }
    }

    // ---------- Class Shield (cover everything below the YouTube video) ----------
    private var ytRect: Rect? = null
    private var ytBottom: Int? = null
    private var shieldView: View? = null
    private var shieldKind = ""
    private var ytAutoKind = ""   // which screen kind already got its automatic Search tap in this YouTube session
    private var ytReel = false      // a full-screen Shorts player is showing
    private var ytSearch = false    // the search box (typing / results screen) is showing
    private var ytBar: Int? = null  // screen y of the bottom of YouTube's top bar

    /** Looks for the video player view in YouTube's window; returns the screen y of its bottom edge, or null. */
    private fun scanPlayer(root: AccessibilityNodeInfo, win: Rect): Int? {
        val sb = StringBuilder("YouTube window: ${win.left},${win.top} - ${win.right},${win.bottom}\nPlayer-like views:\n")
        var best: Rect? = null
        val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(root)
        var n = 0; var shown = 0
        while (stack.isNotEmpty() && n < 900) {
            val x = stack.removeLast(); n++
            val id = x.viewIdResourceName
            if (id != null) {
                val il = id.substringAfter(":id/").lowercase()
                val rr = Rect(); x.getBoundsInScreen(rr)
                if ((il.contains("reel") || il.contains("short")) && rr.width() >= win.width() * 0.9 && rr.height() >= win.height() * 0.6) ytReel = true
                if (il.contains("search_edit") || il.contains("search_query") || il.contains("search_box") || (x.className?.toString() == "android.widget.EditText" && rr.top < win.top + win.height() * 0.25)) ytSearch = true
                if (rr.top < win.top + win.height() * 0.22 && rr.bottom <= win.top + win.height() * 0.25 && rr.bottom > win.top && rr.width() >= win.width() * 0.5 && (il.contains("toolbar") || il.contains("action_bar") || il.contains("app_bar") || il.contains("search"))) {
                    if (ytBar == null || rr.bottom > ytBar!!) ytBar = rr.bottom
                }
                if (rr.top < win.top + win.height() * 0.25 && shown < 10 && !il.contains("player")) { sb.append("   top: ").append(il).append("  ").append(rr.top).append('-').append(rr.bottom).append('\n'); shown++ }
            }
            if (id != null && id.contains("player", true)) {
                val r = Rect(); x.getBoundsInScreen(r)
                val ok = r.width() >= win.width() * 0.9 && r.height() >= r.width() * 0.4 && r.height() <= r.width() * 0.9 && r.top < win.top + win.height() * 0.4
                if (shown < 14) { sb.append(if (ok) " * " else "   ").append(id.substringAfter(":id/")).append("  ").append(r.left).append(',').append(r.top).append('-').append(r.right).append(',').append(r.bottom).append('\n'); shown++ }
                if (ok && (best == null || r.height() * r.width() > best.height() * best.width())) best = Rect(r)
            }
            for (i in 0 until x.childCount) x.getChild(i)?.let { stack.add(it) }
        }
        sb.append("Shorts: $ytReel   Search box: $ytSearch   Top bar bottom: $ytBar\n").append("Nodes scanned: $n\n").append(if (best != null) "Video bottom = ${best.bottom}" else "Player NOT found (shield stays off in Auto mode)")
        Shield.debug = sb.toString()
        return best?.bottom
    }

    private fun updateShield(ytCovered: Boolean) {
        val r = ytRect
        var b = ytBottom
        val dp = resources.displayMetrics.density
        if (r == null) ytAutoKind = ""
        var show = r != null && !ytCovered && r.height() > r.width()
        var kind = "watch"
        if (show && Shield.srch(this)) {
            kind = when {
                ytReel -> "reel"
                ytBottom != null -> "watch"
                ytSearch -> "none"
                else -> "home"
            }
            if (kind == "none") show = false
            if (kind == "reel") b = r!!.top
            if (kind == "home") b = ytBar ?: (r!!.top + (112 * dp).toInt())
        }
        if (show && kind == "watch" && Shield.mode(this) == "fixed") b = r!!.top + r.height() * Shield.pct(this) / 100
        if (b == null) show = false
        // stop above the navigation bar: Back / Home buttons must stay usable
        val dm = android.util.DisplayMetrics()
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm) } catch (_: Throwable) {}
        val rb = if (r != null) minOf(r.bottom, (if (dm.heightPixels > 0) dm.heightPixels else r.bottom) - navInset()) else 0
        if (show && rb - b!! < (80 * dp).toInt()) show = false
        if (!show) { removeShield(); return }
        // Search mode: when YouTube opens on Home (or on Shorts) tap the Search button by itself, once per YouTube session
        if (Shield.srch(this) && (kind == "home" || kind == "reel") && ytAutoKind != kind) {
            if (clickYt(listOf("Search", "खोजें", "खोज"), true)) { ytAutoKind = kind; handler.postDelayed(evalRunnable, 500L) }
        }
        if (kind != shieldKind) removeShield()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            r!!.width(), rb - b!!,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = r.left; lp.y = b
        val v = shieldView
        if (v == null) {
            val nv = buildShield(kind)
            wm.addView(nv, lp)
            shieldView = nv; shieldKind = kind
        } else wm.updateViewLayout(v, lp)
    }

    private fun buildShield(kind: String = "watch"): View {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(col); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        val what = if (kind == "watch") "Video chunna hai?" else "Kuch aur dekhna hai?"
        fun label(): String {
            val l = Shield.pausesLeft(this)
            return if (l > 0) "$what ${Shield.PAUSE_MIN} min ruko ($l baaki, ${Shield.WIN_MIN} min mein ${Shield.PAUSE_PER_WIN})"
            else "Agla pause ${Shield.waitMin(this)} min baad"
        }
        val pauseBtn = Button(this).apply {
            isAllCaps = false; textSize = 13f
            text = label()
            var armed = false // first tap asks "sure?", second tap uses the pause (so one slip does not burn it)
            setOnClickListener {
                if (Shield.pausesLeft(this@BlockService) <= 0) { text = label(); armed = false }
                else if (!armed) { armed = true; text = "Pakka ${Shield.PAUSE_MIN} min? Dobara dabao"; postDelayed({ armed = false; text = label() }, 4000L) }
                else if (Shield.usePause(this@BlockService)) { removeShield(); handler.postDelayed(evalRunnable, Shield.PAUSE_MIN * 60_000L + 500L) }
            }
        }
        val title = when (kind) { "home" -> "Search mode"; "reel" -> "Shorts band hain"; else -> "Class Shield" }
        val sub = when (kind) {
            "home" -> "Home aur recommendations band hain. Upar Search dabao, video dhoondo aur dekho."
            "reel" -> "Shorts yahan nahi chalte. Wapas jaakar Search se video dhoondo."
            else -> "Neeche ke videos band hain. Upar video aur uske controls (speed, seek) chalte rahenge."
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(px(24), px(24), px(24), px(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF06181B.toInt(), 0xFF0D2D30.toInt()))
            addView(tv(title, 20f, Color.WHITE, true))
            addView(tv(sub, 14f, 0xB3FFFFFF.toInt()).apply { setPadding(0, px(6), 0, px(18)) })
            if (kind == "reel") addView(Button(this@BlockService).apply {
                text = "Wapas jao"; isAllCaps = false; textSize = 14f
                setOnClickListener { leaveShorts() }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = px(8) })
            addView(pauseBtn)
        }
    }

    /** Clicks a YouTube button found by its label: [top] = in the top bar (Search), otherwise in the bottom tab bar (Home). */
    private fun clickYt(labels: List<String>, top: Boolean): Boolean {
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val root = w.root ?: continue
                if (root.packageName?.toString() != "com.google.android.youtube") continue
                val wr = Rect(); w.getBoundsInScreen(wr)
                fun inZone(r: Rect) = if (top) r.bottom < wr.top + wr.height() * 0.25 else r.top > wr.top + wr.height() * 0.7
                fun tap(nd: AccessibilityNodeInfo): Boolean {
                    var t: AccessibilityNodeInfo? = nd
                    while (t != null && !t.isClickable) t = t.parent
                    return t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                for (label in labels) {
                    for (nd in root.findAccessibilityNodeInfosByText(label)) {
                        if (nd.className?.toString() == "android.widget.EditText") continue
                        val r = Rect(); nd.getBoundsInScreen(r)
                        if (inZone(r) && tap(nd)) return true
                    }
                }
                if (top) { // fallback: any clickable view whose id says "search"
                    val stack = ArrayDeque<AccessibilityNodeInfo>(); stack.add(root)
                    var n = 0
                    while (stack.isNotEmpty() && n < 500) {
                        val x = stack.removeLast(); n++
                        val id = x.viewIdResourceName?.lowercase() ?: ""
                        if (id.contains("search") && x.isClickable && x.className?.toString() != "android.widget.EditText") {
                            val r = Rect(); x.getBoundsInScreen(r)
                            if (inZone(r) && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                        }
                        for (i in 0 until x.childCount) x.getChild(i)?.let { stack.add(it) }
                    }
                }
            }
        } catch (_: Throwable) {}
        return false
    }

    /** Gets out of Shorts INSIDE YouTube: taps the Home tab (the Back action would close the app when Shorts was opened first). */
    private fun leaveShorts() {
        if (clickYt(listOf("Home", "होम"), false)) { handler.postDelayed(evalRunnable, 400L); return }
        performGlobalAction(GLOBAL_ACTION_BACK) // Home tab not found
    }

    /** Height of the system navigation bar, so the overlay never covers the Back / Home buttons. */
    private fun navInset(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        val h = if (id > 0) resources.getDimensionPixelSize(id) else 0
        return if (h > 0) h else (24 * resources.displayMetrics.density).toInt()
    }

    private fun removeShield() {
        val v = shieldView ?: return
        shieldView = null; shieldKind = ""
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Throwable) {}
    }

    // ---------- bedtime dim ----------
    private var dimView: View? = null
    private fun updateDim() {
        val a = Bed.dimAlpha(this)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (a < 0.02f) { dimView?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; dimView = null; return }
        var v = dimView
        if (v == null) {
            v = View(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            dimView = v
        }
        v.setBackgroundColor(Color.argb((a * 255).toInt(), 12, 4, 0))
    }

    // ---------- daily usage (for "daily limit" rules) ----------
    private var fgPkg: String? = null
    private var fgSince = 0L

    private fun trackUsage(newPkg: String?) {
        val now = SystemClock.elapsedRealtime()
        val old = fgPkg
        if (old != null && fgSince > 0 && screenOn) {
            val d = (now - fgSince).coerceAtMost(30_000L)
            if (d > 0 && old in Blocker.limitPkgs(this)) Usage.add(this, old, d)
            if (d > 0) try { Report.addUse(this, old, d) } catch (_: Throwable) {}
        }
        fgPkg = if (screenOn) newPkg else null
        fgSince = now
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { "App" }

    // ---------- full-screen hold ----------
    private var holdCover: Cover? = null

    private fun showHold(left: Long) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        var c = holdCover
        if (c == null) {
            c = buildCover("hold", Hold.title(this).ifEmpty { "Screen block" }, "Screen is blocked right now")
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.OPAQUE)
            wm.addView(c.view, lp)
            holdCover = c
        }
        c.time.text = "${Blocker.format(left)} left"
        updateEm(c)
    }

    private fun removeHold() {
        val c = holdCover ?: return
        holdCover = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(c.view) } catch (_: Throwable) {}
    }

    // ---------- emergency (2 x 5 min, double tap) ----------
    private var armedKey = ""
    private var armedAt = 0L

    private fun updateEm(c: Cover) {
        val b = c.em ?: return
        val left = Emerg.left(this, c.key)
        val armed = armedKey == c.key && SystemClock.elapsedRealtime() - armedAt < 4000L
        if (left <= 0) { b.text = "Emergency used up (for today)"; b.isEnabled = false }
        else { b.isEnabled = true; b.text = if (armed) "Tap again: opens for ${Emerg.MINUTES} min" else "Emergency • ${Emerg.MINUTES} min ($left left)" }
        (b.tag as? Button)?.let { updateGp(it) }
    }

    // ---------- "Sab block hatao": every 2 hours, all blocks off for 5 minutes ----------
    private var gapArmedAt = -10_000L

    private fun updateGp(b: Button) {
        val ready = Gap.readyInMs(this)
        val armed = SystemClock.elapsedRealtime() - gapArmedAt < 4000L
        if (ready > 0) { b.text = "Remove all blocks: in ${Blocker.format(ready)}"; b.isEnabled = false }
        else { b.isEnabled = true; b.text = if (armed) "Tap again: all blocks removed for ${Gap.MINUTES} min" else "Remove all blocks • ${Gap.MINUTES} min (once every 2 hours)" }
    }

    private fun onGapTap() {
        val now = SystemClock.elapsedRealtime()
        if (now - gapArmedAt >= 4000L) {
            gapArmedAt = now
            (covers.values + listOfNotNull(holdCover)).forEach { updateEm(it) }
            return
        }
        gapArmedAt = -10_000L
        Friction.request(this, "gap", "")
        handler.removeCallbacks(evalRunnable); handler.post(evalRunnable)
    }

    private fun onEmTap(key: String) {
        val now = SystemClock.elapsedRealtime()
        if (armedKey != key || now - armedAt >= 4000L) {
            armedKey = key; armedAt = now
            (covers.values + listOfNotNull(holdCover)).filter { it.key == key }.forEach { updateEm(it) }
            return
        }
        armedKey = ""
        Friction.request(this, "em", key)
        handler.removeCallbacks(evalRunnable); handler.post(evalRunnable)
    }

    private fun buildCover(pkg: String, titleText: String = "${appLabel(pkg)} is blocked", sub: String = "You cannot use this app right now"): Cover {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(col); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        val why = tv(sub, 14f, 0xB3FFFFFF.toInt()).apply { setPadding(px(8), px(4), px(8), 0) }
        val time = tv("", 14f, 0xFFD4A857.toInt()).apply { setPadding(0, px(8), 0, px(28)) }
        val btn = Button(this).apply {
            text = "Home jao"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF062018.toInt())
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
            setPadding(px(40), px(10), px(40), px(10))
            setOnClickListener { performGlobalAction(GLOBAL_ACTION_HOME) }
        }
        val yt = pkg.contains("youtube") && !pkg.contains("music") && Cfg.str(this, "cls", "[]").length > 2
        val cls = Button(this).apply {
            text = "Class Player kholo"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF1F6F63.toInt()) }
            setPadding(px(32), px(10), px(32), px(10))
            setOnClickListener {
                try { startActivity(android.content.Intent(this@BlockService, ClassActivity::class.java).putExtra("i", -1).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
            }
        }
        val em = Button(this).apply {
            isAllCaps = false; textSize = 13f
            setOnClickListener { onEmTap(pkg) }
        }
        val gp = Button(this).apply {
            isAllCaps = false; textSize = 12f
            setOnClickListener { onGapTap() }
        }
        em.tag = gp
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            setPadding(px(24), px(24), px(24), px(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF06181B.toInt(), 0xFF0D2D30.toInt()))
            addView(tv("🔒", 48f, Color.WHITE))
            addView(tv(titleText, 22f, Color.WHITE, true).apply { setPadding(0, px(8), 0, 0) })
            addView(why)
            addView(time)
            if (pkg != "hold") addView(btn) // the full-screen hold has no Home button: it blocks everything
            if (yt) addView(cls, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
            addView(em, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(14) })
            addView(gp, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(6) })
        }
        return Cover(v, time, em, pkg, why)
    }

    private fun showOrUpdateCover(hit: Hit) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            hit.rect.width(), hit.rect.height(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = hit.rect.left
        lp.y = hit.rect.top
        val existing = covers[hit.id]
        val c: Cover
        if (existing == null) {
            c = buildCover(hit.pkg)
            wm.addView(c.view, lp)
            covers[hit.id] = c
            try { Report.addBlock(this, hit.pkg) } catch (_: Throwable) {}
        } else {
            c = existing
            wm.updateViewLayout(c.view, lp)
        }
        c.time.text = "${Blocker.format(hit.remMs)} left"
        c.why?.text = hit.why
        updateEm(c)
    }

    private fun removeCover(id: Int) {
        val c = covers.remove(id) ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(c.view) } catch (_: Throwable) {}
    }

    private fun removeAllCovers() { for (id in covers.keys.toList()) removeCover(id); removeHold(); removeShield() }

    override fun onInterrupt() {}
}
