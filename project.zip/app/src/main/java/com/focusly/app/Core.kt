package com.focusly.app

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Alarm(val id: Int, val hour: Int, val minute: Int, val days: Set<Int>, val label: String, val on: Boolean = true, val blk: Int = 0)
data class Reminder(val id: Int, val title: String, val at: Long, val daily: Boolean, val on: Boolean = true, val blk: Int = 0)
/** start/end = minutes of day (0..1440). days empty = every day */
data class Rule(val id: Int, val pkg: String, val name: String, val start: Int, val end: Int, val days: Set<Int>, val on: Boolean = true, val lim: Int = 0, val pls: List<PlaceRef> = emptyList(), val d1: Long = 0L, val d2: Long = 0L, val gaps: String = "")

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    private fun load(c: Context, k: String): List<JSONObject> {
        val a = JSONArray(sp(c).getString(k, "[]"))
        return (0 until a.length()).map { a.getJSONObject(it) }
    }
    private fun save(c: Context, k: String, l: List<JSONObject>) = sp(c).edit().putString(k, JSONArray(l).toString()).apply()
    private fun ds(s: String) = s.split(",").filter { it.isNotEmpty() }.map { it.toInt() }.toSet()

    fun alarms(c: Context) = load(c, "alarms").map { Alarm(it.getInt("id"), it.getInt("h"), it.getInt("m"), ds(it.getString("d")), it.getString("l"), it.getBoolean("on"), it.optInt("bk", 0)) }
    fun saveAlarms(c: Context, l: List<Alarm>) = save(c, "alarms", l.map { JSONObject().put("id", it.id).put("h", it.hour).put("m", it.minute).put("d", it.days.joinToString(",")).put("l", it.label).put("on", it.on).put("bk", it.blk) })

    fun reminders(c: Context) = load(c, "reminders").map { Reminder(it.getInt("id"), it.getString("t"), it.getLong("at"), it.getBoolean("daily"), it.getBoolean("on"), it.optInt("bk", 0)) }
    fun saveReminders(c: Context, l: List<Reminder>) = save(c, "reminders", l.map { JSONObject().put("id", it.id).put("t", it.title).put("at", it.at).put("daily", it.daily).put("on", it.on).put("bk", it.blk) })

    /** "12:u,15:b" (new) or a single legacy "pl" id (an Unblock place). */
    private fun plsOf(o: JSONObject): List<PlaceRef> {
        val s = o.optString("pls", "")
        if (s.isNotEmpty()) return s.split(",").mapNotNull { t ->
            val a = t.split(":")
            a[0].toIntOrNull()?.let { PlaceRef(it, a.getOrNull(1)?.firstOrNull() ?: 'r') }
        }
        val old = o.optInt("pl", 0)
        return if (old != 0) listOf(PlaceRef(old, 'r')) else emptyList()
    }

    fun rules(c: Context) = load(c, "rules").map { Rule(it.getInt("id"), it.getString("p"), it.getString("n"), it.getInt("s"), it.getInt("e"), ds(it.getString("d")), it.getBoolean("on"), it.optInt("lm", 0), plsOf(it), it.optLong("d1", 0L), it.optLong("d2", 0L), it.optString("gp", "")) }
    fun saveRules(c: Context, l: List<Rule>) = save(c, "rules", l.map { JSONObject().put("id", it.id).put("p", it.pkg).put("n", it.name).put("s", it.start).put("e", it.end).put("d", it.days.joinToString(",")).put("on", it.on).put("lm", it.lim).put("pls", it.pls.joinToString(",") { p -> "${p.id}:${p.m}" }).put("d1", it.d1).put("d2", it.d2).put("gp", it.gaps) })
}

object Sched {
    fun intent(c: Context, k: String, id: Int, act: String = "FIRE") =
        Intent(c, Rx::class.java).setAction(act).putExtra("k", k).putExtra("id", id)

    private fun pi(c: Context, k: String, id: Int) = PendingIntent.getBroadcast(
        c, if (k == "a") id else id + 500000, intent(c, k, id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun set(c: Context, k: String, id: Int, at: Long) {
        val p = pi(c, k, id)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(at, p), p)
    }

    fun cancel(c: Context, k: String, id: Int) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, k, id))

    fun next(a: Alarm): Long {
        val now = Calendar.getInstance()
        for (i in 0..7) {
            val t = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, i)
                set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (t.after(now) && (a.days.isEmpty() || t.get(Calendar.DAY_OF_WEEK) in a.days)) return t.timeInMillis
        }
        return 0
    }

    fun arm(c: Context, a: Alarm) { cancel(c, "a", a.id); if (a.on) set(c, "a", a.id, next(a)) }

    fun armAll(c: Context) {
        Store.alarms(c).forEach { arm(c, it) }
        val now = System.currentTimeMillis()
        Store.reminders(c).filter { it.on }.forEach {
            var t = it.at
            if (it.daily) while (t < now) t += 86400000L
            if (t > now) set(c, "r", it.id, t)
        }
        GoalSched.armAll(c)
    }
}

class Rx : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED || i.action == "android.intent.action.QUICKBOOT_POWERON") {
            Sched.armAll(c); if (Blocker.anyConfigured(c)) Blocker.tryEnableService(c); KeepService.start(c); return
        }
        KeepService.start(c) // every alarm / reminder wake-up also revives the keep-alive service
        val id = i.getIntExtra("id", 0)
        val k = i.getStringExtra("k") ?: "a"
        val nid = if (k == "a") id else id + 500000
        val nm = c.getSystemService(NotificationManager::class.java)
        if (i.action == "STOP") { nm.cancel(nid); return }
        if (i.action == "GDONE") { GoalSched.done(c, i); return }
        if (i.action == "SNOOZE") { nm.cancel(nid); Sched.set(c, k, id, System.currentTimeMillis() + 10 * 60000L); return }

        if (k == "g") { GoalSched.fire(c, i); return }
        val title: String; val text: String; var blk = 0
        if (k == "a") {
            val a = Store.alarms(c).find { it.id == id } ?: return
            title = "⏰ " + a.label.ifEmpty { "Alarm" }; text = "%02d:%02d".format(a.hour, a.minute); blk = a.blk
            if (a.days.isEmpty()) Store.saveAlarms(c, Store.alarms(c).map { if (it.id == id) it.copy(on = false) else it }) else Sched.arm(c, a)
        } else {
            val r = Store.reminders(c).find { it.id == id } ?: return
            title = "🔔 " + r.title; text = "Reminder"; blk = r.blk
            val n = if (r.daily) r.copy(at = r.at + 86400000L) else r.copy(on = false)
            Store.saveReminders(c, Store.reminders(c).map { if (it.id == id) n else it })
            if (r.daily) Sched.set(c, "r", id, n.at)
        }
        nm.createNotificationChannel(NotificationChannel("fx", "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            enableVibration(true)
        })
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val snooze = PendingIntent.getBroadcast(c, nid + 9000000, Sched.intent(c, k, id, "SNOOZE"), flags)
        val stop = PendingIntent.getBroadcast(c, nid + 18000000, Sched.intent(c, k, id, "STOP"), flags)
        val open = PendingIntent.getActivity(c, nid, Intent(c, MainActivity::class.java), flags)
        val n = NotificationCompat.Builder(c, "fx").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(text).setAutoCancel(true)
            .setContentIntent(open).setTimeoutAfter(5 * 60000L)
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(0, "Snooze 10 min", snooze).addAction(0, "Stop", stop).build()
        // alarms AND reminders keep ringing until stopped / snoozed
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(nid, n)
        if (blk > 0) Hold.start(c, title, blk)
    }
}
