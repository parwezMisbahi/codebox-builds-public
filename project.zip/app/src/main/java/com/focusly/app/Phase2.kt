package com.focusly.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar

/** Apps that "block everything" systems never touch (Phone Lock, "Saare apps" rules, screen block, goal "all apps" link). */
object Allow {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun get(c: Context): Set<String> = (sp(c).getString("allow", "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()
    fun set(c: Context, s: Set<String>) = sp(c).edit().putString("allow", s.joinToString(",")).apply()
}

object Lock {
    fun until(c: Context) = c.getSharedPreferences("focusly", 0).getLong("lock", 0)
    fun set(c: Context, t: Long) = c.getSharedPreferences("focusly", 0).edit().putLong("lock", t).apply()
    /** Optional place that ends the lock as soon as you reach it (0 = none). */
    fun place(c: Context) = c.getSharedPreferences("focusly", 0).getInt("lockPl", 0)
    fun setPlace(c: Context, id: Int) = c.getSharedPreferences("focusly", 0).edit().putInt("lockPl", id).apply()
    /** Places linked to the running lock: "id:m,id:m" (m = b block here / u unlock here / r unlock on reaching). Old single place = 'r'. */
    fun pls(c: Context): List<PlaceRef> {
        val sp = c.getSharedPreferences("focusly", 0)
        val s = sp.getString("lockPls", "") ?: ""
        if (s.isNotEmpty()) return s.split(",").mapNotNull { t ->
            val a = t.split(":"); a[0].toIntOrNull()?.let { PlaceRef(it, a.getOrNull(1)?.firstOrNull() ?: 'r') }
        }
        val old = sp.getInt("lockPl", 0)
        return if (old != 0) listOf(PlaceRef(old, 'r')) else emptyList()
    }
    fun setPls(c: Context, l: List<PlaceRef>) = c.getSharedPreferences("focusly", 0).edit()
        .putString("lockPls", l.joinToString(",") { "${it.id}:${it.m}" }).putInt("lockPl", 0).apply()
}

/** Full-screen block for a fixed time (started by an alarm / reminder / goal reminder that has "screen block" on). */
object Hold {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun left(c: Context): Long = (sp(c).getLong("hold", 0) - System.currentTimeMillis()).coerceAtLeast(0)
    fun title(c: Context): String = sp(c).getString("holdT", "") ?: ""
    fun start(c: Context, title: String, minutes: Int) {
        val m = minutes.coerceIn(1, 180)
        val end = System.currentTimeMillis() + m * 60_000L
        if (end > sp(c).getLong("hold", 0)) sp(c).edit().putLong("hold", end).putString("holdT", title).apply()
        BlockService.poke()
    }
}

/**
 * Emergency use: fixed 2 passes per day, 5 minutes each. The counter is kept per key (an app's package,
 * or "hold" for the full-screen block) and is NOT reset by deleting / re-creating a rule.
 */
object Emerg {
    const val MINUTES = 5
    const val PER_DAY = 2
    private fun sp(c: Context) = c.getSharedPreferences("focusly_em", 0)
    private fun day() = LocalDate.now().toEpochDay()
    private fun obj(c: Context, k: String): JSONObject {
        val o = try { JSONObject(sp(c).getString(k, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        if (o.optLong("d", -1) != day()) return JSONObject().put("d", day()).put("u", 0).put("p", o.optLong("p", 0))
        return o
    }
    fun left(c: Context, k: String) = (PER_DAY - obj(c, k).optInt("u", 0)).coerceAtLeast(0)
    fun active(c: Context, k: String) = obj(c, k).optLong("p", 0) > System.currentTimeMillis()
    fun anyActive(c: Context): Boolean = sp(c).all.keys.any { active(c, it) }
    @Synchronized fun use(c: Context, k: String): Boolean {
        val o = obj(c, k)
        if (o.optLong("p", 0) > System.currentTimeMillis() || o.optInt("u", 0) >= PER_DAY) return false
        o.put("u", o.optInt("u", 0) + 1).put("p", System.currentTimeMillis() + MINUTES * 60_000L)
        sp(c).edit().putString(k, o.toString()).apply()
        return true
    }
}

/**
 * Alarms / reminders / timers that are ringing right now (notification ids, newest time). The block screens show a
 * "Stop alarm" button while this is not empty, so a ringing alarm can always be stopped even during a block.
 */
object Ring {
    private const val TTL = 5 * 60_000L // same as the notification timeout
    private fun sp(c: Context) = c.getSharedPreferences("focusly_ring", 0)
    private fun load(c: Context): JSONObject {
        val o = try { JSONObject(sp(c).getString("r", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val now = System.currentTimeMillis()
        for (k in o.keys().asSequence().toList()) if (now - o.optLong(k, 0L) > TTL) o.remove(k)
        return o
    }
    @Synchronized fun add(c: Context, nid: Int) { val o = load(c); o.put(nid.toString(), System.currentTimeMillis()); sp(c).edit().putString("r", o.toString()).apply() }
    @Synchronized fun remove(c: Context, nid: Int) { val o = load(c); o.remove(nid.toString()); sp(c).edit().putString("r", o.toString()).apply() }
    fun active(c: Context): Boolean = try { load(c).length() > 0 } catch (_: Throwable) { false }
    /** Stops sound + vibration of everything that is ringing (the notifications are cancelled). */
    @Synchronized fun stopAll(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val o = load(c)
        for (k in o.keys().asSequence().toList()) k.toIntOrNull()?.let { nm.cancel(it) }
        sp(c).edit().putString("r", "{}").apply()
    }
}

/**
 * Timer / countdown alarms made in the Time tab. Stored as [{id, at, label}] so they survive reboot.
 * The tab itself (stopwatch, timer display, countdown list) lives in index.html; this only rings at [at].
 */
object Tm {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_tm", 0)
    private fun load(c: Context): MutableList<Triple<Int, Long, String>> {
        val a = try { JSONArray(sp(c).getString("l", "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.getInt("id"), o.getLong("at"), o.optString("n", "")) }.toMutableList()
    }
    private fun save(c: Context, l: List<Triple<Int, Long, String>>) =
        sp(c).edit().putString("l", JSONArray(l.map { JSONObject().put("id", it.first).put("at", it.second).put("n", it.third) }).toString()).apply()

    @Synchronized fun set(c: Context, id: Int, at: Long, label: String) {
        val l = load(c); l.removeAll { it.first == id }; l.add(Triple(id, at, label.take(40))); save(c, l)
        if (at > System.currentTimeMillis()) Sched.set(c, "t", id, at)
    }
    @Synchronized fun cancel(c: Context, id: Int) {
        val l = load(c); l.removeAll { it.first == id }; save(c, l)
        Sched.cancel(c, "t", id)
    }
    /** After reboot / app update: schedule everything that is still in the future. */
    @Synchronized fun armAll(c: Context) {
        val now = System.currentTimeMillis()
        val l = load(c).filter { it.second > now }; save(c, l)
        l.forEach { Sched.set(c, "t", it.first, it.second) }
    }
    /** The soonest timer / countdown (label, time) or null. */
    fun next(c: Context): Pair<String, Long>? {
        val now = System.currentTimeMillis()
        return load(c).filter { it.second > now }.minByOrNull { it.second }?.let { Pair(it.third, it.second) }
    }

    @Synchronized fun fire(c: Context, id: Int) {
        val l = load(c); val e = l.find { it.first == id } ?: return
        l.remove(e); save(c, l)
        val nid = id + 500000
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fx", "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build())
            enableVibration(true)
        })
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val stop = PendingIntent.getBroadcast(c, nid + 18000000, Sched.intent(c, "t", id, "STOP"), flags)
        val open = PendingIntent.getActivity(c, nid, Intent(c, MainActivity::class.java), flags)
        val n = NotificationCompat.Builder(c, "fx").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("\u23F1 " + e.third.ifEmpty { "Timer" }).setContentText("Time is up").setAutoCancel(true)
            .setContentIntent(open).setTimeoutAfter(5 * 60000L)
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(0, "Stop", stop).build()
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(nid, n)
        Ring.add(c, nid)
    }
}

/** Foreground time per app per day (counted by the accessibility service, no extra permission). */
object Usage {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_usage", 0)
    private fun day() = LocalDate.now().toEpochDay()
    private fun obj(c: Context): JSONObject {
        val o = try { JSONObject(sp(c).getString("u", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        return if (o.optLong("_d", -1) == day()) o else JSONObject().put("_d", day())
    }
    fun get(c: Context, pkg: String): Long = obj(c).optLong(pkg, 0)
    @Synchronized fun add(c: Context, pkg: String, ms: Long) {
        val o = obj(c)
        o.put(pkg, o.optLong(pkg, 0) + ms)
        sp(c).edit().putString("u", o.toString()).apply()
    }
}
