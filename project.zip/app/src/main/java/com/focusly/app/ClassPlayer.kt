package com.focusly.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Class Player: plays ONLY a saved YouTube playlist through the YouTube embed player.
 * No home feed, no recommendations, no Shorts, no search: every navigation out of the player is blocked,
 * and the page (assets/class.html) pushes the player back if a suggested video is tapped.
 * Playlists are stored as JSON [{n:name,id:playlistId}] in Cfg "cls" (edited from Settings > Class Player).
 */
class ClassActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        try { window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK } catch (_: Throwable) {}
        val sel = intent?.getIntExtra("i", -1) ?: -1
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                setSupportMultipleWindows(false)
                setSupportZoom(false)
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                // The page itself never navigates: any main-frame navigation (logo, "Watch on YouTube", ad click) is blocked.
                override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                    if (r == null) return true
                    if (r.isForMainFrame) return true
                    val h = r.url.host ?: return true
                    return !(h.endsWith("youtube.com") || h.endsWith("youtube-nocookie.com") || h.endsWith("google.com") || h.endsWith("gstatic.com"))
                }
            }
            addJavascriptInterface(CB(sel), "CN")
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = ins.getInsets(android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
                android.view.WindowInsets.CONSUMED
            } else ins
        }
        setContentView(root)
        val html = assets.open("class.html").bufferedReader().use { it.readText() }
        // https base URL: the YouTube embed refuses to play without a proper origin/referrer
        web.loadDataWithBaseURL("https://www.youtube-nocookie.com/", html, "text/html", "utf-8", null)
    }

    inner class CB(private val idx: Int) {
        @JavascriptInterface fun list(): String = Cfg.str(applicationContext, "cls", "[]")
        @JavascriptInterface fun sel(): Int = idx
        @JavascriptInterface fun close() { runOnUiThread { finish() } }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
