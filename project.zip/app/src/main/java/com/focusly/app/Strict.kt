package com.focusly.app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** Device Admin receiver: while Focusly is an active device admin, Android refuses to uninstall it. */
class AdminRx : DeviceAdminReceiver()

/**
 * Strict mode = uninstall protection (Device Admin) + settings guard (BlockService sends the person Home when a
 * Settings / uninstall / accessibility / device-admin page that shows "Focusly" is opened).
 * Once started for a fixed time it can NOT be turned off or shortened until that time ends (it can only be extended).
 * Cfg: strict_until (epoch ms, 0 = off).
 */
object Strict {
    private fun cn(c: Context) = ComponentName(c, AdminRx::class.java)
    private fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun until(c: Context) = Cfg.long(c, "strict_until", 0L)
    fun admin(c: Context) = try { dpm(c).isAdminActive(cn(c)) } catch (_: Throwable) { false }

    /** True while the lock runs. When the time is over this switches strict mode off and releases the device admin. */
    fun active(c: Context): Boolean {
        val u = until(c)
        if (u <= 0L) return false
        if (System.currentTimeMillis() < u) return true
        Cfg.put(c, "strict_until", 0L)
        try { if (admin(c)) dpm(c).removeActiveAdmin(cn(c)) } catch (_: Throwable) {}
        return false
    }

    fun leftMin(c: Context): Int = if (!active(c)) 0 else ((until(c) - System.currentTimeMillis() + 59_999L) / 60_000L).toInt().coerceAtLeast(1)

    /** Intent that asks the person to activate Focusly as device admin (null if already active). */
    fun adminIntent(c: Context): Intent? {
        if (admin(c)) return null
        return Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn(c))
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Strict mode: Focusly cannot be uninstalled until the time you set is over.")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Starts (or extends) strict mode for [min] minutes from now. Returns false if that would shorten a running lock. */
    fun start(c: Context, min: Int): Boolean {
        val end = System.currentTimeMillis() + min.coerceAtLeast(1) * 60_000L
        if (active(c) && end <= until(c)) return false
        Cfg.put(c, "strict_until", end)
        return true
    }

    /** Pages (by package) that can reach Focusly's uninstall / accessibility / device-admin / app-info screens. */
    val GUARD = setOf(
        "com.android.settings", "com.android.settings.intelligence", "com.miui.securitycenter", "com.miui.packageinstaller",
        "com.android.packageinstaller", "com.google.android.packageinstaller", "com.samsung.android.packageinstaller",
        "com.google.android.permissioncontroller", "com.android.permissioncontroller", "com.coloros.safecenter",
        "com.oplus.battery", "com.samsung.android.settings", "com.huawei.systemmanager")
}
