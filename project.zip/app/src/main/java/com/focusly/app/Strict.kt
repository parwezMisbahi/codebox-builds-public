package com.focusly.app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** Device Admin receiver: while Focusly is an active device admin, Android refuses to uninstall it. */
class AdminRx : DeviceAdminReceiver()

/**
 * Strict mode is AUTOMATIC (no separate time to set): it is ON exactly as long as any block is running
 * (app rule, Phone lock / Focus, hold, bedtime ...). While ON: Focusly cannot be uninstalled (Device Admin, activated once from
 * Settings > Setup) and BlockService sends the person Home when a Settings / uninstall / accessibility / device-admin page that
 * shows "Focusly" is opened. When the last block ends, strict mode ends with it.
 */
object Strict {
    private fun cn(c: Context) = ComponentName(c, AdminRx::class.java)
    private fun dpm(c: Context) = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun admin(c: Context) = try { dpm(c).isAdminActive(cn(c)) } catch (_: Throwable) { false }

    fun active(c: Context): Boolean = try { Blocker.anyActive(c) } catch (_: Throwable) { false }

    /** Longest remaining time (ms) among the running blocks. */
    fun leftMs(c: Context): Long {
        var m = 0L
        val now = System.currentTimeMillis()
        try { m = maxOf(m, Hold.left(c)) } catch (_: Throwable) {}
        try { m = maxOf(m, Lock.until(c) - now) } catch (_: Throwable) {}
        try { m = maxOf(m, Pomo.focusLeft(c)) } catch (_: Throwable) {}
        try { Store.rules(c).filter { ruleBlocking(it, c) }.forEach { m = maxOf(m, ruleLeftPublic(it)) } } catch (_: Throwable) {}
        return m.coerceAtLeast(0L)
    }

    fun leftMin(c: Context): Int = if (!active(c)) 0 else ((leftMs(c) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)

    /** Intent that asks the person to activate Focusly as device admin (null if already active). */
    fun adminIntent(c: Context): Intent? {
        if (admin(c)) return null
        return Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn(c))
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Focusly cannot be uninstalled while a block is running.")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Pages (by package) that can reach Focusly's uninstall / accessibility / device-admin / app-info screens. */
    val GUARD = setOf(
        "com.android.settings", "com.android.settings.intelligence", "com.miui.securitycenter", "com.miui.packageinstaller",
        "com.android.packageinstaller", "com.google.android.packageinstaller", "com.samsung.android.packageinstaller",
        "com.google.android.permissioncontroller", "com.android.permissioncontroller", "com.coloros.safecenter",
        "com.oplus.battery", "com.samsung.android.settings", "com.huawei.systemmanager")
}
