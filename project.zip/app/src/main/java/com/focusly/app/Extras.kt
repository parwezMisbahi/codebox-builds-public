package com.focusly.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.SystemClock
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.util.Calendar

/** Small on/off + number settings shared by the new features. */
object Cfg {
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun str(c: Context, k: String, d: String = "") = sp(c).getString(k, d) ?: d
    fun long(c: Context, k: String, d: Long = 0L) = sp(c).getLong(k, d)
    fun put(c: Context, k: String, v: Any) {
        val e = sp(c).edit()
        when (v) { is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v); is Long -> e.putLong(k, v); else -> e.putString(k, v.toString()) }
        e.apply()
    }
}

private fun today() = LocalDate.now().toEpochDay()

private fun labelOf(c: Context, pkg: String): String = try {
    c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
} catch (_: Throwable) { pkg }

/** Per-app screen time and "block ne roka" counts for the last 3 weeks (report + weekly summary). */
object Report {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_report", 0)
    private var skip: Set<String> = emptySet()
    private var skipAt = 0L
    private fun skipSet(c: Context): Set<String> {
        val n = SystemClock.elapsedRealtime()
        if (skip.isEmpty() || n - skipAt > 300_000L) { skip = try { Blocker.protectedPackages(c) } catch (_: Throwable) { emptySet() }; skipAt = n }
        return skip
    }
    private fun load(c: Context, k: String): JSONObject = try { JSONObject(sp(c).getString(k, "{}") ?: "{}") } catch (_: Throwable) { JSONObject() }

    @Synchronized private fun add(c: Context, k: String, pkg: String, v: Long) {
        val o = load(c, k)
        val d = today().toString()
        val dd = o.optJSONObject(d) ?: JSONObject().also { o.put(d, it) }
        dd.put(pkg, dd.optLong(pkg, 0L) + v)
        for (key in o.keys().asSequence().toList()) if ((key.toLongOrNull() ?: 0L) < today() - 20) o.remove(key)
        sp(c).edit().putString(k, o.toString()).apply()
    }

    fun addUse(c: Context, pkg: String, ms: Long) {
        if (ms <= 0L || pkg in skipSet(c)) return
        add(c, "use", pkg, ms)
    }
    fun addBlock(c: Context, pkg: String) = add(c, "blk", pkg, 1L)

    /** {days:[{d,ms,blk}], top:[{p,n,ms}], total, blocks, blkTop:[{p,n,c}]} for the last 7 days (today last). */
    fun week(c: Context): JSONObject {
        val use = load(c, "use"); val blk = load(c, "blk"); val t = today()
        val days = JSONArray(); val tot = HashMap<String, Long>(); val bt = HashMap<String, Long>()
        var total = 0L; var blocks = 0L
        for (i in 6 downTo 0) {
            val d = (t - i).toString()
            val u = use.optJSONObject(d); val b = blk.optJSONObject(d)
            var ms = 0L; var n = 0L
            if (u != null) for (k in u.keys()) { val v = u.optLong(k, 0L); ms += v; tot[k] = (tot[k] ?: 0L) + v }
            if (b != null) for (k in b.keys()) { val v = b.optLong(k, 0L); n += v; bt[k] = (bt[k] ?: 0L) + v }
            days.put(JSONObject().put("d", t - i).put("ms", ms).put("blk", n))
            total += ms; blocks += n
        }
        val top = JSONArray()
        tot.entries.sortedByDescending { it.value }.take(8).forEach { top.put(JSONObject().put("p", it.key).put("n", labelOf(c, it.key)).put("ms", it.value)) }
        val bTop = JSONArray()
        bt.entries.sortedByDescending { it.value }.take(5).forEach { bTop.put(JSONObject().put("p", it.key).put("n", labelOf(c, it.key)).put("c", it.value)) }
        return JSONObject().put("days", days).put("top", top).put("total", total).put("blocks", blocks).put("blkTop", bTop)
    }
}

/** How long you stayed at each saved place, per day. */
object PlaceLog {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_log", 0)
    fun logOn(c: Context) = Cfg.bool(c, "plog_on", true)
    private var lastAt = 0L

    private fun load(c: Context): JSONObject = try { JSONObject(sp(c).getString("l", "{}") ?: "{}") } catch (_: Throwable) { JSONObject() }

    @Synchronized private fun add(c: Context, id: Int, sec: Long) {
        val o = load(c)
        val d = today().toString()
        val dd = o.optJSONObject(d) ?: JSONObject().also { o.put(d, it) }
        dd.put(id.toString(), dd.optLong(id.toString(), 0L) + sec)
        for (key in o.keys().asSequence().toList()) if ((key.toLongOrNull() ?: 0L) < today() - 40) o.remove(key)
        sp(c).edit().putString("l", o.toString()).apply()
    }

    /** Called with every location fix that Presence receives. */
    fun onFix(c: Context, loc: Location) {
        val places = Places.all(c)
        if (places.isEmpty()) return
        val now = System.currentTimeMillis()
        val res = FloatArray(1)
        val acc = minOf(loc.accuracy, 30f)
        var best: Place? = null; var bd = Float.MAX_VALUE
        for (p in places) {
            Location.distanceBetween(loc.latitude, loc.longitude, p.lat, p.lng, res)
            val inn = res[0] <= p.r + acc + minOf(p.a.toFloat(), 30f)
            if (inn && res[0] < bd) { best = p; bd = res[0] }
            if (inn && p.by >= 0) Late.arrived(c, p.id)
        }
        if (!logOn(c)) return
        val dt = if (lastAt == 0L) 0L else now - lastAt
        lastAt = now
        val fresh = now - loc.time < 120_000L
        if (best != null && fresh && dt in 1L..150_000L) add(c, best.id, dt / 1000L)
    }

    /** {day:{placeId:seconds}} for the last 7 days. */
    fun week(c: Context): JSONObject {
        val o = load(c); val out = JSONObject(); val t = today()
        for (i in 0..6) { val d = (t - i).toString(); o.optJSONObject(d)?.let { out.put(d, it) } }
        return out
    }

    fun weekTotals(c: Context): Map<Int, Long> {
        val w = week(c); val m = HashMap<Int, Long>()
        for (d in w.keys()) { val dd = w.getJSONObject(d); for (k in dd.keys()) m[k.toInt()] = (m[k.toInt()] ?: 0L) + dd.optLong(k, 0L) }
        return m
    }
}

/** "Class par 8:00 tak pahuncho" - if you are not there by then you get a notification. */
object Late {
    private fun sp(c: Context) = c.getSharedPreferences("focusly_late", 0)
    fun arrived(c: Context, id: Int) { if (sp(c).getLong("ok$id", 0L) != today()) sp(c).edit().putLong("ok$id", today()).apply() }

    private fun dayOk(p: Place): Boolean {
        if (p.bd.isEmpty()) return true
        val d = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        return p.bd.split(",").mapNotNull { it.toIntOrNull() }.contains(d)
    }
    private fun nowMin(): Int { val c = Calendar.getInstance(); return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE) }

    /** true while a check is pending (a bit before the time until 2 h after): keeps the location watcher running. */
    fun wanted(c: Context): Boolean {
        val n = nowMin()
        return Places.all(c).any { p ->
            p.by >= 0 && dayOk(p) && n >= p.by - 20 && n < p.by + 120 &&
                sp(c).getLong("ok${p.id}", 0L) != today() && sp(c).getLong("nt${p.id}", 0L) != today()
        }
    }

    fun tick(c: Context) {
        val n = nowMin()
        for (p in Places.all(c)) {
            if (p.by < 0 || !dayOk(p) || n < p.by || n >= p.by + 120) continue
            if (sp(c).getLong("ok${p.id}", 0L) == today() || sp(c).getLong("nt${p.id}", 0L) == today()) continue
            if (Presence.lastFixAgeMs() > 240_000L) continue // no fresh location: do not guess
            sp(c).edit().putLong("nt${p.id}", today()).apply()
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fl", "Place alerts", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(c, 41, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(41000 + p.id, NotificationCompat.Builder(c, "fl").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Not yet arrived at ${p.name}")
                .setContentText("%02d:%02d was the arrival deadline.".format(p.by / 60, p.by % 60))
                .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build())
        }
    }
}

/** Bedtime: from the start time the phone dims slowly and every app except calls/clock/home is blocked until morning. */
object Bed {
    val EXEMPT = setOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage", "com.oneplus.deskclock",
        "com.coloros.alarmclock", "com.heytap.alarmclock", "com.miui.clock", "com.huawei.deskclock")
    const val MAX_DIM = 0.55f
    fun on(c: Context) = Cfg.bool(c, "bed_on", false)
    fun s(c: Context) = Cfg.int(c, "bed_s", 1380)
    fun e(c: Context) = Cfg.int(c, "bed_e", 360)
    fun dim(c: Context) = Cfg.bool(c, "bed_dim", true)
    fun days(c: Context): Set<Int> = Cfg.str(c, "bed_d").split(",").mapNotNull { it.toIntOrNull() }.toSet()
    fun set(c: Context, on: Boolean, s: Int, e: Int, days: String, dim: Boolean) {
        Cfg.setBool(c, "bed_on", on); Cfg.put(c, "bed_s", s.coerceIn(0, 1439)); Cfg.put(c, "bed_e", e.coerceIn(0, 1439))
        Cfg.put(c, "bed_d", days); Cfg.setBool(c, "bed_dim", dim)
    }
    private fun prev(d: Int) = if (d == 1) 7 else d - 1

    fun active(c: Context): Boolean {
        if (!on(c)) return false
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = s(c); val e = e(c)
        if (s == e) return false
        val inWin = if (s < e) now in s until e else now >= s || now < e
        if (!inWin) return false
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val startDow = if (s > e && now < e) prev(dow) else dow
        val d = days(c)
        return d.isEmpty() || startDow in d
    }

    /** Milliseconds until morning while bedtime is running, else 0. */
    fun leftMs(c: Context): Long {
        if (!active(c)) return 0L
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val e = e(c)
        val m = if (e > now) e - now else e + 1440 - now
        return (m * 60_000L - cal.get(Calendar.SECOND) * 1000L).coerceAtLeast(1000L)
    }

    fun endText(c: Context) = "%02d:%02d".format(e(c) / 60, e(c) % 60)

    /** 0 .. MAX_DIM: grows during the 30 minutes before bedtime, stays at MAX_DIM until morning. */
    fun dimAlpha(c: Context): Float {
        if (!on(c) || !dim(c)) return 0f
        if (active(c)) return MAX_DIM
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val toStart = (s(c) - now + 1440) % 1440
        if (toStart > 30 || toStart == 0) return 0f
        val d = days(c)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val startDow = if (s(c) < now) (dow % 7) + 1 else dow
        if (d.isNotEmpty() && startDow !in d) return 0f
        return MAX_DIM * (1f - toStart / 30f)
    }
}

/** Sunday-evening summary notification. */
object Weekly {
    private fun lastSunday(): Long { val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK); return today() - (dow - 1) }

    fun tick(c: Context) {
        if (!Cfg.bool(c, "wk_on", true)) return
        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val sun = dow == Calendar.SUNDAY && cal.get(Calendar.HOUR_OF_DAY) >= 20
        if (!sun && dow != Calendar.MONDAY) return
        val key = lastSunday()
        if (Cfg.long(c, "wk_sent") >= key) return
        val r = Report.week(c)
        val total = r.optLong("total")
        if (total <= 0L) return
        Cfg.put(c, "wk_sent", key)
        fun hm(ms: Long): String { val m = ms / 60_000L; return if (m >= 60) "${m / 60} hour ${m % 60} min" else "$m min" }
        val sb = StringBuilder()
        sb.append("Screen time: ").append(hm(total)).append(" (daily ~").append(hm(total / 7)).append(")\n")
        val top = r.optJSONArray("top")
        if (top != null && top.length() > 0) {
            sb.append("Top apps: ")
            sb.append((0 until minOf(3, top.length())).joinToString(", ") { top.getJSONObject(it).getString("n") + " " + hm(top.getJSONObject(it).getLong("ms")) }).append('\n')
        }
        val blocks = r.optLong("blocks")
        if (blocks > 0) sb.append("Blocks stopped you ").append(blocks).append(" times\n")
        val pt = PlaceLog.weekTotals(c).entries.sortedByDescending { it.value }.take(2)
        if (pt.isNotEmpty()) sb.append("Places: ").append(pt.joinToString(", ") { (Places.get(c, it.key)?.name ?: "?") + " " + hm(it.value * 1000L) }).append('\n')
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fw", "Weekly summary", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 42, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        nm.notify(42000, NotificationCompat.Builder(c, "fw").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Focusly: your weekly summary").setContentText(sb.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString().trim())).setContentIntent(open).setAutoCancel(true).build())
    }
}

/** Home screen widget: next alarm, next timer / countdown, block status. */
class InfoWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { for (id in ids) m.updateAppWidget(id, views(c)) }

    companion object {
        private var lastRefresh = 0L
        fun views(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_info)
            var nextT = Long.MAX_VALUE; var nextL = ""
            try {
                for (a in Store.alarms(c).filter { it.on }) { val t = Sched.next(a); if (t in 1 until nextT) { nextT = t; nextL = a.label } }
            } catch (_: Throwable) {}
            val alarmTxt = if (nextT == Long.MAX_VALUE) "No alarm" else {
                val cal = Calendar.getInstance().apply { timeInMillis = nextT }
                val sameDay = cal.get(Calendar.DAY_OF_YEAR) == Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
                "Alarm %02d:%02d %s%s".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), if (sameDay) "today" else "tomorrow+", if (nextL.isNotEmpty()) " • $nextL" else "")
            }
            val tm = try { Tm.next(c) } catch (_: Throwable) { null }
            val goalTxt = if (tm == null) "No timer / countdown" else {
                val mins = ((tm.second - System.currentTimeMillis()) / 60000L).coerceAtLeast(0)
                (if (tm.first.isNotEmpty()) tm.first + ": " else "") + (if (mins >= 1440) "${mins / 1440}d ${(mins % 1440) / 60}h" else if (mins >= 60) "${mins / 60}h ${mins % 60}m" else "${mins}m") + " left"
            }
            val blk = try { if (Bed.active(c)) "Bedtime is on" else if (Blocker.anyActive(c)) "A block is on" else "No block" } catch (_: Throwable) { "" }
            v.setTextViewText(R.id.iAlarm, alarmTxt); v.setTextViewText(R.id.iGoals, goalTxt); v.setTextViewText(R.id.iBlock, blk)
            v.setOnClickPendingIntent(R.id.iRoot, PendingIntent.getActivity(c, 43, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            return v
        }

        fun refresh(c: Context, force: Boolean = false) {
            val n = SystemClock.elapsedRealtime()
            if (!force && n - lastRefresh < 60_000L) return
            lastRefresh = n
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, InfoWidget::class.java))
                if (ids.isNotEmpty()) m.updateAppWidget(ids, views(c))
            } catch (_: Throwable) {}
        }
    }
}
