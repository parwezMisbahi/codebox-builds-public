package com.focusly.app

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.text.InputType
import android.view.ActionMode
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat

/**
 * Pomodoro / focus timer: [n] rounds of [f] minutes focus (ALL apps blocked, except the "Kabhi block nahi" apps,
 * Phone, Home and Focusly) with [b] minutes break in between. Pure clock maths from the start time, so nothing
 * has to survive in memory. A running focus phase can not be stopped (same idea as Phone Lock); a break can.
 */
object Pomo {
    class St(val running: Boolean, val focus: Boolean, val leftMs: Long, val round: Int, val rounds: Int, val f: Int, val b: Int)

    private fun sp(c: Context) = c.getSharedPreferences("focusly_pomo", 0)

    fun quickMin(c: Context) = c.getSharedPreferences("focusly", 0).getInt("qf", 25)
    fun setQuickMin(c: Context, m: Int) = c.getSharedPreferences("focusly", 0).edit().putInt("qf", m.coerceIn(1, 180)).apply()

    fun st(c: Context): St {
        val p = sp(c)
        val start = p.getLong("start", 0L)
        val f = p.getInt("f", 25); val b = p.getInt("b", 5); val n = p.getInt("n", 4)
        if (start == 0L) return St(false, false, 0L, 0, n, f, b)
        val fm = f * 60_000L; val bm = b * 60_000L
        val cycle = fm + bm
        val total = n * fm + (n - 1) * bm
        val el = System.currentTimeMillis() - start
        if (el < 0 || el >= total) return St(false, false, 0L, 0, n, f, b)
        val r = minOf((el / cycle).toInt(), n - 1)
        val within = el - r * cycle
        return if (within < fm) St(true, true, fm - within, r + 1, n, f, b)
        else St(true, false, cycle - within, r + 1, n, f, b)
    }

    fun running(c: Context) = st(c).running
    fun focusLeft(c: Context): Long = st(c).let { if (it.running && it.focus) it.leftMs else 0L }

    fun start(c: Context, f: Int, b: Int, n: Int): Boolean {
        if (running(c)) return false
        sp(c).edit().putLong("start", System.currentTimeMillis()).putInt("f", f.coerceIn(1, 180)).putInt("b", b.coerceIn(0, 60))
            .putInt("n", n.coerceIn(1, 12)).putString("pk", "1:f").putLong("wAt", 0L).apply()
        KeepService.start(c)
        BlockService.poke()
        FocusWidget.refresh(c)
        return true
    }

    /** One quick focus (tile / widget): [quickMin] minutes, one round, no break. */
    fun quick(c: Context) = start(c, quickMin(c), 0, 1)

    /** Stops the session. Not possible while a focus phase is running. */
    fun stop(c: Context): Boolean {
        if (focusLeft(c) > 0) return false
        sp(c).edit().putLong("start", 0L).apply()
        BlockService.poke()
        FocusWidget.refresh(c)
        return true
    }

    /** Called every few seconds by KeepService: phase-change notifications, re-check of the blocker, widget refresh. */
    fun tick(c: Context) {
        val p = sp(c)
        if (p.getLong("start", 0L) == 0L) return
        val s = st(c)
        val key = if (s.running) "${s.round}:${if (s.focus) "f" else "b"}" else "done"
        if (key != p.getString("pk", "")) {
            p.edit().putString("pk", key).apply()
            val msg = when {
                !s.running -> "Focus timer finished. Well done!"
                s.focus -> "Focus started (round ${s.round}/${s.rounds}) - ${s.f} min"
                else -> "Break started - ${s.b} min. You can use your phone."
            }
            notify(c, msg)
            BlockService.poke()
            FocusWidget.refresh(c)
            if (!s.running) p.edit().putLong("start", 0L).apply()
        } else if (System.currentTimeMillis() - p.getLong("wAt", 0L) > 30_000L) {
            p.edit().putLong("wAt", System.currentTimeMillis()).apply()
            FocusWidget.refresh(c)
        }
    }

    private fun notify(c: Context, text: String) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fp", "Focus timer", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(c, 41, Intent(c, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(4141, NotificationCompat.Builder(c, "fp").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Focusly Focus").setContentText(text).setContentIntent(open).setAutoCancel(true).build())
        } catch (_: Throwable) {}
    }
}

/**
 * Friction before an unblock (Emergency): a waiting time. It can be loosened only while no block is running.
 */
object Friction {
    const val NOTE_ID = 4343
    private fun sp(c: Context) = c.getSharedPreferences("focusly", 0)
    private fun rp(c: Context) = c.getSharedPreferences("focusly_fr", 0)
    fun wait(c: Context) = sp(c).getInt("frWait", 2)
    fun set(c: Context, waitMin: Int) = sp(c).edit().putInt("frWait", waitMin.coerceIn(0, 30)).apply()

    /** Starts (or continues) the unblock request; the waiting time keeps running while the screen is closed. */
    fun begin(c: Context, kind: String, key: String) {
        val rk = "$kind:$key"
        val at = rp(c).getLong("at", 0L)
        val stale = at == 0L || System.currentTimeMillis() - at > (wait(c) + 10) * 60_000L
        if (rp(c).getString("rk", "") != rk || stale) rp(c).edit().putString("rk", rk).putLong("at", System.currentTimeMillis()).apply()
    }
    fun readyIn(c: Context): Long = (rp(c).getLong("at", 0L) + wait(c) * 60_000L - System.currentTimeMillis()).coerceAtLeast(0L)
    fun clear(c: Context) = rp(c).edit().putLong("at", 0L).putString("rk", "").apply()

    /** true = the unblock was done right away (no friction set); false = the challenge screen was opened. */
    fun request(c: Context, kind: String, key: String): Boolean {
        if (wait(c) == 0) {
            Emerg.use(c, key)
            return true
        }
        val i = Intent(c, ChallengeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("k", kind).putExtra("key", key)
        try { c.startActivity(i) } catch (_: Throwable) {}
        // fallback if Android refuses to open the screen from the background: tap the notification
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fr", "Unblock request", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 43, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify(NOTE_ID, NotificationCompat.Builder(c, "fr").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Unblock request").setContentText("Tap to continue")
                .setContentIntent(pi).setAutoCancel(true).setTimeoutAfter(120_000L).build())
        } catch (_: Throwable) {}
        return false
    }
}

/** Waiting time before an Emergency pass. */
class ChallengeActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private var kind = "em"
    private var key = ""
    private lateinit var status: TextView
    private lateinit var go: Button
    private val tickR = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 500L) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        kind = intent.getStringExtra("k") ?: "em"
        key = intent.getStringExtra("key") ?: ""
        try { getSystemService(NotificationManager::class.java).cancel(Friction.NOTE_ID) } catch (_: Throwable) {}
        Friction.begin(this, kind, key)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(col); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        status = tv("", 20f, 0xFFD4A857.toInt(), true).apply { setPadding(0, px(14), 0, px(14)) }
        go = Button(this).apply {
            text = "Emergency unblock"
            isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF062018.toInt())
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
            setOnClickListener { submit() }
        }
        val back = Button(this).apply { text = "Go back"; isAllCaps = false; setOnClickListener { finish() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(px(24), px(24), px(24), px(24))
            addView(tv("🔒", 44f, Color.WHITE))
            addView(tv("Emergency unblock?", 22f, Color.WHITE, true))
            addView(status)
            addView(go, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(18) })
            addView(back, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(8) })
        }
        val root = FrameLayout(this)
        root.setBackgroundColor(0xFF06181B.toInt())
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                WindowInsets.CONSUMED
            } else ins
        }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); h.post(tickR) }
    override fun onPause() { h.removeCallbacks(tickR); super.onPause() }

    private fun fmt(ms: Long): String { val s = (ms + 999) / 1000; return "%d:%02d".format(s / 60, s % 60) }

    private fun refresh() {
        val left = Friction.readyIn(this)
        if (left > 0) {
            status.text = "Wait: ${fmt(left)}"
            go.visibility = View.GONE
        } else {
            status.text = "You can continue now"
            go.visibility = View.VISIBLE
        }
    }

    private fun submit() {
        if (Friction.readyIn(this) > 0) return
        val ok = Emerg.use(this, key)
        Friction.clear(this)
        BlockService.poke()
        Toast.makeText(this, if (ok) "Unblocked" else "Not possible now (today limit reached)", Toast.LENGTH_LONG).show()
        finish()
    }
}

/** Quick Settings tile: tap = one focus of [Pomo.quickMin] minutes. */
class FocusTile : TileService() {
    override fun onStartListening() { refresh() }
    override fun onClick() {
        val c = applicationContext
        if (!Pomo.running(c)) Pomo.quick(c)
        else if (!Pomo.stop(c)) Toast.makeText(c, "Focus is running and cannot be stopped midway", Toast.LENGTH_LONG).show()
        refresh()
    }
    private fun refresh() {
        val t = qsTile ?: return
        val s = Pomo.st(this)
        t.state = if (s.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Focus mode"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (s.running) (if (s.focus) "Focus " else "Break ") + ((s.leftMs + 59_999L) / 60_000L) + " min" else "${Pomo.quickMin(this)} min"
        t.updateTile()
    }
}

/** Home-screen widget: tap = one focus of THIS widget's minutes (set when it is added / reconfigured), or stop a break. */
class FocusWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { for (id in ids) m.updateAppWidget(id, views(c, id)) }

    override fun onDeleted(c: Context, ids: IntArray) {
        val e = c.getSharedPreferences("focusly_wmin", 0).edit(); ids.forEach { e.remove("w$it") }; e.apply()
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == TAP) {
            val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            if (!Pomo.running(c)) Pomo.start(c, minutes(c, id), 0, 1)
            else if (!Pomo.stop(c)) Toast.makeText(c, "Focus is running and cannot be stopped midway", Toast.LENGTH_LONG).show()
            refresh(c)
        }
    }

    companion object {
        const val TAP = "com.focusly.app.FOCUS_TAP"
        private fun wp(c: Context) = c.getSharedPreferences("focusly_wmin", 0)
        /** Minutes of widget [id]; falls back to the Settings "quick focus" value. */
        fun minutes(c: Context, id: Int): Int = wp(c).getInt("w$id", 0).let { if (it in 1..180) it else Pomo.quickMin(c) }
        fun setMinutes(c: Context, id: Int, m: Int) = wp(c).edit().putInt("w$id", m.coerceIn(1, 180)).apply()

        fun views(c: Context, id: Int): RemoteViews {
            val s = Pomo.st(c)
            val v = RemoteViews(c.packageName, R.layout.widget_focus)
            val m = minutes(c, id)
            v.setTextViewText(R.id.wTitle, if (!s.running) "Focus " + (if (m >= 60 && m % 60 == 0) "${m / 60} h" else "$m min") else if (s.focus) "Focus running" else "Break")
            v.setTextViewText(R.id.wSub, if (!s.running) "Tap to start" else "${(s.leftMs + 59_999L) / 60_000L} min left")
            v.setOnClickPendingIntent(R.id.wRoot, PendingIntent.getBroadcast(c, 3100 + id, Intent(c, FocusWidget::class.java).setAction(TAP)
                .setData(android.net.Uri.parse("focusly://focus/$id")).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            return v
        }
        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                for (id in m.getAppWidgetIds(ComponentName(c, FocusWidget::class.java))) m.updateAppWidget(id, views(c, id))
            } catch (_: Throwable) {}
        }
    }
}

/** Opens when a Focus widget is added (and from "Reconfigure"): choose how many minutes this widget focuses for. */
class FocusWidgetConfig : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        wid = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val cur = FocusWidget.minutes(this, wid)
        val input = EditText(this).apply {
            hint = "Custom (1-180)"; setText(cur.toString()); setSelectAllOnFocus(true)
            setHintTextColor(0x80FFFFFF.toInt()); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(android.text.InputFilter.LengthFilter(3))
            gravity = Gravity.CENTER
        }
        fun chip(m: Int) = Button(this).apply {
            text = if (m >= 60 && m % 60 == 0) "${m / 60}h" else "${m}m"
            isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = px(12).toFloat(); setColor(0xFF1F6F63.toInt()) }
            setPadding(px(14), px(4), px(14), px(4))
            setOnClickListener { input.setText(m.toString()) }
        }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            listOf(15, 25, 45, 60, 90).forEach { addView(chip(it), LinearLayout.LayoutParams(-2, px(40)).apply { marginEnd = px(6); marginStart = px(6) }) }
        }
        val save = Button(this).apply {
            text = "Save"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF062018.toInt())
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
            setPadding(px(40), px(8), px(40), px(8))
            setOnClickListener {
                val m = (input.text.toString().toIntOrNull() ?: 0).coerceIn(1, 180)
                FocusWidget.setMinutes(this@FocusWidgetConfig, wid, m)
                val mgr = AppWidgetManager.getInstance(this@FocusWidgetConfig)
                mgr.updateAppWidget(wid, FocusWidget.views(this@FocusWidgetConfig, wid))
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
                finish()
            }
        }
        fun tv(t: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(px(24), px(24), px(24), px(24))
            setBackgroundColor(0xFF06181B.toInt())
            addView(tv("Focus widget", 20f, true))
            addView(tv("How many minutes of focus?", 14f).apply { setPadding(0, px(6), 0, px(14)) })
            addView(chips)
            addView(input, LinearLayout.LayoutParams(px(160), -2).apply { topMargin = px(14) })
            addView(save, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(16) })
        }
        setContentView(col)
    }
}
