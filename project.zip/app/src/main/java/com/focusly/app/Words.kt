package com.focusly.app

import android.content.Context
import org.json.JSONArray

/**
 * Search block: text typed into any app, the URL bar of common browsers and (optionally) text visible on screen is
 * checked against word lists. On a match: typed field cleared, then Back / Home. Nothing is stored or sent anywhere.
 * Cfg: kw_on, kw_adult (built-in porn lists), kw_screen (also scan visible screen text), kw_list (user's own words, JSON array).
 *
 * Tiers: SITES + STRONG are used for typing, URL bar AND screen text. WEAK words (ambiguous in normal pages: "naked", "escort",
 * "xxx" ...) are used only for typing / URL bar, so ordinary pages do not get blocked.
 */
object Words {
    private val SITES = listOf(
        "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang", "brazzers", "bangbros", "naughtyamerica",
        "onlyfans", "fansly", "chaturbate", "stripchat", "bongacams", "livejasmin", "eporner", "tnaflix", "txxx", "hqporner",
        "motherless", "rule34", "e621", "nhentai", "hanime", "fapello", "thothub", "camsoda", "myfreecams", "sexmex",
        "desixx", "desi49", "indianporn", "mmsbaba", "savitabhabhi", "kamababa"
    )
    private val STRONG = listOf(
        "porn", "porno", "nsfw", "hentai", "nudes", "sex video", "sex videos", "sex scene", "sex tape", "sexy video",
        "adult video", "blue film", "bf video", "bf film", "bf movie", "chudai", "mms video", "desi sex", "bhabhi sex",
        "camgirl", "cam girl", "onlyfans leak", "onlyfans leaks", "leaked mms", "sexy bhabhi", "hot bhabhi",
        "चुदाई", "रंडी", "ब्लू फिल्म", "सेक्सी वीडियो", "गंदी वीडियो", "nangi video"
    )
    private val WEAK = listOf(
        "xxx", "nude", "naked", "topless", "nudity", "hot video", "adult movie", "18+ video", "18+ movie", "erotic", "erotica",
        "webcam girl", "live cam", "escort", "call girl", "strip", "stripper", "lingerie haul", "leaked video", "boobs",
        "bikini hot", "hot girl video", "hardcore", "milf", "threesome", "orgasm", "masturbation", "fetish", "bdsm",
        "randi", "chodna", "aunty sex", "bhabhi video", "desi mms", "mms clip", "garam video", "garam movie",
        "gandi video", "gandi movie", "nangi", "kamukta", "नंगी"
    )
    private val rx = HashMap<String, Regex>()

    fun on(c: Context) = Cfg.bool(c, "kw_on", false)
    fun adult(c: Context) = Cfg.bool(c, "kw_adult", true)
    fun screen(c: Context) = Cfg.bool(c, "kw_screen", true)

    fun custom(c: Context): List<String> = try {
        val a = JSONArray(Cfg.str(c, "kw_list", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Throwable) { emptyList() }

    /** [csv]: the user's words separated by commas or new lines. */
    fun set(c: Context, on: Boolean, adult: Boolean, screen: Boolean, csv: String) {
        Cfg.setBool(c, "kw_on", on)
        Cfg.setBool(c, "kw_adult", adult)
        Cfg.setBool(c, "kw_screen", screen)
        val a = JSONArray()
        csv.split(',', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct().take(200).forEach { a.put(it) }
        Cfg.put(c, "kw_list", a.toString())
    }

    /** Short words must stand alone (so "porn" matches but "brandi" never matches "randi"). */
    private fun find(t: String, words: List<String>): String? {
        for (w in words) {
            if (w.length <= 5 && !w.contains(' ') && !w.contains('.')) {
                val r = rx.getOrPut(w) { Regex("(?<![a-z0-9])" + Regex.escape(w) + "(?![a-z0-9])") }
                if (r.containsMatchIn(t)) return w
            } else if (t.contains(w)) return w
        }
        return null
    }

    /** Typed text / URL bar: every list. */
    fun hit(c: Context, raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val words = (if (adult(c)) SITES + STRONG + WEAK else emptyList()) + custom(c)
        return find(raw.lowercase(), words)
    }

    /** Text visible on screen: only the strong lists (and the user's own words). */
    fun hitScreen(c: Context, raw: String?): String? {
        if (raw.isNullOrBlank() || !screen(c)) return null
        val words = (if (adult(c)) SITES + STRONG else emptyList()) + custom(c)
        return find(raw.lowercase(), words)
    }
}
