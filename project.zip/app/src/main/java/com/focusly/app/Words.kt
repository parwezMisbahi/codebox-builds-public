package com.focusly.app

import android.content.Context
import org.json.JSONArray

/**
 * Search block: while on, any text typed into any app / browser (and the URL bar of common browsers) is checked
 * against a word list. On a match the field is cleared and the phone goes Home. Nothing is stored or sent anywhere:
 * the text is only compared and then forgotten.
 * Cfg: kw_on (bool), kw_adult (bool, built-in adult list), kw_list (JSON array of the user's own words).
 */
object Words {
    private val BUILTIN = listOf(
        "porn", "porno", "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang", "brazzers",
        "onlyfans", "hentai", "xxx", "nsfw", "nude", "nudes", "naked girl", "sex video", "sexy video", "sex scene",
        "blue film", "bf video", "adult video", "18+ video", "hot video", "boobs", "chudai", "randi", "bhabhi sex",
        "desi sex", "mms video", "mia khalifa", "sunny leone video", "erotic", "camgirl", "escort service"
    )
    private val rx = HashMap<String, Regex>()

    fun on(c: Context) = Cfg.bool(c, "kw_on", false)
    fun adult(c: Context) = Cfg.bool(c, "kw_adult", true)

    fun custom(c: Context): List<String> = try {
        val a = JSONArray(Cfg.str(c, "kw_list", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Throwable) { emptyList() }

    /** [csv]: the user's words separated by commas or new lines. */
    fun set(c: Context, on: Boolean, adult: Boolean, csv: String) {
        Cfg.setBool(c, "kw_on", on)
        Cfg.setBool(c, "kw_adult", adult)
        val a = JSONArray()
        csv.split(',', '\n').map { it.trim().lowercase() }.filter { it.isNotEmpty() }.distinct().take(200).forEach { a.put(it) }
        Cfg.put(c, "kw_list", a.toString())
    }

    /** The matching word, or null. Short words must stand alone (so "xxx" matches but not part of another word). */
    fun hit(c: Context, raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val t = raw.lowercase()
        val words = (if (adult(c)) BUILTIN else emptyList()) + custom(c)
        for (w in words) {
            if (w.length <= 4 && !w.contains(' ') && !w.contains('.')) {
                val r = rx.getOrPut(w) { Regex("(?<![a-z0-9])" + Regex.escape(w) + "(?![a-z0-9])") }
                if (r.containsMatchIn(t)) return w
            } else if (t.contains(w)) return w
        }
        return null
    }
}
