package com.focusly.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.AppOpsManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat

/**
 * Keeps Focusly alive after "clear recents" AND works as a second blocker (same idea as Docera's
 * BlockGuardService): while the Accessibility blocker is not running it watches the foreground app via
 * Usage Access and covers blocked apps with an overlay (needs Usage access + Display over other apps).
 */
class KeepService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    private val handler = Handler(Looper.getMainLooper())
    private var ticking = false
    private var fg: String? = null
    private var lastQuery = 0L
    private var lastTick = 0L
    private var cover: View? = null
    private var coverKey = ""
    private var coverTime: TextView? = null
    private var coverWhy: TextView? = null
    private var coverEm: Button? = null
    private var coverStop: Button? = null
    private var armedKey = ""
    private var armedAt = 0L
    private var prot: Set<String> = emptySet()
    private var protAt = 0L

    // Every package that currently has a visible activity (split-screen / floating / pip windows included), not just the last one that resumed.
    private val vis = LinkedHashSet<String>()
    private var homeAt = 0L
    private var homeTries = 0
    private var a11yGrace = 0L
    private var a11yObs: android.database.ContentObserver? = null
    private var a11yFix = 0L

    private fun strictLeftMs() = Strict.leftMs(this)

    /** Somebody turned Focusly's Accessibility switch OFF while a block / strict mode exists: switch it back on at once (needs the adb WRITE_SECURE_SETTINGS grant, debug/sideload build). */
    private fun watchAccessibility() {
        if (a11yObs != null) return
        val obs = object : android.database.ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                handler.removeCallbacks(a11yCheck)
                handler.postDelayed(a11yCheck, 350L)
            }
        }
        try {
            contentResolver.registerContentObserver(Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES), false, obs)
            a11yObs = obs
        } catch (_: Throwable) {}
    }

    private val a11yCheck = Runnable {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - a11yFix < 2500L) return@Runnable            // ignore the changes we made ourselves
            if (!(Blocker.anyConfigured(this) || Strict.active(this))) return@Runnable
            if (accessibilityOn(this)) return@Runnable
            if (SystemClock.elapsedRealtime() < a11yGrace) return@Runnable   // person is in the "turn it ON" window
            a11yFix = now
            Blocker.tryEnableService(this)
        } catch (_: Throwable) {}
    }

    private var fgNote: Notification? = null
    private var fgLoc = false

    /** Foreground type: add "location" once the "all the time" permission exists, so Android keeps location updates coming in the background. */
    private fun promote() {
        val n = fgNote ?: return
        if (Build.VERSION.SDK_INT < 34) { startForeground(77, n); return }
        startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        fgLoc = false
    }

    private val locLoop = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT >= 34 && !fgLoc && Presence.permLevel(this@KeepService) == 2) { try { promote() } catch (_: Throwable) {} }
            try { Presence.tick(this@KeepService) } catch (_: Throwable) {}
            handler.postDelayed(this, 8000L)
        }
    }

    private var lastWatch = 0L
    private var screenRx: android.content.BroadcastReceiver? = null

    private var lastJob = 0L

    /** Survives the process being killed: an alarm every ~30 s + a persisted job every 15 min both restart this service.
     *  Every ~30 s it also checks the accessibility service and switches it back on if Android / the user turned it off while a block or Strict mode is active. */
    private fun watch() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastWatch < 25_000L) return
        lastWatch = now
        revive(30_000L)
        try { if ((Blocker.anyConfigured(this) || Strict.active(this)) && !BlockService.connected) Blocker.tryEnableService(this) } catch (_: Throwable) {}
        if (now - lastJob > 120_000L) { lastJob = now; try { Watchdog.schedule(this) } catch (_: Throwable) {} }
    }

    /** Screen on / unlock: if Android dropped the accessibility service meanwhile, switch it on again and make sure everything is running. */
    private fun registerScreen() {
        if (screenRx != null) return
        val rx = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                try { if ((Blocker.anyConfigured(c) || Strict.active(c)) && !BlockService.connected) Blocker.tryEnableService(c) } catch (_: Throwable) {}
                try { Sched.armAll(c) } catch (_: Throwable) {}
                lastWatch = 0L; watch()
            }
        }
        val f = android.content.IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT) }
        try { if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f); screenRx = rx } catch (_: Throwable) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            try { watch() } catch (_: Throwable) {}
            var next = 3000L
            try { next = step() } catch (_: Throwable) {}
            handler.postDelayed(this, next)
        }
    }

    override fun onCreate() {
        super.onCreate()
        try { NoLoc.run(applicationContext) } catch (_: Throwable) {}
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fk2", "Focusly is running", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(this, 11, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n: Notification = NotificationCompat.Builder(this, "fk2").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Focusly active").setContentText("Block, alarm and reminder are on")
                .setOngoing(true).setContentIntent(open).setPriority(NotificationCompat.PRIORITY_LOW).build()
            fgNote = n
            promote()
        } catch (_: Throwable) {}
        try { Sched.armAll(this) } catch (_: Throwable) {}
        try { if (Blocker.anyConfigured(this) || Strict.active(this)) Blocker.tryEnableService(this) } catch (_: Throwable) {}
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try { if ((Blocker.anyConfigured(this) || Strict.active(this)) && !BlockService.connected) Blocker.tryEnableService(this) } catch (_: Throwable) {}
        registerScreen()
        watchAccessibility()
        if (!ticking) { ticking = true; handler.post(tick) }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        revive(1500L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        try { screenRx?.let { unregisterReceiver(it) } } catch (_: Throwable) {}
        screenRx = null
        try { a11yObs?.let { contentResolver.unregisterContentObserver(it) } } catch (_: Throwable) {}
        a11yObs = null
        ticking = false
        handler.removeCallbacksAndMessages(null)
        removeCover()
        revive(3000L)
        super.onDestroy()
    }

    private fun revive(delay: Long) {
        try {
            val p = PendingIntent.getForegroundService(this, 12, Intent(this, KeepService::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, p)
        } catch (_: Throwable) {}
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (prot.isEmpty() || now - protAt > 60_000L) { prot = Blocker.protectedPackages(this); protAt = now }
        return prot
    }

    /** One check. Returns the delay until the next one. */
    private fun step(): Long {
        try { Pomo.tick(this) } catch (_: Throwable) {}
        try { Weekly.tick(this) } catch (_: Throwable) {}
        try { InfoWidget.refresh(this) } catch (_: Throwable) {}
        val strictFb = Strict.active(this) && !BlockService.connected
        if (!Blocker.anyConfigured(this) && !strictFb) { removeCover(); fg = null; vis.clear(); lastQuery = 0L; return 4000L }
        if (BlockService.connected) { removeCover(); fg = null; vis.clear(); lastQuery = 0L; lastTick = 0L; return 2500L } // accessibility blocker does the work
        if (!ready(this)) { removeCover(); return 3000L }
        val interactive = try { getSystemService(PowerManager::class.java).isInteractive } catch (_: Throwable) { true }
        if (!interactive) { removeCover(); lastTick = 0L; vis.clear(); lastQuery = 0L; return 3000L }

        updateForeground()
        val now = SystemClock.elapsedRealtime()
        val p = fg
        if (lastTick > 0L && p != null && p in Blocker.limitPkgs(this)) Usage.add(this, p, (now - lastTick).coerceIn(0L, 2000L))
        lastTick = now

        val callUp = p != null && (p.contains("incallui") || p == "com.android.server.telecom" || p.contains("emergency") || p == "com.android.phone" || p.contains("dialer"))
        val holdLeft = Hold.left(this)
        if (holdLeft > 0 && !Emerg.active(this, "hold") && !callUp && (p == null || p !in Allow.get(this))) {
            show("hold", Hold.title(this).ifEmpty { "Screen block" }, "Screen is blocked right now", holdLeft, false)
            return 500L
        }
        // Strict mode + Accessibility is OFF: Settings is NOT covered any more (it used to lock the whole Settings app). Focusly switches
        // Accessibility back ON by itself (see watchAccessibility / watch); the Focusly row itself is guarded by the accessibility service.
        if (cover != null && coverKey == "strict") removeCover()

        // Look at EVERY visible window, not only the last one that resumed. Otherwise a blocked app in a split-screen / floating window
        // stays usable as soon as the other window is touched (that window's app becomes "fg" and the cover is dropped).
        val prot = protectedSet()
        var hit: String? = null
        var hitLeft = 0L
        var hitWhy = ""
        val cands = LinkedHashSet<String>()
        if (p != null) cands.add(p)
        cands.addAll(vis)
        for (c in cands) {
            if (c == packageName || c in prot) continue
            val bi = Blocker.info(this, c)
            if (bi.left > hitLeft) { hit = c; hitLeft = bi.left; hitWhy = bi.why }
        }
        if (hit == null) { removeCover(); homeTries = 0; return 700L }
        val nowT = SystemClock.elapsedRealtime()
        // The blocked app only lingers in a floating / split window while something else (launcher, another app) is in front: do NOT keep the
        // whole phone behind a full-screen cover (nothing could be used or closed). Drop the cover; it comes back as soon as that window is touched.
        if (coverKey == hit && p != null && p != hit && homeTries >= 1 && nowT - homeAt > 1500L) {
            vis.remove(hit); removeCover(); homeTries = 0
            return 700L
        }
        val created = cover == null || coverKey != hit
        show(hit, "${label(hit)} is blocked", hitWhy, hitLeft, true)
        if (created) { homeTries = 0; homeAt = nowT; goHome() }
        else if (homeTries < 3 && nowT - homeAt > 1500L) { homeTries++; homeAt = nowT; goHome() }   // blocked app still visible (split / floating window): send Home again
        return 500L
    }

    private fun label(pkg: String) = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { "App" }

    private fun updateForeground() {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val nowMs = System.currentTimeMillis()
        val begin = if (lastQuery == 0L) nowMs - 6 * 3_600_000L else lastQuery - 1000L   // first look: replay a few hours so already-open windows are known
        val ev = usm.queryEvents(begin, nowMs)
        val e = UsageEvents.Event()
        val stopType = if (Build.VERSION.SDK_INT >= 29) 23 else 2   // ACTIVITY_STOPPED (API 29+) / MOVE_TO_BACKGROUND
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val pk = e.packageName ?: continue
            when (e.eventType) {
                1 -> { fg = pk; vis.add(pk) }                       // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
                stopType, 24 -> vis.remove(pk)                      // stopped / destroyed
            }
        }
        lastQuery = nowMs
    }

    private fun goHome() {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
    }

    private fun show(key: String, title: String, why: String, left: Long, home: Boolean) {
        if (cover != null && coverKey != key) removeCover()
        if (cover == null) {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = build(key, title, why, home)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE)
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            cover = v; coverKey = key
        }
        coverTime?.text = "${Blocker.format(left)} left"
        coverWhy?.text = why
        updateEm()
    }

    private fun build(key: String, title: String, why: String, home: Boolean): View {
        val w = CoverUi.why(this, why)
        val t = CoverUi.time(this)
        val em = CoverUi.soft(this, Button(this)).apply { setOnClickListener { onEm(key) } }
        val stopB = CoverUi.danger(this, Button(this)).apply {
            text = "\u23F0 Stop alarm"
            visibility = if (Ring.active(this@KeepService)) android.view.View.VISIBLE else android.view.View.GONE
            setOnClickListener { Ring.stopAll(this@KeepService); visibility = android.view.View.GONE }
        }
        coverWhy = w; coverTime = t; coverEm = em; coverStop = stopB
        val list = ArrayList<View>()
        list.add(stopB)
        if (home) list.add(CoverUi.primary(this, "Go Home") { goHome() })
        if (key == "strict") {
            list.add(CoverUi.soft(this, Button(this), "Turn Accessibility ON").apply { setOnClickListener {
                a11yGrace = SystemClock.elapsedRealtime() + 60_000L
                removeCover()
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
            } })
        } else list.add(em)
        return CoverUi.screen(this, title, w, t, list)
    }

    private fun updateEm() {
        coverStop?.visibility = if (Ring.active(this)) android.view.View.VISIBLE else android.view.View.GONE
        val b = coverEm ?: return
        if (coverKey == "strict") { b.visibility = View.GONE; return }
        val left = Emerg.left(this, coverKey)
        val armed = armedKey == coverKey && SystemClock.elapsedRealtime() - armedAt < 4000L
        if (left <= 0) { b.text = "Emergency used up (for today)"; b.isEnabled = false }
        else { b.isEnabled = true; b.text = if (armed) "Tap again: opens for ${Emerg.MINUTES} min" else "Emergency • ${Emerg.MINUTES} min ($left left)" }
    }

    private fun onEm(key: String) {
        val now = SystemClock.elapsedRealtime()
        if (armedKey != key || now - armedAt >= 4000L) { armedKey = key; armedAt = now; updateEm(); return }
        armedKey = ""
        if (Friction.request(this, "em", key)) removeCover()
    }

    private fun removeCover() {
        val v = cover ?: return
        cover = null; coverKey = ""; coverTime = null; coverWhy = null; coverEm = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Throwable) {}
    }

    companion object {
        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, KeepService::class.java)) } catch (_: Throwable) {}
        }

        @Suppress("DEPRECATION")
        fun hasUsage(c: Context): Boolean = try {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            (if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
             else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)) == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) { false }

        fun hasOverlay(c: Context): Boolean = try { Settings.canDrawOverlays(c) } catch (_: Throwable) { false }
        fun ready(c: Context) = hasUsage(c) && hasOverlay(c)
    }
}

/** Shortcuts to the phone settings that decide whether Focusly survives "clear recents". */
object Oem {
    fun batteryOk(c: Context) = try { c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName) } catch (_: Throwable) { false }

    private fun go(c: Context, i: Intent): Boolean = try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Throwable) { false }

    fun usage(c: Context) = go(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + c.packageName))) || go(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    fun overlay(c: Context) = go(c, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) || appInfo(c)

    fun appInfo(c: Context) = go(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)))

    fun autostart(c: Context): Boolean {
        val tries = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartDetailManagementActivity"))
        for (t in tries) if (go(c, Intent().setComponent(t))) return true
        return appInfo(c)
    }

    @android.annotation.SuppressLint("BatteryLife")
    fun battery(c: Context): Boolean {
        if (go(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)))) return true
        if (go(c, Intent().setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")).putExtra("package_name", c.packageName).putExtra("package_label", "Focusly"))) return true
        return appInfo(c)
    }
}


/** Persisted periodic job (every ~15 min, also after reboot): if Android killed Focusly, this brings the blocker back. */
class Watchdog : android.app.job.JobService() {
    override fun onStartJob(params: android.app.job.JobParameters?): Boolean {
        try { if ((Blocker.anyConfigured(this) || Strict.active(this)) && !BlockService.connected) Blocker.tryEnableService(this) } catch (_: Throwable) {}
        try { Sched.armAll(this) } catch (_: Throwable) {}
        KeepService.start(this)
        return false
    }
    override fun onStopJob(params: android.app.job.JobParameters?) = true

    companion object {
        fun schedule(c: Context) {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as android.app.job.JobScheduler
            if (js.getPendingJob(4242) != null) return
            js.schedule(android.app.job.JobInfo.Builder(4242, ComponentName(c, Watchdog::class.java))
                .setPeriodic(15 * 60_000L).setPersisted(true).build())
        }
    }
}
