package com.focusly.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.AppOpsManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationCompat

/**
 * Keeps Focusly alive after "clear recents" AND works as a second blocker (same idea as Docera's
 * BlockGuardService): while the Accessibility blocker is not running it watches the foreground app via
 * Usage Access and covers blocked apps with an overlay (needs Usage access + Display over other apps).
 */
class KeepService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    private val handler = Handler(Looper.getMainLooper())
    private var ticking = false
    private var fg: String? = null
    private var lastQuery = 0L
    private var lastTick = 0L
    private var cover: View? = null
    private var coverKey = ""
    private var coverTime: TextView? = null
    private var coverWhy: TextView? = null
    private var coverEm: Button? = null
    private var armedKey = ""
    private var armedAt = 0L
    private var prot: Set<String> = emptySet()
    private var protAt = 0L

    private var fgNote: Notification? = null
    private var fgLoc = false

    /** Foreground type: add "location" once the "all the time" permission exists, so Android keeps location updates coming in the background. */
    private fun promote() {
        val n = fgNote ?: return
        if (Build.VERSION.SDK_INT < 34) { startForeground(77, n); return }
        startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        fgLoc = false
    }

    private val locLoop = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT >= 34 && !fgLoc && Presence.permLevel(this@KeepService) == 2) { try { promote() } catch (_: Throwable) {} }
            try { Presence.tick(this@KeepService) } catch (_: Throwable) {}
            handler.postDelayed(this, 8000L)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            var next = 3000L
            try { next = step() } catch (_: Throwable) {}
            handler.postDelayed(this, next)
        }
    }

    override fun onCreate() {
        super.onCreate()
        try { NoLoc.run(applicationContext) } catch (_: Throwable) {}
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("fk", "Focusly is running", NotificationManager.IMPORTANCE_MIN))
            val open = PendingIntent.getActivity(this, 11, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n: Notification = NotificationCompat.Builder(this, "fk").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Focusly active").setContentText("Block, alarm and reminder are on")
                .setOngoing(true).setContentIntent(open).setPriority(NotificationCompat.PRIORITY_MIN).build()
            fgNote = n
            promote()
        } catch (_: Throwable) {}
        try { Sched.armAll(this) } catch (_: Throwable) {}
        try { if (Blocker.anyConfigured(this)) Blocker.tryEnableService(this) } catch (_: Throwable) {}
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try { if (Blocker.anyConfigured(this) && !BlockService.connected) Blocker.tryEnableService(this) } catch (_: Throwable) {}
        if (!ticking) { ticking = true; handler.post(tick) }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        revive(1500L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        ticking = false
        handler.removeCallbacksAndMessages(null)
        removeCover()
        revive(3000L)
        super.onDestroy()
    }

    private fun revive(delay: Long) {
        try {
            val p = PendingIntent.getForegroundService(this, 12, Intent(this, KeepService::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, p)
        } catch (_: Throwable) {}
    }

    private fun protectedSet(): Set<String> {
        val now = SystemClock.elapsedRealtime()
        if (prot.isEmpty() || now - protAt > 60_000L) { prot = Blocker.protectedPackages(this); protAt = now }
        return prot
    }

    /** One check. Returns the delay until the next one. */
    private fun step(): Long {
        try { Pomo.tick(this) } catch (_: Throwable) {}
        try { Weekly.tick(this) } catch (_: Throwable) {}
        try { InfoWidget.refresh(this) } catch (_: Throwable) {}
        if (!Blocker.anyConfigured(this)) { removeCover(); fg = null; lastQuery = 0L; return 4000L }
        if (BlockService.connected) { removeCover(); fg = null; lastQuery = 0L; lastTick = 0L; return 2500L } // accessibility blocker does the work
        if (!ready(this)) { removeCover(); return 3000L }
        val interactive = try { getSystemService(PowerManager::class.java).isInteractive } catch (_: Throwable) { true }
        if (!interactive) { removeCover(); lastTick = 0L; return 3000L }

        updateForeground()
        val now = SystemClock.elapsedRealtime()
        val p = fg
        if (lastTick > 0L && p != null && p in Blocker.limitPkgs(this)) Usage.add(this, p, (now - lastTick).coerceIn(0L, 2000L))
        lastTick = now

        val callUp = p != null && (p.contains("incallui") || p == "com.android.server.telecom" || p.contains("emergency") || p == "com.android.phone" || p.contains("dialer"))
        val holdLeft = Hold.left(this)
        if (holdLeft > 0 && !Emerg.active(this, "hold") && !callUp && (p == null || p !in Allow.get(this))) {
            show("hold", Hold.title(this).ifEmpty { "Screen block" }, "Screen is blocked right now", holdLeft, false)
            return 500L
        }
        if (p == null || p == packageName || p in protectedSet()) { removeCover(); return 700L }
        val bi = Blocker.info(this, p)
        if (bi.left <= 0L) { removeCover(); return 700L }
        val created = cover == null || coverKey != p
        show(p, "${label(p)} is blocked", bi.why, bi.left, true)
        if (created) goHome()
        return 500L
    }

    private fun label(pkg: String) = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { "App" }

    private fun updateForeground() {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val nowMs = System.currentTimeMillis()
        val begin = if (lastQuery == 0L) nowMs - 60_000L else lastQuery - 1000L
        val ev = usm.queryEvents(begin, nowMs)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.packageName }
        lastQuery = nowMs
    }

    private fun goHome() {
        try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
    }

    private fun show(key: String, title: String, why: String, left: Long, home: Boolean) {
        if (cover != null && coverKey != key) removeCover()
        if (cover == null) {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = build(key, title, why, home)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE)
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            cover = v; coverKey = key
        }
        coverTime?.text = "${Blocker.format(left)} left"
        coverWhy?.text = why
        updateEm()
    }

    private fun build(key: String, title: String, why: String, home: Boolean): View {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        fun tv(t: String, sp: Float, col: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(col); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        val w = tv(why, 14f, 0xB3FFFFFF.toInt()).apply { setPadding(px(8), px(4), px(8), 0) }
        val t = tv("", 14f, 0xFFD4A857.toInt()).apply { setPadding(0, px(8), 0, px(28)) }
        val em = Button(this).apply { isAllCaps = false; textSize = 13f; setOnClickListener { onEm(key) } }
        coverWhy = w; coverTime = t; coverEm = em
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true
            setPadding(px(24), px(24), px(24), px(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF06181B.toInt(), 0xFF0D2D30.toInt()))
            addView(tv("🔒", 48f, Color.WHITE))
            addView(tv(title, 22f, Color.WHITE, true).apply { setPadding(0, px(8), 0, 0) })
            addView(w); addView(t)
            if (home) addView(Button(this@KeepService).apply {
                text = "Home jao"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF062018.toInt())
                background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
                setPadding(px(40), px(10), px(40), px(10))
                setOnClickListener { goHome() }
            })
            addView(em, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(14) })
        }
    }

    private fun updateEm() {
        val b = coverEm ?: return
        val left = Emerg.left(this, coverKey)
        val armed = armedKey == coverKey && SystemClock.elapsedRealtime() - armedAt < 4000L
        if (left <= 0) { b.text = "Emergency used up (for today)"; b.isEnabled = false }
        else { b.isEnabled = true; b.text = if (armed) "Tap again: opens for ${Emerg.MINUTES} min" else "Emergency • ${Emerg.MINUTES} min ($left left)" }
    }

    private fun onEm(key: String) {
        val now = SystemClock.elapsedRealtime()
        if (armedKey != key || now - armedAt >= 4000L) { armedKey = key; armedAt = now; updateEm(); return }
        armedKey = ""
        if (Friction.request(this, "em", key)) removeCover()
    }

    private fun removeCover() {
        val v = cover ?: return
        cover = null; coverKey = ""; coverTime = null; coverWhy = null; coverEm = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Throwable) {}
    }

    companion object {
        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, KeepService::class.java)) } catch (_: Throwable) {}
        }

        @Suppress("DEPRECATION")
        fun hasUsage(c: Context): Boolean = try {
            val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            (if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
             else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)) == AppOpsManager.MODE_ALLOWED
        } catch (_: Throwable) { false }

        fun hasOverlay(c: Context): Boolean = try { Settings.canDrawOverlays(c) } catch (_: Throwable) { false }
        fun ready(c: Context) = hasUsage(c) && hasOverlay(c)
    }
}

/** Shortcuts to the phone settings that decide whether Focusly survives "clear recents". */
object Oem {
    fun batteryOk(c: Context) = try { c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName) } catch (_: Throwable) { false }

    private fun go(c: Context, i: Intent): Boolean = try { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Throwable) { false }

    fun usage(c: Context) = go(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + c.packageName))) || go(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    fun overlay(c: Context) = go(c, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))) || appInfo(c)

    fun appInfo(c: Context) = go(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName)))

    fun autostart(c: Context): Boolean {
        val tries = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartDetailManagementActivity"))
        for (t in tries) if (go(c, Intent().setComponent(t))) return true
        return appInfo(c)
    }

    @android.annotation.SuppressLint("BatteryLife")
    fun battery(c: Context): Boolean {
        if (go(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName)))) return true
        if (go(c, Intent().setComponent(ComponentName("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")).putExtra("package_name", c.packageName).putExtra("package_label", "Focusly"))) return true
        return appInfo(c)
    }
}
