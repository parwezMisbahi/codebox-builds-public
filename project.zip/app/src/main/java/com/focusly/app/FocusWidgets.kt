package com.focusly.app

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RemoteViews
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

/** Starts a Focus (the same lock as the Focus page: all apps blocked, "Never block" apps stay open) from a home-screen widget. */
object FocusStart {
    fun label(m: Int) = if (m >= 60 && m % 60 == 0) "${m / 60} h" else if (m > 60) "${m / 60} h ${m % 60} min" else "$m min"

    fun start(c: Context, minutes: Int): Boolean {
        val m = minutes.coerceIn(1, 1440)
        val now = System.currentTimeMillis()
        if (Lock.until(c) > now) {
            Toast.makeText(c, "Focus is already running", Toast.LENGTH_SHORT).show()
            return false
        }
        Lock.set(c, now + m * 60_000L)
        Lock.setPls(c, emptyList())
        try { KeepService.start(c) } catch (_: Throwable) {}
        try { if (!BlockService.connected) Blocker.tryEnableService(c) } catch (_: Throwable) {}
        try { BlockService.poke() } catch (_: Throwable) {}
        Toast.makeText(c, "Focus on for ${label(m)}", Toast.LENGTH_SHORT).show()
        refreshAll(c)
        return true
    }

    /** "Focus on until 15:40" while a focus runs, else null. */
    fun runningText(c: Context): String? {
        val u = Lock.until(c)
        if (u <= System.currentTimeMillis()) return null
        val cal = Calendar.getInstance().apply { timeInMillis = u }
        return "Focus on • until %02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
    }

    fun refreshAll(c: Context) { FocusWidget.refresh(c); FocusPickWidget.refresh(c) }
}

/** Widget "Focus - custom time": tap = one focus of THIS widget's minutes (set when it is added / reconfigured, 1-1440). */
class FocusWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { for (id in ids) m.updateAppWidget(id, views(c, id)) }

    override fun onDeleted(c: Context, ids: IntArray) {
        val e = c.getSharedPreferences("focusly_wmin", 0).edit(); ids.forEach { e.remove("w$it") }; e.apply()
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == TAP) {
            val id = i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            FocusStart.start(c, minutes(c, id))
        }
    }

    companion object {
        const val TAP = "com.focusly.app.FOCUS_TAP"
        private fun wp(c: Context) = c.getSharedPreferences("focusly_wmin", 0)
        fun minutes(c: Context, id: Int): Int = wp(c).getInt("w$id", 0).let { if (it in 1..1440) it else 25 }
        fun setMinutes(c: Context, id: Int, m: Int) = wp(c).edit().putInt("w$id", m.coerceIn(1, 1440)).apply()

        fun views(c: Context, id: Int): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_focus)
            val run = FocusStart.runningText(c)
            v.setTextViewText(R.id.wTitle, run ?: "Focus " + FocusStart.label(minutes(c, id)))
            v.setTextViewText(R.id.wSub, if (run != null) "Tap does nothing until it ends" else "Tap to start")
            v.setOnClickPendingIntent(R.id.wRoot, PendingIntent.getBroadcast(c, 3100 + id, Intent(c, FocusWidget::class.java).setAction(TAP)
                .setData(android.net.Uri.parse("focusly://focus/$id")).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            return v
        }
        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                for (id in m.getAppWidgetIds(ComponentName(c, FocusWidget::class.java))) m.updateAppWidget(id, views(c, id))
            } catch (_: Throwable) {}
        }
    }
}

/** Widget "Focus": the same choices as "Focus for how long?" - 15m / 30m / 1h / 2h and Custom (type your own minutes). */
class FocusPickWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { for (id in ids) m.updateAppWidget(id, views(c)) }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == PICK) FocusStart.start(c, i.getIntExtra("m", 0))
    }

    companion object {
        const val PICK = "com.focusly.app.FOCUS_PICK"
        private val BTN = listOf(R.id.p15 to 15, R.id.p30 to 30, R.id.p60 to 60, R.id.p120 to 120)

        fun views(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget_pick)
            val run = FocusStart.runningText(c)
            v.setTextViewText(R.id.wpTitle, run ?: "Focus for how long?")
            for ((rid, m) in BTN) {
                v.setOnClickPendingIntent(rid, PendingIntent.getBroadcast(c, 3300 + m, Intent(c, FocusPickWidget::class.java).setAction(PICK)
                    .setData(android.net.Uri.parse("focusly://pick/$m")).putExtra("m", m),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            v.setOnClickPendingIntent(R.id.pc, PendingIntent.getActivity(c, 3399, Intent(c, FocusAskActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            return v
        }
        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                for (id in m.getAppWidgetIds(ComponentName(c, FocusPickWidget::class.java))) m.updateAppWidget(id, views(c))
            } catch (_: Throwable) {}
        }
    }
}

/** Small dialog opened by the widget's "Custom" button: type minutes (1-1440) and start. */
class FocusAskActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val input = EditText(this).apply {
            hint = "Minutes (1-1440)"; setHintTextColor(0x80FFFFFF.toInt()); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(android.text.InputFilter.LengthFilter(4)); gravity = Gravity.CENTER
        }
        val go = Button(this).apply {
            text = "Start focus"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF062018.toInt())
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
            setPadding(px(40), px(8), px(40), px(8))
            setOnClickListener {
                val m = input.text.toString().toIntOrNull() ?: 0
                if (m < 1) { Toast.makeText(this@FocusAskActivity, "Enter minutes", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                FocusStart.start(this@FocusAskActivity, m)
                finish()
            }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(px(24), px(24), px(24), px(24))
            setBackgroundColor(0xFF06181B.toInt())
            addView(TextView(this@FocusAskActivity).apply { text = "Focus for how long?"; textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
            addView(input, LinearLayout.LayoutParams(px(180), -2).apply { topMargin = px(14) })
            addView(go, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(16) })
        }
        setContentView(col)
    }
}

/** Opens when a "Focus - custom time" widget is added (and from "Reconfigure"): choose the minutes of this widget. */
class FocusWidgetConfig : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        wid = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val input = EditText(this).apply {
            hint = "Minutes (1-1440)"; setText(FocusWidget.minutes(this@FocusWidgetConfig, wid).toString()); setSelectAllOnFocus(true)
            setHintTextColor(0x80FFFFFF.toInt()); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(android.text.InputFilter.LengthFilter(4)); gravity = Gravity.CENTER
        }
        fun chip(m: Int) = Button(this).apply {
            text = if (m >= 60 && m % 60 == 0) "${m / 60}h" else "${m}m"
            isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = px(12).toFloat(); setColor(0xFF1F6F63.toInt()) }
            setPadding(px(14), px(4), px(14), px(4))
            setOnClickListener { input.setText(m.toString()) }
        }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            listOf(15, 30, 60, 120).forEach { addView(chip(it), LinearLayout.LayoutParams(-2, px(40)).apply { marginEnd = px(6); marginStart = px(6) }) }
        }
        val save = Button(this).apply {
            text = "Save"; isAllCaps = false; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF062018.toInt())
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(0xFF5FE3C0.toInt()) }
            setPadding(px(40), px(8), px(40), px(8))
            setOnClickListener {
                val m = (input.text.toString().toIntOrNull() ?: 0).coerceIn(1, 1440)
                FocusWidget.setMinutes(this@FocusWidgetConfig, wid, m)
                AppWidgetManager.getInstance(this@FocusWidgetConfig).updateAppWidget(wid, FocusWidget.views(this@FocusWidgetConfig, wid))
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
                finish()
            }
        }
        fun tv(t: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(px(24), px(24), px(24), px(24))
            setBackgroundColor(0xFF06181B.toInt())
            addView(tv("Focus widget", 20f, true))
            addView(tv("How many minutes should this widget focus for?", 14f).apply { setPadding(0, px(6), 0, px(14)) })
            addView(chips)
            addView(input, LinearLayout.LayoutParams(px(180), -2).apply { topMargin = px(14) })
            addView(save, LinearLayout.LayoutParams(-2, -2).apply { topMargin = px(16) })
        }
        setContentView(col)
    }
}
