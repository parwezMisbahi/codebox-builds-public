package com.focusly.app

import android.content.Context
import java.util.Calendar

/**
 * Class Shield: while the real YouTube app is open (portrait), everything BELOW the video is covered by an
 * opaque overlay that eats touches (recommendations, comments, Shorts shelf). The video itself and its controls
 * (play / pause / seek / settings > speed) stay fully usable, so YouTube Premium speed still works.
 *
 * The overlay lives in BlockService (needs the accessibility window list). Settings are stored in Cfg:
 *   sh_on (bool), sh_s / sh_e (minutes of day; equal = always), sh_mode ("auto" | "fixed"), sh_pct (fixed mode: video bottom, % of window height).
 * "auto" finds the player view in YouTube's accessibility tree; if it can not find one it shows nothing (so the feed / library stay usable).
 * "fixed" always covers from sh_pct % downwards while YouTube is open in portrait.
 */
object Shield {
    val YT = setOf("com.google.android.youtube")

    fun on(c: Context) = Cfg.bool(c, "sh_on", false)
    fun s(c: Context) = Cfg.int(c, "sh_s", 0)
    fun e(c: Context) = Cfg.int(c, "sh_e", 0)
    fun mode(c: Context) = Cfg.str(c, "sh_mode", "auto")
    fun pct(c: Context) = Cfg.int(c, "sh_pct", 36).coerceIn(15, 80)
    /** Search-only mode (YouTube): Home / Subscriptions / Library feed and Shorts are covered; Search + search results + the video itself stay usable. */
    fun srch(c: Context) = Cfg.bool(c, "sh_srch", false)
    fun pausedUntil(c: Context) = Cfg.long(c, "sh_pause", 0L)
    fun pause(c: Context, ms: Long) = Cfg.put(c, "sh_pause", System.currentTimeMillis() + ms)

    /** The "video chunna hai" pause: PAUSE_MIN minutes each, at most PAUSE_PER_WIN times inside any WIN_MIN minutes. */
    const val PAUSE_MIN = 2
    const val PAUSE_PER_WIN = 2
    const val WIN_MIN = 30
    private fun recentPauses(c: Context): List<Long> {
        val now = System.currentTimeMillis()
        return Cfg.str(c, "sh_pt", "").split(",").mapNotNull { it.toLongOrNull() }.filter { now - it in 0 until WIN_MIN * 60_000L }
    }
    fun pausesLeft(c: Context): Int = (PAUSE_PER_WIN - recentPauses(c).size).coerceAtLeast(0)
    /** Minutes until the next pause is allowed (0 = one is available now). */
    fun waitMin(c: Context): Int {
        if (pausesLeft(c) > 0) return 0
        val oldest = recentPauses(c).minOrNull() ?: return 0
        return ((oldest + WIN_MIN * 60_000L - System.currentTimeMillis() + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
    }
    /** Starts the pause if one is allowed right now. */
    fun usePause(c: Context): Boolean {
        if (pausesLeft(c) <= 0) return false
        Cfg.put(c, "sh_pt", (recentPauses(c) + System.currentTimeMillis()).joinToString(","))
        pause(c, PAUSE_MIN * 60_000L)
        return true
    }

    fun set(c: Context, on: Boolean, s: Int, e: Int, mode: String, pct: Int, srch: Boolean = false) {
        Cfg.setBool(c, "sh_srch", srch)
        Cfg.setBool(c, "sh_on", on)
        Cfg.put(c, "sh_s", s.coerceIn(0, 1439)); Cfg.put(c, "sh_e", e.coerceIn(0, 1439))
        Cfg.put(c, "sh_mode", if (mode == "fixed") "fixed" else "auto")
        Cfg.put(c, "sh_pct", pct.coerceIn(15, 80))
        Cfg.put(c, "sh_pause", 0L)
    }

    fun inWindow(c: Context): Boolean {
        val a = s(c); val b = e(c)
        if (a == b) return true
        val cal = Calendar.getInstance()
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (a < b) m in a until b else (m >= a || m < b)
    }

    /** Should the shield be covering YouTube right now? */
    fun active(c: Context) = on(c) && inWindow(c) && System.currentTimeMillis() >= pausedUntil(c)

    /** Last scan of the YouTube window (for the "Check" button in the app). */
    @Volatile var debug: String = "YouTube has not been scanned yet. Open a class video in YouTube, wait 2-3 seconds, then come back and tap Check."
}
