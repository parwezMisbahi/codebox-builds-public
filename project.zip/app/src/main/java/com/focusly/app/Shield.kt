package com.focusly.app

import android.content.Context
import java.util.Calendar

/**
 * Class Shield: while the real YouTube app is open (portrait), everything BELOW the video is covered by an
 * opaque overlay that eats touches (recommendations, comments, Shorts shelf). The video itself and its controls
 * (play / pause / seek / settings > speed) stay fully usable, so YouTube Premium speed still works.
 *
 * The overlay lives in BlockService (needs the accessibility window list). Settings are stored in Cfg:
 *   sh_on (bool), sh_s / sh_e (minutes of day; equal = always), sh_mode ("auto" | "fixed"), sh_pct (fixed mode: video bottom, % of window height).
 * "auto" finds the player view in YouTube's accessibility tree; if it can not find one it shows nothing (so the feed / library stay usable).
 * "fixed" always covers from sh_pct % downwards while YouTube is open in portrait.
 */
object Shield {
    val YT = setOf("com.google.android.youtube")

    fun on(c: Context) = Cfg.bool(c, "sh_on", false)
    fun s(c: Context) = Cfg.int(c, "sh_s", 0)
    fun e(c: Context) = Cfg.int(c, "sh_e", 0)
    fun mode(c: Context) = Cfg.str(c, "sh_mode", "auto")
    fun pct(c: Context) = Cfg.int(c, "sh_pct", 36).coerceIn(15, 80)
    fun pausedUntil(c: Context) = Cfg.long(c, "sh_pause", 0L)
    fun pause(c: Context, ms: Long) = Cfg.put(c, "sh_pause", System.currentTimeMillis() + ms)

    fun set(c: Context, on: Boolean, s: Int, e: Int, mode: String, pct: Int) {
        Cfg.setBool(c, "sh_on", on)
        Cfg.put(c, "sh_s", s.coerceIn(0, 1439)); Cfg.put(c, "sh_e", e.coerceIn(0, 1439))
        Cfg.put(c, "sh_mode", if (mode == "fixed") "fixed" else "auto")
        Cfg.put(c, "sh_pct", pct.coerceIn(15, 80))
        Cfg.put(c, "sh_pause", 0L)
    }

    fun inWindow(c: Context): Boolean {
        val a = s(c); val b = e(c)
        if (a == b) return true
        val cal = Calendar.getInstance()
        val m = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (a < b) m in a until b else (m >= a || m < b)
    }

    /** Should the shield be covering YouTube right now? */
    fun active(c: Context) = on(c) && inWindow(c) && System.currentTimeMillis() >= pausedUntil(c)

    /** Last scan of the YouTube window (for the "Check" button in the app). */
    @Volatile var debug: String = "YouTube abhi tak scan nahi hua. YouTube mein class video kholo, 2-3 second ruko, phir wapas aakar Check dabao."
}
