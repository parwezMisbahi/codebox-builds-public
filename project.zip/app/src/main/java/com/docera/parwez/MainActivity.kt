package com.docera.parwez

import android.Manifest
import android.graphics.Bitmap
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ClipData
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.net.Uri
import android.widget.Toast
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.FileOutputStream
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream
import java.io.RandomAccessFile

// FragmentActivity (a subclass of ComponentActivity) is required by BiometricPrompt.
class MainActivity : FragmentActivity() {

    companion object {
        private const val STORAGE_PREFS = "vaultnotes_storage_prefs"
        private const val KEY_FOLDER_URIS = "pdf_folder_tree_uris"
        private const val MAX_FOLDER_DEPTH = 8
        private const val MAX_ENTRIES_PER_FOLDER = 20000
        private const val MAX_TOTAL_ALL_FILES_SCAN = 60000
        private const val SCAN_BUDGET_MS = 75_000L
        // Folders that only hold photos / videos / voice notes. Telegram and WhatsApp keep tens of thousands of files in them;
        // walking them used up the scan limit before the document folders (where the PDFs are) were reached.
        private val MEDIA_DIR_NAMES = setOf(
            "dcim", "movies", "music", "ringtones", "alarms", "notifications", "podcasts", "thumbnails", "cache", "stickers",
            "sent", "private", "wallpaper", "profile photos"
        )
        private val MEDIA_DIR_PREFIXES = listOf(
            "whatsapp images", "whatsapp video", "whatsapp audio", "whatsapp voice", "whatsapp animated", "whatsapp stickers",
            "whatsapp profile", "whatsapp wallpaper", "whatsapp business images", "whatsapp business video",
            "whatsapp business audio", "whatsapp business voice", "telegram images", "telegram video", "telegram audio",
            "telegram stories", "telegram stickers"
        )
        fun isMediaOnlyDir(name: String): Boolean {
            val l = name.lowercase()
            return l in MEDIA_DIR_NAMES || MEDIA_DIR_PREFIXES.any { l.startsWith(it) }
        }
    }

    private lateinit var webView: WebView
    private val inkBridge = InkBridge { code -> runOnUiThread { try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {} } }
    // Word / sentence translation for selected text in the reader
    private val trBridge: TranslateBridge by lazy { TranslateBridge(TranslateBridge.JsRunner { code -> runOnUiThread { try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {} } }) }
    // Website tabs of the PDF reader: real WebViews laid over the reader, without any app bridges
    private val webTabs: WebTabs by lazy { WebTabs(this, WebTabs.JsRunner { code -> runOnUiThread { try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {} } }) }
    @Volatile private var hideSelMenu = false

    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Incoming PDF state
    @Volatile
    private var hasIncomingPdf: Boolean = false
    @Volatile
    private var incomingPdfName: String? = null
    @Volatile
    private var incomingPdfSize: Long = 0L
    @Volatile
    private var incomingPdfError: String? = null
    @Volatile
    private var currentTempFile: File? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris: Array<Uri>? = if (result.resultCode == RESULT_OK && result.data != null) {
            val clipData = result.data?.clipData
            if (clipData != null && clipData.itemCount > 0) {
                Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
            } else {
                result.data?.data?.let { arrayOf(it) }
            }
        } else {
            null
        }
        filePathCallback?.onReceiveValue(uris)
        filePathCallback = null
    }

    /** Window widget "open PDF" button: system file picker, the chosen PDF is then opened like an "Open with" PDF. */
    private val widgetPdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) {}
            onNewIntent(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf"))
        }
    }

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        try { webView.evaluateJavascript("window.__notifPerm&&window.__notifPerm(" + granted + ")", null) } catch (_: Throwable) {}
    }

    private val restorePickLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val u: Uri? = if (result.resultCode == RESULT_OK) result.data?.data else null
        if (u == null) {
            bkJs("window.__restorePicked&&window.__restorePicked('')")
        } else {
            restoreUri = u
            bkJs("window.__restoreBusy&&window.__restoreBusy()")
            Thread {
                val info = try {
                    restorePrepare(u)
                } catch (t: Throwable) {
                    org.json.JSONObject().put("err", t.toString()).toString()
                }
                bkJs("window.__restorePicked&&window.__restorePicked(" + org.json.JSONObject.quote(info) + ")")
            }.start()
        }
    }

    @Volatile
    private var biometricActive: Boolean = false

    private var pendingWebPermission: PermissionRequest? = null

    // ---- "Save as": the system file manager picker, the user chooses the folder and name ----
    private val stagedFiles = HashMap<String, Pair<File, String>>()   // id -> (temp file, mime)
    // ---- restoring a backup: the app reads the zip in small pieces, it is never handed to the WebView as one giant file ----
    @Volatile private var restoreUri: Uri? = null
    @Volatile private var restoreCache: File? = null
    private var pendingSaveId: String? = null
    private var printWv: WebView? = null   // kept alive while the system print dialog is open

    private class SaveAsContract : ActivityResultContract<Pair<String, String>, Uri?>() {
        override fun createIntent(context: Context, input: Pair<String, String>): Intent =
            Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE)
                .setType(input.second.ifBlank { "application/octet-stream" })
                .putExtra(Intent.EXTRA_TITLE, input.first)

        override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
            if (resultCode == Activity.RESULT_OK) intent?.data else null
    }

    private val saveAsLauncher = registerForActivityResult(SaveAsContract()) { uri ->
        val id = pendingSaveId
        pendingSaveId = null
        val item = if (id != null) synchronized(stagedFiles) { stagedFiles.remove(id) } else null
        var ok = false
        var msg = ""
        if (item == null) {
            msg = "file missing"
        } else if (uri == null) {
            msg = "cancelled"
        } else {
            try {
                contentResolver.openOutputStream(uri, "w")?.use { out ->
                    item.first.inputStream().use { it.copyTo(out) }
                } ?: throw FileNotFoundException("cannot write")
                ok = true
            } catch (e: Exception) {
                msg = e.localizedMessage ?: "write failed"
            }
        }
        try { item?.first?.parentFile?.deleteRecursively() } catch (_: Exception) {}
        try {
            webView.evaluateJavascript(
                "if(window.__saveAsDone){window.__saveAsDone($ok,${JSONObject.quote(msg)})}", null
            )
        } catch (_: Throwable) {
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val req = pendingWebPermission
        pendingWebPermission = null
        if (req != null) {
            val allowed = req.resources.filter { res ->
                when (res) {
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                        result[Manifest.permission.RECORD_AUDIO] == true ||
                            hasPerm(Manifest.permission.RECORD_AUDIO)
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                        result[Manifest.permission.CAMERA] == true ||
                            hasPerm(Manifest.permission.CAMERA)
                    else -> false
                }
            }.toTypedArray()
            try {
                if (allowed.isNotEmpty()) req.grant(allowed) else req.deny()
            } catch (_: Exception) {
            }
        }
    }

    private fun hasPerm(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    // --- YouTube tabs: the player lives in an iframe of https://docera.yt/yt.html (answered in-app) so that
    //     YouTube gets a normal https Referer (a file:// page sends none and YouTube then refuses to play). ---
    private val ytHost = "docera.yt"

    private fun ytFrameHost(h: String?): Boolean {
        val x = (h ?: "").lowercase()
        return listOf(
            "youtube.com", "youtube-nocookie.com", "google.com", "googlevideo.com", "gstatic.com",
            "ytimg.com", "doubleclick.net", "googleapis.com", "googlesyndication.com"
        ).any { x == it || x.endsWith(".$it") }
    }

    /** VideoDL (separate app) downloads the DVL videos; Docera only plays the finished files, so its own size stays small. */
    private val VDL_PKG = "com.parwez.videodl"
    private val VDL_HOST = "docera.vid"
    private val VDL_AUTH = "content://com.parwez.videodl.bridge"

    /** https://docera.vid/v/<download id>  ->  the file from VideoDL, with Range support so the video can seek. */
    private fun vdlStream(u: Uri, rq: WebResourceRequest): WebResourceResponse {
        val cors = mutableMapOf("Access-Control-Allow-Origin" to "*", "Accept-Ranges" to "bytes", "Cache-Control" to "no-store")
        fun fail(code: Int, msg: String) =
            WebResourceResponse("text/plain", "utf-8", code, msg, cors, java.io.ByteArrayInputStream(ByteArray(0)))
        try {
            val id = (u.path ?: "").removePrefix("/v/")
            if (!Regex("[A-Za-z0-9-]+").matches(id)) return fail(404, "Not Found")
            val pfd = contentResolver.openFileDescriptor(Uri.parse("$VDL_AUTH/file/$id"), "r") ?: return fail(404, "Not Found")
            val total = pfd.statSize
            var start = 0L
            var end = total - 1
            val range = rq.requestHeaders.entries.firstOrNull { it.key.equals("Range", true) }?.value
            var partial = false
            if (range != null) {
                val m = Regex("bytes=(\\d*)-(\\d*)").find(range)
                if (m != null) {
                    val a = m.groupValues[1]
                    val b = m.groupValues[2]
                    if (a.isEmpty() && b.isNotEmpty()) { start = (total - b.toLong()).coerceAtLeast(0) }
                    else if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1) }
                    partial = true
                }
            }
            if (start >= total) { pfd.close(); return fail(416, "Range Not Satisfiable") }
            val len = end - start + 1
            // positional reads (pread): several range requests of the same file run at the same time and must not
            // share one file offset (that corrupted the video and stopped it after a while)
            val ch = java.io.FileInputStream(pfd.fileDescriptor).channel
            val body = object : InputStream() {
                var pos = start
                var left = len
                override fun read(): Int {
                    val one = ByteArray(1)
                    return if (read(one, 0, 1) <= 0) -1 else one[0].toInt() and 0xff
                }
                override fun read(b: ByteArray, off: Int, n: Int): Int {
                    if (left <= 0) return -1
                    val want = minOf(n.toLong(), left).toInt()
                    val r = ch.read(java.nio.ByteBuffer.wrap(b, off, want), pos)
                    if (r > 0) { pos += r; left -= r }
                    return r
                }
                override fun close() { try { ch.close() } catch (_: Exception) {}; try { pfd.close() } catch (_: Exception) {} }
            }
            cors["Content-Length"] = len.toString()
            if (partial) cors["Content-Range"] = "bytes $start-$end/$total"
            return WebResourceResponse("video/mp4", null, if (partial) 206 else 200, if (partial) "Partial Content" else "OK", cors, body)
        } catch (_: Exception) {
            return fail(404, "Not Found")
        }
    }

    private fun ytHttp(url: String, body: String?): String {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI")
        if (body != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Origin", "https://www.youtube.com")
            c.setRequestProperty("Referer", "https://www.youtube.com/")
            c.setRequestProperty("X-YouTube-Client-Name", "1")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        return try {
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun ytFindText(n: Any?, key: String): String {
        when (n) {
            is JSONObject -> {
                n.optJSONObject(key)?.optString("text")?.takeIf { it.isNotEmpty() }?.let { return it }
                val it = n.keys()
                while (it.hasNext()) { val r = ytFindText(n.opt(it.next()), key); if (r.isNotEmpty()) return r }
            }
            is JSONArray -> for (i in 0 until n.length()) { val r = ytFindText(n.opt(i), key); if (r.isNotEmpty()) return r }
        }
        return ""
    }

    /** Last resort: take every video id that appears in the data, in order (titles are filled in by the page). */
    private fun ytIdsOnly(raw: String, vids: JSONArray, seen: HashSet<String>) {
        for (m in Regex("\"videoId\"\\s*:\\s*\"([A-Za-z0-9_-]{11})\"").findAll(raw)) {
            if (seen.add(m.groupValues[1])) vids.put(JSONObject().put("v", m.groupValues[1]).put("t", "").put("d", ""))
        }
    }

    /** Walks the YouTube page data and collects every playlist entry (and the "load more" token). */
    private fun ytCollect(n: Any?, vids: JSONArray, seen: HashSet<String>, tok: Array<String?>, title: Array<String?>) {
        when (n) {
            is JSONObject -> {
                n.optJSONObject("playlistVideoRenderer")?.let { r ->
                    val id = r.optString("videoId")
                    if (id.isNotEmpty() && seen.add(id)) {
                        val t = r.optJSONObject("title")
                        val name = t?.optJSONArray("runs")?.optJSONObject(0)?.optString("text")
                            ?: t?.optString("simpleText") ?: id
                        vids.put(JSONObject().put("v", id).put("t", name).put("d", r.optJSONObject("lengthText")?.optString("simpleText") ?: ""))
                    }
                }
                // newer YouTube pages describe each playlist row as a "lockup"
                n.optJSONObject("lockupViewModel")?.let { r ->
                    val id = r.optString("contentId")
                    val type = r.optString("contentType")
                    if (id.length == 11 && (type.isEmpty() || type.contains("VIDEO")) && seen.add(id)) {
                        val name = r.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
                            ?.optJSONObject("title")?.optString("content") ?: ""
                        vids.put(JSONObject().put("v", id).put("t", name).put("d", ytFindText(r, "thumbnailBadgeViewModel")))
                    }
                }
                for (key in arrayOf("playlistPanelVideoRenderer", "gridVideoRenderer")) {
                    n.optJSONObject(key)?.let { r ->
                        val id = r.optString("videoId")
                        if (id.isNotEmpty() && seen.add(id)) {
                            val t = r.optJSONObject("title")
                            val name = t?.optJSONArray("runs")?.optJSONObject(0)?.optString("text") ?: t?.optString("simpleText") ?: ""
                            vids.put(JSONObject().put("v", id).put("t", name).put("d", r.optJSONObject("lengthText")?.optString("simpleText") ?: ""))
                        }
                    }
                }
                n.optJSONObject("continuationItemRenderer")?.let { r ->
                    r.optJSONObject("continuationEndpoint")?.optJSONObject("continuationCommand")?.optString("token")
                        ?.takeIf { it.isNotEmpty() }?.let { tok[0] = it }
                }
                n.optJSONObject("playlistMetadataRenderer")?.optString("title")?.takeIf { it.isNotEmpty() }?.let { if (title[0] == null) title[0] = it }
                val it = n.keys()
                while (it.hasNext()) ytCollect(n.opt(it.next()), vids, seen, tok, title)
            }
            is JSONArray -> for (i in 0 until n.length()) ytCollect(n.opt(i), vids, seen, tok, title)
        }
    }

    private fun fetchYtPlaylist(list: String): String {
        var key = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"   // YouTube's public web key (the same one youtube.com itself uses)
        var ver = "2.20250101.00.00"
        val vids = JSONArray()
        val seen = HashSet<String>()
        val tok = arrayOfNulls<String>(1)
        val title = arrayOfNulls<String>(1)
        val errs = StringBuilder()
        fun browse(extra: (JSONObject) -> Unit): JSONObject {
            val body = JSONObject().put("context", JSONObject().put("client",
                JSONObject().put("clientName", "WEB").put("clientVersion", ver).put("hl", "en").put("gl", "US")))
            extra(body)
            return JSONObject(ytHttp("https://www.youtube.com/youtubei/v1/browse?key=$key&prettyPrint=false", body.toString()))
        }
        // 1) the same data call the YouTube website makes
        var raw = ""
        try {
            val j = browse { it.put("browseId", "VL$list") }
            raw = j.toString()
            ytCollect(j, vids, seen, tok, title)
        } catch (e: Throwable) { errs.append("api: ").append(e.message ?: e.javaClass.simpleName).append(". ") }
        // 2) fallback: read the playlist web page
        if (vids.length() == 0) {
            try {
                val html = ytHttp("https://www.youtube.com/playlist?list=$list&hl=en", null)
                Regex("\"INNERTUBE_API_KEY\"\\s*:\\s*\"([^\"]+)\"").find(html)?.groupValues?.get(1)?.let { key = it }
                Regex("\"INNERTUBE_CLIENT_VERSION\"\\s*:\\s*\"([^\"]+)\"").find(html)?.groupValues?.get(1)?.let { ver = it }
                val m = Regex("ytInitialData\\s*=\\s*(\\{.*?\\});\\s*</script>", RegexOption.DOT_MATCHES_ALL).find(html)
                if (m != null) { raw += m.groupValues[1]; ytCollect(JSONObject(m.groupValues[1]), vids, seen, tok, title) }
                else errs.append("page: no data. ")
            } catch (e: Throwable) { errs.append("page: ").append(e.message ?: e.javaClass.simpleName).append(". ") }
        }
        if (vids.length() == 0 && raw.isNotEmpty()) ytIdsOnly(raw, vids, seen)
        if (vids.length() == 0) throw IllegalStateException(errs.toString().ifBlank { "no videos found (data " + raw.length + " bytes)" })
        var pages = 0
        while (tok[0] != null && pages < 30 && vids.length() < 1500) {
            pages++
            val t = tok[0]!!
            tok[0] = null
            try { ytCollect(browse { it.put("continuation", t) }, vids, seen, tok, title) } catch (_: Throwable) { break }
        }
        return JSONObject().put("title", title[0] ?: "").put("videos", vids).toString()
    }

    inner class AndroidVdlBridge {
        @JavascriptInterface
        fun installed(): Boolean = try {
            packageManager.getPackageInfo(VDL_PKG, 0); true
        } catch (_: Exception) { false }

        /**
         * Sends a video link to VideoDL's download service: it downloads in the background, no VideoDL screen opens.
         * (If the service cannot be started, VideoDL's screen is opened as before.)
         */
        @JavascriptInterface
        fun download(url: String, title: String): Boolean {
            if (!installed()) return false
            try {
                val i = Intent("com.parwez.videodl.action.DOWNLOAD")
                    .setClassName(VDL_PKG, "$VDL_PKG.DownloadService")
                    .putExtra("url", url).putExtra("title", title).putExtra("height", 720)
                ContextCompat.startForegroundService(this@MainActivity, i)
                return true
            } catch (_: Exception) { }
            return try {
                val i = Intent("com.parwez.videodl.action.DOWNLOAD")
                    .setClassName(VDL_PKG, "$VDL_PKG.MainActivity")
                    .putExtra("url", url).putExtra("title", title).putExtra("height", 720)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runOnUiThread { try { startActivity(i) } catch (_: Exception) {} }
                true
            } catch (_: Exception) { false }
        }

        /** [{id,url,title,state,progress,name,size}] of VideoDL's downloads, or "" when VideoDL is not available. */
        @JavascriptInterface
        fun list(): String {
            if (!installed()) return ""
            return try {
                val arr = JSONArray()
                contentResolver.query(Uri.parse("$VDL_AUTH/list"), null, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        arr.put(JSONObject().apply {
                            put("id", c.getString(0)); put("url", c.getString(1)); put("title", c.getString(2))
                            put("state", c.getString(3)); put("progress", c.getInt(4))
                            put("name", c.getString(5)); put("size", c.getLong(6))
                        })
                    }
                }
                arr.toString()
            } catch (_: Exception) { "" }
        }

        /**
         * Lists the videos of a YouTube playlist (id, title, length). Runs in the background and answers by calling
         * window.onPlaylist(list, json) in the page. Nothing needs to be installed and no key is used.
         */
        @JavascriptInterface
        fun playlist(list: String) {
            if (!Regex("[A-Za-z0-9_-]{10,64}").matches(list)) return
            Thread {
                var out = ""
                try { out = fetchYtPlaylist(list) }
                catch (e: Throwable) { out = JSONObject().put("error", (e.message ?: e.javaClass.simpleName).take(160)).toString() }
                val js = "if(window.onPlaylist)window.onPlaylist(" + JSONObject.quote(list) + "," + JSONObject.quote(out) + ")"
                runOnUiThread { try { webView.evaluateJavascript(js, null) } catch (_: Throwable) {} }
            }.start()
        }

        /** Local web address (127.0.0.1 only) that plays a downloaded video, or "" when it cannot be served. */
        @JavascriptInterface
        fun streamUrl(id: String): String = try { VdlHttp.url(applicationContext, id) } catch (_: Throwable) { "" }

        /** The text shared into Docera (a YouTube link), once. */
        @JavascriptInterface
        fun takeShared(): String {
            val t = sharedText ?: return ""
            sharedText = null
            return t
        }

        @JavascriptInterface
        fun open() {
            runOnUiThread {
                try {
                    val i = packageManager.getLaunchIntentForPackage(VDL_PKG)
                    if (i != null) startActivity(i)
                } catch (_: Exception) {}
            }
        }
    }

    /** Page that asks the YouTube player (IFrame API, like Focusly's Class Player) for the list of videos of a playlist. */
    private fun ytPlaylistPage(u: Uri): WebResourceResponse {
        val list = (u.getQueryParameter("list") ?: "").takeIf { Regex("[A-Za-z0-9_-]{10,64}").matches(it) } ?: ""
        val html = "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>html,body{margin:0;height:100%;background:#000}#yt{width:100%;height:100%}</style></head><body><div id=\"yt\"></div>" +
            "<script>var L=" + JSONObject.quote(list) + ",P=null,T=0,last='';" +
            "function send(){try{var pl=P.getPlaylist();if(pl&&pl.length){var j=pl.join();if(j!==last){last=j;parent.postMessage({ytpl:pl,list:L},'*')}}}catch(e){}}" +
            "function onYouTubeIframeAPIReady(){if(!L)return;P=new YT.Player('yt',{width:'100%',height:'100%',host:'https://www.youtube.com'," +
            "playerVars:{playsinline:1,rel:0,fs:0,origin:'https://docera.yt'}," +
            "events:{onReady:function(){try{P.mute();P.cuePlaylist({listType:'playlist',list:L})}catch(e){}}," +
            "onStateChange:function(){send()},onError:function(){send()}}});" +
            "T=setInterval(function(){send()},500);setTimeout(function(){clearInterval(T)},30000)}" +
            "</script><script src=\"https://www.youtube.com/iframe_api\"></script></body></html>"
        return WebResourceResponse(
            "text/html", "utf-8", 200, "OK", mapOf("Cache-Control" to "no-store"),
            java.io.ByteArrayInputStream(html.toByteArray(Charsets.UTF_8))
        )
    }

    private fun ytPage(u: Uri): WebResourceResponse {
        if ((u.path ?: "") == "/pl.html") return ytPlaylistPage(u)
        val v = (u.getQueryParameter("v") ?: "").takeIf { Regex("[A-Za-z0-9_-]{11}").matches(it) }
        val list = (u.getQueryParameter("list") ?: "").takeIf { Regex("[A-Za-z0-9_-]{10,64}").matches(it) }
        // t = seconds already watched: the video continues from there
        val t = (u.getQueryParameter("t") ?: "").toIntOrNull()?.takeIf { it in 1..864000 }
        val src = when {
            v != null -> "https://www.youtube.com/embed/$v?playsinline=1&rel=0&autoplay=1&enablejsapi=1&origin=https%3A%2F%2Fdocera.yt" + (if (list != null) "&list=$list" else "") + (if (t != null) "&start=$t" else "")
            list != null -> "https://www.youtube.com/embed/videoseries?list=$list&playsinline=1&rel=0&autoplay=1&enablejsapi=1&origin=https%3A%2F%2Fdocera.yt"
            else -> ""
        }
        val html = "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>html,body{margin:0;height:100%;background:#000}iframe{position:absolute;left:0;top:0;width:100%;height:100%;border:0}</style>" +
            "</head><body>" +
            (if (src.isNotEmpty())
                "<iframe id=\"f\" src=\"$src\" allow=\"autoplay; encrypted-media; picture-in-picture; fullscreen\" allowfullscreen referrerpolicy=\"strict-origin-when-cross-origin\"></iframe>"
            else "") +
            // relay: Docera page <-> YouTube player (play / pause / speed commands go in, state comes back)
            "<script>var f=document.getElementById('f');" +
            "addEventListener('message',function(e){if(!f)return;" +
            "if(e.source===parent){try{f.contentWindow.postMessage(typeof e.data==='string'?e.data:JSON.stringify(e.data),'*')}catch(x){}}" +
            "else if(e.source===f.contentWindow){try{parent.postMessage({ytm:e.data},'*')}catch(x){}}});" +
            "function L(){try{f.contentWindow.postMessage(JSON.stringify({event:'listening',id:1,channel:'widget'}),'*')}catch(x){}}" +
            "if(f)f.addEventListener('load',function(){L();setTimeout(L,700);setTimeout(L,2200)});</script>" +
            "</body></html>"
        return WebResourceResponse(
            "text/html", "utf-8", 200, "OK", mapOf("Cache-Control" to "no-store"),
            java.io.ByteArrayInputStream(html.toByteArray(Charsets.UTF_8))
        )
    }

    // full-screen button of the YouTube player
    private var customView: android.view.View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private fun hideCustomView() {
        val v = customView ?: return
        try { (window.decorView as android.widget.FrameLayout).removeView(v) } catch (_: Throwable) {}
        customView = null
        try { customCb?.onCustomViewHidden() } catch (_: Throwable) {}
        customCb = null
    }

    // --- Auto-import from device storage: folder picker (Storage Access Framework) ---
    private val folderPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val treeUri = if (result.resultCode == RESULT_OK) result.data?.data else null
        if (treeUri == null) {
            notifyFolderPickResult(false, null)
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some providers (or File Managers) don't support persistable permission.
            // We still remember the folder below; it just may need to be re-picked
            // later if the OS revokes temporary access. Never crash here.
        }
        val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
        val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
        current.add(treeUri.toString())
        prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
        notifyFolderPickResult(true, folderDisplayName(treeUri))
    }

    // --- Auto-import from device storage: "All files access" (whole storage scan) ---
    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> notifyAllFilesAccessChanged() }

    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> notifyAllFilesAccessChanged() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NativePdfEngine.cleanup(applicationContext)

        // Ask for the notification permission on every app open until it is granted (Android 13+).
        if (android.os.Build.VERSION.SDK_INT >= 33 && !SylAlert.canNotify(this)) {
            window.decorView.postDelayed({
                try { notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS) } catch (_: Throwable) {}
            }, 800)
        }

        // Camera / microphone permissions are now requested only when a feature
        // actually needs them (see onPermissionRequest below), not at app start.

        // Process incoming intent (e.g. Open with from File Manager)
        handleIntent(intent)

        webView = object : WebView(this@MainActivity) {
            // Note editor open: no Cut / Copy / Paste / Select all pop-up on text select (selection + handles still work)
            override fun startActionMode(callback: android.view.ActionMode.Callback?): android.view.ActionMode? =
                super.startActionMode(if (hideSelMenu && callback != null) NoMenuActionCallback(callback) else callback)
            override fun startActionMode(callback: android.view.ActionMode.Callback?, type: Int): android.view.ActionMode? =
                super.startActionMode(if (hideSelMenu && callback != null) NoMenuActionCallback(callback) else callback, type)
        }.apply {
            // Videos played from VideoDL used to be kept in the WebView cache (Docera size grew). Clear that once.
            try { val pf = getSharedPreferences("docera_misc", MODE_PRIVATE); if (!pf.getBoolean("vdl_cache_cleared", false)) { clearCache(true); pf.edit().putBoolean("vdl_cache_cleared", true).apply() } } catch (_: Throwable) {}
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                useWideViewPort = true
                loadWithOverviewMode = false
                // Native WebView pinch-zoom OFF: it zoomed the whole app UI. PDF zoom is
                // handled by the app's own JS pinch-to-zoom inside the PDF viewer only.
                displayZoomControls = false
                setSupportZoom(false)
                builtInZoomControls = false
                textZoom = 100
                mediaPlaybackRequiresUserGesture = false
                // SECURITY: a page loaded from file:// must NOT be able to read other files or other origins
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = false
                }
            }

            webViewClient = object : WebViewClient() {
                // SECURITY: the WebView (and its JS bridges) may only ever show Docera's own page.
                // Anything else (web links, intent:, file:, content:) is refused or handed to the system.
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val rq = request ?: return true
                    val u = rq.url ?: return true
                    val sc = u.scheme ?: return true
                    if (sc == "file" && (u.path ?: "").startsWith("/android_asset/")) return false
                    if (sc == "https" && (u.host == NativePdfEngine.HOST || u.host == ArchiveStream.HOST)) return false
                    if (sc == "blob" || (sc == "about" && u.toString() == "about:blank")) return false
                    if (sc == "https" && (u.host == ytHost || (!rq.isForMainFrame && ytFrameHost(u.host)))) return false
                    if (rq.isForMainFrame && rq.hasGesture() && (sc == "http" || sc == "https" || sc == "mailto" || sc == "tel")) {
                        try { startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    }
                    return true
                }

                // Native PDF engine: https://docera.pdf/... is answered in-app (never touches the network)
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val u = request?.url
                    // pdf.js character maps (CJK etc.) come from the app's assets through the in-app host,
                    // because a file:// page may no longer read other files itself.
                    if (u != null && u.host == NativePdfEngine.HOST && (u.path ?: "").startsWith("/cmaps/")) {
                        val nm = (u.path ?: "").removePrefix("/cmaps/")
                        return try {
                            if (!Regex("[A-Za-z0-9._-]+").matches(nm)) throw IllegalArgumentException("bad name")
                            WebResourceResponse(
                                "application/octet-stream", null, 200, "OK",
                                mapOf("Access-Control-Allow-Origin" to "*"), assets.open("cmaps/$nm")
                            )
                        } catch (_: Exception) {
                            WebResourceResponse("text/plain", "utf-8", 404, "Not Found", mapOf("Access-Control-Allow-Origin" to "*"), java.io.ByteArrayInputStream(ByteArray(0)))
                        }
                    }
                    if (u != null && u.scheme == "https" && u.host == ytHost) return ytPage(u)
                    if (u != null && u.scheme == "https" && u.host == VDL_HOST && request != null) return vdlStream(u, request)
                    if (u != null && u.host == NativePdfEngine.HOST) return NativePdfEngine.handle(u)
                    if (u != null && u.host == ScanEngine.HOST) return ScanEngine.handle(u)
                    if (u != null && u.host == ArchiveStream.HOST && request != null) return ArchiveStream.handle(request)
                    return super.shouldInterceptRequest(view, request)
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (hasIncomingPdf) {
                        view?.evaluateJavascript(
                            "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                            null
                        )
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    // SECURITY: only Docera's own page may ask for the microphone / camera
                    if (request.origin?.scheme != "file") { request.deny(); return }
                    runOnUiThread {
                        val needed = mutableListOf<String>()
                        for (res in request.resources) {
                            when (res) {
                                PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO)
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                                    if (!hasPerm(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA)
                            }
                        }
                        val supported = request.resources.filter {
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE ||
                                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                        }.toTypedArray()
                        if (supported.isEmpty()) {
                            request.deny()
                        } else if (needed.isEmpty()) {
                            request.grant(supported)
                        } else {
                            pendingWebPermission?.let { try { it.deny() } catch (_: Exception) {} }
                            pendingWebPermission = request
                            permissionLauncher.launch(needed.toTypedArray())
                        }
                    }
                }

                override fun onShowCustomView(view: android.view.View?, callback: CustomViewCallback?) {
                    if (view == null || customView != null) {
                        try { callback?.onCustomViewHidden() } catch (_: Throwable) {}
                        return
                    }
                    customView = view
                    customCb = callback
                    view.setBackgroundColor(android.graphics.Color.BLACK)
                    (window.decorView as android.widget.FrameLayout).addView(
                        view,
                        android.widget.FrameLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    )
                }

                override fun onHideCustomView() {
                    hideCustomView()
                }

                override fun onPermissionRequestCanceled(request: PermissionRequest) {
                    if (pendingWebPermission === request) pendingWebPermission = null
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }
                    if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }

                    try {
                        filePickerLauncher.launch(intent)
                    } catch (e: Exception) {
                        this@MainActivity.filePathCallback?.onReceiveValue(null)
                        this@MainActivity.filePathCallback = null
                        return false
                    }
                    return true
                }
            }

            // Register bridge for passing incoming PDF data securely into WebView
            addJavascriptInterface(AndroidPdfBridge(), "AndroidPdfBridge")
            addJavascriptInterface(PdfEngineBridge(applicationContext), "AndroidPdfEngine")
            addJavascriptInterface(ScanEngineBridge(applicationContext), "AndroidScan")
            addJavascriptInterface(WebTabsBridge(webTabs), "AndroidWeb")
            addJavascriptInterface(trBridge, "AndroidTr")
            addJavascriptInterface(AppExitBridge(this@MainActivity), "AndroidApp")
            // Register bridge for auto-discovering PDFs already on the device (no import/copy needed)
            addJavascriptInterface(AndroidStorageBridge(), "AndroidStorageBridge")
            // Register bridge so the WebView's About screen can open mailto:/wa.me/Play Store
            // links in the user's actual Gmail/WhatsApp/Play Store app — plain <a href> links
            // to these schemes don't leave the WebView on their own since no
            // shouldOverrideUrlLoading is set up (intentionally, so normal in-app navigation
            // is left untouched everywhere else).
            addJavascriptInterface(AndroidLinkBridge(), "AndroidLinkBridge")
            addJavascriptInterface(AndroidVdlBridge(), "AndroidVdlBridge")
            addJavascriptInterface(AndroidDoceraBridge(), "AndroidDoceraBridge")
            // Biometric (fingerprint / face) unlock for the app lock screen
            addJavascriptInterface(AndroidBiometricBridge(), "AndroidBiometricBridge")
            addJavascriptInterface(AndroidWidgetBridge(), "AndroidWidget")
            // Saves exported/downloaded files (PDFs, images) into the real Downloads folder
            addJavascriptInterface(AndroidSaveBridge(), "AndroidSaveBridge")
            addJavascriptInterface(AndroidArchiveBridge(), "AndroidArchive")
            addJavascriptInterface(AndroidBackupBridge(), "AndroidBackup")
            addJavascriptInterface(inkBridge, "AndroidInk")
            MediaPlayService.sink = { cmd -> runOnUiThread { try { if (cmd != "close") { webView.onResume(); webView.resumeTimers() }; webView.evaluateJavascript("window.__mediaCmd&&window.__mediaCmd('" + cmd + "')", null) } catch (_: Throwable) {} } }
            addJavascriptInterface(MediaBridge(applicationContext), "AndroidMedia")

            loadUrl("file:///android_asset/index.html")
        }

        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    hideCustomView()
                } else if (webTabs.handleBack()) {
                    // went back inside the website tab
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    // The WebView may have no history entry left (e.g. after Docera reopened straight into a PDF) while the page
                    // still has something to close. The page handles Back itself and asks us to exit only when it is at the top.
                    webView.evaluateJavascript("(window.__nativeBack?window.__nativeBack():(window.AndroidApp&&AndroidApp.exit()))", null)
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        try {
            webView.onResume()
            webView.resumeTimers()
            webView.evaluateJavascript("window.__bgAudio&&window.__bgAudio(0)", null)
        } catch (_: Throwable) {
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            // a video that is playing: the page hands the sound to the native player (keeps going when locked)
            if (MediaPlayService.active) webView.evaluateJavascript("window.__bgAudio&&window.__bgAudio(1)", null)
            if (!MediaPlayService.active) webView.onPause()
        } catch (_: Throwable) {
        }
        try { webTabs.appPaused() } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try { MediaPlayService.sink = null; if (!MediaPlayService.audioMode) MediaPlayService.stop(this) } catch (_: Throwable) {}
        try { inkBridge.close() } catch (_: Throwable) {}
        try { webTabs.destroyAll() } catch (_: Throwable) {}
        try {
            webView.stopLoading()
            webView.removeJavascriptInterface("AndroidPdfBridge")
            webView.removeJavascriptInterface("AndroidStorageBridge")
            webView.removeJavascriptInterface("AndroidLinkBridge")
            webView.removeJavascriptInterface("AndroidBiometricBridge")
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView.destroy()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        if (widgetAction != null) {
            try { webView.evaluateJavascript("if(window.onWidgetAction)window.onWidgetAction()", null) } catch (_: Throwable) {}
        }
        if (hasIncomingPdf) {
            webView.evaluateJavascript(
                "if (typeof window.checkIncomingPdf === 'function') { window.checkIncomingPdf(); }",
                null
            )
        }
    }

    @Volatile private var widgetAction: String? = null
    @Volatile private var sharedText: String? = null

    /** True when the app was started on purpose for something new (widget action, new window, a PDF sent from another app):
     *  then the page must NOT jump back to where the app was left last time. */
    @Volatile private var freshLaunch = false

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        // Android replays the ORIGINAL intent (old Telegram PDF, old widget tap) when the app is opened again from Recents.
        // That is not a new request: ignore it, so the app simply resumes where it was left.
        if ((intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return
        if (intent.hasExtra("wa") || intent.hasExtra("nw")) freshLaunch = true
        intent.removeExtra("nw")
        intent.getStringExtra("wa")?.let {
            intent.removeExtra("wa")
            if (it == "pick") window.decorView.post { try { widgetPdfPicker.launch(arrayOf("application/pdf")) } catch (_: Throwable) {} }
            else widgetAction = it
        }
        val action = intent.action
        val type = intent.type

        // A link shared from the YouTube app: kept until the page asks for it (takeShared), then saved in the DVL
        if (action == Intent.ACTION_SEND && type?.startsWith("text/") == true) {
            val t = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrBlank()) {
                sharedText = t
                intent.removeExtra(Intent.EXTRA_TEXT)
                try { webView.evaluateJavascript("if(window.checkSharedLink)window.checkSharedLink()", null) } catch (_: Throwable) {}
            }
            return
        }

        val uri: Uri? = when (action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: intent.data
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_STREAM) ?: intent.data
                }
            }
            else -> null
        }

        // A .docera file (PDF / note with its highlights, drawings and voice) sent by another Docera user
        if (uri != null && isDoceraFile(uri, type)) {
            copyDocera(uri)
            return
        }

        if (uri == null) return

        // Verify if it is a PDF or generic file view intent
        val isPdf = type?.equals("application/pdf", ignoreCase = true) == true ||
                uri.toString().endsWith(".pdf", ignoreCase = true) ||
                uri.lastPathSegment?.endsWith(".pdf", ignoreCase = true) == true ||
                try {
                    contentResolver.getType(uri)?.equals("application/pdf", ignoreCase = true) == true
                } catch (_: Exception) {
                    false
                }

        if (!isPdf && type?.equals("application/octet-stream", ignoreCase = true) == true) return
        if (!isPdf && action != Intent.ACTION_VIEW) return

        copyPdfToCache(uri)
    }

    private var doceraFile: File? = null

    private fun displayName(uri: Uri): String {
        var nm: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i != -1 && c.moveToFirst()) nm = c.getString(i)
                }
            } catch (_: Exception) {}
        }
        return nm ?: (uri.lastPathSegment ?: "")
    }

    /** SECURITY: another app could send a file:// link that points at Docera's OWN private data (notes database, settings).
     *  Such a path is never opened from an incoming intent. */
    private fun isOwnPrivatePath(path: String): Boolean = try {
        val p = File(path).canonicalPath
        listOfNotNull(dataDir, filesDir, cacheDir, codeCacheDir, noBackupFilesDir).any { p == it.canonicalPath || p.startsWith(it.canonicalPath + File.separator) }
    } catch (_: Exception) { true }

    private fun isDoceraFile(uri: Uri, type: String?): Boolean {
        if (type.equals("application/vnd.docera.bundle", ignoreCase = true)) return true
        return displayName(uri).endsWith(".docera", ignoreCase = true)
    }

    private fun copyDocera(uri: Uri) {
        try {
            val target = File(cacheDir, "incoming.docera")
            val ins: InputStream = (try { contentResolver.openInputStream(uri) } catch (e: Exception) {
                if (uri.scheme == "file" && uri.path != null && !isOwnPrivatePath(uri.path!!)) FileInputStream(File(uri.path!!)) else throw e
            }) ?: return
            ins.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            doceraFile = if (target.length() > 0) target else null
        } catch (_: Exception) { doceraFile = null }
        try { webView.evaluateJavascript("if(window.checkIncomingDocera)window.checkIncomingDocera()", null) } catch (_: Throwable) {}
    }

    inner class AndroidDoceraBridge {
        @JavascriptInterface fun has(): Boolean = doceraFile?.exists() == true
        @JavascriptInterface fun size(): Long = doceraFile?.length() ?: 0L
        /** A piece of the received file as base64 (the page puts the pieces back together). */
        @JavascriptInterface fun chunk(offset: Long, len: Int): String {
            val f = doceraFile ?: return ""
            return try {
                java.io.RandomAccessFile(f, "r").use { r ->
                    r.seek(offset)
                    val b = ByteArray(len)
                    val n = r.read(b)
                    if (n <= 0) "" else Base64.encodeToString(b, 0, n, Base64.NO_WRAP)
                }
            } catch (_: Exception) { "" }
        }
        @JavascriptInterface fun clear() { try { doceraFile?.delete() } catch (_: Exception) {}; doceraFile = null }
    }

    private fun copyPdfToCache(uri: Uri) {
        incomingPdfError = null
        hasIncomingPdf = false

        // Extract display name
        var resolvedName: String? = null
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx != -1 && cursor.moveToFirst()) {
                        resolvedName = cursor.getString(nameIdx)
                    }
                }
            } catch (_: Exception) {
                // Ignore cursor query error and fall back
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = uri.lastPathSegment?.let { segment ->
                val lastSlash = segment.lastIndexOf('/')
                if (lastSlash != -1) segment.substring(lastSlash + 1) else segment
            }
        }
        if (resolvedName.isNullOrBlank()) {
            resolvedName = "Document.pdf"
        } else if (!resolvedName!!.endsWith(".pdf", ignoreCase = true)) {
            resolvedName = "$resolvedName.pdf"
        }
        incomingPdfName = resolvedName

        // Safely open stream using ContentResolver with permission handling
        try {
            val inputStream: InputStream = try {
                contentResolver.openInputStream(uri)
            } catch (e: Exception) {
                if (uri.scheme == "file" && uri.path != null && !isOwnPrivatePath(uri.path!!)) {
                    FileInputStream(File(uri.path!!))
                } else {
                    throw e
                }
            } ?: throw FileNotFoundException("Unable to open input stream for: $uri")

            val safePrefix = "open_with_" + System.currentTimeMillis()
            val targetFile = File(cacheDir, "$safePrefix.pdf")

            // Clean up any old temporary open_with_ files
            cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("open_with_") && file.name.endsWith(".pdf")) {
                    file.delete()
                }
            }

            inputStream.use { input ->
                targetFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            if (!targetFile.exists() || targetFile.length() == 0L) {
                targetFile.delete()
                incomingPdfError = "The selected PDF file is empty or could not be read."
                hasIncomingPdf = true
                return
            }

            currentTempFile = targetFile
            NativePdfEngine.incoming = targetFile
            incomingPdfSize = targetFile.length()
            hasIncomingPdf = true
        } catch (e: SecurityException) {
            incomingPdfError = "Permission denied to read this PDF file."
            hasIncomingPdf = true
        } catch (e: FileNotFoundException) {
            incomingPdfError = "The selected PDF file could not be found or opened."
            hasIncomingPdf = true
        } catch (e: Exception) {
            incomingPdfError = "Failed to open PDF: ${e.localizedMessage ?: "File inaccessible"}"
            hasIncomingPdf = true
        }
    }

    // ================= Biometric lock =================

    private fun notifyBiometricResult(success: Boolean, code: Int, msg: String) {
        biometricActive = false
        runOnUiThread {
            webView.evaluateJavascript(
                "if (typeof window.onBiometricResult === 'function') { window.onBiometricResult($success, $code, \"${jsonEscape(msg)}\"); }",
                null
            )
        }
    }

    private fun startBiometric(title: String, subtitle: String) {
        if (biometricActive) return
        biometricActive = true
        try {
            val callback = object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    notifyBiometricResult(true, 0, "")
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    notifyBiometricResult(false, errorCode, errString.toString())
                }
                // onAuthenticationFailed (a non-matching finger) is ignored: the prompt stays open.
            }
            val builder = BiometricPrompt.PromptInfo.Builder()
                .setTitle(if (title.isBlank()) "Unlock Docera" else title)
            if (subtitle.isNotBlank()) builder.setSubtitle(subtitle)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Biometrics, with the phone's own PIN/pattern as a fallback so the user can never be locked out.
                builder.setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
                )
            } else {
                builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .setNegativeButtonText("Cancel")
            }
            BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback)
                .authenticate(builder.build())
        } catch (e: Exception) {
            notifyBiometricResult(false, -1, e.localizedMessage ?: "Biometric error")
        }
    }

    /** Home-screen widgets <-> web UI. */
    inner class AndroidWidgetBridge {
        /** Action chosen on a home-screen widget (note / scan / last), returned once. */
        /** True once if this start came from a widget / new-window tap: the page then skips "resume where I left". */
        @JavascriptInterface
        fun launchedFresh(): Boolean {
            val f = freshLaunch
            freshLaunch = false
            return f
        }

        @JavascriptInterface
        fun pendingWidgetAction(): String {
            val a = widgetAction ?: return ""
            widgetAction = null
            return a
        }

        /** Remembers the PDF being read so the "Continue reading" widget can show it. */
        @JavascriptInterface
        fun setLastRead(name: String, page: Int, total: Int) {
            try { ReadWidget.save(applicationContext, name, page, total) } catch (_: Throwable) {}
        }

        /** Syllabus (page range + finish date) of the PDF being read, shown in the "Continue reading" widget. */
        @JavascriptInterface
        fun setLastReadSyl(from: Int, to: Int, end: Double) {
            try { ReadWidget.saveSyl(applicationContext, from, to, end.toLong()) } catch (_: Throwable) {}
        }

        /** Syllabus reminder numbers (pages left, finish time, pages read today) for the 8 pm "you are behind" notification. */
        @JavascriptInterface
        fun setSylAlert(enabled: Boolean, name: String, left: Int, end: Double, today: Int, day: String) {
            try { SylAlert.save(applicationContext, enabled, name, left, end.toLong(), today, day) } catch (_: Throwable) {}
        }

        /** Progress of every PDF that has a syllabus (JSON), the "all PDFs" switch and the reminder time: feeds notifications + summary widget. */
        @JavascriptInterface
        fun setSylHub(json: String, allOn: Boolean, hour: Int, minute: Int, times: String) {
            try { SylHub.save(applicationContext, json, allOn, hour, minute, times) } catch (_: Throwable) {}
        }

        /** Shows the syllabus notification right now: id = one PDF, "" = summary of all PDFs. */
        @JavascriptInterface
        fun sylShowNow(id: String): Boolean {
            return try {
                if (!SylAlert.canNotify(applicationContext)) { askNotifPermission(); false }
                else SylHub.showNow(applicationContext, id)
            } catch (_: Throwable) { false }
        }

        /** Asks for the notification permission (Android 13+); answers through window.__notifPerm(granted). */
        @JavascriptInterface
        fun askNotifPermission() {
            runOnUiThread {
                try {
                    if (SylAlert.canNotify(this@MainActivity)) webView.evaluateJavascript("window.__notifPerm&&window.__notifPerm(true)", null)
                    else notifPermLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                } catch (_: Throwable) {}
            }
        }

        /** First page of the PDF (base64 JPEG) shown as a small cover in the "Continue reading" widget. */
        @JavascriptInterface
        fun setLastReadThumb(name: String, b64: String) {
            try { ReadWidget.saveThumb(applicationContext, name, b64) } catch (_: Throwable) {}
        }
    }

    inner class AndroidBiometricBridge {
        /** "ok" | "none_enrolled" | "no_hardware" | "unavailable" */
        @JavascriptInterface
        fun status(): String {
            return try {
                when (BiometricManager.from(this@MainActivity)
                    .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
                    BiometricManager.BIOMETRIC_SUCCESS -> "ok"
                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "none_enrolled"
                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "no_hardware"
                    else -> "unavailable"
                }
            } catch (_: Exception) {
                "unavailable"
            }
        }

        /** PBKDF2 of the PIN (salted, 120k rounds) - far harder to brute-force than the old 32-bit hash. "" = not supported. */
        @JavascriptInterface
        fun hashPin(pin: String, saltHex: String): String = try {
            val salt = ByteArray(saltHex.length / 2) { saltHex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
            val h = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            h.joinToString("") { "%02x".format(it) }
        } catch (_: Throwable) { "" }

        /** Blocks screenshots / screen recording and hides the app preview in "recent apps". */
        @JavascriptInterface
        fun setSecure(on: Boolean) {
            runOnUiThread {
                try {
                    if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                    else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                } catch (_: Throwable) {}
            }
        }

        /** Result comes back through window.onBiometricResult(success, code, message). */
        @JavascriptInterface
        fun authenticate(title: String, subtitle: String) {
            runOnUiThread { startBiometric(title, subtitle) }
        }
    }


    // Opens a mailto:/https:// (WhatsApp, Play Store, etc.) link in the user's real
    // Gmail/WhatsApp/Play Store app, since the WebView itself can't handle those.
    inner class AndroidLinkBridge {

        /** Opens Docera's own page in Android Settings (used when the microphone permission was denied). */
        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                }
            }
        }
        /** Reader full screen: hides the system status bar (time, network, notifications) while a PDF is open; swiping down from the top shows it for a moment. */
        @JavascriptInterface
        fun setImmersive(on: Boolean) {
            runOnUiThread {
                try {
                    val w = window
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        val lp = w.attributes
                        lp.layoutInDisplayCutoutMode = if (on)
                            android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        else android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                        w.attributes = lp
                    }
                    val c = androidx.core.view.WindowCompat.getInsetsController(w, w.decorView)
                    if (on) {
                        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        c.hide(androidx.core.view.WindowInsetsCompat.Type.statusBars())
                    } else {
                        c.show(androidx.core.view.WindowInsetsCompat.Type.statusBars())
                    }
                } catch (_: Throwable) {}
            }
        }

        /** Brings the soft keyboard back (used after the keyboard's language picker, opened by long-pressing the spacebar, closes). */
        @JavascriptInterface
        fun showKeyboard() {
            runOnUiThread {
                try {
                    webView.requestFocus()
                    val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    imm.showSoftInput(webView, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                } catch (_: Throwable) {}
            }
        }

        /** Hides the soft keyboard (the write layer's keyboard button switched typing off). */
        @JavascriptInterface
        fun hideKeyboard() {
            runOnUiThread {
                try {
                    val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    imm.hideSoftInputFromWindow(webView.windowToken, 0)
                } catch (_: Throwable) {}
            }
        }

        /** Keeps the screen on while the reader's auto-scroll is running (so it does not go dark while reading hands-free). */
        @JavascriptInterface
        fun keepScreenOn(on: Boolean) {
            runOnUiThread {
                try {
                    if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } catch (_: Throwable) {}
            }
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                val uri = Uri.parse(url)
                // SECURITY: only plain web / mail / phone links (no intent:, file:, content: ...)
                if (uri.scheme?.lowercase() !in setOf("http", "https", "mailto", "tel", "upi")) return
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
            } catch (e: Exception) {
                // No app installed that can handle this link — silently ignore.
            }
        }
    }

    inner class AndroidPdfBridge {
        @JavascriptInterface
        fun hasIncomingPdf(): Boolean {
            return this@MainActivity.hasIncomingPdf
        }

        @JavascriptInterface
        fun getIncomingPdfError(): String? {
            return this@MainActivity.incomingPdfError
        }

        @JavascriptInterface
        fun getIncomingPdfInfo(): String? {
            if (!this@MainActivity.hasIncomingPdf || this@MainActivity.incomingPdfError != null) return null
            val name = this@MainActivity.incomingPdfName ?: "Document.pdf"
            val size = this@MainActivity.incomingPdfSize
            val escapedName = name.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
            return """{"name":"$escapedName","size":$size}"""
        }

        @JavascriptInterface
        fun readPdfChunk(offset: Int, length: Int): String? {
            val file = this@MainActivity.currentTempFile ?: return null
            if (!file.exists() || offset >= file.length() || offset < 0) return null
            return try {
                RandomAccessFile(file, "r").use { raf ->
                    raf.seek(offset.toLong())
                    val remaining = file.length() - offset
                    val toRead = if (remaining < length) remaining.toInt() else length
                    val buffer = ByteArray(toRead)
                    val bytesRead = raf.read(buffer)
                    if (bytesRead > 0) {
                        Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP)
                    } else {
                        null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }

        @JavascriptInterface
        fun clearIncomingPdf() {
            this@MainActivity.hasIncomingPdf = false
            this@MainActivity.incomingPdfError = null
        }
    }

    // ================= Auto-import from device storage (no manual import needed) =================

    private fun notifyFolderPickResult(success: Boolean, folderName: String?) {
        runOnUiThread {
            val nameArg = if (folderName != null) "\"${jsonEscape(folderName)}\"" else "null"
            webView.evaluateJavascript(
                "if (typeof window.onFolderAdded === 'function') { window.onFolderAdded($success, $nameArg); }",
                null
            )
        }
    }

    private fun notifyAllFilesAccessChanged() {
        val granted = hasAllFilesAccessInternal()
        runOnUiThread {
            webView.evaluateJavascript(
                "if (typeof window.onAllFilesAccessChanged === 'function') { window.onAllFilesAccessChanged($granted); }",
                null
            )
        }
    }

    private fun hasAllFilesAccessInternal(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun folderDisplayName(uri: Uri): String {
        return try {
            val last = uri.lastPathSegment?.let { Uri.decode(it) } ?: return uri.toString()
            val afterColon = last.substringAfterLast(':')
            if (afterColon.isBlank()) last else afterColon
        } catch (_: Exception) {
            uri.toString()
        }
    }

    private fun jsonEscape(s: String): String = s
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")

    /**
     * Recursively lists PDF files under a Storage Access Framework folder tree,
     * without copying any bytes. [treeRootUri] stays the same across recursive calls
     * (it identifies the granted tree); only [docId] changes as we descend.
     */
    private fun scanTreeForPdfs(
        treeRootUri: Uri,
        docId: String,
        depth: Int,
        dirPath: String,
        emit: (key: String, name: String, size: Long, lastModified: Long, source: String, folder: String) -> Unit
    ) {
        if (depth > MAX_FOLDER_DEPTH) return
        val childrenUri = try {
            DocumentsContract.buildChildDocumentsUriUsingTree(treeRootUri, docId)
        } catch (_: Exception) {
            return
        }
        try {
            contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null, null, null
            )?.use { cursor ->
                var count = 0
                while (cursor.moveToNext() && count < MAX_ENTRIES_PER_FOLDER) {
                    count++
                    val childDocId = cursor.getString(0) ?: continue
                    val name = cursor.getString(1) ?: continue
                    val mime = cursor.getString(2) ?: ""
                    val size = if (cursor.isNull(3)) 0L else cursor.getLong(3)
                    val lastMod = if (cursor.isNull(4)) 0L else cursor.getLong(4)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (!name.startsWith(".")) {
                            scanTreeForPdfs(treeRootUri, childDocId, depth + 1, dirPath + "/" + name, emit)
                        }
                    } else if (mime.equals("application/pdf", ignoreCase = true) ||
                        name.endsWith(".pdf", ignoreCase = true)
                    ) {
                        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeRootUri, childDocId)
                        emit(docUri.toString(), name, size, lastMod, "folder", dirPath)
                    }
                }
            }
        } catch (_: Exception) {
            // A folder that became inaccessible (revoked permission, unmounted SD card, etc.)
            // is skipped instead of crashing the whole scan.
        }
    }

    inner class AndroidStorageBridge {

        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        )
                    }
                    folderPickerLauncher.launch(intent)
                } catch (_: Exception) {
                    notifyFolderPickResult(false, null)
                }
            }
        }

        @JavascriptInterface
        fun listFolders(): String {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val uris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            val sb = StringBuilder("[")
            var first = true
            for (u in uris) {
                val uri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                val stillGranted = persisted.any { it.uri == uri && it.isReadPermission }
                if (!stillGranted) continue
                if (!first) sb.append(",")
                first = false
                sb.append("{\"uri\":\"").append(jsonEscape(u))
                    .append("\",\"name\":\"").append(jsonEscape(folderDisplayName(uri)))
                    .append("\"}")
            }
            sb.append("]")
            return sb.toString()
        }

        @JavascriptInterface
        fun removeFolder(uriString: String) {
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val current = (prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()).toMutableSet()
            current.remove(uriString)
            prefs.edit().putStringSet(KEY_FOLDER_URIS, current).apply()
            try {
                contentResolver.releasePersistableUriPermission(
                    Uri.parse(uriString),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Already released or never granted — safe to ignore.
            }
        }

        @JavascriptInterface
        fun hasAllFilesAccess(): Boolean = hasAllFilesAccessInternal()

        /** Whole-storage scan is available only while MANAGE_EXTERNAL_STORAGE is declared in the manifest. */
        @JavascriptInterface
        fun allFilesScanSupported(): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.R || try {
                packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
                    .requestedPermissions?.contains(Manifest.permission.MANAGE_EXTERNAL_STORAGE) == true
            } catch (_: Exception) { false }

        @JavascriptInterface
        fun requestAllFilesAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        allFilesAccessLauncher.launch(intent)
                    } catch (_: Exception) {
                        try {
                            allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                        } catch (_: Exception) {
                            notifyAllFilesAccessChanged()
                        }
                    }
                } else {
                    legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
        }

        /**
         * Finds every PDF already reachable on the device — from picked folders and, if granted,
         * the whole shared storage — WITHOUT copying any file. Returns a JSON array of
         * {key, name, size, lastModified, source}. "key" is later passed to readExternalChunk().
         */
        private val scanRunning = java.util.concurrent.atomic.AtomicBoolean(false)

        // ---- covers for discovered PDFs: page 1 rendered straight from the file / document, one at a time on a background thread ----
        private val coverExec = java.util.concurrent.Executors.newSingleThreadExecutor()

        @JavascriptInterface
        fun coverAsync(id: String, key: String, widthPx: Int) {
            coverExec.execute {
                val json = try {
                    renderCoverJson(key, widthPx.coerceIn(120, 800))
                } catch (e: Throwable) {
                    JSONObject().put("err", e.javaClass.simpleName + ": " + (e.message ?: "")).toString()
                }
                runOnUiThread {
                    try {
                        webView.evaluateJavascript(
                            "if(window.__coverDone){window.__coverDone(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")}", null
                        )
                    } catch (_: Throwable) {
                    }
                }
            }
        }

        private fun renderCoverJson(key: String, widthPx: Int): String {
            val pfd: android.os.ParcelFileDescriptor = if (key.startsWith("content://")) {
                contentResolver.openFileDescriptor(Uri.parse(key), "r") ?: throw FileNotFoundException("cannot open file")
            } else {
                android.os.ParcelFileDescriptor.open(File(key), android.os.ParcelFileDescriptor.MODE_READ_ONLY)
            }
            try {
                val renderer = android.graphics.pdf.PdfRenderer(pfd)
                try {
                    val n = renderer.pageCount
                    if (n < 1) throw IllegalStateException("empty PDF")
                    val page = renderer.openPage(0)
                    try {
                        val w = widthPx
                        val h = (page.height.toFloat() / page.width.coerceAtLeast(1) * w).toInt().coerceIn(1, 4000)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 82, bos)
                        bmp.recycle()
                        return JSONObject().put("n", n)
                            .put("b64", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).toString()
                    } finally {
                        try { page.close() } catch (_: Throwable) {}
                    }
                } finally {
                    try { renderer.close() } catch (_: Throwable) {}
                }
            } finally {
                try { pfd.close() } catch (_: Throwable) {}
            }
        }

        /**
         * Same scan as scanForPdfs(), but on a background thread. The JS side used to freeze while the
         * storage was walked; now the result is pushed back through window.__pdfScanDone(json).
         */
        @JavascriptInterface
        fun scanForPdfsAsync() {
            if (!scanRunning.compareAndSet(false, true)) return
            Thread {
                val json = try { scanForPdfs() } catch (_: Throwable) { "[]" }
                scanRunning.set(false)
                runOnUiThread {
                    try {
                        webView.evaluateJavascript(
                            "if(window.__pdfScanDone){window.__pdfScanDone(" + JSONObject.quote(json) + ")}", null
                        )
                    } catch (_: Throwable) {
                    }
                }
            }.start()
        }

        @JavascriptInterface
        fun scanForPdfs(): String {
            val out = StringBuilder("[")
            var first = true
            val emit: (String, String, Long, Long, String, String) -> Unit = { key, name, size, lastMod, source, folder ->
                if (!first) out.append(",")
                first = false
                out.append("{\"key\":\"").append(jsonEscape(key))
                    .append("\",\"name\":\"").append(jsonEscape(name))
                    .append("\",\"size\":").append(size)
                    .append(",\"lastModified\":").append(lastMod)
                    .append(",\"source\":\"").append(source)
                    .append("\",\"folder\":\"").append(jsonEscape(folder)).append("\"}")
            }

            // 1) Folders the user explicitly picked (works on every Android version, minimal permission)
            val prefs = getSharedPreferences(STORAGE_PREFS, MODE_PRIVATE)
            val treeUris = prefs.getStringSet(KEY_FOLDER_URIS, null) ?: emptySet()
            val persisted = try {
                contentResolver.persistedUriPermissions
            } catch (_: Exception) {
                emptyList()
            }
            for (u in treeUris) {
                val treeUri = try {
                    Uri.parse(u)
                } catch (_: Exception) {
                    continue
                }
                if (persisted.none { it.uri == treeUri && it.isReadPermission }) continue
                try {
                    val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
                    // e.g. "primary:Download/Telegram" -> "Download/Telegram" (folder name used for grouping)
                    scanTreeForPdfs(treeUri, rootDocId, 0, rootDocId.substringAfter(':'), emit)
                } catch (_: Exception) {
                    // Skip this folder; never crash the whole scan for one bad entry.
                }
            }

            // 2) Whole-storage scan, only if the user granted "All files access"
            if (hasAllFilesAccessInternal()) {
                try {
                    var scanned = 0
                    val deadline = System.currentTimeMillis() + SCAN_BUDGET_MS
                    val seen = HashSet<String>()
                    val prioritized = HashSet<String>()
                    fun walk(dir: File, depth: Int) {
                        if (depth > MAX_FOLDER_DEPTH || scanned >= MAX_TOTAL_ALL_FILES_SCAN || System.currentTimeMillis() > deadline) return
                        val path = dir.absolutePath
                        // Android 11+ still blocks other apps' private folders even with
                        // "All files access" — skip them so we don't waste time on errors.
                        if (path.endsWith("/Android/data") || path.endsWith("/Android/obb")) return
                        // Folders already walked in the priority pass below are not walked twice.
                        if (depth > 0 && prioritized.contains(path)) return
                        val children = try {
                            dir.listFiles()
                        } catch (_: Exception) {
                            null
                        } ?: return
                        for (f in children) {
                            if (scanned >= MAX_TOTAL_ALL_FILES_SCAN) return
                            scanned++
                            if (f.isDirectory) {
                                if (!f.name.startsWith(".") && !isMediaOnlyDir(f.name)) walk(f, depth + 1)
                            } else if (f.name.endsWith(".pdf", ignoreCase = true)) {
                                if (seen.add(f.absolutePath)) {
                                    // 5th/6th argument: where it came from (library groups by this folder)
                                    emit(f.absolutePath, f.name, f.length(), f.lastModified(), "allfiles", path)
                                }
                            }
                        }
                    }
                    val root = Environment.getExternalStorageDirectory()
                    // Download / Telegram / WhatsApp live in a few well-known places. Scan them first so the
                    // overall entry limit of the whole-phone walk can never cut them off.
                    // (Android/media is last: it is the biggest one and holds Telegram's own "Telegram Documents" folder too)
                    for (rel in listOf("Download", "Documents", "Telegram", "WhatsApp", "Bluetooth", "Android/media")) {
                        val d = File(root, rel)
                        if (!d.isDirectory) continue
                        scanned = 0
                        walk(d, rel.count { it == '/' } + 1)
                        prioritized.add(d.absolutePath)
                    }
                    scanned = 0
                    walk(root, 0)
                } catch (_: Exception) {
                    // Never let a storage scan crash the app.
                }
            }

            out.append("]")
            return out.toString()
        }

        /**
         * Reads one chunk of an already-discovered PDF directly from its source
         * (content:// document or raw filesystem path) — the file is never duplicated
         * into app storage. Mirrors AndroidPdfBridge.readPdfChunk()'s chunking approach.
         */
        @JavascriptInterface
        fun readExternalChunk(key: String, offset: Int, length: Int): String? {
            return try {
                if (key.startsWith("content://")) {
                    val uri = Uri.parse(key)
                    contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        FileInputStream(pfd.fileDescriptor).use { input ->
                            var skippedTotal = 0L
                            while (skippedTotal < offset) {
                                val skipped = input.skip((offset - skippedTotal))
                                if (skipped <= 0) break
                                skippedTotal += skipped
                            }
                            if (skippedTotal < offset) return null
                            val buffer = ByteArray(length)
                            val bytesRead = input.read(buffer)
                            if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                        }
                    }
                } else {
                    val file = File(key)
                    if (!file.exists() || offset >= file.length() || offset < 0) return null
                    RandomAccessFile(file, "r").use { raf ->
                        raf.seek(offset.toLong())
                        val remaining = file.length() - offset
                        val toRead = if (remaining < length) remaining.toInt() else length
                        val buffer = ByteArray(toRead)
                        val bytesRead = raf.read(buffer)
                        if (bytesRead > 0) Base64.encodeToString(buffer, 0, bytesRead, Base64.NO_WRAP) else null
                    }
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    /**
     * Saves a file straight into the device's Downloads folder. Added because the WebView's
     * usual `<a download>` click on a blob: URL does not actually save anything on Android
     * (WebView has no download handler for blob: links) — files "downloaded" from the PDF
     * viewer or note export just silently disappeared. This bridge writes real bytes to
     * Downloads via MediaStore (Android 10+) or, on very old Android, directly to the
     * public Downloads directory, so a Toast/"Saved" confirmation is honest.
     */
    /** Automatic backup: the user picks a folder (e.g. inside Google Drive); Docera keeps one file in it up to date. */
    private val BK_PREFS = "docera_backup"
    private fun bkJs(code: String) { runOnUiThread { try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {} } }

    private val backupFolderLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val u = if (r.resultCode == RESULT_OK) r.data?.data else null
        if (u == null) {
            bkJs("window.__backupFolder&&window.__backupFolder('')")
            return@registerForActivityResult
        }
        try {
            contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) {
        }
        getSharedPreferences(BK_PREFS, MODE_PRIVATE).edit().putString("tree", u.toString()).apply()
        bkJs("window.__backupFolder&&window.__backupFolder(" + org.json.JSONObject.quote(backupFolderName().ifBlank { "Backup folder" }) + ")")
    }

    private fun backupTree(): Uri? {
        val s = getSharedPreferences(BK_PREFS, MODE_PRIVATE).getString("tree", null) ?: return null
        val u = Uri.parse(s)
        val ok = try { contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission } } catch (_: Exception) { false }
        return if (ok) u else null
    }

    private fun backupFolderName(): String {
        val t = backupTree() ?: return ""
        return try {
            val doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(t, android.provider.DocumentsContract.getTreeDocumentId(t))
            contentResolver.query(doc, arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            } ?: "Backup folder"
        } catch (_: Exception) { "Backup folder" }
    }

    /** Replaces (or creates) [name] inside the chosen folder with the contents of [src]. Returns "ok" or an error text. */
    private fun writeBackupFile(tree: Uri, name: String, src: File): String {
        val cr = contentResolver
        val treeId = DocumentsContract.getTreeDocumentId(tree)
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, treeId)
        var existing: Uri? = null
        try {
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, treeId)
            cr.query(kids, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    if (c.getString(1) == name) { existing = DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)); break }
                }
            }
        } catch (_: Exception) {
        }
        fun copyTo(uri: Uri, mode: String): Boolean = try {
            cr.openOutputStream(uri, mode)?.use { out -> src.inputStream().use { it.copyTo(out, 256 * 1024) } ; true } ?: false
        } catch (_: Exception) { false }
        val ex = existing
        if (ex != null) {
            if (copyTo(ex, "wt")) return "ok"
            try { DocumentsContract.deleteDocument(cr, ex) } catch (_: Exception) {}
        }
        val created = try { DocumentsContract.createDocument(cr, parent, "application/zip", name) } catch (_: Exception) { null }
            ?: return "Could not create the file in that folder (choose the folder again)"
        return if (copyTo(created, "w")) "ok" else "Could not write the backup file"
    }

    /** Works out the name and size of the chosen backup. A cloud file that cannot be read in pieces is copied once into the app cache first. Returns JSON. */
    private fun restorePrepare(u: Uri): String {
        var name = "backup.zip"
        var size = -1L
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        } catch (_: Exception) { }
        try { restoreCache?.delete() } catch (_: Exception) { }
        try { File(cacheDir, "restore-src.tmp").delete() } catch (_: Exception) { }
        restoreCache = null
        // files on the phone (Downloads, internal storage, media) are read where they are; anything else (Google Drive, other clouds)
        // is downloaded first, with a progress bar, and then unpacked from the local copy
        val auth = u.authority ?: ""
        val isLocal = auth == "com.android.externalstorage.documents" ||
            auth == "com.android.providers.downloads.documents" ||
            auth == "com.android.providers.media.documents" ||
            auth == "media"
        var seekable = isLocal
        try {
            val pfd = if (isLocal) contentResolver.openFileDescriptor(u, "r") else null
            if (!isLocal) {
                // cloud file: nothing to probe, it is downloaded below
            } else if (pfd == null) {
                seekable = false
            } else {
                val st = pfd.statSize
                android.os.ParcelFileDescriptor.AutoCloseInputStream(pfd).use { fis ->
                    if (size <= 0 && st > 0) size = st
                    if (size <= 0) {
                        val cs = fis.channel.size()
                        if (cs > 0) size = cs
                    }
                    fis.channel.position(if (size > 1) size - 1 else 0L)
                    fis.read()
                }
            }
        } catch (_: Exception) { seekable = false }
        if (!seekable || size <= 0) {
            if (size > 0 && cacheDir.usableSpace < size + 64L * 1024 * 1024) {
                return org.json.JSONObject().put("err", "not enough free space on the phone: the backup needs about " + (size / 1048576L) + " MB while it is restored").toString()
            }
            try {
                val f = File(cacheDir, "restore-src.tmp")
                val total = size
                var done = 0L
                var last = 0L
                contentResolver.openInputStream(u)?.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(512 * 1024)
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                            done += r
                            val now = System.currentTimeMillis()
                            if (now - last > 600) {
                                last = now
                                bkJs("window.__restoreProg&&window.__restoreProg(" + done + "," + total + ")")
                            }
                        }
                    }
                }
                restoreCache = f
                size = f.length()
            } catch (e: Exception) {
                return org.json.JSONObject().put("err", e.localizedMessage ?: "could not read the file").toString()
            }
        }
        return org.json.JSONObject().put("name", name).put("size", size.toDouble()).toString()
    }

    inner class AndroidBackupBridge {
        @JavascriptInterface
        fun folderName(): String = backupFolderName()

        @JavascriptInterface
        fun pickFolder() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                    )
                    backupFolderLauncher.launch(i)
                } catch (_: Exception) {
                    bkJs("window.__backupFolder&&window.__backupFolder('')")
                }
            }
        }

        /** Opens the system file picker for a backup; the result arrives via window.__restorePicked(json). */
        @JavascriptInterface
        fun pickRestore() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "application/json"))
                    }
                    restorePickLauncher.launch(i)
                } catch (_: Exception) {
                    bkJs("window.__restorePicked&&window.__restorePicked('')")
                }
            }
        }

        /** Bytes [offset, offset+len) of the chosen backup as base64, or "ERR:..." */
        @JavascriptInterface
        fun restoreRead(offset: Double, len: Int): String {
            return try {
                val buf = ByteArray(len)
                var n = 0
                val cache = restoreCache
                if (cache != null) {
                    java.io.RandomAccessFile(cache, "r").use { raf ->
                        raf.seek(offset.toLong())
                        while (n < len) {
                            val r = raf.read(buf, n, len - n)
                            if (r < 0) break
                            n += r
                        }
                    }
                } else {
                    val u = restoreUri ?: return "ERR:no backup chosen"
                    val pfd = contentResolver.openFileDescriptor(u, "r") ?: return "ERR:cannot open the backup"
                    android.os.ParcelFileDescriptor.AutoCloseInputStream(pfd).use { fis ->
                        fis.channel.position(offset.toLong())
                        while (n < len) {
                            val r = fis.read(buf, n, len - n)
                            if (r < 0) break
                            n += r
                        }
                    }
                }
                Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
            } catch (e: Exception) {
                "ERR:" + (e.message ?: "read failed")
            }
        }

        @JavascriptInterface
        fun restoreDone() {
            restoreUri = null
            try { restoreCache?.delete() } catch (_: Exception) { }
            restoreCache = null
        }

        /** Copies a staged file into the backup folder on a background thread; the result arrives via window.__backupWritten(text). */
        @JavascriptInterface
        fun write(id: String, name: String): String {
            val tree = backupTree() ?: return "No backup folder chosen"
            val item = synchronized(stagedFiles) { stagedFiles.remove(id) } ?: return "unknown file"
            Thread {
                val r = try { writeBackupFile(tree, name, item.first) } catch (e: Exception) { e.localizedMessage ?: "failed" }
                try { item.first.parentFile?.deleteRecursively() } catch (_: Exception) {}
                bkJs("window.__backupWritten&&window.__backupWritten(" + org.json.JSONObject.quote(r) + ")")
            }.start()
            return "started"
        }
    }

    inner class AndroidSaveBridge {
        @JavascriptInterface
        fun setSelMenu(hide: Boolean) { hideSelMenu = hide }

        /** Clipboard for the in-app Edit menu (Cut / Copy / Paste), because the system selection bar is hidden while editing. */
        @JavascriptInterface
        fun getClip(): String = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val c = cm.primaryClip
            if (c != null && c.itemCount > 0) (c.getItemAt(0).coerceToText(applicationContext)?.toString() ?: "") else ""
        } catch (_: Exception) { "" }

        @JavascriptInterface
        fun setClip(text: String): Boolean = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Docera", text)); true
        } catch (_: Exception) { false }

        // ---- staged (chunked) files: big PDFs are sent in small base64 pieces, never as one giant string ----
        private val staged: HashMap<String, Pair<File, String>> get() = stagedFiles

        /** Turns a staged HTML file into a real, text-based PDF (like "Save as PDF" in Docs). Result comes back via window.__pdfDone(job, pdfStagedId, error). */
        @JavascriptInterface
        fun htmlToPdf(htmlId: String, filename: String, size: String, margins: String): String {
            val src = synchronized(staged) { staged[htmlId]?.first } ?: return "unknown file"
            var finished = false
            fun done(id: String, err: String) {
                if (finished) return
                finished = true
                runOnUiThread {
                    try {
                        webView.evaluateJavascript("window.__pdfDone&&window.__pdfDone(" + JSONObject.quote(htmlId) + "," + JSONObject.quote(id) + "," + JSONObject.quote(err) + ")", null)
                    } catch (_: Throwable) {}
                }
            }
            runOnUiThread {
                try {
                    val html = src.readText(Charsets.UTF_8)
                    val safe = filename.replace(Regex("[\\\\/:*?\"<>|]+"), "_").ifBlank { "note.pdf" }
                    val outId = System.nanoTime().toString()
                    val out = File(File(File(cacheDir, "shared").apply { mkdirs() }, outId).apply { mkdirs() }, safe)
                    val wv = android.webkit.WebView(this@MainActivity)
                    wv.settings.javaScriptEnabled = false
                    wv.settings.textZoom = 100          // never follow the system font size: PDF must match the editor
                    wv.settings.useWideViewPort = false
                    wv.settings.loadWithOverviewMode = false
                    wv.settings.allowFileAccess = false
                    wv.settings.allowContentAccess = false
                    // lay the page out at A4-ish phone size even though the view is never shown
                    wv.measure(
                        android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY),
                        android.view.View.MeasureSpec.makeMeasureSpec(1920, android.view.View.MeasureSpec.EXACTLY)
                    )
                    wv.layout(0, 0, 1080, 1920)
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        if (!finished) {
                            try { wv.destroy() } catch (_: Throwable) {}
                            done("", "timed out")
                        }
                    }, 25000)
                    var started = false
                    wv.webViewClient = object : android.webkit.WebViewClient() {
                        override fun onPageFinished(view: android.webkit.WebView, url: String?) {
                            if (started) return
                            started = true
                            view.postDelayed({
                                try {
                                    val adapter = view.createPrintDocumentAdapter("docera-note")
                                    // margins arrive as "top,bottom,left,right" in mm; 14 mm each if missing
                                    val mm = margins.split(",").map { it.trim().toDoubleOrNull() }
                                    fun mil(i: Int): Int = (((mm.getOrNull(i) ?: 14.0).coerceIn(0.0, 100.0)) * 1000.0 / 25.4).toInt()
                                    val attrs = android.print.PrintAttributes.Builder()
                                        .setMediaSize(
                                            when (size) {
                                                "A3" -> android.print.PrintAttributes.MediaSize.ISO_A3
                                                "A5" -> android.print.PrintAttributes.MediaSize.ISO_A5
                                                "Letter" -> android.print.PrintAttributes.MediaSize.NA_LETTER
                                                "Legal" -> android.print.PrintAttributes.MediaSize.NA_LEGAL
                                                else -> android.print.PrintAttributes.MediaSize.ISO_A4
                                            }
                                        )
                                        .setResolution(android.print.PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                                        .setMinMargins(android.print.PrintAttributes.Margins(mil(2), mil(0), mil(3), mil(1)))  // left, top, right, bottom = same margins as the page layout in the editor
                                        .build()
                                    android.print.PdfPrint(attrs).print(adapter, out) { ok, msg ->
                                        try { wv.destroy() } catch (_: Throwable) {}
                                        try { src.parentFile?.deleteRecursively() } catch (_: Throwable) {}
                                        synchronized(staged) { staged.remove(htmlId) }
                                        if (ok) {
                                            synchronized(staged) { staged[outId] = out to "application/pdf" }
                                            done(outId, "")
                                        } else done("", msg)
                                    }
                                } catch (e: Throwable) {
                                    done("", e.localizedMessage ?: "print failed")
                                }
                            }, 700)
                        }
                    }
                    wv.loadDataWithBaseURL("https://docera.local/", html, "text/html", "utf-8", null)
                } catch (e: Throwable) {
                    done("", e.localizedMessage ?: "PDF failed")
                }
            }
            return "ok"
        }

        /** Size (bytes) of a staged file, or -1. */
        @JavascriptInterface
        fun stagedSize(id: String): Int {
            val f = synchronized(staged) { staged[id]?.first } ?: return -1
            return f.length().toInt()
        }

        /** Reads a piece of a staged file as base64 (used to bring the finished PDF back to the page). */
        @JavascriptInterface
        fun readChunk(id: String, off: Int, len: Int): String {
            val f = synchronized(staged) { staged[id]?.first } ?: return ""
            return try {
                java.io.RandomAccessFile(f, "r").use { raf ->
                    raf.seek(off.toLong())
                    val buf = ByteArray(len)
                    val n = raf.read(buf)
                    if (n <= 0) "" else android.util.Base64.encodeToString(buf, 0, n, android.util.Base64.NO_WRAP)
                }
            } catch (_: Exception) { "" }
        }

        /** Forgets a staged file and deletes it. */
        @JavascriptInterface
        fun dropStaged(id: String) {
            val item = synchronized(staged) { staged.remove(id) } ?: return
            try { item.first.parentFile?.deleteRecursively() } catch (_: Exception) {}
        }

        /** Opens Android's own print screen ("Save as PDF", same as Google Docs / Chrome) for a staged HTML file. Text stays real text. */
        @JavascriptInterface
        fun printHtml(htmlId: String, jobName: String, size: String): String {
            val src = synchronized(staged) { staged[htmlId]?.first } ?: return "unknown file"
            runOnUiThread {
                try {
                    val html = src.readText(Charsets.UTF_8)
                    try {
                        printWv?.let { (it.parent as? android.view.ViewGroup)?.removeView(it); it.destroy() }
                    } catch (_: Throwable) {}
                    val wv = WebView(this@MainActivity)
                    printWv = wv
                    // attached (1px, invisible) so Android really lays the page out before printing
                    wv.alpha = 0f
                    try { addContentView(wv, android.widget.FrameLayout.LayoutParams(1, 1)) } catch (_: Throwable) {}
                    wv.settings.javaScriptEnabled = false
                    wv.settings.textZoom = 100          // never follow the system font size: PDF must match the editor
                    wv.settings.useWideViewPort = false
                    wv.settings.loadWithOverviewMode = false
                    wv.settings.allowFileAccess = false
                    wv.settings.allowContentAccess = false
                    var started = false
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String?) {
                            if (started) return
                            started = true
                            view.postDelayed({
                                try {
                                    val pm = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                                    val media = when (size) {
                                        "A3" -> android.print.PrintAttributes.MediaSize.ISO_A3
                                        "A5" -> android.print.PrintAttributes.MediaSize.ISO_A5
                                        "Letter" -> android.print.PrintAttributes.MediaSize.NA_LETTER
                                        "Legal" -> android.print.PrintAttributes.MediaSize.NA_LEGAL
                                        else -> android.print.PrintAttributes.MediaSize.ISO_A4
                                    }
                                    val attrs = android.print.PrintAttributes.Builder().setMediaSize(media).build()
                                    pm.print(jobName.ifBlank { "Docera note" }, view.createPrintDocumentAdapter(jobName.ifBlank { "Docera note" }), attrs)
                                    webView.evaluateJavascript("window.__printStarted&&window.__printStarted()", null)
                                } catch (e: Throwable) {
                                    try {
                                        webView.evaluateJavascript("window.__printFail&&window.__printFail(" + JSONObject.quote(e.localizedMessage ?: "print failed") + ")", null)
                                    } catch (_: Throwable) {}
                                }
                                try { src.parentFile?.deleteRecursively() } catch (_: Throwable) {}
                                synchronized(staged) { staged.remove(htmlId) }
                            }, 600)
                        }
                    }
                    wv.loadDataWithBaseURL("https://docera.local/", html, "text/html", "utf-8", null)
                } catch (e: Throwable) {
                    try {
                        webView.evaluateJavascript("window.__printFail&&window.__printFail(" + JSONObject.quote(e.localizedMessage ?: "print failed") + ")", null)
                    } catch (_: Throwable) {}
                }
            }
            return "ok"
        }

        /** Starts a temp file in the app cache; returns its id. */
        @JavascriptInterface
        fun beginFile(filename: String, mime: String): String {
            return try {
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val safe = filename.replace(Regex("[\\\\/:*?\"<>|]+"), "_").ifBlank { "docera-file" }
                val id = System.nanoTime().toString()
                val f = File(File(dir, id).apply { mkdirs() }, safe)
                f.writeBytes(ByteArray(0))
                synchronized(staged) { staged[id] = f to mime.ifBlank { "application/octet-stream" } }
                id
            } catch (e: Exception) {
                "ERR:" + (e.localizedMessage ?: "begin failed")
            }
        }

        /** Appends one base64 piece. Returns "ok" or an error text. */
        @JavascriptInterface
        fun appendChunk(id: String, b64: String): String {
            return try {
                val f = synchronized(staged) { staged[id]?.first } ?: return "unknown file"
                FileOutputStream(f, true).use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "write failed"
            }
        }

        /** Copies the staged file into Downloads and drops the temp copy. Returns "ok" or an error text. */
        @JavascriptInterface
        fun finishSave(id: String): String {
            val (f, mime) = synchronized(staged) { staged.remove(id) } ?: return "unknown file"
            return try {
                val bytes = f.readBytes()
                val r = saveBase64(Base64.encodeToString(bytes, Base64.NO_WRAP), f.name, mime)
                r
            } catch (e: Exception) {
                e.localizedMessage ?: "Save failed"
            } finally {
                try { f.parentFile?.deleteRecursively() } catch (_: Exception) {}
            }
        }

        /** Opens the Android share sheet for one or more staged files (ids separated by commas). */
        @JavascriptInterface
        fun shareStaged(ids: String, title: String): String {
            return try {
                val items = ids.split(",").mapNotNull { synchronized(staged) { staged[it.trim()] } }
                if (items.isEmpty()) return "no files"
                val uris = ArrayList<Uri>()
                for ((f, _) in items) uris.add(FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f))
                val mimes = items.map { it.second }.distinct()
                val mime = if (mimes.size == 1) mimes[0] else "*/*"
                val send = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
                } else {
                    Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
                send.type = mime
                if (title.isNotBlank()) send.putExtra(Intent.EXTRA_SUBJECT, title)
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val chooser = Intent.createChooser(send, title.ifBlank { null })
                chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                runOnUiThread {
                    try { startActivity(chooser) } catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Share failed"
            }
        }

        /** Sends a staged page image straight to Google Lens (like choosing Lens for a gallery photo). Falls back to the share sheet if Lens can't be opened. */
        @JavascriptInterface
        fun lensStaged(id: String): String {
            return try {
                val (f, mime) = synchronized(staged) { staged[id] } ?: return "unknown file"
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                fun send(): Intent = Intent(Intent.ACTION_SEND).apply {
                    type = if (mime.isBlank()) "image/jpeg" else mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    clipData = ClipData.newRawUri("image", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread {
                    val targets = listOf(
                        send().setComponent(ComponentName("com.google.android.googlequicksearchbox", "com.google.android.apps.search.lens.LensShareEntryPointActivity")),
                        send().setPackage("com.google.android.googlequicksearchbox"),
                        send().setPackage("com.google.ar.lens")
                    )
                    var opened = false
                    for (t in targets) {
                        try { startActivity(t); opened = true; break } catch (_: Exception) {}
                    }
                    if (!opened) {
                        try {
                            val chooser = Intent.createChooser(send(), "Google Lens")
                            chooser.clipData = ClipData.newRawUri("image", uri)
                            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            startActivity(chooser)
                        } catch (_: Exception) {}
                    }
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Could not open Google Lens"
            }
        }

        /** Opens the file manager's "Save as" screen for a staged file; the result comes back via window.__saveAsDone(ok,msg). */
        @JavascriptInterface
        fun saveAs(id: String, filename: String, mime: String): String {
            return try {
                if (synchronized(staged) { staged[id] } == null) return "unknown file"
                pendingSaveId = id
                runOnUiThread {
                    try {
                        saveAsLauncher.launch(Pair(filename.ifBlank { "docera-file" }, mime))
                    } catch (e: Exception) {
                        pendingSaveId = null
                    }
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Could not open the file manager"
            }
        }

        /** "Open with": lets the user pick ANOTHER app (not Docera) to view the staged file. */
        @JavascriptInterface
        fun openStaged(id: String, title: String): String {
            return try {
                val (f, mime) = synchronized(staged) { staged[id] } ?: return "unknown file"
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    clipData = ClipData.newRawUri("file", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(view, title.ifBlank { null }).apply {
                    clipData = ClipData.newRawUri("file", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    // hide Docera itself from the list - the point is to open the PDF somewhere else
                    putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(this@MainActivity, MainActivity::class.java)))
                }
                runOnUiThread {
                    try { startActivity(chooser) } catch (_: ActivityNotFoundException) {} catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Could not open"
            }
        }

        /** Share plain text (a note) through the Android share sheet. */
        @JavascriptInterface
        fun shareText(text: String, title: String): String {
            return try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    if (title.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, title)
                }
                runOnUiThread {
                    try { startActivity(Intent.createChooser(send, title.ifBlank { null })) } catch (_: Exception) {}
                }
                "ok"
            } catch (e: Exception) {
                e.localizedMessage ?: "Share failed"
            }
        }

        /** Old shared temp files are removed when the app starts a new export. */
        @JavascriptInterface
        fun cleanTemp() {
            try {
                val dir = File(cacheDir, "shared")
                val keep = synchronized(staged) { staged.values.map { it.first.parentFile?.name }.toSet() }
                dir.listFiles()?.forEach { if (it.name !in keep) it.deleteRecursively() }
            } catch (_: Exception) {}
        }

        /** Returns "ok" on success, or an error message string. */
        @JavascriptInterface
        fun saveBase64(base64: String, filename: String, mime: String): String {
            return try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val safeName = filename.ifBlank { "docera-file" }
                val safeMime = mime.ifBlank { "application/octet-stream" }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                        put(MediaStore.MediaColumns.MIME_TYPE, safeMime)
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: return "Could not create file"
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: return "Could not open file for writing"
                    "ok"
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    var out = File(dir, safeName)
                    if (out.exists()) {
                        val dot = safeName.lastIndexOf('.')
                        val base = if (dot > 0) safeName.substring(0, dot) else safeName
                        val ext = if (dot > 0) safeName.substring(dot) else ""
                        var i = 1
                        while (out.exists()) {
                            out = File(dir, "$base ($i)$ext")
                            i++
                        }
                    }
                    out.writeBytes(bytes)
                    // Make it show up immediately in the Downloads / Files app and Media Store.
                    try {
                        sendBroadcast(
                            Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out))
                        )
                    } catch (_: Exception) {
                    }
                    "ok"
                }
            } catch (e: Exception) {
                e.localizedMessage ?: "Save failed"
            }
        }
    }

    /**
     * archive.org: search + download, done natively (a WebView fetch to another site is blocked by CORS).
     * Only items that are free to download are offered; lending-only (borrow / DRM) books are left out.
     */
    inner class AndroidArchiveBridge {
        private val exec = java.util.concurrent.Executors.newFixedThreadPool(2)
        private val cancelled = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
        private val ua = "Docera/1.0 (Android PDF reader)"

        private fun callJs(code: String) {
            runOnUiThread {
                try { webView.evaluateJavascript(code, null) } catch (_: Throwable) {}
            }
        }

        private fun open(url: String): java.net.HttpURLConnection {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua)
            return c
        }

        private fun getText(url: String): String {
            val c = open(url)
            try {
                if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                try { c.disconnect() } catch (_: Throwable) {}
            }
        }

        private fun flat(v: Any?): String = when {
            v == null || v == JSONObject.NULL -> ""
            v is JSONArray -> (0 until v.length()).joinToString(", ") { v.optString(it) }
            else -> v.toString()
        }

        // ---- search ranking ----
        private fun normTxt(s: String): String =
            java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
                .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

        /** Folds common transliteration differences: hidayah / hidaya, kitab / qitab, ee / i, oo / u ... */
        private fun foldW(w: String): String {
            var x = w.replace("ee", "i").replace("oo", "u").replace("aa", "a").replace('w', 'v').replace('q', 'k')
            if (x.length > 3 && x.endsWith("ah")) x = x.dropLast(1)
            return x
        }

        private fun lev(a: String, b: String): Int {
            if (a == b) return 0
            if (kotlin.math.abs(a.length - b.length) > 2) return 3
            var prev = IntArray(b.length + 1) { it }
            for (i in 1..a.length) {
                val cur = IntArray(b.length + 1)
                cur[0] = i
                for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = cur
            }
            return prev[b.length]
        }

        /** How close a result is to the search words (higher = closer). 0 = the words are not in its title or author at all. */
        private fun relScore(title: String, creator: String, words: List<String>): Double {
            val qf = words.map { foldW(normTxt(it)) }.filter { it.isNotEmpty() }
            if (qf.isEmpty()) return 0.0
            val tw = normTxt(title).split(' ').filter { it.isNotEmpty() }.map { foldW(it) }
            val cw = normTxt(creator).split(' ').filter { it.isNotEmpty() }.map { foldW(it) }
            var s = 0.0
            var hit = 0
            for (q in qf) {
                val best = when {
                    tw.any { it == q } -> 15.0
                    tw.any { it.startsWith(q) || (q.length >= 4 && it.length >= 4 && q.startsWith(it)) } -> 10.0
                    q.length >= 4 && tw.any { lev(it, q) <= 1 } -> 8.0
                    q.length >= 6 && tw.any { lev(it, q) <= 2 } -> 5.0
                    else -> 0.0
                }
                if (best > 0.0) hit++ else if (cw.any { it == q || (q.length >= 4 && lev(it, q) <= 1) }) s += 2.0
                s += best
            }
            if (hit == qf.size) s += 30.0
            val tj = tw.joinToString(" ")
            val qj = qf.joinToString(" ")
            if (hit > 0) {
                if (tj == qj) s += 60.0 else if (tj.startsWith(qj)) s += 15.0
                s -= minOf(6.0, 0.15 * maxOf(0, tw.size - qf.size))
            }
            return s
        }

        @JavascriptInterface
        fun search(reqId: String, query: String) {
            exec.execute {
                val out = try {
                    val words = query.trim().split(Regex("\\s+"))
                        .map { it.replace(Regex("[^\\p{L}\\p{N}'-]"), "") }
                        .filter { it.isNotEmpty() }.take(8)
                    if (words.isEmpty()) throw IllegalArgumentException("Type a book name")
                    // spelling variants, so "Hidayah" also finds "Hidaya" / "Hidayat" (archive.org matches exact words only)
                    fun term(w: String): String {
                        val lw = w.lowercase()
                        val v = LinkedHashSet<String>()
                        v.add(w)
                        if (lw.length > 4 && lw.endsWith("ah")) v.add(lw.dropLast(1))
                        if (lw.length > 3 && lw.endsWith("a")) v.add(lw + "h")
                        if (lw.length >= 5) v.add(lw.dropLast(if (lw.endsWith("ah")) 2 else 1) + "*")
                        return "(" + v.joinToString(" OR ") + ")"
                    }
                    val sig = words.map { it.trim('-', '\'') }.filter { it.isNotEmpty() }
                        .let { l -> l.filter { it.length > 1 }.ifEmpty { l } }
                    fun query(withFormat: Boolean, boosted: Boolean): JSONArray {
                        val core = if (boosted) sig.joinToString(" AND ") { term(it) } else "(" + words.joinToString(" AND ") + ")"
                        val match = if (boosted) "(title:($core)^8 OR creator:($core)^2 OR ($core))" else core
                        val q = match + " AND mediatype:texts" +
                            (if (withFormat) " AND format:pdf" else "") + " AND NOT access-restricted-item:true"
                        val url = "https://archive.org/advancedsearch.php?q=" + java.net.URLEncoder.encode(q, "UTF-8") +
                            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=downloads&fl%5B%5D=imagecount&fl%5B%5D=language&rows=60&page=1&output=json"
                        return JSONObject(getText(url)).getJSONObject("response").getJSONArray("docs")
                    }
                    // best query first; if it fails or finds nothing, the old plain query (PDF-only, then any format) is used
                    var archErr: Throwable? = null
                    var docs = JSONArray()
                    try {
                        docs = try { query(true, true) } catch (_: Throwable) { JSONArray() }
                        if (docs.length() == 0) docs = query(true, false)
                        if (docs.length() == 0) docs = query(false, false)
                    } catch (e: Throwable) { archErr = e }
                    val commons = try { ArchiveStream.searchCommons(words) } catch (_: Throwable) { JSONArray() }
                    if (archErr != null && commons.length() == 0) throw archErr
                    val all = ArrayList<Pair<JSONObject, Double>>()
                    for (i in 0 until docs.length()) {
                        val d = docs.getJSONObject(i)
                        val id = d.optString("identifier")
                        if (id.isBlank()) continue
                        val o = JSONObject().put("id", id).put("title", flat(d.opt("title")).ifBlank { id })
                            .put("creator", flat(d.opt("creator"))).put("year", flat(d.opt("year")))
                            .put("pages", flat(d.opt("imagecount"))).put("lang", flat(d.opt("language")))
                            .put("src", "archive")
                        all.add(o to kotlin.math.ln(1.0 + d.optDouble("downloads", 0.0).coerceAtLeast(0.0)) * 0.3)
                    }
                    for (i in 0 until commons.length()) all.add(commons.getJSONObject(i) to 0.0)
                    // closest to what was typed first: title match >> author match >> found only somewhere else (description, subject...)
                    val scored = all.map { (o, pop) ->
                        val rel = relScore(o.optString("title"), o.optString("creator"), words)
                        Triple(o, rel, rel + pop)
                    }
                    val good = scored.count { it.second >= 2.0 }
                    val kept = if (good >= 5) scored.filter { it.second >= 2.0 } else scored   // enough real matches: hide the unrelated ones
                    val arr = JSONArray()
                    for (t in kept.sortedByDescending { it.third }) arr.put(t.first)
                    JSONObject().put("items", arr).toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                }
                callJs("if(window.__arcSearchDone)window.__arcSearchDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        private val paused = java.util.concurrent.ConcurrentHashMap<String, Boolean>()

        @JavascriptInterface
        fun cancel(reqId: String) { cancelled[reqId] = true }

        /** Pause: stop the transfer but keep the part already downloaded, so it can continue later from the same byte. */
        @JavascriptInterface
        fun pause(reqId: String) { paused[reqId] = true }

        /** Throws away the half-downloaded file of a paused item (when the user cancels it). */
        @JavascriptInterface
        fun discard(identifier: String) { try { partFile(identifier).delete() } catch (_: Throwable) {} }

        private fun partFile(identifier: String): File =
            File(cacheDir, "arcpart_" + identifier.filter { it.isLetterOrDigit() || it == '-' || it == '_' }.take(80) +
                "_" + Integer.toHexString(identifier.hashCode()) + ".part")

        /** Download and keep the PDF in Downloads/Docera. */
        @JavascriptInterface
        fun download(reqId: String, identifier: String, title: String) = startJob(reqId, identifier, title, true)

        /** "Read": fetch the PDF into the app's own private storage (not Downloads) so it can be opened in the viewer. */
        @JavascriptInterface
        fun read(reqId: String, identifier: String, title: String) = startJob(reqId, identifier, title, false)

        private fun privDir(): File = File(filesDir, "archive").also { if (!it.exists()) it.mkdirs() }
        private fun isPriv(f: File): Boolean = try {
            f.canonicalPath.startsWith(privDir().canonicalPath + File.separator)
        } catch (_: Throwable) { false }

        /** Moves a private "read" copy into Downloads/Docera (no new download needed). Answers through __arcDone. */
        @JavascriptInterface
        fun keep(reqId: String, key: String, name: String) {
            exec.execute {
                val out = try {
                    val f = File(key)
                    if (!f.exists() || !isPriv(f)) throw IllegalStateException("The saved copy was not found.")
                    val safe = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), " ").trim().ifBlank { "Book.pdf" }
                    val fileName = if (safe.endsWith(".pdf", true)) safe else "$safe.pdf"
                    val saved = saveToDownloads(f, fileName)
                    JSONObject().put("ok", true).put("key", saved).put("name", fileName).put("size", f.length()).toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                }
                callJs("if(window.__arcDone)window.__arcDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        /** Deletes a private "read" copy (only files inside the app's own archive folder). */
        @JavascriptInterface
        fun dropPrivate(key: String): String {
            return try {
                val f = File(key)
                if (isPriv(f)) { f.delete(); "ok" } else "not private"
            } catch (e: Throwable) { e.message ?: "error" }
        }

        private fun startJob(reqId: String, identifier: String, title: String, toDownloads: Boolean) {
            cancelled.remove(reqId)
            paused.remove(reqId)
            exec.execute {
                var tmp: File? = null
                var keepPart = false
                val out = try {
                    val enc = java.net.URLEncoder.encode(identifier, "UTF-8")
                    val isCommons = identifier.startsWith("wc:")
                    val meta = if (isCommons) JSONObject() else JSONObject(getText("https://archive.org/metadata/$enc"))
                    val md = meta.optJSONObject("metadata")
                    if (md != null && md.optString("access-restricted-item") == "true")
                        throw IllegalStateException("This book is lending-only on archive.org, it cannot be downloaded.")
                    val files = if (isCommons) JSONArray() else (meta.optJSONArray("files") ?: throw IllegalStateException("No files found for this book."))
                    var best: String? = null
                    var bestScore = -1
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val fmt = f.optString("format")
                        if (f.optString("private") == "true") continue
                        if (!name.endsWith(".pdf", true) && !fmt.contains("PDF", true)) continue
                        val score = when {
                            fmt.equals("Text PDF", true) -> 3
                            fmt.equals("Image Container PDF", true) -> 2
                            else -> 1
                        }
                        if (score > bestScore) { bestScore = score; best = name }
                    }
                    val url = if (isCommons) ArchiveStream.commonsUrl(identifier) else {
                        val fileOnArchive = best ?: throw IllegalStateException("This book has no PDF file.")
                        "https://archive.org/download/$enc/" +
                            fileOnArchive.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                    }
                    val c = open(url)
                    val file = partFile(identifier)
                    tmp = file
                    var offset = if (file.exists()) file.length() else 0L
                    if (offset > 0) { c.setRequestProperty("Range", "bytes=$offset-"); c.setRequestProperty("Accept-Encoding", "identity") }
                    var got = 0L
                    try {
                        val code = c.responseCode
                        if (offset > 0 && code == 416) { file.delete(); throw IllegalStateException("Could not continue, please try again.") }
                        if (code !in 200..299) throw java.io.IOException("HTTP " + code)
                        if (offset > 0 && code != 206) { file.delete(); offset = 0L }   // server ignored Range: start over
                        got = offset
                        val cl = c.contentLengthLong
                        val total = if (cl < 0) -1L else offset + cl
                        var last = 0L
                        var first = offset == 0L
                        c.inputStream.use { input ->
                            java.io.FileOutputStream(file, offset > 0).use { os ->
                                val buf = ByteArray(64 * 1024)
                                while (true) {
                                    if (cancelled[reqId] == true) throw java.io.InterruptedIOException("cancelled")
                                    if (paused[reqId] == true) { keepPart = true; throw java.io.InterruptedIOException("paused") }
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    if (first) {
                                        first = false
                                        if (n < 4 || buf[0] != '%'.code.toByte() || buf[1] != 'P'.code.toByte() ||
                                            buf[2] != 'D'.code.toByte() || buf[3] != 'F'.code.toByte()
                                        ) throw IllegalStateException("archive.org did not send a PDF (the book may need a login).")
                                    }
                                    os.write(buf, 0, n)
                                    got += n
                                    val now = System.currentTimeMillis()
                                    if (now - last > 300) {
                                        last = now
                                        callJs("if(window.__arcProg)window.__arcProg(" + JSONObject.quote(reqId) + "," + got + "," + total + ")")
                                    }
                                }
                            }
                        }
                    } finally {
                        try { c.disconnect() } catch (_: Throwable) {}
                    }
                    if (got < 100) throw IllegalStateException("The downloaded file is empty.")
                    val safe = title.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), " ").trim()
                        .replace(Regex("\\s+"), " ").take(80).ifBlank { identifier }
                    val fileName = "$safe.pdf"
                    val key = if (toDownloads) saveToDownloads(file, fileName) else {
                        val dest = File(privDir(), identifier.filter { it.isLetterOrDigit() || it == '-' || it == '_' || it == '.' }.ifBlank { "book" } + ".pdf")
                        file.copyTo(dest, overwrite = true)
                        dest.absolutePath
                    }
                    JSONObject().put("ok", true).put("key", key).put("name", fileName).put("size", got).toString()
                } catch (e: java.io.InterruptedIOException) {
                    if (keepPart) JSONObject().put("err", "paused").put("got", tmp?.length() ?: 0L).toString()
                    else JSONObject().put("err", "cancelled").toString()
                } catch (e: Throwable) {
                    JSONObject().put("err", (e.message ?: e.javaClass.simpleName)).toString()
                } finally {
                    // a paused item keeps its partial file; success, cancel and real errors remove it
                    if (!keepPart) { try { tmp?.delete() } catch (_: Throwable) {} }
                    cancelled.remove(reqId)
                    paused.remove(reqId)
                }
                callJs("if(window.__arcDone)window.__arcDone(" + JSONObject.quote(reqId) + "," + JSONObject.quote(out) + ")")
            }
        }

        /** Copies the finished download into Downloads/Docera. Returns the real file path when it can be read (same key the
         *  storage scan uses), otherwise the content:// uri. */
        private fun saveToDownloads(src: File, fileName: String): String {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Docera")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw java.io.IOException("Could not create the file in Downloads")
                val os = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("Could not write the file")
                os.use { o -> FileInputStream(src).use { it.copyTo(o) } }
                try {
                    contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val path = c.getString(0)
                            if (!path.isNullOrBlank() && File(path).canRead()) return path
                        }
                    }
                } catch (_: Throwable) {}
                return uri.toString()
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Docera")
            if (!dir.exists()) dir.mkdirs()
            var out = File(dir, fileName)
            var i = 1
            while (out.exists()) {
                out = File(dir, fileName.removeSuffix(".pdf") + " ($i).pdf")
                i++
            }
            src.copyTo(out)
            try { sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(out))) } catch (_: Throwable) {}
            return out.absolutePath
        }
    }
}

/** Wraps WebView's text-selection action mode and empties its menu, so no Cut/Copy/Paste/Select all bar appears. */
private class NoMenuActionCallback(private val base: android.view.ActionMode.Callback) : android.view.ActionMode.Callback2() {
    override fun onCreateActionMode(mode: android.view.ActionMode?, menu: android.view.Menu?): Boolean =
        base.onCreateActionMode(mode, menu)

    override fun onPrepareActionMode(mode: android.view.ActionMode?, menu: android.view.Menu?): Boolean {
        val r = base.onPrepareActionMode(mode, menu)
        menu?.clear()
        return r
    }

    override fun onActionItemClicked(mode: android.view.ActionMode?, item: android.view.MenuItem?): Boolean =
        base.onActionItemClicked(mode, item)

    override fun onDestroyActionMode(mode: android.view.ActionMode?) = base.onDestroyActionMode(mode)

    override fun onGetContentRect(mode: android.view.ActionMode?, view: android.view.View?, outRect: android.graphics.Rect?) {
        if (base is android.view.ActionMode.Callback2) base.onGetContentRect(mode, view, outRect)
        else super.onGetContentRect(mode, view, outRect)
    }
}
