package com.docera.parwez

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.view.KeyEvent

/**
 * Keeps a video playing with the screen locked / Docera in the background, and shows a media
 * notification (lock screen too) with Play / Pause and Remove.
 *
 * Two modes:
 *  - normal: the video plays in the WebView, this service only keeps the app alive and passes the
 *    button presses back to the page;
 *  - audio mode ("live music"): when the screen locks or Docera goes to the background, a downloaded
 *    video is handed over to a native MediaPlayer that plays only its sound from the same position;
 *    when Docera comes back, the video continues from where the sound reached.
 */
class MediaPlayService : Service() {

    companion object {
        /** true while something is really playing (MainActivity then does not pause its WebView) */
        @Volatile
        var active: Boolean = false

        /** "Bluetooth scroll" mode: sensor / headset / clicker buttons scroll the page instead of play / pause */
        @Volatile
        var btScroll: Boolean = false

        /** true while the sound is played natively (it keeps going even if Docera is swiped away) */
        @Volatile
        var audioMode: Boolean = false

        /** set by MainActivity: runs "play" / "pause" / "close" / "next" / "prev" inside the page */
        @Volatile
        var sink: ((String) -> Unit)? = null

        @Volatile
        var inst: MediaPlayService? = null

        private const val CHANNEL = "docera_media"
        private const val NOTIF_ID = 4102
        private const val A_SHOW = "docera.media.show"
        private const val A_TOGGLE = "docera.media.toggle"
        private const val A_CLOSE = "docera.media.close"

        fun show(ctx: Context, title: String, playing: Boolean) {
            try {
                val i = Intent(ctx, MediaPlayService::class.java).setAction(A_SHOW)
                    .putExtra("t", title).putExtra("p", playing)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, MediaPlayService::class.java))
            } catch (_: Throwable) {
            }
            active = false
            audioMode = false
        }

        /** hand the sound over to the native player; false if that is not possible right now */
        fun audioStart(url: String, posMs: Int, rate: Float, title: String): Boolean {
            val s = inst ?: return false
            return try { s.enterAudio(url, posMs, rate, title) } catch (_: Throwable) { false }
        }

        /** take the video back: "positionMs,playing(1/0)" or "" */
        fun audioStop(): String {
            val s = inst ?: return ""
            return try { s.leaveAudio() } catch (_: Throwable) { "" }
        }
    }

    private var session: MediaSession? = null
    private var wake: PowerManager.WakeLock? = null
    private var title = ""
    private var playing = false
    private var fg = false
    private var forceFg = false // startForegroundService() must always be answered with startForeground()

    private var mp: MediaPlayer? = null
    private var rate = 1f
    private var focusReq: AudioFocusRequest? = null
    private var mpReady = false
    private var userPaused = false
    private var resumeOnGain = false
    private var startedAt = 0L
    private var reason = ""
    private val focusL = AudioManager.OnAudioFocusChangeListener { c ->
        if (!audioMode) return@OnAudioFocusChangeListener
        when (c) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                // another sound (call, assistant, notification) ended: carry on by ourselves
                if (resumeOnGain && !userPaused) {
                    resumeOnGain = false
                    reason = ""
                    audioPlay()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (mpReady && mp?.isPlaying == true) {
                    resumeOnGain = true
                    reason = "Paused: another sound"
                    try { mp?.pause() } catch (_: Throwable) {}
                    playing = false
                    post()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                // the first moments after the hand-over can show a stray loss from the WebView's own player: ignore those
                if (System.currentTimeMillis() - startedAt > 2500 && mpReady && mp?.isPlaying == true) {
                    reason = "Paused: another app took the sound"
                    try { mp?.pause() } catch (_: Throwable) {}
                    playing = false
                    post()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        inst = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_SHOW -> {
                forceFg = true
                if (!audioMode) {
                    title = intent.getStringExtra("t") ?: ""
                    playing = intent.getBooleanExtra("p", false)
                    post()
                }
            }
            A_TOGGLE -> cmd(if (playing) "pause" else "play")
            A_CLOSE -> cmd("close")
            else -> {
                // started without a command (should not happen): never leave an empty service running
                if (!fg) stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    /** one place for every button (notification, lock screen, Bluetooth) */
    private fun cmd(c: String) {
        if (audioMode) {
            when (c) {
                "play" -> audioPlay()
                "pause" -> audioPause()
                "close" -> { sink?.invoke("close"); shutdown() }
                else -> sink?.invoke(c)   // next / prev: the page picks the next file and hands it over
            }
        } else {
            sink?.invoke(c)
            if (c == "close") shutdown()
        }
    }

    // ---------------- audio mode ----------------
    private fun enterAudio(url: String, posMs: Int, r: Float, t: String): Boolean {
        releasePlayer()
        title = t
        rate = if (r > 0f) r else 1f
        playing = true
        audioMode = true
        mpReady = false
        userPaused = false
        resumeOnGain = false
        reason = ""
        startedAt = System.currentTimeMillis()
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(url)
            p.setOnPreparedListener {
                mpReady = true
                try {
                    if (posMs > 0) it.seekTo(posMs)
                    if (playing) {
                        requestFocus()
                        it.start()
                        applyRate(it)
                    }
                } catch (_: Throwable) {}
                post()
            }
            p.setOnCompletionListener { playing = false; reason = ""; post() }
            p.setOnErrorListener { _, what, extra -> playing = false; mpReady = false; reason = "Error $what/$extra"; post(); true }
            p.prepareAsync()
        } catch (_: Throwable) {
            releasePlayer()
            audioMode = false
            return false
        }
        post()
        return true
    }

    private fun applyRate(p: MediaPlayer) {
        try {
            if (rate != 1f) p.playbackParams = PlaybackParams().setSpeed(rate)
        } catch (_: Throwable) {
        }
    }

    private fun audioPlay() {
        val p = mp ?: return
        userPaused = false
        resumeOnGain = false
        try {
            requestFocus()
            p.start()
            applyRate(p)
            playing = true
            reason = ""
        } catch (_: Throwable) {
            reason = "Could not play"
        }
        post()
    }

    private fun audioPause() {
        userPaused = true
        resumeOnGain = false
        try { if (mp?.isPlaying == true) mp?.pause() } catch (_: Throwable) {}
        playing = false
        reason = ""
        post()
    }

    private fun leaveAudio(): String {
        if (!audioMode) return ""
        val pos = try { if (mpReady) mp?.currentPosition ?: 0 else 0 } catch (_: Throwable) { 0 }
        val was = try { mpReady && mp?.isPlaying == true } catch (_: Throwable) { false }
        releasePlayer()
        audioMode = false
        return pos.toString() + "," + (if (was) "1" else "0")
    }

    private fun releasePlayer() {
        try { mp?.setOnPreparedListener(null); mp?.setOnCompletionListener(null); mp?.setOnErrorListener(null) } catch (_: Throwable) {}
        try { mp?.release() } catch (_: Throwable) {}
        mp = null
        mpReady = false
        abandonFocus()
    }

    private fun requestFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                val r = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
                    .setOnAudioFocusChangeListener(focusL).build()
                focusReq = r
                am.requestAudioFocus(r)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(focusL, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
            }
        } catch (_: Throwable) {
        }
    }

    private fun abandonFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26) {
                focusReq?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusL)
            }
        } catch (_: Throwable) {
        }
    }

    // ---------------- notification / session ----------------
    private fun pi(action: String, code: Int): PendingIntent {
        val i = Intent(this, MediaPlayService::class.java).setAction(action)
        return PendingIntent.getService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun post() {
        active = playing
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Video playback", NotificationManager.IMPORTANCE_LOW))
        }
        if (session == null) {
            session = MediaSession(this, "DoceraVideo").apply {
                setCallback(object : MediaSession.Callback() {
                    override fun onPlay() { cmd("play") }
                    override fun onPause() { cmd("pause") }
                    override fun onStop() { cmd("close") }
                    override fun onSkipToNext() { cmd("next") }
                    override fun onSkipToPrevious() { cmd("prev") }
                    // Bluetooth / wired headset keys: handled here directly so they never depend on a stale state
                    override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                        val ke: KeyEvent? = try {
                            if (Build.VERSION.SDK_INT >= 33) mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                            else @Suppress("DEPRECATION") mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                        } catch (_: Throwable) { null }
                        if (ke == null) return super.onMediaButtonEvent(mediaButtonIntent)
                        val handled = when (ke.keyCode) {
                            KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                            KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
                            KeyEvent.KEYCODE_MEDIA_STOP -> true
                            else -> false
                        }
                        if (btScroll) {
                            // any button of the sensor scrolls the page (previous = up, everything else = down)
                            if (ke.action == KeyEvent.ACTION_DOWN && ke.repeatCount == 0) {
                                val up = ke.keyCode == KeyEvent.KEYCODE_MEDIA_PREVIOUS || ke.keyCode == KeyEvent.KEYCODE_MEDIA_REWIND
                                sink?.invoke(if (up) "btscroll:up" else "btscroll:down")
                            }
                            return true
                        }
                        if (!handled) return super.onMediaButtonEvent(mediaButtonIntent)
                        if (ke.action == KeyEvent.ACTION_DOWN && ke.repeatCount == 0) {
                            when (ke.keyCode) {
                                KeyEvent.KEYCODE_MEDIA_PLAY -> cmd("play")
                                KeyEvent.KEYCODE_MEDIA_PAUSE -> cmd("pause")
                                KeyEvent.KEYCODE_MEDIA_NEXT -> cmd("next")
                                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> cmd("prev")
                                KeyEvent.KEYCODE_MEDIA_STOP -> cmd("close")
                                else -> cmd(if (playing) "pause" else "play")
                            }
                        }
                        return true
                    }
                })
                // Bluetooth headset / car / watch buttons (play, pause, next, previous) reach this session
                @Suppress("DEPRECATION")
                setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
                isActive = true
            }
        }
        val s = session!!
        val dur = try { if (audioMode && mpReady) (mp?.duration ?: -1).toLong() else -1L } catch (_: Throwable) { -1L }
        val pos = try { if (audioMode && mpReady) (mp?.currentPosition ?: 0).toLong() else PlaybackState.PLAYBACK_POSITION_UNKNOWN } catch (_: Throwable) { PlaybackState.PLAYBACK_POSITION_UNKNOWN }
        val md = MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title)
        if (dur > 0) md.putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
        s.setMetadata(md.build())
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_STOP or PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, pos, if (playing && audioMode) rate else 1f)
                .build()
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        b.setSmallIcon(if (playing) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
            .setContentTitle(if (title.isEmpty()) "Docera" else title)
            .setContentText(if (playing) "Playing" else if (reason.isNotEmpty()) reason else "Paused")
            .setContentIntent(open)
            .setDeleteIntent(pi(A_CLOSE, 3))
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(playing)
            .setShowWhen(false)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
                    if (playing) "Pause" else "Play",
                    pi(A_TOGGLE, 1)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Remove",
                    pi(A_CLOSE, 2)
                ).build()
            )
            .setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 1))
        val n = b.build()
        // in audio mode the service stays in the foreground even when paused (the sound lives here)
        if (playing || audioMode || forceFg) {
            if (!fg) {
                try {
                    if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                    else startForeground(NOTIF_ID, n)
                    fg = true
                } catch (_: Throwable) {
                    nm.notify(NOTIF_ID, n)
                }
            } else nm.notify(NOTIF_ID, n)
            holdWake(playing)
            if (!playing && !audioMode) {
                // started only to show "paused": keep the notification, but let it be swiped away again
                try { stopForeground(false) } catch (_: Throwable) {}
                fg = false
            }
            forceFg = false
        } else {
            // paused: the notification can be swiped away (that removes the video)
            if (fg) {
                try { stopForeground(false) } catch (_: Throwable) {}
                fg = false
            }
            nm.notify(NOTIF_ID, n)
            holdWake(false)
        }
    }

    private fun holdWake(on: Boolean) {
        try {
            if (on) {
                if (wake == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "docera:video")
                }
                if (wake?.isHeld == false) wake?.acquire(6 * 60 * 60 * 1000L)
            } else if (wake?.isHeld == true) wake?.release()
        } catch (_: Throwable) {
        }
    }

    private fun shutdown() {
        active = false
        audioMode = false
        releasePlayer()
        holdWake(false)
        try { session?.isActive = false; session?.release() } catch (_: Throwable) {}
        session = null
        try { stopForeground(true) } catch (_: Throwable) {}
        fg = false
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID) } catch (_: Throwable) {}
        stopSelf()
    }

    override fun onDestroy() {
        active = false
        audioMode = false
        releasePlayer()
        holdWake(false)
        try { session?.release() } catch (_: Throwable) {}
        session = null
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NOTIF_ID) } catch (_: Throwable) {}
        if (inst === this) inst = null
        super.onDestroy()
    }
}
