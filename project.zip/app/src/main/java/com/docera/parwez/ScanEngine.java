package com.docera.parwez;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Native page scanner. The WebView sends the captured JPEG once (ScanEngineBridge: begin / append / end), then asks
 * for finished pages with  https://docera.scan/render?k=KEY&q=..&sw=..&sh=..&s0=..&ow=..&oh=..&rot=..&mode=..&ql=..
 * and gets a JPEG back. The picture is decoded at the size it is needed (the JPEG decoder itself shrinks it),
 * then ScanCore straightens, cleans and styles it on every CPU core and the result is encoded natively.
 * Any problem answers with an error status and the page falls back to its JavaScript version.
 */
public final class ScanEngine {
    private ScanEngine() {}

    public static final String HOST = "docera.scan";
    private static final int KEEP = 40;
    private static final Object GLOBAL = new Object();
    private static final Object RENDER = new Object();
    private static final LinkedHashMap<String, File> staged = new LinkedHashMap<String, File>();
    private static final HashMap<String, FileOutputStream> pendingOut = new HashMap<String, FileOutputStream>();
    private static final HashMap<String, File> pendingFile = new HashMap<String, File>();
    private static boolean swept = false;

    private static boolean goodKey(String k) {
        if (k == null || k.length() == 0 || k.length() > 64) return false;
        for (int i = 0; i < k.length(); i++) {
            char c = k.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-';
            if (!ok) return false;
        }
        return true;
    }

    private static File dir(Context ctx) {
        File d = new File(ctx.getCacheDir(), "scansrc");
        d.mkdirs();
        return d;
    }

    static String begin(Context ctx, String key) {
        synchronized (GLOBAL) {
            try {
                if (!goodKey(key)) return "ERR:key";
                File d = dir(ctx);
                if (!swept) {
                    swept = true;
                    File[] old = d.listFiles();
                    if (old != null) for (File f : old) { try { f.delete(); } catch (Throwable ignored) {} }
                    staged.clear();
                }
                FileOutputStream prev = pendingOut.remove(key);
                if (prev != null) { try { prev.close(); } catch (Throwable ignored) {} }
                File f = new File(d, key + ".jpg");
                pendingOut.put(key, new FileOutputStream(f, false));
                pendingFile.put(key, f);
                return "ok";
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }
    }

    static String append(String key, String b64) {
        synchronized (GLOBAL) {
            try {
                FileOutputStream out = pendingOut.get(key);
                if (out == null) return "ERR:unknown";
                out.write(Base64.decode(b64, Base64.DEFAULT));
                return "ok";
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }
    }

    static String end(String key) {
        synchronized (GLOBAL) {
            try {
                FileOutputStream out = pendingOut.remove(key);
                File f = pendingFile.remove(key);
                if (out == null || f == null) return "ERR:unknown";
                try { out.flush(); out.close(); } catch (Throwable ignored) {}
                staged.remove(key);
                staged.put(key, f);
                while (staged.size() > KEEP) {
                    Iterator<Map.Entry<String, File>> it = staged.entrySet().iterator();
                    Map.Entry<String, File> eldest = it.next();
                    it.remove();
                    try { eldest.getValue().delete(); } catch (Throwable ignored) {}
                }
                return "ok";
            } catch (Throwable e) {
                return "ERR:" + e.getMessage();
            }
        }
    }

    static void clear() {
        synchronized (GLOBAL) {
            for (FileOutputStream o : pendingOut.values()) { try { o.close(); } catch (Throwable ignored) {} }
            pendingOut.clear();
            pendingFile.clear();
            for (File f : staged.values()) { try { f.delete(); } catch (Throwable ignored) {} }
            staged.clear();
        }
    }

    private static WebResourceResponse reply(String mime, int status, byte[] body) {
        HashMap<String, String> headers = new HashMap<String, String>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse(mime, "utf-8", status, status == 200 ? "OK" : "Error", headers, new ByteArrayInputStream(body));
    }

    private static int intParam(Uri u, String name, int def) {
        String v = u.getQueryParameter(name);
        return v == null ? def : Integer.parseInt(v.trim());
    }

    private static double dblParam(Uri u, String name, double def) {
        String v = u.getQueryParameter(name);
        return v == null ? def : Double.parseDouble(v.trim());
    }

    /** Answers one intercepted https://docera.scan/... request. Runs on a WebView worker thread. */
    public static WebResourceResponse handle(Uri u) {
        try {
            if (!"/render".equals(u.getPath())) return reply("text/plain", 404, "no route".getBytes());
            String key = u.getQueryParameter("k");
            File f;
            synchronized (GLOBAL) {
                f = key == null ? null : staged.get(key);
                if (f != null) { staged.remove(key); staged.put(key, f); } // most recently used goes last
            }
            if (f == null || !f.exists()) return reply("text/plain", 404, "gone".getBytes());
            String qs = u.getQueryParameter("q");
            if (qs == null) return reply("text/plain", 400, "no quad".getBytes());
            String[] parts = qs.split(",");
            if (parts.length != 8) return reply("text/plain", 400, "bad quad".getBytes());
            double[] q = new double[8];
            for (int i = 0; i < 8; i++) q[i] = Double.parseDouble(parts[i].trim());
            int sw = intParam(u, "sw", 0), sh = intParam(u, "sh", 0);
            int ow = intParam(u, "ow", 0), oh = intParam(u, "oh", 0);
            int rot = intParam(u, "rot", 0);
            double s0 = dblParam(u, "s0", 1.0), ql = dblParam(u, "ql", 0.92);
            String mode = u.getQueryParameter("mode");
            if (mode == null) mode = "color";
            if (sw < 1 || sh < 1 || ow < 8 || oh < 8 || ow > 12000 || oh > 12000 || (long) ow * oh > 40000000L || !(s0 > 0 && s0 <= 1.0)) {
                return reply("text/plain", 400, "bad size".getBytes());
            }
            byte[] jpg;
            synchronized (RENDER) { // one page at a time: each one already uses every core
                jpg = render(f, q, sw, sh, s0, ow, oh, rot, mode, ql);
            }
            return reply("image/jpeg", 200, jpg);
        } catch (Throwable e) {
            return reply("text/plain", 500, ("ERR:" + e).getBytes());
        }
    }

    private static byte[] render(File f, double[] q, int sw, int sh, double s0, int ow, int oh, int rot, String mode, double ql) throws IOException {
        int threads = Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors()));
        String path = f.getAbsolutePath();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("unreadable picture");
        int wantW = Math.max(8, (int) Math.round(sw * s0)), wantH = Math.max(8, (int) Math.round(sh * s0));
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= wantW && bounds.outHeight / (sample * 2) >= wantH) sample *= 2;
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inSampleSize = sample;
        opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp = BitmapFactory.decodeFile(path, opt);
        if (bmp == null) throw new IOException("decode failed");
        if (bmp.getWidth() > wantW * 1.05 || bmp.getHeight() > wantH * 1.05) {
            Bitmap scaled = Bitmap.createScaledBitmap(bmp, wantW, wantH, true);
            if (scaled != bmp) bmp.recycle();
            bmp = scaled;
        }
        int dw = bmp.getWidth(), dh = bmp.getHeight();
        int[] src = new int[dw * dh];
        bmp.getPixels(src, 0, dw, 0, 0, dw, dh);
        bmp.recycle();
        double[] qq = new double[8];
        for (int i = 0; i < 8; i++) qq[i] = q[i] * ((i % 2 == 0) ? dw / (double) sw : dh / (double) sh);
        int[] d = ScanCore.warp(src, dw, dh, qq, ow, oh, threads);
        src = null;
        int w = ow, h = oh;
        if (rot != 0) {
            int[] wh = new int[2];
            d = ScanCore.rotate(d, w, h, rot, wh);
            w = wh[0];
            h = wh[1];
        }
        ScanCore.enhance(d, w, h, mode, threads);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        out.setPixels(d, 0, w, 0, 0, w, h);
        d = null;
        int quality = (int) Math.max(50, Math.min(100, Math.round(ql * 100)));
        ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(65536, (int) (((long) w * h) / 6)));
        out.compress(Bitmap.CompressFormat.JPEG, quality, bos);
        out.recycle();
        return bos.toByteArray();
    }
}
