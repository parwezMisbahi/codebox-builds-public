package com.docera.parwez

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent

/**
 * "Bluetooth scroll": buttons of a Bluetooth sensor / clicker / ring / headset scroll the PDF page.
 * Keys can arrive by three roads (accessibility key filter, the activity, a media session) - all of them end up in handle().
 * Only active while Docera is in front AND the PDF viewer asked for it (scroll) or the key tester is open (test).
 */
object BtKeys {
    @Volatile var scroll = false
    @Volatile var test = false
    @Volatile var fg = false
    private var last = 0L
    private var session: MediaSession? = null
    private var track: AudioTrack? = null
    @Volatile private var run = false

    private fun isMedia(kc: Int) = kc == KeyEvent.KEYCODE_MEDIA_PLAY || kc == KeyEvent.KEYCODE_MEDIA_PAUSE ||
        kc == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || kc == KeyEvent.KEYCODE_HEADSETHOOK || kc == KeyEvent.KEYCODE_MEDIA_NEXT ||
        kc == KeyEvent.KEYCODE_MEDIA_PREVIOUS || kc == KeyEvent.KEYCODE_MEDIA_STOP || kc == KeyEvent.KEYCODE_MEDIA_REWIND ||
        kc == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || kc == KeyEvent.KEYCODE_MEDIA_STEP_FORWARD || kc == KeyEvent.KEYCODE_MEDIA_STEP_BACKWARD

    private fun isSystem(kc: Int) = kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_HOME || kc == KeyEvent.KEYCODE_POWER ||
        kc == KeyEvent.KEYCODE_APP_SWITCH || kc == KeyEvent.KEYCODE_MENU || kc == KeyEvent.KEYCODE_ENDCALL ||
        kc == KeyEvent.KEYCODE_SLEEP || kc == KeyEvent.KEYCODE_WAKEUP

    private fun external(d: InputDevice?): Boolean = try {
        if (d == null) false
        else if (Build.VERSION.SDK_INT >= 29) d.isExternal
        else !d.isVirtual && !(d.name ?: "").contains("gpio", true)
    } catch (_: Throwable) { false }

    private fun isUp(kc: Int) = kc == KeyEvent.KEYCODE_MEDIA_PREVIOUS || kc == KeyEvent.KEYCODE_MEDIA_REWIND ||
        kc == KeyEvent.KEYCODE_MEDIA_STEP_BACKWARD || kc == KeyEvent.KEYCODE_PAGE_UP || kc == KeyEvent.KEYCODE_DPAD_UP ||
        kc == KeyEvent.KEYCODE_DPAD_LEFT || kc == KeyEvent.KEYCODE_VOLUME_UP

    /** true = the key was used (the caller must swallow it) */
    fun handle(ev: KeyEvent, src: String): Boolean {
        if (!fg || (!scroll && !test)) return false
        val kc = ev.keyCode
        if (isSystem(kc)) return false
        val media = isMedia(kc)
        val dv = try { ev.device } catch (_: Throwable) { null }
        val ext = media || external(dv)
        val first = ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0
        if (test) {
            if (first) {
                val nm = KeyEvent.keyCodeToString(kc).removePrefix("KEYCODE_")
                MediaPlayService.sink?.invoke("btkey:" + src + ":" + nm + ":" + kc + ":" + (if (ext) "ext" else "phone") + ":" + (dv?.name ?: "?"))
            }
            return true
        }
        if (kc == KeyEvent.KEYCODE_UNKNOWN || !ext) return false
        if (first) {
            val now = SystemClock.uptimeMillis()
            if (now - last > 150) {
                last = now
                MediaPlayService.sink?.invoke(if (isUp(kc)) "btscroll:up" else "btscroll:down")
            }
        }
        return true
    }

    /** start / stop the silent "media session grabber" depending on the flags */
    fun refresh(ctx: Context) {
        if (fg && (scroll || test)) start(ctx.applicationContext) else stop()
    }

    /** Jugaad: a silent audio loop + an active media session make Android send Bluetooth media buttons to Docera,
     *  not to the video's own WebView session. No sound is played and no audio focus is taken. */
    @Synchronized
    private fun start(ctx: Context) {
        if (run) return
        run = true
        try {
            val s = MediaSession(ctx, "DoceraBtScroll")
            s.setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val ke: KeyEvent? = try {
                        if (Build.VERSION.SDK_INT >= 33) mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                        else @Suppress("DEPRECATION") mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    } catch (_: Throwable) { null }
                    if (ke != null && handle(ke, "media")) return true
                    return super.onMediaButtonEvent(mediaButtonIntent)
                }
            })
            @Suppress("DEPRECATION")
            s.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                    .setState(PlaybackState.STATE_PLAYING, 0, 1f).build()
            )
            s.isActive = true
            session = s
            val rate = 8000
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            track = t
            t.play()
            Thread {
                val z = ByteArray(2048)
                while (run) { try { t.write(z, 0, z.size) } catch (_: Throwable) { break } }
            }.start()
        } catch (_: Throwable) { stop() }
    }

    @Synchronized
    fun stop() {
        run = false
        try { session?.isActive = false; session?.release() } catch (_: Throwable) {}
        session = null
        try { track?.stop(); track?.release() } catch (_: Throwable) {}
        track = null
    }
}
