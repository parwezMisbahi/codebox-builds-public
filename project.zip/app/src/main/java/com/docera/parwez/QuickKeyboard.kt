package com.docera.parwez

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Docera's own keyboard (English + Urdu) for the floating Quick Note panel.
 * Rows: 10 keys / 9 keys / shift + 7 keys + backspace / [?123] [language] [space] [. or ۔] [enter].
 * It writes straight into the given EditText, so the Android system keyboard is never needed.
 */
class QuickKeyboard(
    ctx: Context,
    private val target: EditText,
    startLang: String,
    private val onLang: (String) -> Unit
) : LinearLayout(ctx) {

    private var urdu = startLang == "ur"
    private var shift = false
    private var symbols = false
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private val EN = listOf(
            "q w e r t y u i o p".split(" "),
            "a s d f g h j k l".split(" "),
            "z x c v b n m".split(" ")
        )
        private val UR = listOf(
            "ق و ع ر ت ے ء ی ہ پ".split(" "),
            "ا س د ف گ ح ج ک ل".split(" "),
            "ز ش چ ط ب ن م".split(" ")
        )
        private val UR_SHIFT = listOf(
            "ٹ ؤ ظ ڑ ث ئ ۓ ں ھ ٔ".split(" "),
            "آ ص ڈ ٰ غ ً ض خ ذ".split(" "),
            "ژ ث ص ض ظ ، ؟".split(" ")
        )
        private val SYM_EN = listOf(
            "1 2 3 4 5 6 7 8 9 0".split(" "),
            "@ # $ % & - + ( ) /".split(" "),
            "* \" ' : ; ! ?".split(" ")
        )
        private val SYM_UR = listOf(
            "۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹ ۰".split(" "),
            "؟ ، ۔ ! : ؛ ( ) \" '".split(" "),
            "* - + = / @ #".split(" ")
        )

        fun round(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

        /** small header button */
        fun chip(ctx: Context, label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
            text = label
            setTextColor(0xFFE8E9EE.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            gravity = Gravity.CENTER
            val d = ctx.resources.displayMetrics.density
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
            background = round(0xFF30333B.toInt(), 6 * d)
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick() }
        }
    }

    fun toggleLang() {
        urdu = !urdu
        shift = false
        onLang(if (urdu) "ur" else "en")
        build()
    }

    // ---------- text editing ----------
    private fun insert(s: String) {
        val e = target.text ?: return
        val a = target.selectionStart.let { if (it < 0) e.length else it }
        val b = target.selectionEnd.let { if (it < 0) e.length else it }
        e.replace(minOf(a, b), maxOf(a, b), s)
    }

    private fun backspace() {
        val e = target.text ?: return
        val a = target.selectionStart.let { if (it < 0) e.length else it }
        val b = target.selectionEnd.let { if (it < 0) e.length else it }
        if (a != b) { e.delete(minOf(a, b), maxOf(a, b)); return }
        if (a <= 0) return
        val n = if (a >= 2 && Character.isLowSurrogate(e[a - 1]) && Character.isHighSurrogate(e[a - 2])) 2 else 1
        e.delete(a - n, a)
    }

    // ---------- building the rows ----------
    private fun d() = resources.displayMetrics.density

    private fun key(label: String, weight: Float, bg: Int, fg: Int = 0xFFF2F3F7.toInt(), sp: Float = 16f): TextView {
        val t = TextView(context)
        t.text = label
        t.setTextColor(fg)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.gravity = Gravity.CENTER
        t.typeface = Typeface.DEFAULT
        t.isClickable = true
        val shape = round(bg, 6 * d())
        t.background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), shape, null)
        t.layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight).apply {
            setMargins((1.5f * d()).toInt(), (1.5f * d()).toInt(), (1.5f * d()).toInt(), (1.5f * d()).toInt())
        }
        return t
    }

    private fun row(): LinearLayout = LinearLayout(context).apply {
        orientation = HORIZONTAL
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f)
    }

    private val KEY = 0xFF3A3D46.toInt()
    private val SPECIAL = 0xFF2A2C33.toInt()
    private val ACCENT = 0xFF4F7CFF.toInt()

    private fun build() {
        removeAllViews()
        val rows: List<List<String>> = when {
            symbols -> if (urdu) SYM_UR else SYM_EN
            urdu -> if (shift) UR_SHIFT else UR
            else -> EN
        }
        for ((ri, keys) in rows.withIndex()) {
            val r = row()
            if (ri == 1 && !urdu && !symbols) r.addView(View(context), LayoutParams(0, 1, 0.5f))
            if (ri == 2) {
                val sh = key(if (symbols) "=" else "⇧", 1.5f, if (shift && !symbols) ACCENT else SPECIAL)
                if (symbols) sh.setOnClickListener { tap(it); insert("=") } else sh.setOnClickListener { tap(it); shift = !shift; build() }
                r.addView(sh)
            }
            for (k in keys) {
                val label = if (!urdu && !symbols && shift) k.uppercase() else k
                val v = key(label, 1f, KEY)
                v.setOnClickListener {
                    tap(it)
                    insert(label)
                    if (shift && !symbols && !urdu) { shift = false; build() }
                    else if (shift && !symbols && urdu) { shift = false; build() }
                }
                r.addView(v)
            }
            if (ri == 1 && !urdu && !symbols) r.addView(View(context), LayoutParams(0, 1, 0.5f))
            if (ri == 2) {
                val bs = key("⌫", 1.5f, SPECIAL)
                bs.setOnTouchListener(bsTouch)
                r.addView(bs)
            }
            addView(r)
        }
        // bottom row: ?123 | language | space | . | enter
        val b = row()
        val sy = key(if (symbols) (if (urdu) "ابج" else "ABC") else "?123", 1.5f, SPECIAL, sp = 12f)
        sy.setOnClickListener { tap(it); symbols = !symbols; shift = false; build() }
        val lg = key(if (urdu) "EN" else "اردو", 1.3f, SPECIAL, sp = 13f)
        lg.setOnClickListener { tap(it); toggleLang() }
        val sp = key(if (urdu) "اردو" else "English", 5f, KEY, 0xFFB5B8C2.toInt(), 11f)
        sp.setOnClickListener { tap(it); insert(" ") }
        val dot = key(if (urdu) "۔" else ".", 1f, KEY)
        dot.setOnClickListener { tap(it); insert(if (urdu) "۔" else ".") }
        val en = key("↵", 1.5f, ACCENT)
        en.setOnClickListener { tap(it); insert("\n") }
        for (v in listOf(sy, lg, sp, dot, en)) b.addView(v)
        addView(b)
    }

    private fun tap(v: View) {
        try { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } catch (_: Throwable) {}
    }

    /** backspace: one char on tap, keeps deleting while held */
    private val bsTouch = View.OnTouchListener { v, ev ->
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.isPressed = true
                tap(v); backspace()
                val r = object : Runnable {
                    override fun run() { backspace(); handler.postDelayed(this, 55) }
                }
                v.tag = r
                handler.postDelayed(r, 380)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.isPressed = false
                (v.tag as? Runnable)?.let { handler.removeCallbacks(it) }
            }
        }
        true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    init {
        orientation = VERTICAL
        build()
    }
}
