package com.docera.parwez

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Quick Note keeper: a persistent notification with a "Quick Note" button. Tapping it opens the note page
 * (QuickNoteActivity) as a normal split-screen window next to the app you are using, with Docera's own
 * Urdu / English keyboard. No overlay is drawn any more, so no "Display over other apps" permission is needed.
 */
class QuickNoteService : Service() {

    companion object {
        const val ACTION_STOP = "docera.qn.stop"
        private const val CHANNEL = "docera_quicknote"
        private const val NOTIF_ID = 4102

        @Volatile
        var running = false

        fun start(ctx: Context) {
            try {
                val i = Intent(ctx, QuickNoteService::class.java)
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (_: Throwable) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, QuickNoteService::class.java))
            } catch (_: Throwable) {
            }
        }

        /** Kept for the existing settings screen: split-screen needs no overlay permission, so this is always true. */
        @Suppress("UNUSED_PARAMETER")
        fun hasOverlay(ctx: Context): Boolean = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showForeground()
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun showForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Quick Note", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            this, 1, QuickNoteLauncher.intent(this),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Docera Quick Note")
            .setContentText("Tap Quick Note to write beside any app (split screen)")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_edit, "Quick Note", open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
