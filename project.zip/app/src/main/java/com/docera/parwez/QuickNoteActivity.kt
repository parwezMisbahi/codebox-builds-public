package com.docera.parwez

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Quick Note page. Opens as its own window, so Android puts it beside the app you are using (split screen).
 * Header + writing area on top, Docera's own Urdu / English keyboard below. The system keyboard is never used.
 * Text is auto-saved and synced into Docera's notes.
 */
class QuickNoteActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var edit: EditText? = null
    private var status: TextView? = null
    private var kb: QuickKeyboard? = null
    private var noteId = ""
    private var loading = false
    private val saveRun = Runnable { saveNow() }

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)
    private fun dpi(v: Float) = dp(v).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        window.statusBarColor = 0xFF17181C.toInt()
        window.navigationBarColor = 0xFF17181C.toInt()
        buildUi()
    }

    private fun buildUi() {
        noteId = QuickNoteStore.currentId(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF17181C.toInt())
        }
        val padL = dpi(8f); val padT = dpi(4f); val padR = dpi(8f); val padB = dpi(6f)
        root.setPadding(padL, padT, padR, padB)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(padL + bars.left, padT + bars.top, padR + bars.right, padB + bars.bottom)
            insets
        }

        // header
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Quick Note"; setTextColor(0xFFE8E9EE.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        status = TextView(this).apply {
            text = ""; setTextColor(0xFF7FD99A.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setPadding(dpi(8f), 0, 0, 0)
        }
        val bNew = QuickKeyboard.chip(this, "+ New") { saveNow(); noteId = QuickNoteStore.newNote(this); loadText() }
        val bLang = QuickKeyboard.chip(this, "") { kb?.toggleLang() }
        val bX = QuickKeyboard.chip(this, "✕") { saveNow(); finish() }
        head.addView(title); head.addView(status)
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        for (b in listOf(bNew, bLang, bX)) {
            head.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dpi(34f)).apply { leftMargin = dpi(6f) })
        }
        root.addView(head, LinearLayout.LayoutParams(-1, dpi(38f)))

        // writing area
        val et = EditText(this).apply {
            setTextColor(0xFFF2F3F7.toInt()); setHintTextColor(0xFF70737D.toInt())
            hint = "Write here…  /  یہاں لکھیں"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = QuickKeyboard.round(0xFF22242A.toInt(), dp(8f))
            setPadding(dpi(10f), dpi(6f), dpi(10f), dpi(6f))
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            showSoftInputOnFocus = false          // Docera's own keyboard only
            isVerticalScrollBarEnabled = true
            isFocusableInTouchMode = true
        }
        edit = et
        root.addView(et, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dpi(2f); bottomMargin = dpi(6f) })

        // keyboard (about 55% of the window height)
        val k = QuickKeyboard(this, et, QuickNoteStore.lang(this)) { l ->
            QuickNoteStore.setLang(this, l)
            bLang.text = if (l == "ur") "اردو ✓" else "EN ✓"
            et.hint = if (l == "ur") "یہاں لکھیں…" else "Write here…"
        }
        kb = k
        bLang.text = if (QuickNoteStore.lang(this) == "ur") "اردو ✓" else "EN ✓"
        root.addView(k, LinearLayout.LayoutParams(-1, 0, 1.25f))

        loadText()
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loading) return
                status?.text = "…"
                handler.removeCallbacks(saveRun)
                handler.postDelayed(saveRun, 500)
            }
        })
        setContentView(root)
        et.requestFocus()
    }

    private fun loadText() {
        val et = edit ?: return
        loading = true
        et.setText(QuickNoteStore.text(this, noteId))
        et.setSelection(et.text.length)
        loading = false
        status?.text = ""
    }

    private fun saveNow() {
        handler.removeCallbacks(saveRun)
        val et = edit ?: return
        if (noteId.isEmpty()) return
        QuickNoteStore.save(this, noteId, et.text.toString())
        status?.text = if (et.text.isNotBlank()) "✓ Saved" else ""
        try { MainActivity.pullHook?.invoke() } catch (_: Throwable) { }
    }

    override fun onPause() {
        saveNow()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(saveRun)
        super.onDestroy()
    }
}
