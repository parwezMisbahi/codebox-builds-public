package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper

/** Opens the Quick Note page next to the app that is on screen (split screen). */
object QuickNoteLauncher {

    fun intent(ctx: Context): Intent =
        Intent(ctx, QuickNoteActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT
        )

    /**
     * If Docera's accessibility service is on and the screen is not split yet, put the current app into
     * split-screen first, then open the note in the other half. Returns false when this helper cannot do it
     * (caller should then launch the activity itself).
     */
    fun splitThenOpen(ctx: Context): Boolean {
        val svc = AppBlockService.instance ?: return false
        if (svc.splitActive()) return false
        val h = Handler(Looper.getMainLooper())
        try {
            if (Build.VERSION.SDK_INT >= 31) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } catch (_: Throwable) {
        }
        h.postDelayed({
            try { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN) } catch (_: Throwable) {}
        }, 400)
        h.postDelayed({
            try { svc.startActivity(intent(ctx)) } catch (_: Throwable) {}
        }, 1500)
        return true
    }
}
