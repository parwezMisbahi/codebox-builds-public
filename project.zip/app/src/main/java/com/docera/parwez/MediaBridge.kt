package com.docera.parwez

import android.content.Context
import android.webkit.JavascriptInterface

/** JS side of the background-video notification (window.AndroidMedia). */
class MediaBridge(private val ctx: Context) {
    @JavascriptInterface
    fun show(title: String?, playing: Boolean) {
        MediaPlayService.show(ctx, title ?: "", playing)
    }

    @JavascriptInterface
    fun stop() {
        MediaPlayService.stop(ctx)
    }

    /** screen locked / app left: play only the sound natively from this second */
    @JavascriptInterface
    fun audioStart(url: String?, posSec: Double, rate: Double, title: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        return MediaPlayService.audioStart(url, (posSec * 1000).toInt().coerceAtLeast(0), rate.toFloat(), title ?: "")
    }

    /** back in the app: where the sound reached ("ms,1" playing / "ms,0" paused), "" if not in audio mode */
    @JavascriptInterface
    fun audioStop(): String = MediaPlayService.audioStop()
}
