package com.docera.parwez

import android.content.Context
import android.webkit.JavascriptInterface

/** JS side of the background-video notification (window.AndroidMedia). */
class MediaBridge(private val ctx: Context) {
    @JavascriptInterface
    fun show(title: String?, playing: Boolean) {
        MediaPlayService.show(ctx, title ?: "", playing)
    }

    /** Bluetooth scroll mode on/off (sensor buttons scroll the page) */
    @JavascriptInterface
    fun setBtScroll(on: Boolean) {
        MediaPlayService.btScroll = on
        BtKeys.scroll = on
        BtKeys.refresh(ctx)
    }

    /** key tester open: every button is reported to the page instead of acting */
    @JavascriptInterface
    fun setBtTest(on: Boolean) {
        BtKeys.test = on
        BtKeys.refresh(ctx)
    }

    /** is the optional "Docera Bluetooth scroll" accessibility service switched on? */
    @JavascriptInterface
    fun btA11yOn(): Boolean = try {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as android.view.accessibility.AccessibilityManager
        am.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == ctx.packageName && it.resolveInfo.serviceInfo.name == BtKeyService::class.java.name
        }
    } catch (_: Throwable) { false }

    @JavascriptInterface
    fun btA11yOpen() {
        try {
            ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun stop() {
        MediaPlayService.stop(ctx)
    }

    /** screen locked / app left: play only the sound natively from this second */
    @JavascriptInterface
    fun audioStart(url: String?, posSec: Double, rate: Double, title: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        return MediaPlayService.audioStart(url, (posSec * 1000).toInt().coerceAtLeast(0), rate.toFloat(), title ?: "")
    }

    /** back in the app: where the sound reached ("ms,1" playing / "ms,0" paused), "" if not in audio mode */
    @JavascriptInterface
    fun audioStop(): String = MediaPlayService.audioStop()
}
