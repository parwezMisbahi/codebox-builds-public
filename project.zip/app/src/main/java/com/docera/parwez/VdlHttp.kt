package com.docera.parwez

import android.content.Context
import android.net.Uri
import java.io.FileInputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.SecureRandom

/**
 * Tiny web server that listens ONLY on 127.0.0.1 (the phone itself) and hands the videos downloaded by VideoDL to the
 * video player with proper HTTP Range support. (The WebView's own request interception cannot stream long videos
 * reliably.) Every address carries a random key, so other apps cannot read the files.
 */
object VdlHttp {
    private const val AUTH = "content://com.parwez.videodl.bridge"
    private var server: ServerSocket? = null
    private var key = ""

    @Synchronized
    fun url(ctx: Context, id: String): String {
        if (!Regex("[A-Za-z0-9-]+").matches(id)) return ""
        if (server == null || server!!.isClosed) start(ctx.applicationContext)
        val s = server ?: return ""
        return "http://127.0.0.1:${s.localPort}/v/$id?k=$key"
    }

    private fun start(app: Context) {
        val b = ByteArray(12)
        SecureRandom().nextBytes(b)
        key = b.joinToString("") { "%02x".format(it) }
        val s = ServerSocket(0, 20, InetAddress.getByName("127.0.0.1"))
        server = s
        Thread {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    Thread { handle(app, c) }.start()
                } catch (_: Exception) { break }
            }
        }.start()
    }

    private fun handle(app: Context, c: Socket) {
        try {
            c.soTimeout = 30000
            val ins = c.getInputStream()
            val reader = ins.bufferedReader(Charsets.ISO_8859_1)
            val first = reader.readLine() ?: return
            var range: String? = null
            while (true) {
                val l = reader.readLine() ?: break
                if (l.isEmpty()) break
                if (l.startsWith("Range:", true)) range = l.substring(6).trim()
            }
            val out = c.getOutputStream()
            fun reply(code: Int, msg: String, extra: String = "") {
                out.write(("HTTP/1.1 $code $msg\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n$extra\r\n").toByteArray())
                out.flush()
            }
            val p = first.split(" ")
            if (p.size < 2) return reply(400, "Bad Request")
            val head = p[0] == "HEAD"
            val u = Uri.parse("http://x" + p[1])
            val id = (u.path ?: "").removePrefix("/v/")
            if (u.getQueryParameter("k") != key || !Regex("[A-Za-z0-9-]+").matches(id)) return reply(403, "Forbidden", "Content-Length: 0\r\n")
            val pfd = try { app.contentResolver.openFileDescriptor(Uri.parse("$AUTH/file/$id"), "r") } catch (_: Exception) { null }
                ?: return reply(404, "Not Found", "Content-Length: 0\r\n")
            pfd.use {
                val total = pfd.statSize
                var start = 0L
                var end = total - 1
                var partial = false
                if (range != null) {
                    val m = Regex("bytes=(\\d*)-(\\d*)").find(range!!)
                    if (m != null) {
                        val a = m.groupValues[1]
                        val b = m.groupValues[2]
                        if (a.isEmpty() && b.isNotEmpty()) start = (total - b.toLong()).coerceAtLeast(0)
                        else if (a.isNotEmpty()) { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), total - 1) }
                        partial = true
                    }
                }
                if (start >= total) return reply(416, "Range Not Satisfiable", "Content-Range: bytes */$total\r\nContent-Length: 0\r\n")
                val len = end - start + 1
                reply(
                    if (partial) 206 else 200, if (partial) "Partial Content" else "OK",
                    "Content-Type: video/mp4\r\nAccept-Ranges: bytes\r\nContent-Length: $len\r\n" +
                        (if (partial) "Content-Range: bytes $start-$end/$total\r\n" else "")
                )
                if (head) return
                val ch = FileInputStream(pfd.fileDescriptor).channel   // positional reads: parallel requests never disturb each other
                val buf = ByteArray(64 * 1024)
                var pos = start
                var left = len
                while (left > 0) {
                    val n = ch.read(ByteBuffer.wrap(buf, 0, minOf(buf.size.toLong(), left).toInt()), pos)
                    if (n <= 0) break
                    out.write(buf, 0, n)
                    pos += n
                    left -= n
                }
                out.flush()
            }
        } catch (_: Exception) {
        } finally {
            try { c.close() } catch (_: Exception) {}
        }
    }
}
