package com.docera.parwez

import android.content.Context
import android.content.Intent

/**
 * The AI chat app used as a fallback for the PDF Assistant (Translate / Summary / Explain / Research / Extract text)
 * when no API key is set or the direct API call fails. Chosen in Settings -> PDF Assistant -> "If the API can't help".
 */
object AiApps {
    class Ai(val key: String, val label: String, val pkg: String)

    val ALL = listOf(
        Ai("chatgpt", "ChatGPT", "com.openai.chatgpt"),
        Ai("claude", "Claude", "com.anthropic.claude"),
        Ai("gemini", "Gemini", "com.google.android.apps.bard"),
        Ai("perplexity", "Perplexity", "ai.perplexity.app.android"),
        Ai("grok", "Grok", "ai.x.grok"),
        Ai("copilot", "Copilot", "com.microsoft.copilot"),
        Ai("deepseek", "DeepSeek", "com.deepseek.chat")
    )

    private fun p(c: Context) = c.getSharedPreferences("docera_ai_apps", Context.MODE_PRIVATE)

    fun selected(c: Context): Ai = ALL.firstOrNull { it.key == p(c).getString("ai", "chatgpt") } ?: ALL[0]
    fun select(c: Context, key: String) { p(c).edit().putString("ai", key).apply() }

    fun launchIntent(c: Context, ai: Ai): Intent? = try {
        c.packageManager.getLaunchIntentForPackage(ai.pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    } catch (_: Exception) { null }

    fun installed(c: Context, ai: Ai): Boolean = launchIntent(c, ai) != null
}
