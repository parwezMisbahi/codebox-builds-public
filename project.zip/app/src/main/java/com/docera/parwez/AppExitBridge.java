package com.docera.parwez;

import android.app.Activity;
import android.webkit.JavascriptInterface;

/** window.AndroidApp: the page asks the app to close when Back is pressed at the very top (home, nothing open). */
public final class AppExitBridge {
    private final Activity act;

    public AppExitBridge(Activity a) { act = a; }

    @JavascriptInterface
    public void exit() {
        act.runOnUiThread(new Runnable() {
            @Override public void run() {
                try { act.finish(); } catch (Throwable ignored) {}
            }
        });
    }
}
