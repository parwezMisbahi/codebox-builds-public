package com.docera.parwez

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Syllabus reminder: every evening (8 pm) Docera checks whether today's page target was reached and,
 * if not, posts a notification. The target rises by itself when the person falls behind:
 * target = ceil((pages left + pages read today) / days left).
 * The numbers come from the reader (JS) every time the page changes.
 */
object SylAlert {
    private const val PREFS = "docera_syl_alert"
    private const val CH = "syl_alert_hi"
    private const val HOUR = 20
    private const val DAY = 86_400_000L

    fun save(ctx: Context, enabled: Boolean, name: String, left: Int, end: Long, today: Int, day: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("on", enabled && left > 0 && end > 0)
            .putString("name", name).putInt("left", left).putLong("end", end)
            .putInt("today", today).putString("day", day).apply()
        schedule(ctx)
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(ctx, 7001, Intent(ctx, SylAlertReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** Next 8 pm (today if still ahead, otherwise tomorrow). Inexact alarm, so no special permission is needed. */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!sp.getBoolean("on", false)) { am.cancel(pending(ctx)); return }
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, HOUR); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60_000L) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.timeInMillis, pending(ctx))
    }

    fun canNotify(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun fire(ctx: Context) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!sp.getBoolean("on", false) || !canNotify(ctx)) return
        val left = sp.getInt("left", 0)
        val end = sp.getLong("end", 0L)
        if (left <= 0 || end <= 0) return
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val read = if (sp.getString("day", "") == todayStr) sp.getInt("today", 0) else 0
        val days = Math.max(0L, (end - System.currentTimeMillis() + DAY - 1) / DAY).toInt()
        val target = if (days > 0) (left + read + days - 1) / days else left + read
        if (read >= target) return
        val name = (sp.getString("name", "") ?: "").removeSuffix(".pdf").ifBlank { "your PDF" }
        val title = if (days == 0) "Syllabus deadline is over" else "Behind on your syllabus"
        val body = if (days == 0) "$name: $left pages are still left."
        else "$name: read ${target - read} more page${if (target - read > 1) "s" else ""} today to finish on time ($left left · $days day${if (days > 1) "s" else ""})."
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            // old low-key channel replaced by a heads-up one (pops up on screen, then hides)
            try { nm.deleteNotificationChannel("syl_alert") } catch (_: Throwable) {}
            nm.createNotificationChannel(NotificationChannel(CH, "Syllabus reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val tap = PendingIntent.getActivity(ctx, 7002, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(ctx, CH) else android.app.Notification.Builder(ctx)
        if (Build.VERSION.SDK_INT < 26) b.setPriority(android.app.Notification.PRIORITY_HIGH)
        b.setSmallIcon(R.drawable.ic_w_note).setContentTitle(title).setContentText(body)
            .setStyle(android.app.Notification.BigTextStyle().bigText(body)).setContentIntent(tap).setAutoCancel(true)
        nm.notify(7003, b.build())
    }
}

class SylAlertReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try { SylAlert.fire(context) } catch (_: Throwable) {}
        try { SylAlert.schedule(context) } catch (_: Throwable) {}
    }
}
