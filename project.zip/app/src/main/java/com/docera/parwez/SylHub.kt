package com.docera.parwez

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Syllabus hub: progress of EVERY PDF that has a syllabus.
 *  - per-PDF reminder (switched on by hand for each PDF)
 *  - one summary notification for all PDFs
 *  - data for the summary home-screen widget (SylHubWidget)
 * Notifications use a HIGH importance channel, so they pop up on screen (heads-up, like WhatsApp) and then hide
 * into the notification shade by themselves.
 * The reader (JS) pushes the list whenever progress changes; days left / "behind" are recalculated here every time.
 */
object SylHub {
    private const val PREFS = "docera_syl_hub"
    private const val CH_PDF = "syl_pdf_hi"
    private const val CH_ALL = "syl_all_hi"
    private const val DAY = 86_400_000L

    class E(
        val id: String, val name: String, val from: Int, val to: Int, val cur: Int,
        val today: Int, val end: Long, val start: Long, val pn: Boolean
    )

    class S(
        val e: E, val tot: Int, val done: Int, val left: Int, val days: Int,
        val toRead: Int, val behind: Int, val today: Int
    ) {
        val title: String get() = e.name.removeSuffix(".pdf").ifBlank { "PDF" }
        val finished: Boolean get() = left <= 0
        val readLine: String get() = "$done of $tot pages read · $left left"
        /** Short one-liner for the widget: "180 left · 12d · 18 behind" */
        val shortLine: String
            get() = if (finished) "Finished" else "$left left" +
                (if (days > 0) " · ${days}d" else if (days == 0) " · time over" else "") +
                (if (behind > 0) " · $behind behind" else "")
        val timeLine: String
            get() = when {
                finished -> "Finished 🎉"
                days < 0 -> "No deadline"
                days == 0 -> "Time is over" + (if (behind > 0) " · $behind pages behind" else "")
                else -> "$days day${if (days > 1) "s" else ""} left" +
                    (if (behind > 0) " · $behind page${if (behind > 1) "s" else ""} behind" else " · on time")
            }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun todayStr() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    /** times = up to 3 reminder times a day as "08:00,14:00,20:00" (empty = fall back to hour:minute). */
    fun save(ctx: Context, json: String, allOn: Boolean, hour: Int, minute: Int, times: String = "") {
        val sp = prefs(ctx)
        val changed = sp.getString("json", "") != json || sp.getBoolean("all", false) != allOn ||
            sp.getInt("h", 8) != hour || sp.getInt("m", 0) != minute || sp.getString("times", "") != times
        sp.edit().putString("json", json).putBoolean("all", allOn).putInt("h", hour).putInt("m", minute)
            .putString("times", times).putString("day", todayStr()).apply()
        schedule(ctx)
        if (changed) SylHubWidget.refresh(ctx)
    }

    fun load(ctx: Context): List<E> {
        val sp = prefs(ctx)
        val out = ArrayList<E>()
        try {
            val a = JSONArray(sp.getString("json", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    E(
                        o.optString("id"), o.optString("name"), o.optInt("from", 1), o.optInt("to", 1),
                        o.optInt("cur", 1), o.optInt("today", 0), o.optLong("end", 0L), o.optLong("start", 0L),
                        o.optInt("pn", 0) == 1
                    )
                )
            }
        } catch (_: Throwable) {
        }
        return out
    }

    fun stats(ctx: Context): List<S> {
        val sp = prefs(ctx)
        val sameDay = sp.getString("day", "") == todayStr()
        return load(ctx).map { stat(it, sameDay) }
    }

    private fun stat(e: E, sameDay: Boolean): S {
        val now = System.currentTimeMillis()
        val tot = Math.max(1, e.to - e.from + 1)
        val done = (e.cur - e.from + 1).coerceIn(0, tot)
        val left = tot - done
        val today = if (sameDay) e.today else 0
        val days = if (e.end > 0) Math.max(0L, (e.end - now + DAY - 1) / DAY).toInt() else -1
        val toRead = when {
            left <= 0 -> 0
            days > 0 -> Math.max(0, (left + today + days - 1) / days - today)
            else -> left
        }
        var behind = 0
        if (left > 0 && e.start > 0 && e.end > e.start) {
            val span = Math.max(1L, Math.round((e.end - e.start).toDouble() / DAY))
            val elapsed = ((now - e.start) / DAY).coerceIn(0L, span)
            val expected = Math.ceil(tot.toDouble() * elapsed / span).toInt()
            behind = Math.max(0, expected - Math.max(0, done - today))
        }
        return S(e, tot, done, left, days, toRead, behind, today)
    }

    private fun pending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, 7011, Intent(ctx, SylHubReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Next reminder time chosen in the syllabus panel (inexact alarm: no special permission needed). */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val sp = prefs(ctx)
        val any = sp.getBoolean("all", false) || load(ctx).any { it.pn }
        if (!any) { am.cancel(pending(ctx)); return }
        // minutes-of-day of every chosen time (max 3); the nearest one still ahead of now wins, else the first one tomorrow
        val mins = ArrayList<Int>()
        for (p in (sp.getString("times", "") ?: "").split(",")) {
            val hm = p.trim().split(":")
            val h = hm.getOrNull(0)?.toIntOrNull(); val m = hm.getOrNull(1)?.toIntOrNull()
            if (h != null && m != null && h in 0..23 && m in 0..59) mins.add(h * 60 + m)
        }
        if (mins.isEmpty()) mins.add(sp.getInt("h", 8) * 60 + sp.getInt("m", 0))
        val now = System.currentTimeMillis()
        var best = Long.MAX_VALUE
        for (dayAdd in 0..1) for (mm in mins.distinct().take(3)) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, dayAdd)
                set(Calendar.HOUR_OF_DAY, mm / 60); set(Calendar.MINUTE, mm % 60)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > now + 60_000L && c.timeInMillis < best) best = c.timeInMillis
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pending(ctx))
    }

    private fun channels(ctx: Context): NotificationManager {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_PDF, "PDF syllabus reminders", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(CH_ALL, "All PDFs summary", NotificationManager.IMPORTANCE_HIGH))
        }
        return nm
    }

    @Suppress("DEPRECATION")
    private fun builder(ctx: Context, ch: String): Notification.Builder {
        val b = if (android.os.Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, ch) else Notification.Builder(ctx)
        if (android.os.Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH)
            b.setDefaults(Notification.DEFAULT_ALL)
        }
        val open = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val tap = PendingIntent.getActivity(ctx, 7012, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return b.setSmallIcon(R.drawable.ic_w_note).setContentIntent(tap).setAutoCancel(true)
            .setCategory(Notification.CATEGORY_REMINDER)
    }

    private fun postPdf(ctx: Context, nm: NotificationManager, s: S, index: Int) {
        val sb = StringBuilder()
        sb.append(s.readLine).append(".")
        if (s.days >= 0) sb.append(if (s.days == 0) " Time is over." else " ${s.days} day${if (s.days > 1) "s" else ""} left.")
        if (s.behind > 0) sb.append(" You are ${s.behind} page${if (s.behind > 1) "s" else ""} behind.")
        if (s.toRead > 0) sb.append(" Read ${s.toRead} more page${if (s.toRead > 1) "s" else ""} today to finish on time.")
        val body = sb.toString()
        val b = builder(ctx, CH_PDF).setContentTitle(s.title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
        nm.notify(7100 + (index % 40), b.build())
    }

    private fun postAll(ctx: Context, nm: NotificationManager, list: List<S>) {
        val open = list.filter { !it.finished }
        val behind = open.count { it.behind > 0 || (it.days == 0) }
        val head = when {
            list.isEmpty() -> "No syllabus set yet"
            open.isEmpty() -> "All ${list.size} PDFs finished 🎉"
            else -> "${open.size} PDF${if (open.size > 1) "s" else ""} in progress" + (if (behind > 0) " · $behind behind" else " · all on time") +
                open.sumOf { it.toRead }.let { if (it > 0) " · read $it pages today" else " · today's target done" }
        }
        val inbox = Notification.InboxStyle()
        val sorted = list.sortedWith(compareBy<S>({ it.finished }, { -it.behind }, { if (it.days < 0) Int.MAX_VALUE else it.days }))
        sorted.take(6).forEach { s ->
            inbox.addLine(if (s.finished) "${s.title} — finished" else "${s.title} — ${s.left} left · " +
                (if (s.days < 0) "no deadline" else if (s.days == 0) "time over" else "${s.days}d") +
                (if (s.behind > 0) " · ${s.behind} behind" else ""))
        }
        if (sorted.size > 6) inbox.setSummaryText("+${sorted.size - 6} more")
        val b = builder(ctx, CH_ALL).setContentTitle("Docera · PDF progress").setContentText(head)
            .setStyle(inbox)
        nm.notify(7020, b.build())
    }

    /** Alarm: summary of all PDFs (if switched on) + one notification for each PDF that has its own reminder on. */
    fun fire(ctx: Context) {
        if (!SylAlert.canNotify(ctx)) return
        val sp = prefs(ctx)
        val list = stats(ctx)
        val nm = channels(ctx)
        if (sp.getBoolean("all", false) && list.isNotEmpty()) postAll(ctx, nm, list)
        list.filter { it.e.pn && !it.finished }.take(20).forEachIndexed { i, s -> postPdf(ctx, nm, s, i) }
    }

    /** Manual: id = one PDF, "" = all PDFs. Returns false if there was nothing to show. */
    fun showNow(ctx: Context, id: String): Boolean {
        val list = stats(ctx)
        val nm = channels(ctx)
        if (id.isEmpty()) {
            if (list.isEmpty()) return false
            postAll(ctx, nm, list)
            return true
        }
        val s = list.firstOrNull { it.e.id == id } ?: return false
        postPdf(ctx, nm, s, Math.abs(id.hashCode()))
        return true
    }
}

class SylHubReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try { SylHub.fire(context) } catch (_: Throwable) {}
        try { SylHub.schedule(context) } catch (_: Throwable) {}
        try { SylHubWidget.refresh(context) } catch (_: Throwable) {}
    }
}
