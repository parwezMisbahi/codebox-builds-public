package com.docera.parwez

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/** Home-screen widget: one row for every PDF with a syllabus (pages read / left, days left, pages behind). */
class SylHubWidget : AppWidgetProvider() {
    companion object {
        fun refresh(ctx: Context) {
            val app = ctx.applicationContext
            val mgr = AppWidgetManager.getInstance(app)
            val ids = mgr.getAppWidgetIds(ComponentName(app, SylHubWidget::class.java))
            if (ids.isEmpty()) return
            push(app, mgr, ids)
            mgr.notifyAppWidgetViewDataChanged(ids, R.id.sylList)
        }

        fun push(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val open = Intent(ctx, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val tap = PendingIntent.getActivity(ctx, 41, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_syl)
                val svc = Intent(ctx, SylHubService::class.java)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
                rv.setRemoteAdapter(R.id.sylList, svc)
                rv.setEmptyView(R.id.sylList, R.id.sylEmpty)
                rv.setPendingIntentTemplate(R.id.sylList, tap)
                rv.setOnClickPendingIntent(R.id.sylOpen, tap)
                rv.setOnClickPendingIntent(R.id.sylEmpty, tap)
                mgr.updateAppWidget(id, rv)
            }
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        push(ctx, mgr, ids)
        mgr.notifyAppWidgetViewDataChanged(ids, R.id.sylList)
    }
}

class SylHubService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
        private var rows: List<SylHub.S> = emptyList()

        override fun onCreate() {}
        override fun onDataSetChanged() {
            rows = try {
                SylHub.stats(ctx).sortedWith(
                    compareBy<SylHub.S>({ it.finished }, { -it.behind }, { if (it.days < 0) Int.MAX_VALUE else it.days })
                )
            } catch (_: Throwable) { emptyList() }
        }

        override fun onDestroy() { rows = emptyList() }
        override fun getCount() = rows.size
        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_syl_item)
            val s = rows.getOrNull(position) ?: return rv
            rv.setTextViewText(R.id.wsName, s.title)
            rv.setTextViewText(R.id.wsInfo, s.shortLine)
            rv.setTextColor(R.id.wsInfo, if (!s.finished && (s.behind > 0 || s.days == 0)) Color.parseColor("#C62828") else ctx.getColor(R.color.w_mu))
            rv.setViewVisibility(R.id.wsBar, View.VISIBLE)
            rv.setProgressBar(R.id.wsBar, s.tot, s.done, false)
            rv.setOnClickFillInIntent(R.id.wsRoot, Intent())
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = position.toLong()
        override fun hasStableIds() = false
    }
}
