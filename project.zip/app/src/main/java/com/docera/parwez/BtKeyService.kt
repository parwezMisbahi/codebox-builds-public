package com.docera.parwez

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Optional: lets Docera see the buttons of a Bluetooth sensor / clicker / headset before any other app does,
 * so they can scroll the PDF. It only reacts while Docera is in front AND "Bluetooth scroll" is switched on in the PDF viewer.
 * It never reads the screen and never touches anything else.
 */
class BtKeyService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onKeyEvent(event: KeyEvent): Boolean = try { BtKeys.handle(event, "access") } catch (_: Throwable) { false }
}
