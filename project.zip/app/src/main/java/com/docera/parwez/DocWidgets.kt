package com.docera.parwez

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.RemoteViews
import java.io.File

private fun widgetIntent(ctx: Context, action: String, code: Int): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java)
        .setAction(Intent.ACTION_MAIN)
        .putExtra("wa", action)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

/** Opens Docera as a brand-new window: every tap adds one more Docera card in Recents (each can hold its own PDF). */
private fun newWindowIntent(ctx: Context, code: Int): PendingIntent {
    val i = Intent(ctx, MainActivity::class.java)
        .setAction(Intent.ACTION_MAIN)
        .addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                Intent.FLAG_ACTIVITY_MULTIPLE_TASK
        )
    return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

/** Home-screen widget with shortcuts: new note, scan to PDF, new Docera window, last video, continue reading. */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_quick)
            rv.setOnClickPendingIntent(R.id.wNote, widgetIntent(ctx, "note", 11))
            rv.setOnClickPendingIntent(R.id.wScan, widgetIntent(ctx, "scan", 12))
            rv.setOnClickPendingIntent(R.id.wTabs, newWindowIntent(ctx, 13))
            rv.setOnClickPendingIntent(R.id.wLast, widgetIntent(ctx, "last", 14))
            rv.setOnClickPendingIntent(R.id.wVideo, widgetIntent(ctx, "video", 15))
            mgr.updateAppWidget(id, rv)
        }
    }
}

/** Home-screen widget that shows the PDF you were reading last; tap to continue. */
class ReadWidget : AppWidgetProvider() {
    companion object {
        private const val PREFS = "docera_widget"
        private var lastPush = 0L
        private var trailing = false
        private val ui = Handler(Looper.getMainLooper())

        fun save(ctx: Context, name: String, page: Int, total: Int) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val changed = sp.getString("name", "") != name || sp.getInt("page", 0) != page
            if (!changed) return
            sp.edit().putString("name", name).putInt("page", page).putInt("total", total).apply()
            val now = System.currentTimeMillis()
            if (now - lastPush < 5000) {
                // Throttled: still push the final page once the 5s window ends, otherwise the widget stays stale
                // until the next page change (which may never come if the user stops reading).
                if (!trailing) {
                    trailing = true
                    val app = ctx.applicationContext
                    ui.postDelayed({
                        trailing = false
                        lastPush = System.currentTimeMillis()
                        refresh(app)
                    }, 5000 - (now - lastPush) + 50)
                }
                return
            }
            lastPush = now
            refresh(ctx)
        }

        /** Syllabus of the PDF being read (pages from..to, optional finish date in ms; 0 = none). */
        fun saveSyl(ctx: Context, from: Int, to: Int, end: Long) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (sp.getInt("sylFrom", 0) == from && sp.getInt("sylTo", 0) == to && sp.getLong("sylEnd", 0L) == end) return
            sp.edit().putInt("sylFrom", from).putInt("sylTo", to).putLong("sylEnd", end).apply()
            refresh(ctx.applicationContext)
        }

        private fun thumbFile(ctx: Context) = File(ctx.filesDir, "widget_thumb.jpg")

        /** Stores the cover of the PDF being read; ignored if the user has already moved on to another PDF. */
        fun saveThumb(ctx: Context, name: String, b64: String) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (sp.getString("name", "") != name || b64.length > 400_000) return
            thumbFile(ctx).writeBytes(Base64.decode(b64, Base64.DEFAULT))
            sp.edit().putString("thumbFor", name).apply()
            refresh(ctx.applicationContext)
        }

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ReadWidget::class.java))
            if (ids.isNotEmpty()) push(ctx, mgr, ids)
        }

        fun push(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val name = sp.getString("name", "") ?: ""
            val page = sp.getInt("page", 0)
            val total = sp.getInt("total", 0)
            val sFrom = sp.getInt("sylFrom", 0)
            val sTo = sp.getInt("sylTo", 0)
            val sEnd = sp.getLong("sylEnd", 0L)
            val hasSyl = name.isNotEmpty() && sFrom > 0 && sTo >= sFrom
            val sRange = if (hasSyl) sTo - sFrom + 1 else 0
            val sDone = if (hasSyl) (page - sFrom + 1).coerceIn(0, sRange) else 0
            val sLeft = sRange - sDone
            val sDays = if (hasSyl && sEnd > 0) Math.max(0L, (sEnd - System.currentTimeMillis() + 86_399_999L) / 86_400_000L).toInt() else -1
            for (id in ids) {
                val rv = RemoteViews(ctx.packageName, R.layout.widget_read)
                if (name.isEmpty()) {
                    rv.setTextViewText(R.id.wrName, "No PDF read yet")
                    rv.setTextViewText(R.id.wrPage, "Open a PDF in Docera")
                } else {
                    rv.setTextViewText(R.id.wrName, name.removeSuffix(".pdf"))
                    rv.setTextViewText(R.id.wrPage, when {
                        hasSyl && sLeft == 0 -> "Syllabus finished"
                        hasSyl -> "$sLeft pages left" + (if (sDays >= 0) " · ${sDays}d" else "")
                        total > 0 -> "Page $page of $total"
                        else -> "Page $page"
                    })
                }
                if (hasSyl) {
                    rv.setViewVisibility(R.id.wrBar, android.view.View.VISIBLE)
                    rv.setProgressBar(R.id.wrBar, sRange, sDone, false)
                } else if (name.isNotEmpty() && total > 0) {
                    rv.setViewVisibility(R.id.wrBar, android.view.View.VISIBLE)
                    rv.setProgressBar(R.id.wrBar, total, page.coerceIn(0, total), false)
                } else {
                    rv.setViewVisibility(R.id.wrBar, android.view.View.GONE)
                }
                val tf = thumbFile(ctx)
                val bmp = if (name.isNotEmpty() && sp.getString("thumbFor", "") == name && tf.exists())
                    try { BitmapFactory.decodeFile(tf.path) } catch (_: Throwable) { null } else null
                if (bmp != null) {
                    rv.setImageViewBitmap(R.id.wrThumb, bmp)
                    rv.setViewVisibility(R.id.wrThumb, android.view.View.VISIBLE)
                } else rv.setViewVisibility(R.id.wrThumb, android.view.View.GONE)
                rv.setOnClickPendingIntent(R.id.wrRoot, widgetIntent(ctx, "last", 21))
                mgr.updateAppWidget(id, rv)
            }
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = push(ctx, mgr, ids)
}

/** Pill: each tap opens another Docera window (separate card in Recents). The round button on the right opens the PDF picker. */
class WindowWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_window)
            rv.setOnClickPendingIntent(R.id.wwRoot, newWindowIntent(ctx, 31))
            rv.setOnClickPendingIntent(R.id.wwPlus, widgetIntent(ctx, "pick", 32))
            mgr.updateAppWidget(id, rv)
        }
    }
}
