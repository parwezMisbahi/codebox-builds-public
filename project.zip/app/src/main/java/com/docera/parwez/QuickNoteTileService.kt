package com.docera.parwez

import android.app.PendingIntent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** "Quick Note" tile for the quick-settings panel (Edit and sort -> drag it in). */
class QuickNoteTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Quick Note"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        if (isLocked) unlockAndRun { open() } else open()
    }

    @Suppress("DEPRECATION")
    private fun open() {
        try { QuickNoteStore.setEnabled(this, true) } catch (_: Throwable) {}
        if (QuickNoteLauncher.splitThenOpen(applicationContext)) return
        val i = QuickNoteLauncher.intent(this)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(this, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                startActivityAndCollapse(pi)
            } else {
                startActivityAndCollapse(i)
            }
        } catch (_: Throwable) {
        }
    }
}
