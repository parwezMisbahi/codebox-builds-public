package com.docera.parwez

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Floating Quick Note storage. Every quick note lives here first (instant, works while Docera is closed);
 * dirty notes are handed to the web UI (docCmdPull -> takeQuickNotes) which saves them as normal Docera notes.
 */
object QuickNoteStore {
    private const val PREFS = "docera_quicknote"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = p(ctx).getBoolean("enabled", false)
    fun setEnabled(ctx: Context, on: Boolean) { p(ctx).edit().putBoolean("enabled", on).apply() }

    fun lang(ctx: Context): String = p(ctx).getString("lang", "en") ?: "en"
    fun setLang(ctx: Context, l: String) { p(ctx).edit().putString("lang", l).apply() }

    private fun notes(ctx: Context): JSONObject = try {
        JSONObject(p(ctx).getString("notes", "{}") ?: "{}")
    } catch (_: Exception) {
        JSONObject()
    }

    /** id of the note the panel is writing into (a new id is made when there is none yet) */
    @Synchronized
    fun currentId(ctx: Context): String {
        val c = p(ctx).getString("cur", null)
        if (c != null) return c
        return newNote(ctx)
    }

    @Synchronized
    fun newNote(ctx: Context): String {
        val id = "qn" + System.currentTimeMillis().toString(36)
        p(ctx).edit().putString("cur", id).apply()
        return id
    }

    fun text(ctx: Context, id: String): String = notes(ctx).optJSONObject(id)?.optString("text", "") ?: ""

    /** Auto-save: keeps the text and marks it for syncing into Docera's notes. */
    @Synchronized
    fun save(ctx: Context, id: String, text: String) {
        val all = notes(ctx)
        val old = all.optJSONObject(id)
        if (old == null && text.isBlank()) return
        if (old != null && old.optString("text") == text) return
        all.put(id, JSONObject().put("text", text).put("t", System.currentTimeMillis()).put("dirty", true))
        // keep the store small: only the 30 newest notes stay here (all of them are in Docera already)
        if (all.length() > 30) {
            val keys = all.keys().asSequence().toList().sortedBy { all.getJSONObject(it).optLong("t") }
            for (k in keys.take(all.length() - 30)) if (k != id && k != p(ctx).getString("cur", "")) all.remove(k)
        }
        p(ctx).edit().putString("notes", all.toString()).apply()
    }

    /** Dirty notes as a JSON array [{qid,text,t}]; they are marked as handed over. */
    @Synchronized
    fun takeDirty(ctx: Context): String {
        val all = notes(ctx)
        val out = JSONArray()
        for (k in all.keys().asSequence().toList()) {
            val o = all.getJSONObject(k)
            if (o.optBoolean("dirty")) {
                out.put(JSONObject().put("qid", k).put("text", o.optString("text")).put("t", o.optLong("t")))
                o.put("dirty", false)
            }
        }
        if (out.length() > 0) p(ctx).edit().putString("notes", all.toString()).apply()
        return out.toString()
    }

    /** JS could not save a note: mark it dirty again so it is retried. */
    @Synchronized
    fun retry(ctx: Context, id: String) {
        val all = notes(ctx)
        all.optJSONObject(id)?.put("dirty", true)
        p(ctx).edit().putString("notes", all.toString()).apply()
    }
}
