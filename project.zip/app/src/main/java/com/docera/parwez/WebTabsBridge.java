package com.docera.parwez;

import android.webkit.JavascriptInterface;

/** window.AndroidWeb: lets the reader page open and place website tabs (see WebTabs). Only the app's own page gets it. */
public final class WebTabsBridge {
    private final WebTabs tabs;

    public WebTabsBridge(WebTabs t) { tabs = t; }

    @JavascriptInterface public boolean ok() { return true; }
    @JavascriptInterface public void open(String id, String url) { tabs.open(id, url); }
    @JavascriptInterface public void show(String id, int l, int t, int w, int h) { tabs.show(id, l, t, w, h); }
    @JavascriptInterface public void suspend(boolean off) { tabs.suspend(off); }
    @JavascriptInterface public void hide() { tabs.hide(); }
    @JavascriptInterface public void remove(String id) { tabs.remove(id); }
    @JavascriptInterface public void reload(String id) { tabs.reload(id); }
    @JavascriptInterface public void load(String id, String url) { tabs.load(id, url); }
    @JavascriptInterface public String url(String id) { return tabs.currentUrl(id); }
    @JavascriptInterface public void external(String id) { tabs.openExternally(id); }
    @JavascriptInterface public String check(String url) { return tabs.check(url); }
}
