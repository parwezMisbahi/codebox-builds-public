package com.parwez.videodl

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

enum class DlState { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED }

data class NewDownload(val url: String, val title: String, val thumb: String?)

class DownloadItem(
    val id: String,
    val url: String,
    var title: String,
    val thumb: String?,
    val audioOnly: Boolean,
    val height: Int?,
    val seq: Long,
    var state: DlState = DlState.QUEUED,
    var progress: Int = 0,
    var error: String = "",
    var savedUri: String = "",
    var savedName: String = ""
) {
    var speed: String = ""
    var note: String = ""

    @Volatile var stopRequest: Int = 0   // 0 none, 1 pause, 2 cancel/remove
    @Volatile var lastUi: Long = 0

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("url", url); put("title", title)
        put("thumb", thumb ?: ""); put("audioOnly", audioOnly)
        put("height", height ?: -1); put("seq", seq)
        put("state", state.name); put("progress", progress)
        put("error", error); put("savedUri", savedUri); put("savedName", savedName)
    }

    companion object {
        fun fromJson(o: JSONObject): DownloadItem {
            val h = o.optInt("height", -1)
            var st = try { DlState.valueOf(o.optString("state")) } catch (e: Exception) { DlState.PAUSED }
            // anything that was running when the app died becomes "paused" (can be resumed)
            if (st == DlState.DOWNLOADING || st == DlState.QUEUED) st = DlState.PAUSED
            return DownloadItem(
                id = o.getString("id"),
                url = o.getString("url"),
                title = o.optString("title"),
                thumb = o.optString("thumb").ifBlank { null },
                audioOnly = o.optBoolean("audioOnly"),
                height = if (h > 0) h else null,
                seq = o.optLong("seq"),
                state = st,
                progress = o.optInt("progress"),
                error = o.optString("error"),
                savedUri = o.optString("savedUri"),
                savedName = o.optString("savedName")
            )
        }
    }
}

object DownloadManager {
    private const val MAX_PARALLEL = 2
    private const val PREFS = "videodl_prefs"
    private const val KEY = "downloads"

    interface Listener {
        fun onListChanged()
        fun onItemChanged(item: DownloadItem)
    }

    /** Touched only on the main thread. */
    val items = mutableListOf<DownloadItem>()

    private val listeners = mutableSetOf<Listener>()
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: Context
    private var inited = false
    private var seqCounter = 0L

    var engineReady = false

    fun init(context: Context) {
        if (inited) return
        inited = true
        app = context.applicationContext
        load()
    }

    fun addListener(l: Listener) { listeners.add(l) }
    fun removeListener(l: Listener) { listeners.remove(l) }
    private fun notifyList() { listeners.toList().forEach { it.onListChanged() } }
    private fun notifyItem(item: DownloadItem) { listeners.toList().forEach { it.onItemChanged(item) } }

    fun activeCount(): Int =
        items.count { it.state == DlState.DOWNLOADING || it.state == DlState.QUEUED }

    // ---------- public actions (main thread) ----------

    fun enqueue(list: List<NewDownload>, audioOnly: Boolean, height: Int?) {
        val created = list.map {
            DownloadItem(
                id = UUID.randomUUID().toString(),
                url = it.url, title = it.title, thumb = it.thumb,
                audioOnly = audioOnly, height = height, seq = seqCounter++
            )
        }
        items.addAll(0, created)
        save(); notifyList(); pump()
    }

    fun pause(item: DownloadItem) {
        when (item.state) {
            DlState.QUEUED -> { item.state = DlState.PAUSED; save(); notifyList() }
            DlState.DOWNLOADING -> {
                item.stopRequest = 1
                item.note = "Pausing..."
                notifyItem(item)
                killProcess(item)
            }
            else -> {}
        }
    }

    fun resume(item: DownloadItem) {
        if (item.state == DlState.PAUSED || item.state == DlState.FAILED) {
            item.state = DlState.QUEUED
            item.stopRequest = 0
            item.error = ""
            item.note = ""
            save(); notifyList(); pump()
        }
    }

    fun delete(item: DownloadItem, deleteFile: Boolean) {
        val wasDownloading = item.state == DlState.DOWNLOADING
        val wasCompleted = item.state == DlState.COMPLETED
        item.stopRequest = 2
        items.remove(item)
        if (wasDownloading) killProcess(item) else workDir(item).deleteRecursively()
        if (deleteFile && wasCompleted) scope.launch { deleteSaved(item) }
        save(); notifyList(); pump()
    }

    fun clearCompleted() {
        items.removeAll { it.state == DlState.COMPLETED }
        save(); notifyList()
    }

    fun uriFor(item: DownloadItem): Uri? {
        if (item.savedUri.isBlank()) return null
        return if (item.savedUri.startsWith("content://")) Uri.parse(item.savedUri)
        else FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", File(item.savedUri))
    }

    fun pump() {
        if (!engineReady) return
        var running = items.count { it.state == DlState.DOWNLOADING }
        while (running < MAX_PARALLEL) {
            val next = items.filter { it.state == DlState.QUEUED }.minByOrNull { it.seq } ?: break
            start(next)
            running++
        }
    }

    // ---------- internals ----------

    private fun start(item: DownloadItem) {
        item.state = DlState.DOWNLOADING
        item.stopRequest = 0
        item.error = ""
        item.note = ""
        item.speed = ""
        notifyList()
        scope.launch { runDownload(item) }
    }

    private fun killProcess(item: DownloadItem) {
        scope.launch {
            repeat(6) {
                val wanted = withContext(Dispatchers.Main) {
                    item.state == DlState.DOWNLOADING && item.stopRequest != 0
                }
                if (!wanted) return@launch
                try { YoutubeDL.getInstance().destroyProcessById(item.id) } catch (_: Exception) { }
                delay(700)
            }
        }
    }

    private fun workDir(item: DownloadItem) = File(app.filesDir, "dl/${item.id}")

    private suspend fun runDownload(item: DownloadItem) {
        val dir = workDir(item).apply { mkdirs() }
        try {
            if (item.stopRequest != 0) throw IllegalStateException("stopped")

            val req = YoutubeDLRequest(item.url)
            req.addOption("-o", "${dir.absolutePath}/%(title).100s.%(ext)s")
            req.addOption("--no-mtime")
            req.addOption("--no-playlist")
            req.addOption("--continue")
            req.addOption("-N", "4")
            if (item.audioOnly) {
                req.addOption("-x")
                req.addOption("--audio-format", "mp3")
            } else {
                val h = item.height
                val f = if (h == null) "bv*+ba/b" else "bv*[height<=$h]+ba/b[height<=$h]/b"
                req.addOption("-f", f)
                req.addOption("--merge-output-format", "mp4")
            }

            YoutubeDL.getInstance().execute(req, item.id) { progress, _, line ->
                onProgress(item, progress, line ?: "")
            }

            val files = dir.listFiles { f ->
                f.isFile && !f.name.endsWith(".part") && !f.name.endsWith(".ytdl") &&
                    !f.name.endsWith(".temp")
            }.orEmpty()
            val result = files.maxByOrNull { it.length() }
                ?: throw IllegalStateException("No file was produced")

            val removed = withContext(Dispatchers.Main) { item !in items }
            if (removed) {
                dir.deleteRecursively()
                return
            }

            val saved = saveToDownloads(result)
            withContext(Dispatchers.Main) {
                item.state = DlState.COMPLETED
                item.progress = 100
                item.speed = ""
                item.note = ""
                item.savedUri = saved
                item.savedName = result.name
                save(); notifyList(); pump()
            }
            dir.deleteRecursively()
        } catch (e: Exception) {
            val removed = withContext(Dispatchers.Main) {
                val gone = item !in items || item.stopRequest == 2
                if (!gone) {
                    if (item.stopRequest == 1) {
                        item.state = DlState.PAUSED
                    } else {
                        item.state = DlState.FAILED
                        item.error = shortError(e)
                    }
                    item.speed = ""
                    item.note = ""
                }
                save(); notifyList(); pump()
                gone
            }
            if (removed) dir.deleteRecursively()
        }
    }

    private fun onProgress(item: DownloadItem, progress: Float, line: String) {
        val now = SystemClock.elapsedRealtime()
        val newNote = when {
            line.contains("[Merger]") || line.contains("Merging formats") -> "Merging..."
            line.contains("[ExtractAudio]") -> "Converting to MP3..."
            else -> null
        }
        if (newNote == null && now - item.lastUi < 300) return
        item.lastUi = now

        val p = progress.toInt().coerceIn(0, 100)
        val speed = Regex("at\\s+(\\S+/s)").find(line)?.groupValues?.get(1)
        main.post {
            if (item.state != DlState.DOWNLOADING) return@post
            if (p > item.progress) item.progress = p
            if (speed != null) item.speed = speed
            if (newNote != null && item.note != "Pausing...") item.note = newNote
            notifyItem(item)
        }
    }

    private fun shortError(e: Throwable): String {
        val msg = e.message ?: return "Unknown error"
        val line = msg.lines().lastOrNull { it.contains("ERROR", ignoreCase = true) }
            ?: msg.lines().firstOrNull { it.isNotBlank() } ?: msg
        return line.removePrefix("ERROR:").trim().take(140)
    }

    private fun saveToDownloads(file: File): String {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/VideoDL")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = app.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            resolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri.toString()
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "VideoDL"
            ).apply { mkdirs() }
            val target = File(dir, file.name)
            file.copyTo(target, overwrite = true)
            return target.absolutePath
        }
    }

    private fun deleteSaved(item: DownloadItem) {
        try {
            if (item.savedUri.startsWith("content://")) {
                app.contentResolver.delete(Uri.parse(item.savedUri), null, null)
            } else if (item.savedUri.isNotBlank()) {
                File(item.savedUri).delete()
            }
        } catch (_: Exception) { }
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    private fun load() {
        try {
            val s = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) {
                val it = DownloadItem.fromJson(arr.getJSONObject(i))
                items.add(it)
                if (it.seq >= seqCounter) seqCounter = it.seq + 1
            }
        } catch (_: Exception) { }
    }
}
