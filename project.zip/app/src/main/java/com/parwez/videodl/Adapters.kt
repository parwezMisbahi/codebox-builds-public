package com.parwez.videodl

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.progressindicator.LinearProgressIndicator

class PlaylistEntry(
    val url: String,
    val title: String,
    val thumb: String?,
    val duration: Long,
    var checked: Boolean
)

class PlaylistAdapter(private val onChanged: () -> Unit) :
    RecyclerView.Adapter<PlaylistAdapter.VH>() {

    var entries: List<PlaylistEntry> = emptyList()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val check: MaterialCheckBox = v.findViewById(R.id.entryCheck)
        val thumb: ImageView = v.findViewById(R.id.entryThumb)
        val title: TextView = v.findViewById(R.id.entryTitle)
        val duration: TextView = v.findViewById(R.id.entryDuration)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_playlist_entry, parent, false))

    override fun getItemCount() = entries.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = entries[position]
        holder.title.text = e.title
        holder.duration.text = Fmt.duration(e.duration)
        holder.check.isChecked = e.checked
        ThumbLoader.load(holder.thumb, e.thumb)
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                val en = entries[pos]
                en.checked = !en.checked
                notifyItemChanged(pos)
                onChanged()
            }
        }
    }

    fun setAll(checked: Boolean) {
        entries.forEach { it.checked = checked }
        notifyDataSetChanged()
        onChanged()
    }

    fun selectedCount() = entries.count { it.checked }
}

class DownloadsAdapter(
    private val onPrimary: (DownloadItem) -> Unit,
    private val onDelete: (DownloadItem) -> Unit
) : RecyclerView.Adapter<DownloadsAdapter.VH>() {

    companion object {
        const val PAYLOAD_PROGRESS = "progress"
    }

    private var list: List<DownloadItem> = emptyList()

    fun submit(l: List<DownloadItem>) {
        list = l.toList()
        notifyDataSetChanged()
    }

    fun indexOf(item: DownloadItem) = list.indexOf(item)

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.dlThumb)
        val title: TextView = v.findViewById(R.id.dlTitle)
        val status: TextView = v.findViewById(R.id.dlStatus)
        val progress: LinearProgressIndicator = v.findViewById(R.id.dlProgress)
        val primary: MaterialButton = v.findViewById(R.id.dlPrimary)
        val delete: MaterialButton = v.findViewById(R.id.dlDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_download, parent, false))

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            bindState(holder, list[position], animate = true)
        } else {
            onBindViewHolder(holder, position)
        }
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]
        holder.title.text = item.title.ifBlank { item.url }
        ThumbLoader.load(holder.thumb, item.thumb)
        holder.primary.setOnClickListener { onPrimary(item) }
        holder.delete.setOnClickListener { onDelete(item) }
        bindState(holder, item, animate = false)
    }

    private fun bindState(holder: VH, item: DownloadItem, animate: Boolean) {
        val ctx = holder.itemView.context
        val secondary = ContextCompat.getColor(ctx, R.color.text_secondary)
        val green = ContextCompat.getColor(ctx, R.color.green)
        val red = ContextCompat.getColor(ctx, R.color.red)

        val text: String
        var color = secondary
        when (item.state) {
            DlState.QUEUED -> text = "Waiting in queue"
            DlState.DOWNLOADING -> {
                text = if (item.note.isNotEmpty()) item.note
                else if (item.speed.isNotEmpty()) "Downloading ${item.progress}%  -  ${item.speed}"
                else "Downloading ${item.progress}%"
            }
            DlState.PAUSED -> text = "Paused  -  ${item.progress}%"
            DlState.COMPLETED -> { text = "Completed  -  Downloads/VideoDL"; color = green }
            DlState.FAILED -> { text = "Failed  -  ${item.error}"; color = red }
        }
        holder.status.text = text
        holder.status.setTextColor(color)

        val showBar = item.state != DlState.COMPLETED && item.state != DlState.FAILED
        holder.progress.visibility = if (showBar) View.VISIBLE else View.GONE
        if (showBar) holder.progress.setProgressCompat(item.progress, animate)

        when (item.state) {
            DlState.QUEUED, DlState.DOWNLOADING -> {
                holder.primary.text = "Pause"
                holder.primary.setIconResource(R.drawable.ic_pause)
            }
            DlState.PAUSED -> {
                holder.primary.text = "Resume"
                holder.primary.setIconResource(R.drawable.ic_play)
            }
            DlState.FAILED -> {
                holder.primary.text = "Retry"
                holder.primary.setIconResource(R.drawable.ic_refresh)
            }
            DlState.COMPLETED -> {
                holder.primary.text = "Open"
                holder.primary.setIconResource(R.drawable.ic_open)
            }
        }
    }
}
