package com.parwez.videodl

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Tiny thumbnail loader: memory cache, max 4 parallel downloads, cancels stale loads. */
object ThumbLoader {
    private val cache = LruCache<String, Bitmap>(80)
    private val gate = Semaphore(4)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun load(view: ImageView, rawUrl: String?) {
        (view.getTag(R.id.thumb_job) as? Job)?.cancel()
        view.setTag(R.id.thumb_job, null)
        view.tag = rawUrl
        view.setImageDrawable(null)
        if (rawUrl.isNullOrBlank()) return
        val url = rawUrl.replace("http://", "https://")

        cache.get(url)?.let {
            view.setImageBitmap(it)
            return
        }
        val job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { gate.withPermit { fetch(url) } }
            if (bmp != null) {
                cache.put(url, bmp)
                if (view.tag == rawUrl) view.setImageBitmap(bmp)
            }
        }
        view.setTag(R.id.thumb_job, job)
    }

    private fun fetch(url: String): Bitmap? = try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.inputStream.use { stream ->
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeStream(stream, null, opts)
        }
    } catch (e: Exception) {
        null
    }
}
