package com.parwez.videodl

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.ChipGroup
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var urlLayout: TextInputLayout
    private lateinit var urlInput: TextInputEditText
    private lateinit var fetchBtn: MaterialButton
    private lateinit var previewCard: MaterialCardView
    private lateinit var thumbView: ImageView
    private lateinit var durationBadge: TextView
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var modeToggle: MaterialButtonToggleGroup
    private lateinit var qualityBox: View
    private lateinit var qualityGroup: ChipGroup
    private lateinit var downloadBtn: MaterialButton
    private lateinit var cancelBtn: MaterialButton
    private lateinit var updateBtn: MaterialButton
    private lateinit var percentText: TextView
    private lateinit var speedText: TextView
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var statusText: TextView

    private var engineReady = false
    private var pendingAutoFetch = false
    private val processId = "videodl_download"

    private val heights: Map<Int, Int?> = mapOf(
        R.id.chipBest to null,
        R.id.chip1080 to 1080,
        R.id.chip720 to 720,
        R.id.chip480 to 480,
        R.id.chip360 to 360
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlLayout = findViewById(R.id.urlLayout)
        urlInput = findViewById(R.id.urlInput)
        fetchBtn = findViewById(R.id.fetchBtn)
        previewCard = findViewById(R.id.previewCard)
        thumbView = findViewById(R.id.thumbView)
        durationBadge = findViewById(R.id.durationBadge)
        titleText = findViewById(R.id.titleText)
        metaText = findViewById(R.id.metaText)
        modeToggle = findViewById(R.id.modeToggle)
        qualityBox = findViewById(R.id.qualityBox)
        qualityGroup = findViewById(R.id.qualityGroup)
        downloadBtn = findViewById(R.id.downloadBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        updateBtn = findViewById(R.id.updateBtn)
        percentText = findViewById(R.id.percentText)
        speedText = findViewById(R.id.speedText)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)

        urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        fetchBtn.setOnClickListener { fetchInfo() }
        downloadBtn.setOnClickListener { startDownload() }
        updateBtn.setOnClickListener { updateEngine() }
        cancelBtn.setOnClickListener {
            YoutubeDL.getInstance().destroyProcessById(processId)
            resetProgress()
            setStatus("Download cancelled")
            setState(busy = false)
        }
        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                qualityBox.visibility = if (checkedId == R.id.btnAudio) View.GONE else View.VISIBLE
            }
        }

        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }

        handleSharedIntent(intent)
        initEngine()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
        if (engineReady && pendingAutoFetch) {
            pendingAutoFetch = false
            fetchInfo()
        }
    }

    private fun handleSharedIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = Regex("https?://\\S+").find(text)?.value ?: text
            urlInput.setText(link)
            pendingAutoFetch = true
        }
    }

    // ---------- Engine ----------

    private fun initEngine() {
        setState(busy = true)
        setStatus("Starting engine...")
        lifecycleScope.launch {
            val error = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    null
                } catch (e: Exception) {
                    e.printStackTrace()
                    e.message ?: "unknown error"
                }
            }
            engineReady = error == null
            setStatus(if (engineReady) "Ready. Paste a video link." else "Engine failed: $error")
            setState(busy = false)
            if (engineReady && pendingAutoFetch) {
                pendingAutoFetch = false
                fetchInfo()
            }
        }
    }

    private fun updateEngine() {
        if (!engineReady) return
        setState(busy = true)
        setStatus("Updating yt-dlp...")
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) { runUpdateReflective() }
            setStatus(msg)
            setState(busy = false)
        }
    }

    /**
     * Calls YoutubeDL.updateYoutubeDL(...) via reflection so the app compiles
     * no matter which overload / channel type the library version exposes.
     */
    private fun runUpdateReflective(): String {
        var lastError: Throwable? = null
        val ytdl = YoutubeDL.getInstance()
        val methods = YoutubeDL::class.java.methods
            .filter { it.name == "updateYoutubeDL" }
            .sortedBy { it.parameterTypes.size }
        for (m in methods) {
            try {
                val args: Array<Any?> = when (m.parameterTypes.size) {
                    1 -> arrayOf(applicationContext)
                    2 -> {
                        val channel = findStableChannel(m.parameterTypes[1]) ?: continue
                        arrayOf(applicationContext, channel)
                    }
                    else -> continue
                }
                val target = if (java.lang.reflect.Modifier.isStatic(m.modifiers)) null else ytdl
                val result = m.invoke(target, *args)
                return "Engine update finished: $result"
            } catch (e: Throwable) {
                lastError = e.cause ?: e
            }
        }
        return "Update failed: ${lastError?.message ?: "no update method found"}"
    }

    private fun findStableChannel(type: Class<*>): Any? {
        type.fields.firstOrNull {
            it.name.contains("STABLE", ignoreCase = true) &&
                java.lang.reflect.Modifier.isStatic(it.modifiers)
        }?.let { return it.get(null) }
        for (c in type.declaredClasses) {
            if (c.simpleName.contains("stable", ignoreCase = true)) {
                try {
                    return c.getField("INSTANCE").get(null)
                } catch (_: Exception) { }
            }
        }
        return null
    }

    // ---------- Input ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val link = Regex("https?://\\S+").find(text)?.value ?: text.trim()
        urlInput.setText(link)
        if (engineReady) fetchInfo() else pendingAutoFetch = true
    }

    private fun currentUrl(): String? {
        val url = urlInput.text?.toString()?.trim().orEmpty()
        if (!url.startsWith("http")) {
            urlLayout.error = "Enter a valid link"
            return null
        }
        urlLayout.error = null
        return url
    }

    // ---------- Info ----------

    private fun fetchInfo() {
        if (!engineReady) return
        val url = currentUrl() ?: return
        setState(busy = true)
        setStatus("Fetching video info...")
        previewCard.visibility = View.GONE
        lifecycleScope.launch {
            val info = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url))
                } catch (e: Exception) {
                    setStatus("Could not fetch info: ${e.message}")
                    null
                }
            }
            if (info != null) {
                titleText.text = info.title ?: "Untitled"
                metaText.text = info.uploader ?: ""
                durationBadge.text = formatDuration(info.duration.toLong())
                durationBadge.visibility = if (info.duration > 0) View.VISIBLE else View.GONE
                thumbView.setImageDrawable(null)
                previewCard.visibility = View.VISIBLE
                setStatus("Ready to download")
                info.thumbnail?.let { loadThumbnail(it) }
            }
            setState(busy = false)
        }
    }

    private fun loadThumbnail(url: String) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                } catch (e: Exception) {
                    null
                }
            }
            if (bmp != null) thumbView.setImageBitmap(bmp)
        }
    }

    private fun formatDuration(totalSec: Long): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
    }

    // ---------- Download ----------

    private fun startDownload() {
        if (!engineReady) return
        val url = currentUrl() ?: return
        val audioOnly = modeToggle.checkedButtonId == R.id.btnAudio
        val height = heights[qualityGroup.checkedChipId]

        val tmpDir = File(cacheDir, "dl_${System.currentTimeMillis()}").apply { mkdirs() }

        setState(busy = true, canCancel = true)
        progressBar.setProgressCompat(0, false)
        percentText.visibility = View.VISIBLE
        percentText.text = "0%"
        speedText.text = ""
        setStatus("Starting download...")

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("-o", "${tmpDir.absolutePath}/%(title).100s.%(ext)s")
                    req.addOption("--no-mtime")
                    req.addOption("--no-playlist")
                    if (audioOnly) {
                        req.addOption("-x")
                        req.addOption("--audio-format", "mp3")
                    } else {
                        val f = if (height == null) "bv*+ba/b"
                        else "bv*[height<=$height]+ba/b[height<=$height]/b"
                        req.addOption("-f", f)
                        req.addOption("--merge-output-format", "mp4")
                    }

                    YoutubeDL.getInstance().execute(req, processId) { progress, eta, line ->
                        val p = progress.toInt().coerceIn(0, 100)
                        val speed = Regex("at\\s+(\\S+/s)").find(line ?: "")?.groupValues?.get(1) ?: ""
                        runOnUiThread {
                            progressBar.setProgressCompat(p, true)
                            percentText.text = "$p%"
                            speedText.text = speed
                            statusText.text = if (p >= 100) "Finalizing..." else "Downloading... ETA ${eta}s"
                        }
                    }

                    val files = tmpDir.listFiles { f ->
                        f.isFile && !f.name.endsWith(".part") && !f.name.endsWith(".ytdl")
                    }.orEmpty()
                    if (files.isEmpty()) {
                        "Download finished but no file was found."
                    } else {
                        files.forEach { saveToDownloads(it) }
                        "Saved to Downloads/VideoDL\n" + files.joinToString("\n") { it.name }
                    }
                } catch (e: Exception) {
                    "Download failed: ${e.message}"
                } finally {
                    tmpDir.deleteRecursively()
                }
            }
            val ok = result.startsWith("Saved")
            if (ok) progressBar.setProgressCompat(100, true) else resetProgress()
            percentText.visibility = if (ok) View.VISIBLE else View.GONE
            if (ok) percentText.text = "Done"
            speedText.text = ""
            setStatus(result)
            setState(busy = false)
        }
    }

    private fun saveToDownloads(file: File) {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/VideoDL")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            resolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "VideoDL"
            ).apply { mkdirs() }
            file.copyTo(File(dir, file.name), overwrite = true)
        }
    }

    // ---------- UI helpers ----------

    private fun resetProgress() {
        runOnUiThread {
            progressBar.setProgressCompat(0, false)
            percentText.visibility = View.GONE
            speedText.text = ""
        }
    }

    private fun setStatus(text: String) {
        runOnUiThread { statusText.text = text }
    }

    private fun setState(busy: Boolean, canCancel: Boolean = false) {
        runOnUiThread {
            downloadBtn.isEnabled = !busy
            fetchBtn.isEnabled = !busy
            updateBtn.isEnabled = !busy
            cancelBtn.visibility = if (busy && canCancel) View.VISIBLE else View.GONE
        }
    }
}
