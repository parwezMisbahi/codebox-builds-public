package com.parwez.videodl

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: TextInputEditText
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var downloadBtn: Button
    private lateinit var cancelBtn: Button
    private lateinit var modeAudio: RadioButton
    private lateinit var qualitySpinner: Spinner

    private var engineReady = false
    private val processId = "videodl_download"

    private val qualities = listOf("Best", "1080p", "720p", "480p", "360p")
    private val heights = listOf(null, 1080, 720, 480, 360)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)
        downloadBtn = findViewById(R.id.downloadBtn)
        cancelBtn = findViewById(R.id.cancelBtn)
        modeAudio = findViewById(R.id.modeAudio)
        qualitySpinner = findViewById(R.id.qualitySpinner)

        qualitySpinner.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, qualities)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        findViewById<Button>(R.id.infoBtn).setOnClickListener { fetchInfo() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateEngine() }
        downloadBtn.setOnClickListener { startDownload() }
        cancelBtn.setOnClickListener {
            YoutubeDL.getInstance().destroyProcessById(processId)
            setStatus("Cancelled")
            setBusy(false)
        }
        findViewById<RadioButton>(R.id.modeVideo).setOnClickListener {
            qualitySpinner.visibility = View.VISIBLE
        }
        modeAudio.setOnClickListener { qualitySpinner.visibility = View.GONE }

        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }

        handleSharedIntent(intent)
        initEngine()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
    }

    private fun handleSharedIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = Regex("https?://\\S+").find(text)?.value ?: text
            urlInput.setText(link)
        }
    }

    private fun initEngine() {
        setBusy(true)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    true
                } catch (e: Exception) {
                    e.printStackTrace()
                    setStatus("Engine init failed: ${e.message}")
                    false
                }
            }
            engineReady = ok
            if (ok) setStatus("Ready. Paste a link.")
            setBusy(false)
        }
    }

    private fun updateEngine() {
        if (!engineReady) return
        setBusy(true)
        setStatus("Updating yt-dlp...")
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    val r = YoutubeDL.getInstance()
                        .updateYoutubeDL(applicationContext, YoutubeDL.UpdateChannel.STABLE)
                    "Update done: $r"
                } catch (e: Exception) {
                    "Update failed: ${e.message}"
                }
            }
            setStatus(msg)
            setBusy(false)
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else {
            urlInput.setText(text.trim())
        }
    }

    private fun currentUrl(): String? {
        val url = urlInput.text?.toString()?.trim().orEmpty()
        if (!url.startsWith("http")) {
            Toast.makeText(this, "Enter a valid link", Toast.LENGTH_SHORT).show()
            return null
        }
        return url
    }

    private fun fetchInfo() {
        if (!engineReady) return
        val url = currentUrl() ?: return
        setBusy(true)
        setStatus("Fetching info...")
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                try {
                    val info = YoutubeDL.getInstance().getInfo(YoutubeDLRequest(url))
                    val mins = info.duration / 60
                    val secs = info.duration % 60
                    "Title: ${info.title}\nDuration: ${mins}m ${secs}s"
                } catch (e: Exception) {
                    "Could not fetch info: ${e.message}"
                }
            }
            setStatus(msg)
            setBusy(false)
        }
    }

    private fun startDownload() {
        if (!engineReady) return
        val url = currentUrl() ?: return
        val audioOnly = modeAudio.isChecked
        val height = heights[qualitySpinner.selectedItemPosition]

        val tmpDir = File(cacheDir, "dl_${System.currentTimeMillis()}").apply { mkdirs() }

        setBusy(true)
        progressBar.progress = 0
        setStatus("Starting download...")

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("-o", "${tmpDir.absolutePath}/%(title).100s.%(ext)s")
                    req.addOption("--no-mtime")
                    req.addOption("--no-playlist")
                    if (audioOnly) {
                        req.addOption("-x")
                        req.addOption("--audio-format", "mp3")
                    } else {
                        val f = if (height == null) "bv*+ba/b"
                        else "bv*[height<=$height]+ba/b[height<=$height]/b"
                        req.addOption("-f", f)
                        req.addOption("--merge-output-format", "mp4")
                    }

                    YoutubeDL.getInstance().execute(req, processId) { progress, eta, _ ->
                        runOnUiThread {
                            progressBar.progress = progress.toInt().coerceIn(0, 100)
                            setStatus("Downloading... ${progress.toInt()}%  (ETA ${eta}s)")
                        }
                    }

                    val files = tmpDir.listFiles { f ->
                        f.isFile && !f.name.endsWith(".part") && !f.name.endsWith(".ytdl")
                    }.orEmpty()
                    if (files.isEmpty()) {
                        "Download finished but no file was found."
                    } else {
                        files.forEach { saveToDownloads(it) }
                        "Saved to Downloads/VideoDL:\n" + files.joinToString("\n") { it.name }
                    }
                } catch (e: Exception) {
                    "Download failed: ${e.message}"
                } finally {
                    tmpDir.deleteRecursively()
                }
            }
            setStatus(result)
            setBusy(false)
        }
    }

    private fun saveToDownloads(file: File) {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/VideoDL")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            resolver.openOutputStream(uri)!!.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "VideoDL"
            ).apply { mkdirs() }
            file.copyTo(File(dir, file.name), overwrite = true)
        }
    }

    private fun setStatus(text: String) {
        runOnUiThread { statusText.text = text }
    }

    private fun setBusy(busy: Boolean) {
        runOnUiThread {
            downloadBtn.isEnabled = !busy
            cancelBtn.isEnabled = busy
        }
    }
}
