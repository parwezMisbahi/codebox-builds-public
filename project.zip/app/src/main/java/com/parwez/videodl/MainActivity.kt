package com.parwez.videodl

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class MainActivity : AppCompatActivity(), DownloadManager.Listener {

    companion object {
        private const val TELEGRAM_URL = "https://t.me/knowbitofficial"
        // popup comes back this long after the user tapped "Join" (24h = 2 times in 2 days)
        private const val JOIN_GAP_MS = 24L * 60 * 60 * 1000
        private const val PREFS = "videodl_prefs"
        private const val KEY_JOIN_TAP = "join_last_tap"
    }

    private var joinDialog: androidx.appcompat.app.AlertDialog? = null

    private class Fetched(
        val isPlaylist: Boolean,
        val title: String,
        val uploader: String,
        val duration: Long,
        val thumb: String?,
        val entries: List<PlaylistEntry>
    )

    // screens
    private lateinit var rootLayout: View
    private lateinit var screenDownload: View
    private lateinit var screenList: View
    private lateinit var bottomNav: BottomNavigationView

    // download screen
    private lateinit var urlLayout: TextInputLayout
    private lateinit var urlInput: TextInputEditText
    private lateinit var fetchBtn: MaterialButton
    private lateinit var fetchProgress: LinearProgressIndicator
    private lateinit var previewCard: MaterialCardView
    private lateinit var thumbView: ImageView
    private lateinit var durationBadge: TextView
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var playlistCard: MaterialCardView
    private lateinit var playlistTitle: TextView
    private lateinit var playlistMeta: TextView
    private lateinit var selectAllBox: MaterialCheckBox
    private lateinit var selectedCount: TextView
    private lateinit var playlistRecycler: RecyclerView
    private lateinit var modeToggle: MaterialButtonToggleGroup
    private lateinit var qualityBox: View
    private lateinit var qualityGroup: ChipGroup
    private lateinit var downloadBtn: MaterialButton
    private lateinit var updateBtn: MaterialButton
    private lateinit var statusText: TextView

    // downloads screen
    private lateinit var downloadsRecycler: RecyclerView
    private lateinit var emptyView: View
    private lateinit var clearBtn: MaterialButton

    private lateinit var playlistAdapter: PlaylistAdapter
    private lateinit var downloadsAdapter: DownloadsAdapter

    private var engineReady = false
    private var busy = false
    private var pendingAutoFetch = false
    private var fetched: Fetched? = null
    private var fetchedUrl: String = ""

    private val heights: Map<Int, Int?> = mapOf(
        R.id.chipBest to null,
        R.id.chip1080 to 1080,
        R.id.chip720 to 720,
        R.id.chip480 to 480,
        R.id.chip360 to 360
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        DownloadManager.init(applicationContext)

        rootLayout = findViewById(R.id.rootLayout)
        screenDownload = findViewById(R.id.screenDownload)
        screenList = findViewById(R.id.screenList)
        bottomNav = findViewById(R.id.bottomNav)

        urlLayout = findViewById(R.id.urlLayout)
        urlInput = findViewById(R.id.urlInput)
        fetchBtn = findViewById(R.id.fetchBtn)
        fetchProgress = findViewById(R.id.fetchProgress)
        previewCard = findViewById(R.id.previewCard)
        thumbView = findViewById(R.id.thumbView)
        durationBadge = findViewById(R.id.durationBadge)
        titleText = findViewById(R.id.titleText)
        metaText = findViewById(R.id.metaText)
        playlistCard = findViewById(R.id.playlistCard)
        playlistTitle = findViewById(R.id.playlistTitle)
        playlistMeta = findViewById(R.id.playlistMeta)
        selectAllBox = findViewById(R.id.selectAllBox)
        selectedCount = findViewById(R.id.selectedCount)
        playlistRecycler = findViewById(R.id.playlistRecycler)
        modeToggle = findViewById(R.id.modeToggle)
        qualityBox = findViewById(R.id.qualityBox)
        qualityGroup = findViewById(R.id.qualityGroup)
        downloadBtn = findViewById(R.id.downloadBtn)
        updateBtn = findViewById(R.id.updateBtn)
        statusText = findViewById(R.id.statusText)

        downloadsRecycler = findViewById(R.id.downloadsRecycler)
        emptyView = findViewById(R.id.emptyView)
        clearBtn = findViewById(R.id.clearBtn)

        // playlist list
        playlistAdapter = PlaylistAdapter { updateSelection() }
        playlistRecycler.layoutManager = LinearLayoutManager(this)
        playlistRecycler.adapter = playlistAdapter
        selectAllBox.setOnClickListener { playlistAdapter.setAll(selectAllBox.isChecked) }

        // downloads list
        downloadsAdapter = DownloadsAdapter(
            onPrimary = { onPrimaryAction(it) },
            onDelete = { confirmDelete(it) }
        )
        downloadsRecycler.layoutManager = LinearLayoutManager(this)
        downloadsRecycler.adapter = downloadsAdapter
        (downloadsRecycler.itemAnimator as? androidx.recyclerview.widget.SimpleItemAnimator)
            ?.supportsChangeAnimations = false
        clearBtn.setOnClickListener { DownloadManager.clearCompleted() }

        // inputs
        urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        urlInput.doAfterTextChanged {
            urlLayout.error = null
            if (it.toString().trim() != fetchedUrl) clearFetched()
        }
        fetchBtn.setOnClickListener { fetchInfo() }
        downloadBtn.setOnClickListener { onDownloadClick() }
        updateBtn.setOnClickListener { updateEngine() }
        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                qualityBox.visibility = if (checkedId == R.id.btnAudio) View.GONE else View.VISIBLE
            }
        }

        // bottom navigation
        bottomNav.setOnItemSelectedListener {
            showTab(it.itemId == R.id.nav_downloads)
            true
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (screenList.visibility == View.VISIBLE) {
                    showTab(false)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }

        handleSharedIntent(intent)
        refreshButtons()
        initEngine()
        maybeShowJoinDialog()
    }

    override fun onDestroy() {
        joinDialog?.dismiss()
        joinDialog = null
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        DownloadManager.addListener(this)
        onListChanged()
    }

    override fun onStop() {
        super.onStop()
        DownloadManager.removeListener(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleSharedIntent(intent)
        if (engineReady && pendingAutoFetch) {
            pendingAutoFetch = false
            fetchInfo()
        }
    }

    private fun handleSharedIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = Regex("https?://\\S+").find(text)?.value ?: text
            showTab(false)
            urlInput.setText(link)
            pendingAutoFetch = true
        }
    }

    // ---------- tabs ----------

    private fun showTab(downloads: Boolean) {
        screenDownload.visibility = if (downloads) View.GONE else View.VISIBLE
        screenList.visibility = if (downloads) View.VISIBLE else View.GONE
        val target = if (downloads) R.id.nav_downloads else R.id.nav_download
        if (bottomNav.selectedItemId != target) bottomNav.selectedItemId = target
    }

    private fun updateBadge() {
        val n = DownloadManager.activeCount()
        if (n > 0) {
            val badge = bottomNav.getOrCreateBadge(R.id.nav_downloads)
            badge.isVisible = true
            badge.number = n
        } else {
            bottomNav.removeBadge(R.id.nav_downloads)
        }
    }

    // ---------- DownloadManager.Listener ----------

    override fun onListChanged() {
        downloadsAdapter.submit(DownloadManager.items)
        emptyView.visibility = if (DownloadManager.items.isEmpty()) View.VISIBLE else View.GONE
        updateBadge()
    }

    override fun onItemChanged(item: DownloadItem) {
        val i = downloadsAdapter.indexOf(item)
        if (i >= 0) downloadsAdapter.notifyItemChanged(i, DownloadsAdapter.PAYLOAD_PROGRESS)
    }

    private fun onPrimaryAction(item: DownloadItem) {
        when (item.state) {
            DlState.QUEUED, DlState.DOWNLOADING -> DownloadManager.pause(item)
            DlState.PAUSED, DlState.FAILED -> DownloadManager.resume(item)
            DlState.COMPLETED -> openFile(item)
        }
    }

    private fun confirmDelete(item: DownloadItem) {
        if (item.state == DlState.COMPLETED) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Delete")
                .setItems(arrayOf("Remove from list", "Delete file too")) { _, which ->
                    DownloadManager.delete(item, which == 1)
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            MaterialAlertDialogBuilder(this)
                .setTitle("Remove this download?")
                .setMessage("Any partly downloaded data will be deleted.")
                .setPositiveButton("Remove") { _, _ -> DownloadManager.delete(item, false) }
                .setNegativeButton("Keep", null)
                .show()
        }
    }

    private fun openFile(item: DownloadItem) {
        try {
            val uri = DownloadManager.uriFor(item) ?: throw IllegalStateException("no file")
            val ext = item.savedName.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open file (moved or deleted?)", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- engine ----------

    private fun initEngine() {
        setBusy(true)
        setStatus("Starting engine...")
        lifecycleScope.launch {
            val error = withContext(Dispatchers.IO) {
                try {
                    YoutubeDL.getInstance().init(applicationContext)
                    FFmpeg.getInstance().init(applicationContext)
                    null
                } catch (e: Exception) {
                    e.printStackTrace()
                    e.message ?: "unknown error"
                }
            }
            engineReady = error == null
            DownloadManager.engineReady = engineReady
            setStatus(if (engineReady) "Ready. Paste a video or playlist link." else "Engine failed: $error")
            setBusy(false)
            if (engineReady) {
                DownloadManager.pump()
                if (pendingAutoFetch) {
                    pendingAutoFetch = false
                    fetchInfo()
                }
            }
        }
    }

    private fun updateEngine() {
        if (!engineReady) return
        setBusy(true)
        setStatus("Updating yt-dlp...")
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) { runUpdateReflective() }
            setStatus(msg)
            setBusy(false)
        }
    }

    /** Calls YoutubeDL.updateYoutubeDL(...) via reflection so any library version compiles. */
    private fun runUpdateReflective(): String {
        var lastError: Throwable? = null
        val ytdl = YoutubeDL.getInstance()
        val methods = YoutubeDL::class.java.methods
            .filter { it.name == "updateYoutubeDL" }
            .sortedBy { it.parameterTypes.size }
        for (m in methods) {
            try {
                val args: Array<Any?> = when (m.parameterTypes.size) {
                    1 -> arrayOf(applicationContext)
                    2 -> {
                        val channel = findStableChannel(m.parameterTypes[1]) ?: continue
                        arrayOf(applicationContext, channel)
                    }
                    else -> continue
                }
                val target = if (java.lang.reflect.Modifier.isStatic(m.modifiers)) null else ytdl
                val result = m.invoke(target, *args)
                return "Engine update finished: $result"
            } catch (e: Throwable) {
                lastError = e.cause ?: e
            }
        }
        return "Update failed: ${lastError?.message ?: "no update method found"}"
    }

    private fun findStableChannel(type: Class<*>): Any? {
        type.fields.firstOrNull {
            it.name.contains("STABLE", ignoreCase = true) &&
                java.lang.reflect.Modifier.isStatic(it.modifiers)
        }?.let { return it.get(null) }
        for (c in type.declaredClasses) {
            if (c.simpleName.contains("stable", ignoreCase = true)) {
                try {
                    return c.getField("INSTANCE").get(null)
                } catch (_: Exception) { }
            }
        }
        return null
    }

    // ---------- input ----------

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val link = Regex("https?://\\S+").find(text)?.value ?: text.trim()
        urlInput.setText(link)
        if (engineReady) fetchInfo() else pendingAutoFetch = true
    }

    private fun currentUrl(): String? {
        val url = urlInput.text?.toString()?.trim().orEmpty()
        if (!url.startsWith("http")) {
            urlLayout.error = "Enter a valid link"
            return null
        }
        urlLayout.error = null
        return url
    }

    // ---------- fetch (single video or playlist) ----------

    private fun fetchInfo() {
        if (!engineReady || busy) return
        val url = currentUrl() ?: return
        clearFetched()
        setBusy(true)
        fetchProgress.visibility = View.VISIBLE
        setStatus("Fetching info...")

        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("--flat-playlist")
                    req.addOption("--dump-single-json")
                    req.addOption("--no-warnings")
                    req.addOption("--playlist-end", "300")
                    val resp = YoutubeDL.getInstance().execute(req, "videodl_info") { _, _, _ -> }
                    val out = resp.out ?: ""
                    val json = JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
                    Pair(parseInfo(json), null as String?)
                } catch (e: Exception) {
                    Pair(null as Fetched?, e.message ?: "unknown error")
                }
            }
            fetchProgress.visibility = View.GONE
            val info = result.first
            if (info == null) {
                setStatus("Could not fetch info: ${result.second?.lines()?.lastOrNull { it.isNotBlank() }}")
            } else {
                fetched = info
                fetchedUrl = url
                showFetched(info)
            }
            setBusy(false)
        }
    }

    private fun parseInfo(json: JSONObject): Fetched {
        val type = json.optString("_type")
        if (type == "playlist" && json.has("entries")) {
            val arr = json.getJSONArray("entries")
            val list = ArrayList<PlaylistEntry>()
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                var url = e.optString("url").ifBlank { e.optString("webpage_url") }
                if (url.isBlank()) continue
                if (!url.startsWith("http")) {
                    url = if (e.optString("ie_key").equals("Youtube", true))
                        "https://www.youtube.com/watch?v=$url" else continue
                }
                val title = e.optString("title").ifBlank { "Video ${i + 1}" }
                val unavailable = title.startsWith("[Private") || title.startsWith("[Deleted")
                list.add(
                    PlaylistEntry(url, title, pickThumb(e), e.optLong("duration", 0), !unavailable)
                )
            }
            return Fetched(
                true,
                json.optString("title").ifBlank { "Playlist" },
                json.optString("uploader").ifBlank { json.optString("channel") },
                0, null, list
            )
        }
        return Fetched(
            false,
            json.optString("title").ifBlank { "Untitled" },
            json.optString("uploader").ifBlank { json.optString("channel") },
            json.optLong("duration", 0),
            json.optString("thumbnail").ifBlank { pickThumb(json) },
            emptyList()
        )
    }

    private fun pickThumb(e: JSONObject): String? {
        val direct = e.optString("thumbnail")
        if (direct.isNotBlank()) return direct
        val arr = e.optJSONArray("thumbnails") ?: return null
        var fallback: String? = null
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue
            val u = t.optString("url")
            if (u.isBlank()) continue
            fallback = u
            if (t.optInt("width", 0) >= 300) return u
        }
        return fallback
    }

    private fun showFetched(info: Fetched) {
        if (info.isPlaylist) {
            previewCard.visibility = View.GONE
            playlistCard.visibility = View.VISIBLE
            playlistTitle.text = info.title
            val n = info.entries.size
            playlistMeta.text = listOf(info.uploader, "$n videos").filter { it.isNotBlank() }
                .joinToString("  -  ")
            playlistAdapter.entries = info.entries
            updateSelection()
            setStatus("Select the videos you want, then tap Download")
        } else {
            playlistCard.visibility = View.GONE
            previewCard.visibility = View.VISIBLE
            titleText.text = info.title
            metaText.text = info.uploader
            durationBadge.text = Fmt.duration(info.duration)
            durationBadge.visibility = if (info.duration > 0) View.VISIBLE else View.GONE
            ThumbLoader.load(thumbView, info.thumb)
            setStatus("Ready to download")
        }
        refreshButtons()
    }

    private fun clearFetched() {
        fetched = null
        fetchedUrl = ""
        previewCard.visibility = View.GONE
        playlistCard.visibility = View.GONE
        refreshButtons()
    }

    private fun updateSelection() {
        val total = playlistAdapter.entries.size
        val sel = playlistAdapter.selectedCount()
        selectedCount.text = "$sel selected"
        selectAllBox.isChecked = total > 0 && sel == total
        refreshButtons()
    }

    // ---------- start download(s) ----------

    private fun onDownloadClick() {
        if (!engineReady) return
        val audioOnly = modeToggle.checkedButtonId == R.id.btnAudio
        val height = heights[qualityGroup.checkedChipId]
        val f = fetched

        val list: List<NewDownload> = if (f != null && f.isPlaylist) {
            f.entries.filter { it.checked }.map { NewDownload(it.url, it.title, it.thumb) }
        } else {
            val url = currentUrl() ?: return
            listOf(NewDownload(url, f?.title ?: url, f?.thumb))
        }
        if (list.isEmpty()) {
            Toast.makeText(this, "Select at least one video", Toast.LENGTH_SHORT).show()
            return
        }

        DownloadManager.enqueue(list, audioOnly, height)
        val msg = if (list.size == 1) "Added to downloads" else "Added ${list.size} videos to downloads"
        Snackbar.make(rootLayout, msg, Snackbar.LENGTH_LONG)
            .setAnchorView(bottomNav)
            .setAction("View") { showTab(true) }
            .show()
    }

    // ---------- Telegram join popup ----------

    /**
     * Shown on first launch, then again 24h after the user last tapped "Join".
     * No close / cancel / back: the only way out is the Join button, which opens Telegram
     * and removes the popup (whether or not the user actually joins).
     */
    private fun maybeShowJoinDialog() {
        if (joinDialog?.isShowing == true) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong(KEY_JOIN_TAP, 0L)
        val diff = System.currentTimeMillis() - last
        if (last != 0L && diff in 0 until JOIN_GAP_MS) return

        val view = layoutInflater.inflate(R.layout.dialog_join, null)
        val dialog = MaterialAlertDialogBuilder(this)
            .setView(view)
            .setCancelable(false)
            .create()
        dialog.setCanceledOnTouchOutside(false)
        view.findViewById<MaterialButton>(R.id.joinBtn).setOnClickListener {
            prefs.edit().putLong(KEY_JOIN_TAP, System.currentTimeMillis()).apply()
            dialog.dismiss()
            openTelegram()
        }
        joinDialog = dialog
        dialog.show()
    }

    private fun openTelegram() {
        val uri = Uri.parse(TELEGRAM_URL)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("org.telegram.messenger"))
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (e2: Exception) {
                Toast.makeText(this, "Can't open Telegram link", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- ui helpers ----------

    private fun setStatus(text: String) {
        runOnUiThread { statusText.text = text }
    }

    private fun setBusy(b: Boolean) {
        busy = b
        runOnUiThread { refreshButtons() }
    }

    private fun refreshButtons() {
        val f = fetched
        val isPlaylist = f != null && f.isPlaylist
        val sel = if (isPlaylist) playlistAdapter.selectedCount() else 0

        fetchBtn.isEnabled = !busy
        updateBtn.isEnabled = !busy
        downloadBtn.isEnabled = !busy && (!isPlaylist || sel > 0)
        downloadBtn.text = when {
            isPlaylist && sel == 1 -> "Download 1 video"
            isPlaylist -> "Download $sel videos"
            else -> "Download"
        }
    }
}
