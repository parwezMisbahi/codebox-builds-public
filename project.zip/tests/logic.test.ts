import test from "node:test";
import assert from "node:assert/strict";
import { hitTest, pickLayer, exportSize, fitScale, keepInside } from "../src/editor/geometry";
import { createHistory, commit, commitFrom, undo, redo, replace } from "../src/editor/history";
import type { TextLayer } from "../src/editor/types";

const mk = (o: Partial<TextLayer> = {}): TextLayer => ({
  id: "a", type: "text", text: "x", fontFamily: "f", fontSize: 40, color: "#000", strokeColor: "#fff",
  strokeWidth: 0, shadow: false, align: "center", width: 200, x: 500, y: 500, rotation: 0, scale: 1, ...o,
});

test("hit test inside and outside, unrotated", () => {
  const l = mk();
  assert.equal(hitTest(l, { w: 200, h: 100 }, 500, 500), true);
  assert.equal(hitTest(l, { w: 200, h: 100 }, 599, 549), true);
  assert.equal(hitTest(l, { w: 200, h: 100 }, 601, 500), false);
});

test("hit test respects rotation by 90 degrees", () => {
  const l = mk({ rotation: Math.PI / 2 });
  // a 200x100 box rotated 90deg covers x in [450,550], y in [400,600]
  assert.equal(hitTest(l, { w: 200, h: 100 }, 500, 590), true);
  assert.equal(hitTest(l, { w: 200, h: 100 }, 590, 500), false);
});

test("hit test respects scale", () => {
  const l = mk({ scale: 2 });
  assert.equal(hitTest(l, { w: 200, h: 100 }, 690, 500), true);
  assert.equal(hitTest(l, { w: 200, h: 100 }, 710, 500), false);
});

test("pickLayer returns the topmost", () => {
  const a = mk({ id: "a" });
  const b = mk({ id: "b" });
  const sizes = { a: { w: 200, h: 100 }, b: { w: 200, h: 100 } };
  assert.equal(pickLayer([a, b], sizes, 500, 500, 0), "b");
  assert.equal(pickLayer([a, b], sizes, 10, 10, 0), null);
});

test("export size caps the long edge and keeps aspect", () => {
  assert.deepEqual(exportSize(1080, 1920, 4096), { w: 1080, h: 1920 });
  assert.deepEqual(exportSize(8000, 4000, 4000), { w: 4000, h: 2000 });
});

test("fitScale and keepInside", () => {
  assert.equal(fitScale({ w: 1000, h: 2000 }, { w: 500, h: 500 }), 0.25);
  assert.deepEqual(keepInside(-50, 5000, 1000, 1000), { x: 0, y: 1000 });
});

test("history: undo, redo, new commit clears redo, limit", () => {
  let h = createHistory(0);
  h = commit(h, 1); h = commit(h, 2);
  h = undo(h); assert.equal(h.present, 1);
  h = redo(h); assert.equal(h.present, 2);
  h = undo(h); h = commit(h, 9); assert.equal(h.future.length, 0);
  let g = createHistory(0);
  for (let i = 1; i <= 60; i++) g = commit(g, i, 50);
  assert.equal(g.past.length, 50);
  g = replace(g, 999); assert.equal(g.past.length, 50); assert.equal(g.present, 999);
});

test("a drag becomes exactly one undo step", () => {
  let h = createHistory(10);
  const base = h.present;
  h = replace(h, 11); h = replace(h, 12); h = replace(h, 13);
  h = commitFrom(h, base);
  assert.equal(h.present, 13);
  h = undo(h);
  assert.equal(h.present, 10);
});
